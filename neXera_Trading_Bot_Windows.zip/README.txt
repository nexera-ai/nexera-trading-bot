neXera Trading Platform - Windows Executable
===========================================

This folder contains the pre-built Windows executable (.exe) file for the neXera Trading Platform.

Quick Start:
1. Extract all files to a folder on your Windows computer
2. Double-click on "neXera_Trading_Bot.exe" to launch the application
3. The web interface will open automatically in your browser

The application runs in Paper Trading mode by default, so no real funds are at risk.

Important Notes:
- To use live trading, you will need to enter your exchange API keys
- For security, API keys should have "Trade" permission but NOT "Withdraw" permission
- All data is stored locally on your computer

For assistance, please contact support.

========================================
neXera Trading Platform v1.0.0
Copyright © 2025