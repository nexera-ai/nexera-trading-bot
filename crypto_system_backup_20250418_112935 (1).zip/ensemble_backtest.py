"""
Ensemble Strategy Backtesting Module

This module extends the regular backtesting engine to support testing
ensemble strategies and comparing their performance against individual
component strategies.

Key features:
- Backtest ensemble strategies against historical data
- Compare ensemble performance against component strategies
- Generate visualizations showing component vs ensemble decisions
- Analyze which strategies contributed most to successful trades
- Support dynamic weight changes during backtest for auto-rotation simulation

Usage:
    backtest = EnsembleBacktester(ensemble_name="conservative_blend")
    results = backtest.run_from_csv("btc_usdt_1h.csv")
    metrics = backtest.get_performance_metrics()
    
    # Compare with component strategies
    comparison = backtest.compare_with_components()
    
    # Run with weight changes over time (for auto-rotation)
    results = backtest.run_backtest_with_weight_changes(
        symbol="BTC/USDT",
        timeframe="1h",
        start_date=datetime(2023, 1, 1),
        end_date=datetime(2023, 1, 31),
        weight_changes=[
            {'timestamp': '2023-01-10T00:00:00', 'weights': {'dip_buyer': 0.4, 'mean_reversion': 0.3, 'breakout': 0.3}},
            {'timestamp': '2023-01-20T00:00:00', 'weights': {'dip_buyer': 0.3, 'mean_reversion': 0.5, 'breakout': 0.2}}
        ]
    )
"""
import os
import logging
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
from typing import Dict, List, Optional, Union, Any, Tuple
import matplotlib.pyplot as plt
import plotly.graph_objects as go
import plotly.io as pio
from plotly.subplots import make_subplots

from backtest import Backtester, load_csv_data
from ensemble_engine import get_active_ensemble, EnsembleStrategy, SignalType
from strategies import get_strategy
from config import Config
from chart_utils import generate_ohlc_chart, generate_performance_chart

logger = logging.getLogger(__name__)

class EnsembleBacktester(Backtester):
    """
    Backtesting engine specifically designed for ensemble strategies.
    
    This extends the regular Backtester to provide additional functionality
    for ensemble strategies including component strategy comparison and
    support for simulating weight changes during backtest (for auto-rotation).
    """
    
    def __init__(self, ensemble_name=None, ensemble_instance=None, params=None, initial_balance=1000.0):
        """
        Initialize the ensemble backtester.
        
        Args:
            ensemble_name (str, optional): Name of the ensemble to backtest
            ensemble_instance (EnsembleStrategy, optional): An existing ensemble strategy instance
            params (dict, optional): Additional parameters to apply
            initial_balance (float, optional): Initial balance in USDT for the backtest
        """
        self.ensemble_name = ensemble_name
        self.ensemble_instance = ensemble_instance
        self.params = params or {}
        self.initial_balance = initial_balance
        self.current_balance = initial_balance
        self.trades = []
        self.open_positions = {}
        self.equity_curve = []
        self.current_time = None
        self.results = None
        self.component_results = {}  # Results for individual component strategies
        
        # Track signal history for visualization
        self.signal_history = []
        
        # Initialize the ensemble strategy
        self.strategy = self._load_ensemble()
        
    def _load_ensemble(self):
        """
        Load the ensemble strategy by name or instance.
        
        Returns:
            EnsembleStrategy: The loaded ensemble strategy
        """
        if self.ensemble_instance is not None:
            return self.ensemble_instance
        
        if self.ensemble_name is not None:
            # Get the ensemble by name
            ensemble = get_active_ensemble(self.ensemble_name)
            if ensemble is None:
                raise ValueError(f"Ensemble strategy '{self.ensemble_name}' not found")
            return ensemble
        
        # If we get here, no ensemble was specified
        raise ValueError("Must provide either ensemble_name or ensemble_instance")
    
    def run(self, ohlcv_data, symbol="BTC/USDT", timeframe="1h"):
        """
        Run the ensemble backtest on provided OHLCV data.
        
        Args:
            ohlcv_data (list or pd.DataFrame): OHLCV data in format [timestamp, open, high, low, close, volume]
            symbol (str, optional): Trading pair symbol
            timeframe (str, optional): Timeframe of the data
            
        Returns:
            dict: Backtest results
        """
        # Clear signal history
        self.signal_history = []
        
        # Run the regular backtest
        results = super().run(ohlcv_data, symbol, timeframe)
        
        # Return the results
        return results
    
    def _check_entries(self, candle, historical_data):
        """
        Check for entry signals using the ensemble strategy.
        
        This override adds ensemble-specific signal tracking.
        
        Args:
            candle (dict): Current candle data
            historical_data (pd.DataFrame): Historical OHLCV data up to current candle
        """
        # Get signal from ensemble strategy
        signal_result = self.strategy.check_for_signal(historical_data)
        
        # Record signal and component strategy decisions
        signal_record = {
            'timestamp': candle['timestamp'],
            'price': candle['close'],
            'ensemble_signal': signal_result.get('signal', SignalType.UNKNOWN),
            'confidence': signal_result.get('confidence', 0.0),
            'component_signals': signal_result.get('strategy_signals', {}),
            'reasoning': signal_result.get('reasoning', ''),
            'weighted_votes': signal_result.get('weighted_votes', {})
        }
        self.signal_history.append(signal_record)
        
        # Process entry if signal type is BUY
        if isinstance(signal_result, dict) and signal_result.get('signal') == SignalType.BUY:
            # Calculate position size (use a fixed percentage of balance)
            position_size_usd = self.current_balance * 0.1  # 10% of balance per trade
            
            if position_size_usd < 10:  # Minimum position size
                return
            
            # Calculate quantity based on current price
            entry_price = candle['close']
            quantity = position_size_usd / entry_price
            
            # Calculate take profit and stop loss prices
            take_profit_price = entry_price * (1 + self.take_profit_pct / 100)
            stop_loss_price = entry_price * (1 - self.stop_loss_pct / 100)
            
            # Generate a unique ID for the position
            position_id = f"{self.symbol}_{len(self.trades)}"
            
            # Record the position
            position = {
                'id': position_id,
                'symbol': self.symbol,
                'entry_time': candle['timestamp'],
                'entry_price': entry_price,
                'quantity': quantity,
                'position_size': position_size_usd,
                'take_profit_price': take_profit_price,
                'stop_loss_price': stop_loss_price,
                'current_price': entry_price,
                'last_update_time': candle['timestamp'],
                'signal_data': signal_result,  # Store the detailed signal data
                'historical_data': historical_data  # Store historical data for exit decision
            }
            
            # Add to open positions
            self.open_positions[position_id] = position
            
            # Update balance
            self.current_balance -= position_size_usd
            
            # Log entry
            logger.info(f"ENTRY: {candle['timestamp']} | {self.symbol} | Price: {entry_price:.2f} | Qty: {quantity:.6f} | Size: ${position_size_usd:.2f}")
    
    def compare_with_components(self):
        """
        Run individual backtest for each component strategy and compare results.
        
        Returns:
            dict: Comparison results
        """
        if not hasattr(self.strategy, 'strategy_names'):
            raise ValueError("Cannot compare with components - not an ensemble strategy")
        
        # Save original data for reuse
        ohlcv_df = None
        if hasattr(self, '_df') and self._df is not None:
            ohlcv_df = self._df.copy()
        else:
            # Try to reconstruct from equity curve timestamps and last known data
            timestamps = [point['timestamp'] for point in self.equity_curve]
            if timestamps and hasattr(self, 'last_data'):
                # Filter last_data to only include timestamps in the backtest
                ohlcv_df = self.last_data[self.last_data['timestamp'].isin(timestamps)]
        
        if ohlcv_df is None:
            raise ValueError("No historical data available for component comparison")
        
        # Initialize results for component strategies
        component_results = {}
        
        # Run backtest for each component strategy
        for strategy_name in self.strategy.strategy_names:
            logger.info(f"Running backtest for component strategy: {strategy_name}")
            try:
                # Create a regular backtester with this strategy
                backtester = Backtester(
                    strategy_name=strategy_name,
                    params=self.params,  # Pass the same params
                    initial_balance=self.initial_balance
                )
                
                # Run the backtest with the same data
                result = backtester.run(ohlcv_df, self.symbol, self.timeframe)
                
                # Store the results
                component_results[strategy_name] = {
                    'metrics': result,
                    'trades': backtester.trades.copy(),
                    'equity_curve': backtester.equity_curve.copy()
                }
                
                logger.info(f"Strategy {strategy_name}: {result['total_trades']} trades, {result['win_rate']:.1%} win rate, {result['profit_loss_percent']:.2f}% return")
                
            except Exception as e:
                logger.error(f"Error running backtest for strategy {strategy_name}: {e}")
                component_results[strategy_name] = {
                    'error': str(e),
                    'metrics': {}
                }
        
        # Store the component results
        self.component_results = component_results
        
        # Create comparison summary
        ensemble_metrics = self.results
        
        comparison = {
            'ensemble': {
                'name': self.ensemble_name or 'Custom Ensemble',
                'metrics': ensemble_metrics
            },
            'components': {
                name: results['metrics'] for name, results in component_results.items() if 'metrics' in results
            },
            'summary': self._create_comparison_summary(ensemble_metrics, component_results)
        }
        
        return comparison
    
    def _create_comparison_summary(self, ensemble_metrics, component_results):
        """
        Create a summary comparing ensemble vs component performance.
        
        Args:
            ensemble_metrics (dict): Metrics for the ensemble strategy
            component_results (dict): Results for component strategies
            
        Returns:
            dict: Comparison summary
        """
        # Extract component metrics
        component_metrics = {
            name: results['metrics'] for name, results in component_results.items() 
            if 'metrics' in results and 'error' not in results
        }
        
        if not component_metrics:
            return {'error': 'No valid component metrics available for comparison'}
        
        # Key metrics to compare
        metrics_to_compare = [
            'profit_loss_percent',
            'win_rate',
            'profit_factor',
            'max_drawdown_percent',
            'sharpe_ratio',
            'total_trades'
        ]
        
        # Create summary with comparisons
        summary = {
            'outperforms_components': False,
            'metrics_comparison': {},
            'rank': {},
            'best_strategy': {},
            'improvement_over_avg': {},
            'improvement_over_best': {}
        }
        
        # Compare each metric
        for metric in metrics_to_compare:
            if metric not in ensemble_metrics:
                continue
                
            # Get ensemble value
            ensemble_value = ensemble_metrics[metric]
            
            # Get component values
            component_values = {}
            for name, metrics in component_metrics.items():
                if metric in metrics:
                    component_values[name] = metrics[metric]
            
            if not component_values:
                continue
                
            # Calculate average and best for this metric
            avg_value = sum(component_values.values()) / len(component_values)
            
            # For some metrics, higher is better; for others, lower is better
            if metric in ['max_drawdown_percent']:
                # Lower is better
                best_value = min(component_values.values())
                best_strategy = min(component_values.items(), key=lambda x: x[1])[0]
                is_better = ensemble_value < best_value
                ensemble_rank = sum(1 for v in component_values.values() if v >= ensemble_value) + 1
            else:
                # Higher is better
                best_value = max(component_values.values())
                best_strategy = max(component_values.items(), key=lambda x: x[1])[0]
                is_better = ensemble_value > best_value
                ensemble_rank = sum(1 for v in component_values.values() if v > ensemble_value) + 1
            
            # Calculate improvements
            if metric == 'profit_loss_percent' or metric == 'win_rate' or metric == 'profit_factor':
                if avg_value != 0:
                    pct_over_avg = ((ensemble_value - avg_value) / abs(avg_value)) * 100
                else:
                    pct_over_avg = float('inf') if ensemble_value > 0 else float('-inf') if ensemble_value < 0 else 0
                    
                if best_value != 0:
                    pct_over_best = ((ensemble_value - best_value) / abs(best_value)) * 100
                else:
                    pct_over_best = float('inf') if ensemble_value > 0 else float('-inf') if ensemble_value < 0 else 0
                    
                summary['improvement_over_avg'][metric] = pct_over_avg
                summary['improvement_over_best'][metric] = pct_over_best
            
            # Store comparison data
            summary['metrics_comparison'][metric] = {
                'ensemble_value': ensemble_value,
                'component_values': component_values,
                'avg_value': avg_value,
                'best_value': best_value,
                'ensemble_better_than_best': is_better,
                'ensemble_rank': ensemble_rank,
                'total_rank': len(component_values) + 1  # +1 for ensemble
            }
            
            summary['best_strategy'][metric] = best_strategy
        
        # Determine if ensemble outperforms components overall
        key_performance_metrics = ['profit_loss_percent', 'sharpe_ratio', 'win_rate']
        available_metrics = [m for m in key_performance_metrics if m in summary['metrics_comparison']]
        
        if available_metrics:
            # Count how many metrics where ensemble is better than the best component
            outperformance_count = sum(
                1 for m in available_metrics 
                if summary['metrics_comparison'][m]['ensemble_better_than_best']
            )
            
            # Ensemble outperforms if it's better on more than half of key metrics
            summary['outperforms_components'] = outperformance_count > len(available_metrics) / 2
        
        return summary
    
    def generate_strategy_contribution_chart(self, height=500):
        """
        Generate a chart showing the contribution of each strategy to ensemble decisions.
        
        Args:
            height (int, optional): Height of the chart in pixels
            
        Returns:
            str: JSON representation of the chart
        """
        if not self.signal_history:
            return None
            
        # Extract data points
        timestamps = [record['timestamp'] for record in self.signal_history]
        prices = [record['price'] for record in self.signal_history]
        
        # Create subplots - price chart and strategy signals
        fig = make_subplots(
            rows=2, 
            cols=1, 
            shared_xaxes=True,
            vertical_spacing=0.05,
            row_heights=[0.7, 0.3],
            subplot_titles=("Price", "Strategy Signals")
        )
        
        # Add price line
        fig.add_trace(
            go.Scatter(
                x=timestamps, 
                y=prices,
                mode='lines',
                name='Price',
                line=dict(color='rgba(156, 165, 196, 1)', width=1.5)
            ),
            row=1, col=1
        )
        
        # Add buy signals from ensemble
        buy_timestamps = [record['timestamp'] for record in self.signal_history 
                         if record['ensemble_signal'] == SignalType.BUY]
        buy_prices = [record['price'] for record in self.signal_history 
                     if record['ensemble_signal'] == SignalType.BUY]
        
        if buy_timestamps:
            fig.add_trace(
                go.Scatter(
                    x=buy_timestamps, 
                    y=buy_prices,
                    mode='markers',
                    name='Ensemble Buy Signal',
                    marker=dict(color='rgba(0, 255, 0, 0.8)', size=12, symbol='triangle-up')
                ),
                row=1, col=1
            )
        
        # Add sell signals from ensemble
        sell_timestamps = [record['timestamp'] for record in self.signal_history 
                          if record['ensemble_signal'] == SignalType.SELL]
        sell_prices = [record['price'] for record in self.signal_history 
                      if record['ensemble_signal'] == SignalType.SELL]
        
        if sell_timestamps:
            fig.add_trace(
                go.Scatter(
                    x=sell_timestamps, 
                    y=sell_prices,
                    mode='markers',
                    name='Ensemble Sell Signal',
                    marker=dict(color='rgba(255, 0, 0, 0.8)', size=12, symbol='triangle-down')
                ),
                row=1, col=1
            )
        
        # Extract individual strategy signals
        if self.signal_history and 'component_signals' in self.signal_history[0]:
            # Get unique strategy names from first record
            strategy_names = list(self.signal_history[0]['component_signals'].keys())
            
            # Plot signals for each strategy
            for i, strategy_name in enumerate(strategy_names):
                # Create a trace for each strategy's contribution to the signals
                strategy_signals = []
                
                for record in self.signal_history:
                    if strategy_name in record['component_signals']:
                        signal_info = record['component_signals'][strategy_name]
                        signal_type = signal_info.get('signal', SignalType.UNKNOWN)
                        
                        # Convert enum to numeric for chart (1=buy, -1=sell, 0=hold)
                        if signal_type == SignalType.BUY:
                            signal_value = 1
                        elif signal_type == SignalType.SELL:
                            signal_value = -1
                        else:
                            signal_value = 0
                            
                        strategy_signals.append(signal_value)
                    else:
                        strategy_signals.append(0)
                        
                # Normalize values for display
                offset = i * 0.2
                normalized_signals = [val + offset for val in strategy_signals]
                
                # Add trace
                fig.add_trace(
                    go.Scatter(
                        x=timestamps,
                        y=normalized_signals,
                        mode='lines+markers',
                        name=f"{strategy_name} Signals",
                        marker=dict(size=6)
                    ),
                    row=2, col=1
                )
        
        # Update layout
        fig.update_layout(
            height=height,
            title_text=f"Ensemble Strategy Signal Contributions - {self.symbol}",
            showlegend=True,
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            ),
            xaxis_rangeslider_visible=False
        )
        
        # Add trade entries to chart
        for trade in self.trades:
            # Entry marker
            fig.add_trace(
                go.Scatter(
                    x=[trade['entry_time']],
                    y=[trade['entry_price']],
                    mode='markers',
                    name='Trade Entry',
                    marker=dict(color='blue', size=10, symbol='circle'),
                    showlegend=False
                ),
                row=1, col=1
            )
            
            # Exit marker
            fig.add_trace(
                go.Scatter(
                    x=[trade['exit_time']],
                    y=[trade['exit_price']],
                    mode='markers',
                    name='Trade Exit',
                    marker=dict(color='purple', size=10, symbol='circle'),
                    showlegend=False
                ),
                row=1, col=1
            )
            
            # Line connecting entry and exit
            fig.add_trace(
                go.Scatter(
                    x=[trade['entry_time'], trade['exit_time']],
                    y=[trade['entry_price'], trade['exit_price']],
                    mode='lines',
                    line=dict(
                        color='green' if trade['profit_pct'] > 0 else 'red',
                        width=1.5,
                        dash='dot'
                    ),
                    showlegend=False
                ),
                row=1, col=1
            )
        
        # Format y-axis for signal pane
        fig.update_yaxes(
            title_text="Signals",
            tickvals=[-1, 0, 1],
            ticktext=["Sell", "Hold", "Buy"],
            row=2, col=1
        )
        
        return pio.to_json(fig)
    
    def generate_component_comparison_chart(self, height=500):
        """
        Generate a chart comparing equity curves of the ensemble vs component strategies.
        
        Args:
            height (int, optional): Height of the chart in pixels
            
        Returns:
            str: JSON representation of the chart
        """
        if not self.component_results:
            logger.warning("No component results available. Run compare_with_components() first.")
            return None
            
        # Create figure
        fig = go.Figure()
        
        # Add ensemble equity curve
        ensemble_timestamps = [point['timestamp'] for point in self.equity_curve]
        ensemble_equity = [point['equity'] for point in self.equity_curve]
        
        fig.add_trace(
            go.Scatter(
                x=ensemble_timestamps,
                y=ensemble_equity,
                mode='lines',
                name=f"Ensemble ({self.ensemble_name or 'Custom'})",
                line=dict(color='rgba(0, 0, 255, 0.8)', width=3)
            )
        )
        
        # Add component equity curves
        for strategy_name, results in self.component_results.items():
            if 'equity_curve' in results and results['equity_curve']:
                timestamps = [point['timestamp'] for point in results['equity_curve']]
                equity = [point['equity'] for point in results['equity_curve']]
                
                fig.add_trace(
                    go.Scatter(
                        x=timestamps,
                        y=equity,
                        mode='lines',
                        name=strategy_name,
                        line=dict(width=1.5)
                    )
                )
        
        # Update layout
        fig.update_layout(
            height=height,
            title_text=f"Equity Curve Comparison - {self.symbol}",
            xaxis_title="Date",
            yaxis_title="Account Value (USDT)",
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            )
        )
        
        return pio.to_json(fig)


    def get_default_weights(self):
        """
        Get the default weights used by the ensemble strategy.
        
        Returns:
            dict: Default strategy weights
        """
        if hasattr(self.strategy, 'strategy_weights'):
            return self.strategy.strategy_weights
        
        # If no explicit weights, create equal weights
        if hasattr(self.strategy, 'strategy_names'):
            strategy_count = len(self.strategy.strategy_names)
            if strategy_count > 0:
                equal_weight = 1.0 / strategy_count
                return {name: equal_weight for name in self.strategy.strategy_names}
                
        return {}
    
    def run_backtest(self, 
                   symbol="BTC/USDT", 
                   timeframe="1h", 
                   start_date=None, 
                   end_date=None, 
                   weights=None,
                   initial_balance=None,
                   commission_pct=0.1,
                   continue_previous=False):
        """
        Run an ensemble backtest for a specified date range.
        
        Args:
            symbol (str): Trading pair symbol
            timeframe (str): Timeframe for data (e.g., "1h", "4h", "1d")
            start_date (datetime, optional): Start date for backtest
            end_date (datetime, optional): End date for backtest
            weights (dict, optional): Custom weights for strategies
            initial_balance (float, optional): Initial account balance
            commission_pct (float, optional): Commission percentage
            continue_previous (bool, optional): Whether to continue from previous backtest
            
        Returns:
            dict: Backtest results
        """
        from utils import get_historical_ohlcv
        
        # If no dates specified, use recent history
        if start_date is None:
            end_date = datetime.now() if end_date is None else end_date
            start_date = end_date - timedelta(days=30)
        elif end_date is None:
            end_date = datetime.now()
            
        # Log the date range
        logger.info(f"Running ensemble backtest for {symbol} from {start_date} to {end_date}")
        
        # Get historical data
        ohlcv_data = get_historical_ohlcv(symbol, timeframe, start_date, end_date)
        
        if ohlcv_data is None or len(ohlcv_data) < 10:
            return {"error": "Insufficient historical data available"}
            
        # Set initial balance if provided
        if initial_balance is not None and not continue_previous:
            self.initial_balance = initial_balance
            self.current_balance = initial_balance
            
        # Apply custom weights if provided
        if weights is not None and hasattr(self.strategy, 'set_weights'):
            self.strategy.set_weights(weights)
            logger.info(f"Applied custom weights: {weights}")
            
        # Reset state if not continuing
        if not continue_previous:
            self.trades = []
            self.open_positions = {}
            self.equity_curve = []
            self.signal_history = []
            
        # Run the backtest
        results = self.run(ohlcv_data, symbol, timeframe)
        
        return results
    
    def run_backtest_with_weight_changes(self,
                                      symbol="BTC/USDT",
                                      timeframe="1h",
                                      start_date=None,
                                      end_date=None,
                                      weight_changes=None,
                                      initial_weights=None,
                                      initial_balance=1000.0,
                                      commission_pct=0.1):
        """
        Run a backtest with strategy weight changes at specified times.
        
        This method is used to simulate auto-rotation by changing weights
        at specific timestamps during the backtest.
        
        Args:
            symbol (str): Trading pair symbol
            timeframe (str): Timeframe for data
            start_date (datetime, optional): Start date for backtest
            end_date (datetime, optional): End date for backtest
            weight_changes (list): List of weight change events
                [{'timestamp': datetime, 'weights': {strat1: w1, strat2: w2, ...}}, ...]
            initial_weights (dict, optional): Starting weights for strategies
            initial_balance (float, optional): Initial account balance
            commission_pct (float, optional): Commission percentage
            
        Returns:
            dict: Backtest results
        """
        from utils import get_historical_ohlcv
        
        # If no dates specified, use recent history
        if start_date is None:
            end_date = datetime.now() if end_date is None else end_date
            start_date = end_date - timedelta(days=30)
        elif end_date is None:
            end_date = datetime.now()
            
        # Validate weight changes
        if weight_changes is None or not isinstance(weight_changes, list):
            weight_changes = []
            
        # Convert string timestamps to datetime if needed
        for i, change in enumerate(weight_changes):
            if isinstance(change['timestamp'], str):
                weight_changes[i]['timestamp'] = datetime.fromisoformat(change['timestamp'])
                
        # Sort weight changes by timestamp
        weight_changes.sort(key=lambda x: x['timestamp'])
        
        # Reset state
        self.trades = []
        self.open_positions = {}
        self.equity_curve = []
        self.signal_history = []
        self.current_balance = initial_balance
        self.initial_balance = initial_balance
        
        # Get historical data for the full period
        ohlcv_data = get_historical_ohlcv(symbol, timeframe, start_date, end_date)
        
        if ohlcv_data is None or len(ohlcv_data) < 10:
            return {"error": "Insufficient historical data available"}
            
        # Convert to DataFrame for easier time-based splitting
        df = pd.DataFrame(ohlcv_data)
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df = df.sort_values('timestamp')
        
        # Apply initial weights if provided
        current_weights = initial_weights
        if current_weights is not None and hasattr(self.strategy, 'set_weights'):
            self.strategy.set_weights(current_weights)
            logger.info(f"Applied initial weights: {current_weights}")
            
        # If no weight changes, run a single backtest
        if not weight_changes:
            return self.run(df, symbol, timeframe)
            
        # Divide the backtest into segments based on weight change times
        segments = []
        
        # Add the initial segment (start to first weight change)
        first_change = weight_changes[0]['timestamp']
        initial_segment = df[df['timestamp'] < first_change]
        if not initial_segment.empty:
            segments.append({
                'data': initial_segment,
                'weights': current_weights
            })
            
        # Add segments between weight changes
        for i in range(len(weight_changes)):
            change = weight_changes[i]
            current_change_time = change['timestamp']
            current_weights = change['weights']
            
            # Determine end time for this segment
            if i < len(weight_changes) - 1:
                next_change_time = weight_changes[i + 1]['timestamp']
                segment_data = df[(df['timestamp'] >= current_change_time) & 
                                 (df['timestamp'] < next_change_time)]
            else:
                # Last segment goes to the end
                segment_data = df[df['timestamp'] >= current_change_time]
                
            if not segment_data.empty:
                segments.append({
                    'data': segment_data,
                    'weights': current_weights
                })
                
        # Run backtest for each segment, continuing from previous segment
        logger.info(f"Running backtest with {len(segments)} weight change segments")
        
        for i, segment in enumerate(segments):
            segment_df = segment['data']
            segment_weights = segment['weights']
            
            if segment_df.empty:
                continue
                
            # Apply the weights for this segment
            if segment_weights is not None and hasattr(self.strategy, 'set_weights'):
                self.strategy.set_weights(segment_weights)
                
            # Log the weight change
            if i > 0:
                logger.info(f"Weight change at {segment_df['timestamp'].iloc[0]}: {segment_weights}")
                
            # Run backtest for this segment
            self.run(segment_df, symbol, timeframe)
            
        # Process final performance metrics
        metrics = {
            'total_trades': len(self.trades),
            'win_count': sum(1 for trade in self.trades if trade.get('profit_loss', 0) > 0),
            'loss_count': sum(1 for trade in self.trades if trade.get('profit_loss', 0) <= 0),
            'total_profit_loss': sum(trade.get('profit_loss', 0) for trade in self.trades),
            'profit_loss_percent': ((self.current_balance / self.initial_balance) - 1) * 100,
            'final_balance': self.current_balance
        }
        
        # Calculate win rate
        if metrics['total_trades'] > 0:
            metrics['win_rate'] = metrics['win_count'] / metrics['total_trades']
        else:
            metrics['win_rate'] = 0.0
            
        # Store metrics in results
        self.results = metrics
        
        return self.get_results()
        
    def get_results(self):
        """
        Get the results of the ensemble backtest.
        
        Returns:
            dict: Complete backtest results
        """
        return self.results

def run_ensemble_backtest(ensemble_name, symbol="BTC/USDT", timeframe="1h", days=30):
    """
    Convenience function to run an ensemble backtest with sample data.
    
    Args:
        ensemble_name (str): Name of the ensemble to backtest
        symbol (str, optional): Trading pair symbol
        timeframe (str, optional): Timeframe to use
        days (int, optional): Number of days of historical data to use
        
    Returns:
        dict: Results of the backtest
    """
    from utils import generate_historical_data
    
    # Generate historical data for testing
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    historical_data = generate_historical_data(symbol, timeframe, start_date, end_date)
    
    # Create and run backtester
    backtest = EnsembleBacktester(ensemble_name=ensemble_name)
    results = backtest.run(historical_data, symbol, timeframe)
    
    # Compare with components
    component_comparison = backtest.compare_with_components()
    
    # Return combined results
    return {
        'ensemble_results': results,
        'component_comparison': component_comparison,
        'backtest_instance': backtest
    }