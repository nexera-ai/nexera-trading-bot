#!/usr/bin/env python3
"""
Alert Notifier Module

This module handles sending notifications via various channels (email, SMS)
for risk management events and other critical alerts in the trading system.
"""

import os
import logging
from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Union, Any

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class AlertChannel(Enum):
    """Available notification channels"""
    EMAIL = "email"
    SMS = "sms"
    WEB = "web"  # For in-app notifications

class AlertPriority(Enum):
    """Alert priority levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class AlertType(Enum):
    """Types of alerts that can be sent"""
    RISK_LEVEL_CHANGE = "risk_level_change"
    RISK_OFF_ACTIVATED = "risk_off_activated"
    RISK_OFF_DEACTIVATED = "risk_off_deactivated"
    DEFENSIVE_ACTION = "defensive_action"
    MANUAL_OVERRIDE = "manual_override"
    EMERGENCY_STOP = "emergency_stop"
    RECOVERY_ATTEMPT = "recovery_attempt"
    PERFORMANCE_THRESHOLD = "performance_threshold"

class AlertNotifier:
    """
    Handles sending notifications through different channels
    """
    def __init__(self):
        """Initialize the alert notifier with configuration"""
        # Default alert configuration (can be overridden by user settings)
        self.alert_config = {
            AlertType.RISK_LEVEL_CHANGE.value: {
                "channels": [AlertChannel.EMAIL.value, AlertChannel.WEB.value],
                "min_priority": AlertPriority.MEDIUM.value,
                "enabled": True
            },
            AlertType.RISK_OFF_ACTIVATED.value: {
                "channels": [AlertChannel.EMAIL.value, AlertChannel.SMS.value, AlertChannel.WEB.value],
                "min_priority": AlertPriority.HIGH.value,
                "enabled": True
            },
            AlertType.RISK_OFF_DEACTIVATED.value: {
                "channels": [AlertChannel.EMAIL.value, AlertChannel.WEB.value],
                "min_priority": AlertPriority.MEDIUM.value,
                "enabled": True
            },
            AlertType.DEFENSIVE_ACTION.value: {
                "channels": [AlertChannel.EMAIL.value, AlertChannel.WEB.value],
                "min_priority": AlertPriority.MEDIUM.value,
                "enabled": True
            },
            AlertType.MANUAL_OVERRIDE.value: {
                "channels": [AlertChannel.EMAIL.value, AlertChannel.SMS.value, AlertChannel.WEB.value],
                "min_priority": AlertPriority.HIGH.value,
                "enabled": True
            },
            AlertType.EMERGENCY_STOP.value: {
                "channels": [AlertChannel.EMAIL.value, AlertChannel.SMS.value, AlertChannel.WEB.value],
                "min_priority": AlertPriority.CRITICAL.value,
                "enabled": True
            },
            AlertType.RECOVERY_ATTEMPT.value: {
                "channels": [AlertChannel.EMAIL.value, AlertChannel.WEB.value],
                "min_priority": AlertPriority.MEDIUM.value,
                "enabled": True
            },
            AlertType.PERFORMANCE_THRESHOLD.value: {
                "channels": [AlertChannel.EMAIL.value, AlertChannel.WEB.value],
                "min_priority": AlertPriority.MEDIUM.value,
                "enabled": True
            }
        }
        
        # Load channel settings (credentials)
        self.channel_settings = {
            "email": {
                "enabled": os.environ.get("SENDGRID_API_KEY") is not None,
                "from_email": os.environ.get("ALERT_FROM_EMAIL", "crypto-trading-bot@example.com"),
                "to_email": os.environ.get("ALERT_TO_EMAIL", "user@example.com"),
            },
            "sms": {
                "enabled": all([
                    os.environ.get("TWILIO_ACCOUNT_SID") is not None,
                    os.environ.get("TWILIO_AUTH_TOKEN") is not None,
                    os.environ.get("TWILIO_PHONE_NUMBER") is not None
                ]),
                "to_phone": os.environ.get("ALERT_TO_PHONE", "+10000000000"),
            },
            "web": {
                "enabled": True,
                "max_alerts": 100,  # Maximum number of in-app alerts to store
            }
        }
        
        # In-memory alert log (will be persisted to database in a larger implementation)
        self.alert_history = []
        self.max_history = 1000
        
        logger.info("Alert Notifier initialized")
    
    def update_alert_config(self, alert_type: str, settings: Dict[str, Any]) -> bool:
        """
        Update the configuration for a specific alert type
        
        Args:
            alert_type: The type of alert to update
            settings: New settings (channels, min_priority, enabled)
            
        Returns:
            bool: Success status
        """
        if alert_type not in self.alert_config:
            logger.error(f"Unknown alert type: {alert_type}")
            return False
        
        # Update only the provided settings
        for key, value in settings.items():
            if key in self.alert_config[alert_type]:
                self.alert_config[alert_type][key] = value
        
        logger.info(f"Alert configuration updated for {alert_type}")
        return True
    
    def update_channel_settings(self, channel: str, settings: Dict[str, Any]) -> bool:
        """
        Update the settings for a notification channel
        
        Args:
            channel: The channel to update (email, sms, web)
            settings: New settings
            
        Returns:
            bool: Success status
        """
        if channel not in self.channel_settings:
            logger.error(f"Unknown channel: {channel}")
            return False
        
        # Update only the provided settings
        for key, value in settings.items():
            if key in self.channel_settings[channel]:
                self.channel_settings[channel][key] = value
        
        logger.info(f"Channel settings updated for {channel}")
        return True
    
    def send_alert(self, 
                  alert_type: Union[AlertType, str], 
                  message: str, 
                  details: Optional[Dict[str, Any]] = None,
                  priority: Union[AlertPriority, str] = AlertPriority.MEDIUM,
                  channels: Optional[List[Union[AlertChannel, str]]] = None) -> Dict[str, Any]:
        """
        Send an alert through configured channels
        
        Args:
            alert_type: Type of the alert
            message: Main alert message
            details: Additional context and details for the alert
            priority: Alert priority level
            channels: Override default channels for this specific alert
            
        Returns:
            Dict: Results of the alert delivery attempts
        """
        # Convert enums to string values if needed
        if isinstance(alert_type, AlertType):
            alert_type = alert_type.value
            
        if isinstance(priority, AlertPriority):
            priority = priority.value
        
        # Get alert config
        if alert_type not in self.alert_config:
            logger.warning(f"Unknown alert type '{alert_type}', using default configuration")
            config = {
                "channels": [AlertChannel.EMAIL.value, AlertChannel.WEB.value],
                "min_priority": AlertPriority.MEDIUM.value,
                "enabled": True
            }
        else:
            config = self.alert_config[alert_type]
        
        # Check if this alert type is enabled
        if not config.get("enabled", True):
            logger.info(f"Alert type '{alert_type}' is disabled, skipping")
            return {"status": "skipped", "reason": "alert_type_disabled"}
        
        # Check priority threshold
        priority_levels = {
            AlertPriority.LOW.value: 0,
            AlertPriority.MEDIUM.value: 1,
            AlertPriority.HIGH.value: 2,
            AlertPriority.CRITICAL.value: 3
        }
        
        if priority_levels.get(priority, 0) < priority_levels.get(config.get("min_priority"), 0):
            logger.info(f"Alert priority '{priority}' is below threshold '{config.get('min_priority')}', skipping")
            return {"status": "skipped", "reason": "priority_below_threshold"}
        
        # Determine which channels to use
        if channels is None:
            channels = config.get("channels", [AlertChannel.WEB.value])
        else:
            # Convert enums to string values if needed
            channels = [c.value if isinstance(c, AlertChannel) else c for c in channels]
        
        # Create the alert record
        alert = {
            "id": len(self.alert_history) + 1,
            "timestamp": datetime.now(),
            "type": alert_type,
            "priority": priority,
            "message": message,
            "details": details or {},
            "delivery_status": {}
        }
        
        # Send through each channel
        for channel in channels:
            if channel not in self.channel_settings:
                logger.warning(f"Unknown channel '{channel}', skipping")
                alert["delivery_status"][channel] = "unknown_channel"
                continue
                
            if not self.channel_settings[channel].get("enabled", False):
                logger.info(f"Channel '{channel}' is disabled, skipping")
                alert["delivery_status"][channel] = "channel_disabled"
                continue
            
            try:
                if channel == AlertChannel.EMAIL.value:
                    result = self._send_email_alert(alert)
                elif channel == AlertChannel.SMS.value:
                    result = self._send_sms_alert(alert)
                elif channel == AlertChannel.WEB.value:
                    result = self._store_web_alert(alert)
                else:
                    result = False
                    
                alert["delivery_status"][channel] = "delivered" if result else "failed"
            except Exception as e:
                logger.error(f"Error sending alert via {channel}: {str(e)}")
                alert["delivery_status"][channel] = f"error: {str(e)}"
        
        # Add to history
        self.alert_history.append(alert)
        
        # Trim history if needed
        if len(self.alert_history) > self.max_history:
            self.alert_history = self.alert_history[-self.max_history:]
        
        return {
            "status": "alert_sent",
            "alert_id": alert["id"],
            "delivery_status": alert["delivery_status"]
        }
    
    def _send_email_alert(self, alert: Dict[str, Any]) -> bool:
        """
        Send an alert via email using SendGrid
        
        Args:
            alert: The alert data
            
        Returns:
            bool: Success status
        """
        try:
            # Check for SendGrid API key
            if not os.environ.get("SENDGRID_API_KEY"):
                logger.warning("SendGrid API key not found, cannot send email alert")
                return False
                
            from sendgrid import SendGridAPIClient
            from sendgrid.helpers.mail import Mail, Email, To, Content, Subject
            
            # Get email settings
            from_email = self.channel_settings["email"].get("from_email", "crypto-trading-bot@example.com")
            to_email = self.channel_settings["email"].get("to_email", "user@example.com")
            
            # Create subject with priority prefix
            priority_prefix = {
                AlertPriority.LOW.value: "[INFO]",
                AlertPriority.MEDIUM.value: "[ALERT]",
                AlertPriority.HIGH.value: "[URGENT]",
                AlertPriority.CRITICAL.value: "[CRITICAL]"
            }
            prefix = priority_prefix.get(alert["priority"], "[ALERT]")
            subject = f"{prefix} Crypto Trading Bot: {alert['message']}"
            
            # Format email content
            alert_time = alert["timestamp"].strftime("%Y-%m-%d %H:%M:%S")
            
            content = f"""
            <h2>{prefix} Trading Bot Alert</h2>
            <p><strong>Time:</strong> {alert_time}</p>
            <p><strong>Type:</strong> {alert['type']}</p>
            <p><strong>Message:</strong> {alert['message']}</p>
            
            <h3>Details:</h3>
            <ul>
            """
            
            # Add details if available
            if alert["details"]:
                for key, value in alert["details"].items():
                    content += f"<li><strong>{key}:</strong> {value}</li>"
            else:
                content += "<li>No additional details available</li>"
            
            content += """
            </ul>
            
            <p>This is an automated alert from your Crypto Trading Bot.</p>
            """
            
            # Create the email
            message = Mail(
                from_email=Email(from_email),
                to_emails=To(to_email),
                subject=subject,
                html_content=Content("text/html", content)
            )
            
            # Send the email
            sg = SendGridAPIClient(os.environ.get("SENDGRID_API_KEY"))
            response = sg.send(message)
            
            logger.info(f"Email alert sent: {response.status_code}")
            return response.status_code in (200, 201, 202)
            
        except Exception as e:
            logger.error(f"Error sending email alert: {str(e)}")
            return False
    
    def _send_sms_alert(self, alert: Dict[str, Any]) -> bool:
        """
        Send an alert via SMS using Twilio
        
        Args:
            alert: The alert data
            
        Returns:
            bool: Success status
        """
        try:
            # Check for required Twilio credentials
            if not all([
                os.environ.get("TWILIO_ACCOUNT_SID"),
                os.environ.get("TWILIO_AUTH_TOKEN"),
                os.environ.get("TWILIO_PHONE_NUMBER")
            ]):
                logger.warning("Twilio credentials not found, cannot send SMS alert")
                return False
                
            from twilio.rest import Client
            
            # Get SMS settings
            to_phone = self.channel_settings["sms"].get("to_phone", "+10000000000")
            
            # Create SMS content (shorter for text messages)
            priority_prefix = {
                AlertPriority.LOW.value: "[INFO]",
                AlertPriority.MEDIUM.value: "[ALERT]",
                AlertPriority.HIGH.value: "[URGENT]",
                AlertPriority.CRITICAL.value: "[CRITICAL]"
            }
            prefix = priority_prefix.get(alert["priority"], "[ALERT]")
            
            # Format the message - keeping it concise for SMS
            alert_time = alert["timestamp"].strftime("%H:%M:%S")
            message_body = f"{prefix} {alert_time}: {alert['message']}"
            
            # Add key details if available (limiting to important ones for SMS brevity)
            key_details = []
            if "risk_level" in alert["details"]:
                key_details.append(f"Risk: {alert['details']['risk_level']}")
            if "action_taken" in alert["details"]:
                key_details.append(f"Action: {alert['details']['action_taken']}")
                
            if key_details:
                message_body += " | " + " | ".join(key_details)
            
            # Send the SMS
            client = Client(
                os.environ.get("TWILIO_ACCOUNT_SID"),
                os.environ.get("TWILIO_AUTH_TOKEN")
            )
            
            message = client.messages.create(
                body=message_body,
                from_=os.environ.get("TWILIO_PHONE_NUMBER"),
                to=to_phone
            )
            
            logger.info(f"SMS alert sent: {message.sid}")
            return True
            
        except Exception as e:
            logger.error(f"Error sending SMS alert: {str(e)}")
            return False
    
    def _store_web_alert(self, alert: Dict[str, Any]) -> bool:
        """
        Store an alert for web notification (in-app)
        
        Args:
            alert: The alert data
            
        Returns:
            bool: Success status
        """
        try:
            # For now, just adding to the in-memory history is sufficient
            # In a production system, this would be stored in a database
            logger.info(f"Web alert stored: {alert['id']}")
            return True
            
        except Exception as e:
            logger.error(f"Error storing web alert: {str(e)}")
            return False
    
    def get_recent_alerts(self, limit: int = 20, alert_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get recent alerts from history
        
        Args:
            limit: Maximum number of alerts to return
            alert_type: Filter by alert type
            
        Returns:
            List[Dict[str, Any]]: List of recent alerts
        """
        filtered_alerts = self.alert_history
        
        if alert_type:
            filtered_alerts = [a for a in filtered_alerts if a["type"] == alert_type]
            
        # Return the most recent alerts first
        return sorted(filtered_alerts, key=lambda a: a["timestamp"], reverse=True)[:limit]
    
    def get_alert_by_id(self, alert_id: int) -> Optional[Dict[str, Any]]:
        """
        Get a specific alert by ID
        
        Args:
            alert_id: The ID of the alert to retrieve
            
        Returns:
            Optional[Dict[str, Any]]: The alert data or None if not found
        """
        for alert in self.alert_history:
            if alert["id"] == alert_id:
                return alert
                
        return None
    
    def get_alerts_count_by_priority(self) -> Dict[str, int]:
        """
        Get alert counts by priority level
        
        Returns:
            Dict[str, int]: Count of alerts for each priority level
        """
        counts = {
            AlertPriority.LOW.value: 0,
            AlertPriority.MEDIUM.value: 0,
            AlertPriority.HIGH.value: 0,
            AlertPriority.CRITICAL.value: 0
        }
        
        for alert in self.alert_history:
            priority = alert.get("priority", AlertPriority.MEDIUM.value)
            counts[priority] = counts.get(priority, 0) + 1
            
        return counts
    
    def clear_history(self) -> bool:
        """
        Clear the alert history
        
        Returns:
            bool: Success status
        """
        self.alert_history = []
        logger.info("Alert history cleared")
        return True

# Initialize global alert notifier instance
alert_notifier = AlertNotifier()