"""
Batch Strategy Comparison Module

This module provides functionality to run multiple strategies against the
same dataset and compare their performance side-by-side.
"""

import os
import json
import time
import logging
import numpy as np
import pandas as pd
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns

from backtest import Backtester
from config import Config
from strategies import get_available_strategies

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class BatchComparison:
    """
    Runs multiple trading strategies on the same dataset for comparison.
    
    Attributes:
        strategies (list): List of strategy names to compare
        symbol (str): Trading pair symbol
        timeframe (str): Timeframe for the backtest
        initial_balance (float): Initial balance for the backtest
        start_date (str): Start date for the backtest
        end_date (str): End date for the backtest
        data (pd.DataFrame): OHLCV data for the backtest
        results (dict): Results of the backtests
    """
    
    def __init__(self, strategies=None, symbol="BTC/USDT", timeframe="1h", 
                 initial_balance=1000.0, start_date=None, end_date=None):
        """
        Initialize the BatchComparison object.
        
        Args:
            strategies (list, optional): List of strategy names to compare. 
                                        If None, all available strategies will be used.
            symbol (str, optional): Trading pair symbol
            timeframe (str, optional): Timeframe for the backtest
            initial_balance (float, optional): Initial balance for the backtest
            start_date (str, optional): Start date for the backtest (YYYY-MM-DD)
            end_date (str, optional): End date for the backtest (YYYY-MM-DD)
        """
        self.strategies = strategies or get_available_strategies()
        self.symbol = symbol
        self.timeframe = timeframe
        self.initial_balance = initial_balance
        self.start_date = start_date
        self.end_date = end_date
        self.data = None
        self.results = {}
        
    def load_data(self, csv_path=None):
        """
        Load OHLCV data from either a CSV file or fetch from an exchange.
        
        Args:
            csv_path (str, optional): Path to a CSV file containing OHLCV data
            
        Returns:
            pd.DataFrame: OHLCV data
        """
        if csv_path and os.path.exists(csv_path):
            logger.info(f"Loading data from CSV: {csv_path}")
            self.data = pd.read_csv(csv_path)
            
            # Convert timestamp to datetime if needed
            if 'timestamp' in self.data.columns and not pd.api.types.is_datetime64_any_dtype(self.data['timestamp']):
                self.data['timestamp'] = pd.to_datetime(self.data['timestamp'], unit='ms')
                
        else:
            logger.info(f"Generating sample data for {self.symbol} {self.timeframe}")
            from backtest import load_sample_data
            self.data = pd.DataFrame(load_sample_data(), 
                                   columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            self.data['timestamp'] = pd.to_datetime(self.data['timestamp'], unit='ms')
            
        # Apply date filters if provided
        if self.start_date:
            start_dt = pd.to_datetime(self.start_date)
            self.data = self.data[self.data['timestamp'] >= start_dt]
            
        if self.end_date:
            end_dt = pd.to_datetime(self.end_date)
            self.data = self.data[self.data['timestamp'] <= end_dt]
            
        logger.info(f"Loaded {len(self.data)} candles for {self.symbol} {self.timeframe}")
        return self.data
    
    def run_comparison(self, use_optimal_params=True):
        """
        Run backtests for all strategies and store the results.
        
        Args:
            use_optimal_params (bool, optional): Whether to use optimal parameters for each strategy
            
        Returns:
            dict: Results of the backtests
        """
        if self.data is None:
            self.load_data()
            
        for strategy_name in self.strategies:
            logger.info(f"Running backtest for strategy: {strategy_name}")
            
            params = None
            if use_optimal_params:
                # Try to load optimal parameters if available
                params = self._get_optimal_params(strategy_name)
                if params:
                    logger.info(f"Using optimal parameters for {strategy_name}")
                
            # Run backtest
            backtester = Backtester(strategy_name, params, self.initial_balance)
            results = backtester.run(self.data, symbol=self.symbol, timeframe=self.timeframe)
            
            # Store results
            self.results[strategy_name] = {
                'metrics': backtester.get_performance_metrics(),
                'equity_chart': backtester.generate_equity_chart(height=300),
                'trade_chart': backtester.generate_trade_chart(height=400),
                'trades': backtester.trades,
                'parameters': params or {}
            }
            
        return self.results
    
    def _get_optimal_params(self, strategy_name):
        """
        Get optimal parameters for a strategy from saved optimization results.
        
        Args:
            strategy_name (str): Name of the strategy
            
        Returns:
            dict: Optimal parameters for the strategy, or None if not available
        """
        # Directory for optimization results
        opt_dir = os.path.join('data', 'optimization')
        if not os.path.exists(opt_dir):
            return None
            
        # Try to find the latest optimization result for this strategy
        strategy_files = [f for f in os.listdir(opt_dir) 
                         if f.startswith(f"{strategy_name}_") and f.endswith(".json")]
        
        if not strategy_files:
            return None
            
        # Sort by timestamp (newest first)
        strategy_files.sort(reverse=True)
        latest_file = os.path.join(opt_dir, strategy_files[0])
        
        try:
            with open(latest_file, 'r') as f:
                opt_data = json.load(f)
                
            # Use balanced parameters if available, otherwise fall back to best profit
            if 'best_balanced' in opt_data:
                return {k: v for k, v in opt_data['best_balanced'].items() 
                       if k not in ['total_profit', 'total_return_pct', 'win_rate', 
                                   'total_trades', 'max_drawdown', 'sharpe_ratio', 
                                   'profit_factor', 'balanced_score']}
            elif 'best_profit' in opt_data:
                return {k: v for k, v in opt_data['best_profit'].items() 
                       if k not in ['total_profit', 'total_return_pct', 'win_rate', 
                                   'total_trades', 'max_drawdown', 'sharpe_ratio', 
                                   'profit_factor']}
                
        except Exception as e:
            logger.error(f"Error loading optimization data: {e}")
            
        return None
        
    def generate_comparison_table(self):
        """
        Generate a comparison table of strategy performance metrics.
        
        Returns:
            pd.DataFrame: Comparison table
        """
        if not self.results:
            logger.warning("No results available. Run comparison first.")
            return None
            
        metrics = []
        for strategy_name, result in self.results.items():
            metrics_dict = result['metrics'].copy()
            metrics_dict['strategy'] = strategy_name
            metrics.append(metrics_dict)
            
        comparison_df = pd.DataFrame(metrics)
        
        # Reorder columns to put strategy first
        cols = ['strategy'] + [col for col in comparison_df.columns if col != 'strategy']
        comparison_df = comparison_df[cols]
        
        return comparison_df
        
    def generate_comparison_charts(self, metric='total_return_pct', save_dir='static/images'):
        """
        Generate comparison charts of strategy performance.
        
        Args:
            metric (str, optional): Metric to compare (e.g., 'total_return_pct', 'win_rate')
            save_dir (str, optional): Directory to save the charts
            
        Returns:
            dict: Paths to the generated charts
        """
        if not self.results:
            logger.warning("No results available. Run comparison first.")
            return {}
            
        os.makedirs(save_dir, exist_ok=True)
        timestamp = int(time.time())
        
        # 1. Bar chart for key metrics
        comparison_df = self.generate_comparison_table()
        
        # Select key metrics for comparison
        key_metrics = ['total_return_pct', 'win_rate', 'sharpe_ratio', 'max_drawdown', 'profit_factor']
        metrics_df = comparison_df[['strategy'] + [m for m in key_metrics if m in comparison_df.columns]]
        
        # Prepare data for plotting - convert to long format
        plot_df = pd.melt(metrics_df, id_vars=['strategy'], 
                         value_vars=[m for m in key_metrics if m in metrics_df.columns],
                         var_name='metric', value_name='value')
        
        # Create bar chart
        plt.figure(figsize=(12, 6))
        sns.set_style("darkgrid")
        
        ax = sns.barplot(x='metric', y='value', hue='strategy', data=plot_df)
        plt.title('Strategy Comparison - Key Metrics')
        plt.xlabel('Metric')
        plt.ylabel('Value')
        plt.xticks(rotation=45)
        plt.tight_layout()
        
        bar_chart_path = f"{save_dir}/strategy_comparison_bar_{timestamp}.png"
        plt.savefig(bar_chart_path)
        plt.close()
        
        # 2. Radar chart for normalized metrics
        # Normalize the data for radar chart
        metrics_to_normalize = {
            'total_return_pct': 1,  # Higher is better
            'win_rate': 1,          # Higher is better
            'sharpe_ratio': 1,      # Higher is better
            'max_drawdown': -1,     # Lower is better (multiply by -1)
            'profit_factor': 1      # Higher is better
        }
        
        # Filter to only include metrics we have and want to normalize
        metrics_to_use = [m for m in metrics_to_normalize.keys() if m in comparison_df.columns]
        
        if metrics_to_use:
            # Create a copy for normalization
            radar_df = comparison_df[['strategy'] + metrics_to_use].copy()
            
            # Normalize each metric to 0-1 range, considering whether higher or lower is better
            for metric, direction in metrics_to_normalize.items():
                if metric in radar_df.columns:
                    values = radar_df[metric].values
                    if len(set(values)) > 1:  # Only normalize if there's variation
                        if metric == 'max_drawdown':
                            # For drawdown, smaller is better, so invert
                            min_val, max_val = values.min(), values.max()
                            radar_df[metric] = (max_val - values) / (max_val - min_val) if max_val != min_val else 0.5
                        else:
                            # For other metrics, larger is better
                            min_val, max_val = values.min(), values.max()
                            radar_df[metric] = (values - min_val) / (max_val - min_val) if max_val != min_val else 0.5
            
            # Create radar chart
            plt.figure(figsize=(10, 8))
            
            # Number of metrics
            categories = metrics_to_use
            N = len(categories)
            
            # Create angles for each metric
            angles = [n / float(N) * 2 * np.pi for n in range(N)]
            angles += angles[:1]  # Close the loop
            
            # Set up the plot
            ax = plt.subplot(111, polar=True)
            
            # Add lines and dots for each strategy
            for idx, strategy in enumerate(radar_df['strategy']):
                values = radar_df.loc[radar_df['strategy'] == strategy, metrics_to_use].values.flatten().tolist()
                values += values[:1]  # Close the loop
                
                ax.plot(angles, values, linewidth=2, linestyle='solid', label=strategy)
                ax.fill(angles, values, alpha=0.1)
            
            # Set category labels
            plt.xticks(angles[:-1], categories, size=12)
            
            # Draw y-axis labels
            ax.set_rlabel_position(0)
            plt.yticks([0.25, 0.5, 0.75], ["0.25", "0.5", "0.75"], color="grey", size=10)
            plt.ylim(0, 1)
            
            # Add legend
            plt.legend(loc='upper right', bbox_to_anchor=(0.1, 0.1))
            
            plt.title('Strategy Comparison - Normalized Metrics', size=15, y=1.1)
            
            radar_chart_path = f"{save_dir}/strategy_comparison_radar_{timestamp}.png"
            plt.savefig(radar_chart_path)
            plt.close()
        else:
            radar_chart_path = None
        
        # 3. Equity curves comparison
        plt.figure(figsize=(12, 6))
        
        # Extract equity curves from each strategy
        for strategy_name, result in self.results.items():
            if 'equity_curve' in result['metrics']:
                equity_data = result['metrics']['equity_curve']
                if isinstance(equity_data, list) and equity_data:
                    dates = [pd.to_datetime(point[0]) for point in equity_data]
                    values = [point[1] for point in equity_data]
                    plt.plot(dates, values, label=strategy_name)
        
        plt.title('Equity Curves Comparison')
        plt.xlabel('Date')
        plt.ylabel('Account Value (USD)')
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        
        equity_chart_path = f"{save_dir}/strategy_comparison_equity_{timestamp}.png"
        plt.savefig(equity_chart_path)
        plt.close()
        
        return {
            'bar_chart': bar_chart_path,
            'radar_chart': radar_chart_path,
            'equity_chart': equity_chart_path
        }
    
    def export_comparison_data(self, output_dir='data/comparisons'):
        """
        Export comparison data to files.
        
        Args:
            output_dir (str, optional): Directory to save the exported data
            
        Returns:
            dict: Paths to the exported files
        """
        os.makedirs(output_dir, exist_ok=True)
        timestamp = int(time.time())
        
        export_paths = {}
        
        # Export comparison table as CSV
        comparison_df = self.generate_comparison_table()
        if comparison_df is not None:
            csv_path = f"{output_dir}/strategy_comparison_{timestamp}.csv"
            comparison_df.to_csv(csv_path, index=False)
            export_paths['csv'] = csv_path
        
        # Export full results as JSON
        json_path = f"{output_dir}/strategy_comparison_full_{timestamp}.json"
        
        # Create serializable results
        serializable_results = {}
        for strategy, result in self.results.items():
            serializable_results[strategy] = {
                'metrics': result['metrics'],
                'parameters': result['parameters'],
                'trades': [trade for trade in result['trades']]
            }
            
        with open(json_path, 'w') as f:
            json.dump(serializable_results, f, indent=2, default=str)
            
        export_paths['json'] = json_path
        
        return export_paths

def run_batch_comparison(strategies=None, symbol="BTC/USDT", timeframe="1h", 
                        initial_balance=1000.0, start_date=None, end_date=None, 
                        use_optimal_params=True):
    """
    Run a batch comparison of strategies and return the results.
    
    Args:
        strategies (list, optional): List of strategy names to compare
        symbol (str, optional): Trading pair symbol
        timeframe (str, optional): Timeframe for the backtest
        initial_balance (float, optional): Initial balance for the backtest
        start_date (str, optional): Start date for the backtest (YYYY-MM-DD)
        end_date (str, optional): End date for the backtest (YYYY-MM-DD)
        use_optimal_params (bool, optional): Whether to use optimal parameters
        
    Returns:
        dict: Results of the comparison
    """
    batch = BatchComparison(
        strategies=strategies,
        symbol=symbol,
        timeframe=timeframe,
        initial_balance=initial_balance,
        start_date=start_date,
        end_date=end_date
    )
    
    batch.load_data()
    batch.run_comparison(use_optimal_params=use_optimal_params)
    
    comparison_table = batch.generate_comparison_table()
    charts = batch.generate_comparison_charts()
    
    return {
        'batch': batch,
        'table': comparison_table,
        'charts': charts,
        'results': batch.results
    }