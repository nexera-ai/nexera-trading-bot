"""
Performance Tracking Module
Tracks and analyzes trading performance metrics in real-time.
"""
import os
import json
import logging
from datetime import datetime, timedelta
from collections import defaultdict

logger = logging.getLogger(__name__)

class PerformanceTracker:
    """
    Tracks and analyzes trading performance metrics.
    Maintains session statistics and historical data for visualization.
    """
    
    def __init__(self, data_dir='./data', save_interval=60):
        """
        Initialize the performance tracker.
        
        Args:
            data_dir (str): Directory to store performance data
            save_interval (int): Interval in seconds to auto-save data
        """
        self.data_dir = data_dir
        self.save_interval = save_interval
        self.last_save_time = datetime.now()
        
        # Create data directory if it doesn't exist
        os.makedirs(data_dir, exist_ok=True)
        
        # Session stats (reset when bot restarts)
        self.session_start_time = datetime.now()
        self.session_trades = []
        self.session_pnl = 0.0
        self.current_positions = {}
        
        # Overall stats (persisted)
        self.total_trades = 0
        self.winning_trades = 0
        self.losing_trades = 0
        self.break_even_trades = 0
        self.largest_win = 0.0
        self.largest_loss = 0.0
        self.total_pnl = 0.0
        self.peak_balance = 0.0
        self.drawdown = 0.0
        self.strategy_performance = defaultdict(
            lambda: {
                'trades': 0,
                'wins': 0,
                'losses': 0,
                'pnl': 0.0,
                'win_rate': 0.0
            }
        )
        
        # Time series data for charts
        self.balance_history = []
        self.trade_history = []
        
        # Load existing data if available
        self._load_data()
    
    def _load_data(self):
        """Load performance data from disk if available."""
        try:
            data_file = os.path.join(self.data_dir, 'performance_data.json')
            if os.path.exists(data_file):
                with open(data_file, 'r') as f:
                    data = json.load(f)
                
                # Load overall stats
                self.total_trades = data.get('total_trades', 0)
                self.winning_trades = data.get('winning_trades', 0)
                self.losing_trades = data.get('losing_trades', 0)
                self.break_even_trades = data.get('break_even_trades', 0)
                self.largest_win = data.get('largest_win', 0.0)
                self.largest_loss = data.get('largest_loss', 0.0)
                self.total_pnl = data.get('total_pnl', 0.0)
                self.peak_balance = data.get('peak_balance', 0.0)
                self.drawdown = data.get('drawdown', 0.0)
                
                # Load strategy performance
                for strategy, stats in data.get('strategy_performance', {}).items():
                    self.strategy_performance[strategy] = stats
                
                # Load time series data
                self.balance_history = data.get('balance_history', [])
                
                # We skip loading trade_history as it can be large
                # and is mostly needed for detailed analytics
                
                logger.info(f"Loaded performance data: {self.total_trades} trades, {self.total_pnl:.2f} total PnL")
        except Exception as e:
            logger.error(f"Error loading performance data: {e}")
    
    def save_data(self):
        """Save performance data to disk."""
        try:
            data = {
                'total_trades': self.total_trades,
                'winning_trades': self.winning_trades,
                'losing_trades': self.losing_trades,
                'break_even_trades': self.break_even_trades,
                'largest_win': self.largest_win,
                'largest_loss': self.largest_loss,
                'total_pnl': self.total_pnl,
                'peak_balance': self.peak_balance,
                'drawdown': self.drawdown,
                'strategy_performance': {k: v for k, v in self.strategy_performance.items()},
                'balance_history': self.balance_history[-1000:],  # Keep last 1000 points to limit file size
                'last_updated': datetime.now().isoformat()
            }
            
            data_file = os.path.join(self.data_dir, 'performance_data.json')
            with open(data_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            # Save detailed trade history to a separate file (limited to recent trades)
            if len(self.trade_history) > 0:
                trades_file = os.path.join(self.data_dir, 'trade_history.json')
                with open(trades_file, 'w') as f:
                    json.dump(self.trade_history[-500:], f, indent=2)  # Keep last 500 trades
            
            self.last_save_time = datetime.now()
            logger.debug("Performance data saved")
        except Exception as e:
            logger.error(f"Error saving performance data: {e}")
    
    def record_trade(self, trade_data):
        """
        Record a completed trade and update statistics.
        
        Args:
            trade_data (dict): Dictionary containing trade information
                Required keys:
                - symbol: Trading pair symbol
                - strategy: Strategy name
                - entry_time: Entry timestamp
                - exit_time: Exit timestamp
                - entry_price: Entry price
                - exit_price: Exit price
                - quantity: Trade quantity
                - pnl: Profit/loss in quote currency
                - pnl_percent: Profit/loss as percentage
                - exit_reason: Reason for exiting the trade
        """
        # Add timestamp if not provided
        if 'timestamp' not in trade_data:
            trade_data['timestamp'] = datetime.now().isoformat()
        
        # Store the trade in history
        self.trade_history.append(trade_data)
        self.session_trades.append(trade_data)
        
        # Update session PnL
        pnl = trade_data.get('pnl', 0.0)
        self.session_pnl += pnl
        self.total_pnl += pnl
        
        # Update trade counts
        self.total_trades += 1
        if pnl > 0:
            self.winning_trades += 1
            self.largest_win = max(self.largest_win, pnl)
        elif pnl < 0:
            self.losing_trades += 1
            self.largest_loss = min(self.largest_loss, pnl)
        else:
            self.break_even_trades += 1
        
        # Update strategy performance
        strategy = trade_data.get('strategy', 'unknown')
        self.strategy_performance[strategy]['trades'] += 1
        if pnl > 0:
            self.strategy_performance[strategy]['wins'] += 1
        elif pnl < 0:
            self.strategy_performance[strategy]['losses'] += 1
        
        self.strategy_performance[strategy]['pnl'] += pnl
        
        # Update win rate
        strategy_trades = self.strategy_performance[strategy]['trades']
        if strategy_trades > 0:
            self.strategy_performance[strategy]['win_rate'] = (
                self.strategy_performance[strategy]['wins'] / strategy_trades * 100
            )
        
        # Record balance point for chart
        timestamp = trade_data.get('exit_time', datetime.now().isoformat())
        self.balance_history.append({
            'timestamp': timestamp,
            'balance': self.total_pnl,
            'trade_id': len(self.trade_history) - 1
        })
        
        # Update peak balance and drawdown
        if self.total_pnl > self.peak_balance:
            self.peak_balance = self.total_pnl
        else:
            current_drawdown = self.peak_balance - self.total_pnl
            self.drawdown = max(self.drawdown, current_drawdown)
        
        # Auto-save if interval has passed
        if (datetime.now() - self.last_save_time).total_seconds() > self.save_interval:
            self.save_data()
        
        logger.info(
            f"Recorded trade: {trade_data['symbol']} with {pnl:.2f} PnL " 
            f"({trade_data.get('pnl_percent', 0):.2f}%)"
        )
    
    def update_position(self, symbol, entry_price, quantity, strategy):
        """
        Update or add an open position.
        
        Args:
            symbol (str): Trading pair symbol
            entry_price (float): Entry price
            quantity (float): Position size
            strategy (str): Strategy name
        """
        self.current_positions[symbol] = {
            'entry_price': entry_price,
            'quantity': quantity,
            'entry_time': datetime.now().isoformat(),
            'strategy': strategy
        }
    
    def remove_position(self, symbol):
        """
        Remove a position when closed.
        
        Args:
            symbol (str): Trading pair symbol
        """
        if symbol in self.current_positions:
            del self.current_positions[symbol]
    
    def get_session_stats(self):
        """
        Get statistics for the current session.
        
        Returns:
            dict: Session statistics
        """
        session_duration = datetime.now() - self.session_start_time
        hours = session_duration.total_seconds() / 3600
        
        # Calculate session-specific stats
        session_trades = len(self.session_trades)
        session_wins = sum(1 for t in self.session_trades if t.get('pnl', 0) > 0)
        session_losses = sum(1 for t in self.session_trades if t.get('pnl', 0) < 0)
        
        win_rate = 0
        if session_trades > 0:
            win_rate = (session_wins / session_trades) * 100
        
        trades_per_hour = 0
        if hours > 0:
            trades_per_hour = session_trades / hours
        
        return {
            'start_time': self.session_start_time.isoformat(),
            'duration': str(session_duration).split('.')[0],  # HH:MM:SS format
            'trades': session_trades,
            'wins': session_wins,
            'losses': session_losses,
            'win_rate': win_rate,
            'pnl': self.session_pnl,
            'trades_per_hour': trades_per_hour,
            'open_positions': len(self.current_positions)
        }
    
    def get_overall_stats(self):
        """
        Get overall performance statistics.
        
        Returns:
            dict: Overall statistics
        """
        win_rate = 0
        if self.total_trades > 0:
            win_rate = (self.winning_trades / self.total_trades) * 100
        
        return {
            'total_trades': self.total_trades,
            'winning_trades': self.winning_trades,
            'losing_trades': self.losing_trades,
            'break_even_trades': self.break_even_trades,
            'win_rate': win_rate,
            'largest_win': self.largest_win,
            'largest_loss': self.largest_loss,
            'total_pnl': self.total_pnl,
            'peak_balance': self.peak_balance,
            'max_drawdown': self.drawdown,
            'profit_factor': abs(self.largest_win / self.largest_loss) if self.largest_loss != 0 else float('inf')
        }
    
    def get_strategy_performance(self, strategy=None):
        """
        Get performance metrics for a specific strategy or all strategies.
        
        Args:
            strategy (str, optional): Strategy name. If None, returns data for all strategies.
            
        Returns:
            dict: Strategy performance metrics
        """
        if strategy is not None:
            return self.strategy_performance.get(strategy, {})
        return {k: v for k, v in self.strategy_performance.items()}
    
    def get_balance_history(self, timeframe='all'):
        """
        Get balance history for charting.
        
        Args:
            timeframe (str): Time period to retrieve ('day', 'week', 'month', 'all')
            
        Returns:
            list: Balance history data points
        """
        if timeframe == 'all' or not self.balance_history:
            return self.balance_history
        
        # Calculate cutoff time based on timeframe
        now = datetime.now()
        if timeframe == 'day':
            cutoff = now - timedelta(days=1)
        elif timeframe == 'week':
            cutoff = now - timedelta(days=7)
        elif timeframe == 'month':
            cutoff = now - timedelta(days=30)
        else:
            return self.balance_history
        
        cutoff_str = cutoff.isoformat()
        return [point for point in self.balance_history if point['timestamp'] >= cutoff_str]
    
    def get_recent_trades(self, limit=50):
        """
        Get most recent trades.
        
        Args:
            limit (int): Maximum number of trades to retrieve
            
        Returns:
            list: Recent trades
        """
        return self.trade_history[-limit:] if self.trade_history else []
    
    def reset_session(self):
        """Reset session statistics but keep overall statistics."""
        self.session_start_time = datetime.now()
        self.session_trades = []
        self.session_pnl = 0.0
        logger.info("Performance session reset")
    
    def reset_all_stats(self):
        """Reset all statistics (session and overall)."""
        self.__init__(data_dir=self.data_dir, save_interval=self.save_interval)
        logger.info("All performance statistics reset")

# Example usage:
# tracker = PerformanceTracker()
# 
# # Record a trade
# tracker.record_trade({
#     'symbol': 'BTC/USDT',
#     'strategy': 'dip_buyer',
#     'entry_time': '2025-04-10T12:30:45',
#     'exit_time': '2025-04-10T14:15:22',
#     'entry_price': 60000.0,
#     'exit_price': 61200.0,
#     'quantity': 0.01,
#     'pnl': 12.0,
#     'pnl_percent': 2.0,
#     'exit_reason': 'take_profit'
# })
# 
# # Get session stats
# stats = tracker.get_session_stats()
# print(f"Session PnL: ${stats['pnl']}, Win Rate: {stats['win_rate']}%")