"""
Trading Bot Implementation
This module contains the main trading bot logic.
"""
import logging
import time
import os
from datetime import datetime
from config import Config
from binance_client import BinanceClient
from strategies import get_strategy
from utils import calculate_profit_percentage
from performance_tracker import PerformanceTracker
from safety import TradeSafety, SafetyConfig
from ensemble_engine import ensemble_manager, get_active_ensemble, create_default_ensembles, SignalType

logger = logging.getLogger(__name__)

# Global position size multiplier used by Risk-Off Trigger System
_position_size_multiplier = 1.0

def get_position_size_multiplier():
    """
    Get the current position size multiplier.
    This is used by the Risk-Off Trigger System to scale position sizes.
    
    Returns:
        float: Current position size multiplier (1.0 = normal, < 1.0 = reduced)
    """
    global _position_size_multiplier
    return _position_size_multiplier

def adjust_position_size_multiplier(multiplier):
    """
    Adjust the global position size multiplier.
    This is used by the Risk-Off Trigger System to scale position sizes
    in response to different risk levels.
    
    Args:
        multiplier (float): New position size multiplier
            1.0 = normal position sizes
            < 1.0 = reduced position sizes (e.g., 0.5 = half size)
            0.0 = no new positions
    
    Returns:
        float: The new position size multiplier
    """
    global _position_size_multiplier
    
    # Ensure multiplier is between 0 and 1
    multiplier = max(0.0, min(1.0, multiplier))
    _position_size_multiplier = multiplier
    
    logger.info(f"Position size multiplier adjusted to {multiplier:.2f}")
    return _position_size_multiplier

class TradingBot:
    """Main trading bot class that orchestrates the trading process."""
    
    def __init__(self, api_key, api_secret, trading_pairs, base_position_size, 
                 check_interval=300, paper_trading=True, strategy_name=None):
        """
        Initialize the trading bot with the given parameters.
        
        Args:
            api_key (str): Binance API key
            api_secret (str): Binance API secret
            trading_pairs (list): List of trading pairs to monitor and trade
            base_position_size (float): Base position size in USDT
            check_interval (int): Interval between checks in seconds
            paper_trading (bool): Whether to run in paper trading mode
            strategy_name (str): Name of the strategy to use, defaults to Config.ACTIVE_STRATEGY
        """
        self.trading_pairs = trading_pairs
        self.base_position_size = base_position_size
        self.check_interval = check_interval
        self.paper_trading = paper_trading
        
        # Initialize the Binance client with paper trading option
        self.client = BinanceClient(
            api_key=api_key, 
            api_secret=api_secret, 
            testnet=Config.TEST_MODE,
            paper_trading=paper_trading
        )
        
        # Use the provided strategy name or default from config
        if strategy_name is None:
            strategy_name = Config.ACTIVE_STRATEGY
        
        # Track the strategy name
        self.active_strategy = strategy_name
        
        # Initialize default ensembles if needed
        create_default_ensembles()
        
        # Initialize the strategy (regular or ensemble)
        self._initialize_strategy(strategy_name)
        
        # Dictionary to track open positions
        self.open_positions = {}
        
        # Create data directory if it doesn't exist
        os.makedirs('./data', exist_ok=True)
        
        # Initialize performance tracker
        self.performance_tracker = PerformanceTracker(data_dir='./data')
        
        # Initialize safety module with config
        safety_config = SafetyConfig(**Config.get_safety_params())
        self.safety = TradeSafety(safety_config)
        logger.info(f"Safety module initialized with {safety_config.safety_mode_level} mode")
        
        # Track bot performance stats (legacy, will be migrated to performance tracker)
        self.total_trades = 0
        self.successful_trades = 0
        self.failed_trades = 0
        self.total_profit_usdt = 0.0
        
        # Get initial portfolio value
        try:
            portfolio = self.client.get_portfolio_summary()
            self.initial_portfolio_value = portfolio['total_usd_value']
            self.current_portfolio_value = self.initial_portfolio_value
            logger.info(f"Initial portfolio value: ${self.initial_portfolio_value:.2f} USDT")
        except Exception as e:
            logger.error(f"Error getting initial portfolio value: {e}")
            self.initial_portfolio_value = 1000.0
            self.current_portfolio_value = 1000.0
        
        logger.info("Trading bot initialized successfully.")
    
    def check_and_execute_trades(self):
        """Check for trading opportunities and execute trades based on the strategy."""
        logger.info("Checking for trading opportunities...")
        
        # First check if we need to close any positions (take profit/stop loss)
        self._check_exit_positions()
        
        # Then check for new entry opportunities
        if len(self.open_positions) < Config.MAX_OPEN_POSITIONS:
            self._check_entry_positions()
        else:
            logger.info(f"Maximum number of open positions reached ({Config.MAX_OPEN_POSITIONS}). Skipping entry check.")
        
        # Log current portfolio status
        self._log_portfolio_status()
    
    def _check_entry_positions(self):
        """Check for new entry opportunities based on the strategy."""
        for pair in self.trading_pairs:
            # Skip if we already have an open position for this pair
            if pair in self.open_positions:
                logger.debug(f"Already have an open position for {pair}. Skipping.")
                continue
            
            try:
                # Get historical price data
                historical_data = self.client.get_historical_prices(pair, timeframe='1m', limit=20)
                
                # Check if entry conditions are met
                if self.strategy.should_enter(historical_data):
                    logger.info(f"Entry signal triggered for {pair}!")
                    current_price = self.client.get_current_price(pair)
                    
                    # Calculate position size
                    position_size = self._calculate_position_size(pair)
                    
                    # Execute buy order
                    order_id = self._execute_buy(pair, position_size, current_price)
                    
                    if order_id:
                        # Record the position
                        self.open_positions[pair] = {
                            'order_id': order_id,
                            'entry_price': current_price,
                            'entry_time': datetime.now(),
                            'position_size': position_size,
                            'take_profit_price': current_price * (1 + (Config.TAKE_PROFIT / 100)),
                            'stop_loss_price': current_price * (1 - (Config.STOP_LOSS / 100))
                        }
                        logger.info(f"Opened position for {pair} at {current_price} with {position_size} USDT")
                        logger.info(f"Take profit set at: {self.open_positions[pair]['take_profit_price']}")
                        logger.info(f"Stop loss set at: {self.open_positions[pair]['stop_loss_price']}")
            
            except Exception as e:
                logger.error(f"Error checking entry for {pair}: {e}")
    
    def _check_exit_positions(self):
        """Check and execute exit conditions for open positions."""
        pairs_to_remove = []
        
        for pair, position in self.open_positions.items():
            try:
                current_price = self.client.get_current_price(pair)
                entry_price = position['entry_price']
                
                # Calculate current profit/loss
                profit_percentage = calculate_profit_percentage(entry_price, current_price)
                
                logger.debug(f"{pair} current price: {current_price}, P/L: {profit_percentage:.2f}%")
                
                # Check exit conditions
                if current_price >= position['take_profit_price']:
                    logger.info(f"Take profit triggered for {pair}! Current price: {current_price}")
                    self._execute_sell(pair, position, current_price, "TAKE_PROFIT")
                    pairs_to_remove.append(pair)
                    
                elif current_price <= position['stop_loss_price']:
                    logger.info(f"Stop loss triggered for {pair}! Current price: {current_price}")
                    self._execute_sell(pair, position, current_price, "STOP_LOSS")
                    pairs_to_remove.append(pair)
                    
            except Exception as e:
                logger.error(f"Error checking exit for {pair}: {e}")
        
        # Remove closed positions
        for pair in pairs_to_remove:
            if pair in self.open_positions:
                del self.open_positions[pair]
    
    def _execute_buy(self, pair, position_size, current_price):
        """Execute a buy order."""
        try:
            # Get current portfolio value for safety checks
            portfolio = self.client.get_portfolio_summary()
            current_balance = portfolio['total_usd_value']
            asset_exposure = {}
            
            # Calculate current exposure for each asset
            for currency, data in portfolio['balances'].items():
                if data['usd_value'] > 0 and currency != 'USDT':
                    base_currency = currency
                    asset_exposure[base_currency] = data['usd_value']
            
            # Run safety checks before executing the trade
            base_currency = pair.split('/')[0]
            can_trade, reason = self.safety.can_execute_trade(
                symbol=pair,
                amount_usd=position_size,
                current_balance=current_balance,
                asset_exposure=asset_exposure
            )
            
            if not can_trade:
                logger.warning(f"Safety check failed for {pair}: {reason}")
                return None
                
            if self.paper_trading:
                logger.info(f"[PAPER TRADING] Would buy {position_size/current_price} {pair} at {current_price}")
                order_id = f"paper_buy_{int(time.time())}"
            else:
                # Check if live trading is enabled in safety module
                if not self.safety.config.live_trading_enabled:
                    logger.warning("Live trading is disabled in safety settings. Skipping real order.")
                    return None
                    
                # Execute actual buy order via Binance API
                order = self.client.create_market_buy_order(pair, position_size)
                order_id = order['id']
                logger.info(f"Buy order executed: {order_id}")
            
            # Update legacy stats
            self.total_trades += 1
            
            # Update performance tracker with the new position
            quantity = position_size / current_price
            self.performance_tracker.update_position(
                symbol=pair,
                entry_price=current_price,
                quantity=quantity,
                strategy=self.active_strategy
            )
            
            # Record the trade in safety module for tracking
            trade_data = {
                'symbol': pair,
                'side': 'buy',
                'amount_usd': position_size,
                'price': current_price,
                'timestamp': datetime.now()
            }
            self.safety.record_trade(trade_data)
            
            return order_id
            
        except Exception as e:
            logger.error(f"Error executing buy order for {pair}: {e}")
            return None
    
    def _execute_sell(self, pair, position, current_price, exit_reason):
        """Execute a sell order."""
        try:
            entry_price = position['entry_price']
            position_size = position['position_size']
            entry_time = position['entry_time']
            profit_percentage = calculate_profit_percentage(entry_price, current_price)
            profit_usdt = position_size * (profit_percentage / 100)
            
            if self.paper_trading:
                logger.info(f"[PAPER TRADING] Would sell {pair} at {current_price}")
                logger.info(f"[PAPER TRADING] {exit_reason}: Profit/Loss: {profit_percentage:.2f}% ({profit_usdt:.2f} USDT)")
                order_id = f"paper_sell_{int(time.time())}"
            else:
                # Check if live trading is enabled in safety module
                if not self.safety.config.live_trading_enabled:
                    logger.warning("Live trading is disabled in safety settings. Using paper trading mode for sell.")
                    order_id = f"paper_sell_{int(time.time())}"
                else:
                    # Execute actual sell order via Binance API
                    order = self.client.create_market_sell_order(pair, position_size/entry_price)
                    order_id = order['id']
                    logger.info(f"Sell order executed: {order_id}")
            
            # Update legacy statistics
            if profit_percentage > 0:
                self.successful_trades += 1
            else:
                self.failed_trades += 1
                
            self.total_profit_usdt += profit_usdt
            
            # Record trade in performance tracker
            quantity = position_size / entry_price
            trade_data = {
                'symbol': pair,
                'strategy': self.active_strategy,
                'entry_time': entry_time.isoformat() if isinstance(entry_time, datetime) else entry_time,
                'exit_time': datetime.now().isoformat(),
                'entry_price': entry_price,
                'exit_price': current_price,
                'quantity': quantity,
                'pnl': profit_usdt,
                'pnl_percent': profit_percentage,
                'exit_reason': exit_reason
            }
            self.performance_tracker.record_trade(trade_data)
            
            # Remove position from tracker
            self.performance_tracker.remove_position(pair)
            
            # Record the trade in safety module for tracking
            safety_trade_data = {
                'symbol': pair,
                'side': 'sell',
                'amount_usd': position_size,
                'price': current_price,
                'pnl': profit_usdt,
                'timestamp': datetime.now()
            }
            self.safety.record_trade(safety_trade_data)
            
            # Check daily loss limit after this trade
            if profit_usdt < 0 and not self.paper_trading:
                # Get current portfolio value for safety checks
                portfolio = self.client.get_portfolio_summary()
                current_balance = portfolio['total_usd_value']
                
                # Check if we hit the daily loss limit
                max_daily_loss_from_pct = self.initial_portfolio_value * (self.safety.config.max_daily_loss_pct / 100.0)
                max_daily_loss = min(self.safety.config.max_daily_loss_usd, max_daily_loss_from_pct)
                
                if self.safety.daily_loss >= max_daily_loss:
                    logger.warning(f"SAFETY: Daily loss limit of ${max_daily_loss:.2f} reached. Current loss: ${self.safety.daily_loss:.2f}")
                    logger.warning("SAFETY: Trading will be restricted until daily stats reset.")
            
            logger.info(f"Closed position for {pair}. {exit_reason} executed.")
            logger.info(f"Entry price: {entry_price}, Exit price: {current_price}")
            logger.info(f"Profit/Loss: {profit_percentage:.2f}% ({profit_usdt:.2f} USDT)")
            
            return order_id
            
        except Exception as e:
            logger.error(f"Error executing sell order for {pair}: {e}")
            return None
    
    def _calculate_position_size(self, pair):
        """
        Calculate position size for a new trade, accounting for compounding if enabled.
        Also applies the Risk-Off Trigger System position size multiplier.
        """
        position_size = self.base_position_size
        
        # Apply compounding if enabled
        if Config.REINVEST_PROFITS and self.total_profit_usdt > 0:
            # Distribute the profits equally among trading pairs
            profit_share = self.total_profit_usdt / len(self.trading_pairs)
            position_size += profit_share
        
        # Apply the Risk-Off Trigger System position size multiplier
        multiplier = get_position_size_multiplier()
        if multiplier < 1.0:
            original_size = position_size
            position_size = position_size * multiplier
            logger.info(f"Position size reduced by Risk-Off Trigger System: {original_size:.2f} → {position_size:.2f} USDT (multiplier: {multiplier:.2f})")
        
        return position_size
    
    def _log_portfolio_status(self):
        """Log the current portfolio status."""
        open_positions_count = len(self.open_positions)
        logger.info("===== PORTFOLIO STATUS =====")
        logger.info(f"Open positions: {open_positions_count}/{Config.MAX_OPEN_POSITIONS}")
        
        # Get latest portfolio summary
        try:
            portfolio = self.client.get_portfolio_summary()
            self.current_portfolio_value = portfolio['total_usd_value']
            
            portfolio_change = ((self.current_portfolio_value - self.initial_portfolio_value) / self.initial_portfolio_value) * 100
            
            logger.info(f"Initial portfolio: ${self.initial_portfolio_value:.2f} USDT")
            logger.info(f"Current portfolio: ${self.current_portfolio_value:.2f} USDT")
            logger.info(f"Portfolio change: {portfolio_change:+.2f}%")
            
            # Log individual balances
            logger.info("Current balances:")
            for currency, data in portfolio['balances'].items():
                if data['amount'] > 0:
                    logger.info(f"  {currency}: {data['amount']:.6f} (${data['usd_value']:.2f})")
        except Exception as e:
            logger.error(f"Error getting portfolio summary: {e}")
        
        if open_positions_count > 0:
            logger.info("Current open positions:")
            for pair, position in self.open_positions.items():
                current_price = self.client.get_current_price(pair)
                entry_price = position['entry_price']
                profit_percentage = calculate_profit_percentage(entry_price, current_price)
                duration = datetime.now() - position['entry_time']
                hours, remainder = divmod(duration.seconds, 3600)
                minutes, _ = divmod(remainder, 60)
                
                logger.info(f"  {pair}: Entry: {entry_price}, Current: {current_price}, P/L: {profit_percentage:.2f}%, Duration: {hours}h {minutes}m")
        
        logger.info(f"Total trades: {self.total_trades}")
        logger.info(f"Successful trades: {self.successful_trades}")
        logger.info(f"Failed trades: {self.failed_trades}")
        logger.info(f"Total profit/loss: {self.total_profit_usdt:.2f} USDT")
        if self.total_trades > 0:
            win_rate = (self.successful_trades / self.total_trades) * 100
            logger.info(f"Win rate: {win_rate:.2f}%")
        logger.info("============================")
        
    def get_portfolio_info(self):
        """
        Get detailed portfolio information for the web interface.
        
        Returns:
            dict: Portfolio information
        """
        portfolio_info = {}
        
        # Get account balance and portfolio summary
        try:
            portfolio = self.client.get_portfolio_summary()
            self.current_portfolio_value = portfolio['total_usd_value']
            
            portfolio_change = ((self.current_portfolio_value - self.initial_portfolio_value) / self.initial_portfolio_value) * 100
            
            portfolio_info['current_value'] = self.current_portfolio_value
            portfolio_info['initial_value'] = self.initial_portfolio_value
            portfolio_info['change_percentage'] = portfolio_change
            portfolio_info['balances'] = portfolio['balances']
            
        except Exception as e:
            logger.error(f"Error getting portfolio info: {e}")
            portfolio_info['error'] = str(e)
        
        # Add open positions
        portfolio_info['open_positions'] = []
        for pair, position in self.open_positions.items():
            try:
                current_price = self.client.get_current_price(pair)
                entry_price = position['entry_price']
                profit_percentage = calculate_profit_percentage(entry_price, current_price)
                duration = datetime.now() - position['entry_time']
                hours, remainder = divmod(duration.seconds, 3600)
                minutes, _ = divmod(remainder, 60)
                
                position_info = {
                    'pair': pair,
                    'entry_price': entry_price,
                    'current_price': current_price,
                    'profit_percentage': profit_percentage,
                    'position_size': position['position_size'],
                    'duration': f"{hours}h {minutes}m",
                    'take_profit_price': position['take_profit_price'],
                    'stop_loss_price': position['stop_loss_price']
                }
                
                portfolio_info['open_positions'].append(position_info)
            except Exception as e:
                logger.error(f"Error getting position info for {pair}: {e}")
        
        # Add performance statistics (from both legacy and new performance tracker)
        
        # Legacy stats (for backward compatibility)
        legacy_stats = {
            'total_trades': self.total_trades,
            'successful_trades': self.successful_trades,
            'failed_trades': self.failed_trades,
            'total_profit_usdt': self.total_profit_usdt,
            'win_rate': (self.successful_trades / self.total_trades) * 100 if self.total_trades > 0 else 0
        }
        
        # Performance tracker stats
        try:
            # Get session stats
            session_stats = self.performance_tracker.get_session_stats()
            overall_stats = self.performance_tracker.get_overall_stats()
            
            # Get strategy performance
            strategy_performance = self.performance_tracker.get_strategy_performance()
            
            # Get recent trades
            recent_trades = self.performance_tracker.get_recent_trades(limit=10)
            
            # Add to portfolio info
            portfolio_info['session_stats'] = session_stats
            portfolio_info['overall_stats'] = overall_stats
            portfolio_info['strategy_performance'] = strategy_performance
            portfolio_info['recent_trades'] = recent_trades
            
            # Add chart data
            portfolio_info['balance_history'] = self.performance_tracker.get_balance_history(timeframe='day')
            
        except Exception as e:
            logger.error(f"Error getting performance stats: {e}")
            portfolio_info['performance_error'] = str(e)
        
        # Add legacy stats
        portfolio_info['stats'] = legacy_stats
        
        # Add safety status
        portfolio_info['safety_status'] = self.get_safety_status()
        
        return portfolio_info
    
    def _initialize_strategy(self, strategy_name):
        """
        Initialize a strategy (regular or ensemble).
        
        Args:
            strategy_name (str): Name of the strategy to initialize
            
        Returns:
            object: Initialized strategy instance
        """
        try:
            # Check if this is an ensemble strategy
            if strategy_name.startswith('ensemble_'):
                # Fetch the ensemble configuration
                ensemble_config = get_active_ensemble(strategy_name)
                
                if ensemble_config:
                    logger.info(f"Initializing ensemble strategy: {strategy_name}")
                    
                    # Initialize the ensemble strategy
                    self.strategy = ensemble_manager.create_ensemble_strategy(
                        ensemble_name=strategy_name,
                        strategies_config=ensemble_config.get('strategies', []),
                        voting_method=ensemble_config.get('voting', 'majority')
                    )
                    
                    logger.info(f"Ensemble strategy initialized with {len(ensemble_config.get('strategies', []))} sub-strategies")
                    logger.info(f"Voting method: {ensemble_config.get('voting', 'majority')}")
                else:
                    # Fallback to default strategy if ensemble not found
                    logger.warning(f"Ensemble {strategy_name} not found, falling back to default strategy")
                    self._initialize_regular_strategy(Config.ACTIVE_STRATEGY)
            else:
                # Regular strategy initialization
                self._initialize_regular_strategy(strategy_name)
                
            return self.strategy
                
        except Exception as e:
            logger.error(f"Error initializing strategy: {e}")
            # Fall back to default strategy
            logger.warning(f"Falling back to default strategy: {Config.ACTIVE_STRATEGY}")
            self._initialize_regular_strategy(Config.ACTIVE_STRATEGY)
            return self.strategy
            
    def _initialize_regular_strategy(self, strategy_name):
        """
        Initialize a regular (non-ensemble) strategy.
        
        Args:
            strategy_name (str): Name of the strategy to initialize
        """
        # Get strategy parameters from config
        strategy_params = Config.get_strategy_params()
        
        # Initialize the strategy
        self.strategy = get_strategy(strategy_name, **strategy_params)
        self.active_strategy = strategy_name
        
        logger.info(f"Strategy initialized: {self.strategy.__class__.__name__}")
    
    def switch_strategy(self, strategy_name):
        """
        Switch the active trading strategy.
        
        Args:
            strategy_name (str): Name of the strategy to switch to
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Initialize the new strategy (regular or ensemble)
            self._initialize_strategy(strategy_name)
            
            # Update active strategy name
            self.active_strategy = strategy_name
            
            strategy_type = "ensemble" if strategy_name.startswith('ensemble_') else "regular"
            logger.info(f"Switched to {strategy_type} strategy: {strategy_name}")
            return True
        except Exception as e:
            logger.error(f"Error switching strategy: {e}")
            return False
            
    def switch_to_ensemble(self, ensemble_name):
        """
        Switch the active strategy to an ensemble strategy.
        
        Args:
            ensemble_name (str): Name of the ensemble strategy to switch to
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Get the ensemble
            ensemble = ensemble_manager.get_ensemble(ensemble_name)
            
            if not ensemble:
                logger.error(f"Ensemble strategy '{ensemble_name}' not found")
                return False
                
            logger.info(f"Switching to ensemble strategy: {ensemble_name}")
            
            # Store the current strategy name to restore if needed
            old_strategy_name = self.strategy.__class__.__name__ if self.strategy else "None"
            
            # Initialize the new ensemble strategy
            self.strategy = ensemble
            
            # Update the Config.ACTIVE_STRATEGY if available
            if hasattr(Config, 'ACTIVE_STRATEGY'):
                Config.ACTIVE_STRATEGY = ensemble_name
                
            logger.info(f"Successfully switched from {old_strategy_name} to ensemble strategy {ensemble_name}")
            
            return True
            
        except Exception as e:
            logger.error(f"Error switching to ensemble strategy: {e}")
            return False
        
    def get_performance_stats(self):
        """
        Get performance statistics for the web interface.
        
        Returns:
            dict: Performance statistics
        """
        stats = {}
        
        try:
            # Save current data to ensure we have the latest
            self.performance_tracker.save_data()
            
            # Get session stats
            stats['session'] = self.performance_tracker.get_session_stats()
            
            # Get overall stats
            stats['overall'] = self.performance_tracker.get_overall_stats()
            
            # Get strategy-specific performance
            stats['strategies'] = self.performance_tracker.get_strategy_performance()
            
            # Get active strategy performance
            stats['active_strategy'] = self.performance_tracker.get_strategy_performance(self.active_strategy)
            
            # Get balance history for charts
            stats['balance_history'] = {
                'day': self.performance_tracker.get_balance_history(timeframe='day'),
                'week': self.performance_tracker.get_balance_history(timeframe='week'),
                'month': self.performance_tracker.get_balance_history(timeframe='month'),
                'all': self.performance_tracker.get_balance_history(timeframe='all')
            }
            
            # Get recent trades
            stats['recent_trades'] = self.performance_tracker.get_recent_trades(limit=50)
            
        except Exception as e:
            logger.error(f"Error getting performance stats: {e}")
            stats['error'] = str(e)
            
        return stats
        
    def reset_performance_tracker(self, reset_all=False):
        """
        Reset the performance tracker.
        
        Args:
            reset_all (bool): If True, reset all stats. If False, only reset session stats.
        """
        try:
            if reset_all:
                self.performance_tracker.reset_all_stats()
                logger.info("Reset all performance statistics")
            else:
                self.performance_tracker.reset_session()
                logger.info("Reset session performance statistics")
                
            return True
        except Exception as e:
            logger.error(f"Error resetting performance tracker: {e}")
            return False
            
    def get_safety_status(self):
        """
        Get the current safety status information.
        
        Returns:
            dict: Safety status information
        """
        try:
            # Get portfolio information for safety checks
            portfolio = self.client.get_portfolio_summary()
            current_balance = portfolio['total_usd_value']
            
            # Calculate asset exposure
            asset_exposure = {}
            for currency, data in portfolio['balances'].items():
                if data['usd_value'] > 0 and currency != 'USDT':
                    asset_exposure[currency] = data['usd_value']
            
            # Get safety status from the safety module
            safety_status = self.safety.get_safety_status(
                current_balance=current_balance,
                asset_exposure=asset_exposure
            )
            
            # Add safety configuration information
            safety_status['config'] = {
                'max_trade_size_usd': self.safety.config.max_trade_size_usd,
                'max_trade_size_pct': self.safety.config.max_trade_size_pct,
                'max_daily_loss_usd': self.safety.config.max_daily_loss_usd,
                'max_daily_loss_pct': self.safety.config.max_daily_loss_pct,
                'min_trade_interval_seconds': self.safety.config.min_trade_interval_seconds,
                'max_trades_per_hour': self.safety.config.max_trades_per_hour,
                'max_trades_per_day': self.safety.config.max_trades_per_day,
                'max_single_asset_exposure_pct': self.safety.config.max_single_asset_exposure_pct,
                'max_total_exposure_pct': self.safety.config.max_total_exposure_pct,
                'emergency_stop_active': self.safety.config.emergency_stop_active,
                'live_trading_enabled': self.safety.config.live_trading_enabled,
                'safety_mode_level': self.safety.config.safety_mode_level
            }
            
            return safety_status
            
        except Exception as e:
            logger.error(f"Error getting safety status: {e}")
            return {
                'error': str(e),
                'live_trading_enabled': self.safety.config.live_trading_enabled,
                'emergency_stop_active': self.safety.config.emergency_stop_active,
                'safety_mode_level': self.safety.config.safety_mode_level
            }
