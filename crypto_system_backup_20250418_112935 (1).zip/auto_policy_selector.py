#!/usr/bin/env python3
"""
Auto Policy Selector Module

This module automatically selects the best rotation policy based on benchmark results
and market conditions. It runs periodically to adapt to changing market conditions.
"""

import os
import json
import logging
import datetime
from typing import Dict, List, Any, Tuple, Optional
import time
import threading
import schedule

from policy_benchmark import PolicyBenchmark
from auto_rotation import auto_rotation_engine, PerformanceBasedPolicy, TimeBasedPolicy, DegradationPolicy, AdaptivePerformancePolicy
from performance_tracker import PerformanceTracker

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('auto_policy_selector')

class AutoPolicySelector:
    """
    Automatically selects and applies the best rotation policy based on benchmark results.
    
    This class periodically runs benchmarks, analyzes the results, and applies the best-performing
    policy to the auto-rotation engine.
    """
    
    def __init__(self, 
                 data_dir: str = './data',
                 benchmark_period_days: int = 30,
                 selection_metric: str = 'sharpe_ratio',
                 schedule_time: str = '04:00',  # 4 AM daily
                 check_interval_minutes: int = 1440,  # 24 hours
                 is_enabled: bool = False):
        """
        Initialize the auto policy selector.
        
        Args:
            data_dir: Directory for storing data
            benchmark_period_days: Number of days to benchmark
            selection_metric: Primary metric for selecting the best policy
            schedule_time: Daily time to run the selection (HH:MM format)
            check_interval_minutes: Minutes between checks (as a backup to scheduled runs)
            is_enabled: Whether auto selection is enabled
        """
        self.data_dir = data_dir
        self.benchmark_period_days = benchmark_period_days
        self.selection_metric = selection_metric
        self.schedule_time = schedule_time
        self.check_interval_minutes = check_interval_minutes
        self.is_enabled = is_enabled
        self.last_run_time = None
        self.last_selected_policy = None
        self.selection_history = []
        self.scheduler_running = False
        self.thread = None
        
        # Create selection history directory
        self.history_dir = os.path.join(data_dir, 'policy_selections')
        os.makedirs(self.history_dir, exist_ok=True)
        
        # Load selection history
        self._load_history()
    
    def _load_history(self):
        """Load policy selection history from disk."""
        history_file = os.path.join(self.history_dir, 'selection_history.json')
        if os.path.exists(history_file):
            try:
                with open(history_file, 'r') as f:
                    self.selection_history = json.load(f)
                logger.info(f"Loaded {len(self.selection_history)} policy selection records")
            except Exception as e:
                logger.error(f"Error loading policy selection history: {e}")
    
    def _save_history(self):
        """Save policy selection history to disk."""
        history_file = os.path.join(self.history_dir, 'selection_history.json')
        try:
            with open(history_file, 'w') as f:
                json.dump(self.selection_history, f, indent=2)
            logger.debug("Saved policy selection history")
        except Exception as e:
            logger.error(f"Error saving policy selection history: {e}")
    
    def run_benchmark(self) -> Dict[str, Any]:
        """
        Run a benchmark to compare policy performance.
        
        Returns:
            Dict[str, Any]: Benchmark results
        """
        logger.info("Running policy benchmark for auto selection")
        
        # Create benchmark
        benchmark = PolicyBenchmark(
            test_period_days=self.benchmark_period_days,
            initial_capital=10000.0,
            backtest_interval_hours=24
        )
        
        # Run benchmark
        results = benchmark.run_benchmark()
        
        # Save results with timestamp
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        results_filename = f"auto_selection_{timestamp}.json"
        benchmark.save_results(results_filename)
        
        return results
    
    def select_best_policy(self, benchmark_results: Dict[str, Any]) -> Tuple[str, Dict[str, Any]]:
        """
        Select the best policy based on benchmark results.
        
        Args:
            benchmark_results: Results from benchmark run
            
        Returns:
            Tuple[str, Dict[str, Any]]: Policy name and details
        """
        if not benchmark_results:
            logger.error("No benchmark results to analyze")
            return None, None
        
        # Extract performance metrics for each policy
        metrics = {}
        for policy_name, result in benchmark_results.items():
            # Calculate a composite score
            # Higher score is better
            score = 0.0
            
            # Primary metric
            if self.selection_metric == 'sharpe_ratio':
                # Higher Sharpe ratio is better
                score += result.get('sharpe_ratio', 0) * 5.0
            elif self.selection_metric == 'total_return':
                # Higher return is better
                score += result.get('total_return', 0) * 3.0
            else:
                # Default to Sharpe if invalid metric
                score += result.get('sharpe_ratio', 0) * 5.0
            
            # Secondary metrics
            # Lower max drawdown is better
            score -= result.get('max_drawdown', 0) * 2.0
            
            # Lower volatility is moderately better (unless seeking aggressive growth)
            score -= result.get('volatility', 0) * 1.0
            
            # Store metrics
            metrics[policy_name] = {
                'score': score,
                'sharpe_ratio': result.get('sharpe_ratio', 0),
                'total_return': result.get('total_return', 0),
                'max_drawdown': result.get('max_drawdown', 0),
                'volatility': result.get('volatility', 0),
                'rotation_count': result.get('rotation_count', 0)
            }
        
        # Find policy with highest score
        best_policy = max(metrics.items(), key=lambda x: x[1]['score'])
        policy_name = best_policy[0]
        policy_metrics = best_policy[1]
        
        logger.info(f"Selected best policy: {policy_name} with score {policy_metrics['score']:.4f}")
        
        return policy_name, policy_metrics
    
    def apply_policy(self, policy_name: str) -> bool:
        """
        Apply the selected policy to the auto-rotation engine.
        
        Args:
            policy_name: Name of the policy to apply
            
        Returns:
            bool: Success status
        """
        if not policy_name:
            logger.error("No policy name provided")
            return False
        
        try:
            # Enable this policy and disable others
            for policy in auto_rotation_engine.get_policies():
                # Skip if this is the policy we want to enable
                if policy_name in policy.name.lower():
                    auto_rotation_engine.enable_policy(policy.name)
                    logger.info(f"Enabled policy: {policy.name}")
                else:
                    auto_rotation_engine.disable_policy(policy.name)
                    logger.info(f"Disabled policy: {policy.name}")
            
            # Run rotation immediately
            auto_rotation_engine.check_and_rotate_weights()
            
            # Update last selected policy
            self.last_selected_policy = policy_name
            
            return True
        except Exception as e:
            logger.error(f"Error applying policy {policy_name}: {e}")
            return False
    
    def record_selection(self, policy_name: str, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """
        Record the policy selection with relevant metrics.
        
        Args:
            policy_name: Selected policy name
            metrics: Policy performance metrics
            
        Returns:
            Dict[str, Any]: Selection record
        """
        record = {
            'timestamp': datetime.datetime.now().isoformat(),
            'policy_name': policy_name,
            'metrics': metrics,
            'market_conditions': self._get_market_conditions()
        }
        
        # Add to history
        self.selection_history.append(record)
        
        # Keep history to a reasonable size
        if len(self.selection_history) > 100:
            self.selection_history = self.selection_history[-100:]
        
        # Save history
        self._save_history()
        
        return record
    
    def _get_market_conditions(self) -> Dict[str, Any]:
        """
        Get current market conditions.
        
        Returns:
            Dict[str, Any]: Market condition metrics
        """
        # This could be expanded to include more detailed market analysis
        # For now, just include basic volatility estimate
        tracker = PerformanceTracker(data_dir=self.data_dir)
        
        # Get recent trade data
        strategies_perf = tracker.get_strategy_performance()
        
        # Calculate rough volatility estimate
        volatility = 0.0
        trade_count = 0
        
        for strategy, perf in strategies_perf.items():
            trades = perf.get('trade_list', [])
            if trades:
                returns = [trade.get('pnl', 0) for trade in trades[-20:]]  # Last 20 trades
                if returns:
                    # Simple volatility estimate: standard deviation of returns
                    mean_return = sum(returns) / len(returns)
                    variance = sum((r - mean_return) ** 2 for r in returns) / len(returns)
                    strategy_vol = variance ** 0.5
                    
                    volatility += strategy_vol
                    trade_count += 1
        
        # Average volatility across strategies
        if trade_count > 0:
            volatility /= trade_count
        
        # Categorize market condition
        condition = "unknown"
        if volatility > 0.05:
            condition = "high_volatility"
        elif volatility > 0.02:
            condition = "medium_volatility"
        else:
            condition = "low_volatility"
        
        return {
            'volatility': volatility,
            'condition': condition,
            'trade_count': trade_count
        }
    
    def run_selection(self) -> Dict[str, Any]:
        """
        Run a complete selection cycle:
        1. Run benchmark
        2. Select best policy
        3. Apply the policy
        4. Record the selection
        
        Returns:
            Dict[str, Any]: Selection details
        """
        if not self.is_enabled:
            logger.info("Auto policy selection is disabled")
            return {'success': False, 'reason': 'disabled'}
        
        try:
            # Update last run time
            self.last_run_time = datetime.datetime.now()
            
            # Run benchmark
            benchmark_results = self.run_benchmark()
            
            # Select best policy
            policy_name, metrics = self.select_best_policy(benchmark_results)
            
            if not policy_name:
                return {'success': False, 'reason': 'selection_failed'}
            
            # Apply policy
            success = self.apply_policy(policy_name)
            
            if not success:
                return {'success': False, 'reason': 'application_failed'}
            
            # Record selection
            record = self.record_selection(policy_name, metrics)
            
            return {
                'success': True,
                'policy_name': policy_name,
                'metrics': metrics,
                'timestamp': self.last_run_time.isoformat()
            }
        except Exception as e:
            logger.error(f"Error in selection cycle: {e}")
            return {'success': False, 'reason': str(e)}
    
    def _scheduler_loop(self):
        """Background thread for running the scheduler."""
        logger.info("Starting policy selection scheduler")
        
        # Set up schedule
        schedule.every().day.at(self.schedule_time).do(self.run_selection)
        
        # Run indefinitely
        while self.scheduler_running:
            schedule.run_pending()
            time.sleep(60)  # Check every minute
            
            # Also check if we need to run based on interval
            if self.last_run_time:
                elapsed_minutes = (datetime.datetime.now() - self.last_run_time).total_seconds() / 60
                if elapsed_minutes >= self.check_interval_minutes:
                    logger.info(f"Running policy selection due to interval ({self.check_interval_minutes} minutes elapsed)")
                    self.run_selection()
        
        logger.info("Policy selection scheduler stopped")
    
    def start_scheduler(self):
        """Start the background scheduler thread."""
        if self.thread and self.thread.is_alive():
            logger.warning("Scheduler already running")
            return
        
        self.scheduler_running = True
        self.thread = threading.Thread(target=self._scheduler_loop)
        self.thread.daemon = True  # Thread will exit when main program exits
        self.thread.start()
        
        logger.info(f"Auto policy selection scheduled to run daily at {self.schedule_time}")
    
    def stop_scheduler(self):
        """Stop the background scheduler thread."""
        self.scheduler_running = False
        
        if self.thread:
            self.thread.join(timeout=2.0)  # Wait for thread to exit
            self.thread = None
        
        logger.info("Auto policy selection scheduler stopped")
    
    def enable(self):
        """Enable auto policy selection."""
        self.is_enabled = True
        if not self.scheduler_running:
            self.start_scheduler()
    
    def disable(self):
        """Disable auto policy selection."""
        self.is_enabled = False
        if self.scheduler_running:
            self.stop_scheduler()
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get current status of auto policy selection.
        
        Returns:
            Dict[str, Any]: Status information
        """
        return {
            'is_enabled': self.is_enabled,
            'scheduler_running': self.scheduler_running and (self.thread and self.thread.is_alive()),
            'last_run_time': self.last_run_time.isoformat() if self.last_run_time else None,
            'last_selected_policy': self.last_selected_policy,
            'schedule_time': self.schedule_time,
            'check_interval_minutes': self.check_interval_minutes,
            'selection_metric': self.selection_metric,
            'benchmark_period_days': self.benchmark_period_days,
            'selection_count': len(self.selection_history)
        }
    
    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get policy selection history.
        
        Args:
            limit: Maximum number of records to return
            
        Returns:
            List[Dict[str, Any]]: Selection history
        """
        # Return most recent records first
        return sorted(self.selection_history, key=lambda x: x['timestamp'], reverse=True)[:limit]


# Create global instance
auto_policy_selector = AutoPolicySelector(data_dir='./data')