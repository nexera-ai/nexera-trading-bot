#!/usr/bin/env python3
"""
Rotation Logic Test Runner

This script executes the comprehensive test suite for the Auto-Rotation Engine
and generates a detailed report of the results.

Usage:
    python run_rotation_tests.py

Output:
    - Prints test results to console
    - Generates a detailed HTML report (optional)
    - Saves test results to a JSON file for future comparison
"""

import os
import sys
import json
import datetime
import unittest
from rotation_test_updated import run_tests

# Optional: Add HTML report generation if HtmlTestRunner is installed
try:
    import HtmlTestRunner
    HTML_REPORT_AVAILABLE = True
except ImportError:
    HTML_REPORT_AVAILABLE = False


def generate_summary(test_result):
    """Generate a summary of test results"""
    summary = {
        "timestamp": datetime.datetime.now().isoformat(),
        "total": test_result.testsRun,
        "failures": len(test_result.failures),
        "errors": len(test_result.errors),
        "skipped": len(test_result.skipped) if hasattr(test_result, 'skipped') else 0,
        "success": test_result.wasSuccessful(),
        "success_percentage": (test_result.testsRun - len(test_result.failures) - len(test_result.errors)) / test_result.testsRun * 100 if test_result.testsRun > 0 else 0
    }
    
    # Add detailed results
    if test_result.failures:
        summary["failure_details"] = []
        for test, traceback in test_result.failures:
            summary["failure_details"].append({
                "test": str(test),
                "traceback": traceback
            })
    
    if test_result.errors:
        summary["error_details"] = []
        for test, traceback in test_result.errors:
            summary["error_details"].append({
                "test": str(test),
                "traceback": traceback
            })
    
    return summary


def save_results(summary, filename="rotation_test_results.json"):
    """Save test results to JSON file"""
    try:
        # Check if previous results exist
        if os.path.exists(filename):
            with open(filename, 'r') as f:
                results_history = json.load(f)
        else:
            results_history = {"results": []}
        
        # Add current results
        results_history["results"].append(summary)
        results_history["last_run"] = summary["timestamp"]
        
        # Save updated history
        with open(filename, 'w') as f:
            json.dump(results_history, f, indent=2)
        
        print(f"\nResults saved to {filename}")
        
    except Exception as e:
        print(f"Error saving results: {e}")


def print_summary(summary):
    """Print test summary to console"""
    print("\n" + "="*50)
    print(" ROTATION ENGINE TEST RESULTS")
    print("="*50)
    print(f"Time: {summary['timestamp']}")
    print(f"Total Tests: {summary['total']}")
    print(f"Success: {summary['success_percentage']:.2f}%")
    print(f"Passed: {summary['total'] - summary['failures'] - summary['errors']}")
    print(f"Failed: {summary['failures']}")
    print(f"Errors: {summary['errors']}")
    if 'skipped' in summary:
        print(f"Skipped: {summary['skipped']}")
    print("="*50)
    
    # Print failure details
    if summary.get('failure_details'):
        print("\nFailures:")
        for i, failure in enumerate(summary['failure_details'], 1):
            print(f"\n{i}. {failure['test']}")
            print("-"*40)
            print(failure['traceback'])
    
    # Print error details
    if summary.get('error_details'):
        print("\nErrors:")
        for i, error in enumerate(summary['error_details'], 1):
            print(f"\n{i}. {error['test']}")
            print("-"*40)
            print(error['traceback'])


def run_html_report():
    """Run tests with HTML report generation"""
    if not HTML_REPORT_AVAILABLE:
        print("HtmlTestRunner not installed. Run 'pip install html-testrunner' to enable HTML reports.")
        return None
    
    # Create test directory
    report_dir = "rotation_test_reports"
    os.makedirs(report_dir, exist_ok=True)
    
    # Run tests with HTML report
    from rotation_test_updated import (
        RotationPolicyTests, 
        RotationEngineTests, 
        EdgeCaseTests
    )
    
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(RotationPolicyTests))
    suite.addTest(unittest.makeSuite(RotationEngineTests))
    suite.addTest(unittest.makeSuite(EdgeCaseTests))
    
    runner = HtmlTestRunner.HTMLTestRunner(
        output=report_dir,
        report_name="rotation_engine_test_report",
        combine_reports=True,
        template='report_template.html'
    )
    
    result = runner.run(suite)
    print(f"\nHTML report saved to {report_dir}/rotation_engine_test_report.html")
    return result


def main():
    """Main entry point"""
    # Check for HTML report flag
    if '--html' in sys.argv:
        result = run_html_report()
        if result is None:
            # Fall back to regular test runner
            result = run_tests()
    else:
        # Run regular tests
        result = run_tests()
    
    # Generate and print summary
    summary = generate_summary(result)
    print_summary(summary)
    
    # Save results
    save_results(summary)
    
    # Return exit code based on test success
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    # If no arguments, use simple test runner with our specific test classes
    if len(sys.argv) == 1:
        from rotation_test_updated import (
            RotationPolicyTests, 
            RotationEngineTests, 
            EdgeCaseTests
        )
        
        suite = unittest.TestSuite()
        suite.addTest(unittest.makeSuite(RotationPolicyTests))
        suite.addTest(unittest.makeSuite(RotationEngineTests))
        suite.addTest(unittest.makeSuite(EdgeCaseTests))
        
        unittest.TextTestRunner(verbosity=2).run(suite)
    else:
        sys.exit(main())