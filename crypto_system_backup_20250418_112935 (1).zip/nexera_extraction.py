#!/usr/bin/env python3
"""
neXera Trading Platform - Final Extraction Script
-------------------------------------------------
This script creates a complete extraction of the neXera Trading Platform
for deployment on desktop environments.
"""

import os
import shutil
import datetime
import json
import sys

def create_nexera_zip():
    """Create a ZIP archive of the neXera Trading Platform."""
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_filename = f"nexera_platform_{timestamp}.zip"
    
    print(f"Starting neXera Trading Platform extraction to {zip_filename}...")
    
    # Get all Python files in the root directory
    python_files = [f for f in os.listdir('.') if f.endswith('.py')]
    
    # Define essential directories
    essential_dirs = ['templates', 'static', 'data', 'strategies', 'chart_templates']
    
    # Define essential non-Python files
    essential_files = [
        '.replit', 
        'replit.nix', 
        'pyproject.toml',
        'requirements.txt',
        'generated-icon.png',
        'README.md',
        'LICENSE'
    ]
    
    # Create requirements.txt if it doesn't exist
    if 'requirements.txt' not in os.listdir('.'):
        print("Creating requirements.txt...")
        with open('requirements.txt', 'w') as f:
            f.write("""ccxt==4.2.9
email-validator==2.1.1
flask==3.0.3
flask-sqlalchemy==3.1.1
gunicorn==23.0.0
markdown==3.6
markupsafe==2.1.5
matplotlib==3.9.0
numpy==1.26.4
openai==1.26.5
pandas==2.2.1
plotly==5.22.0
psycopg2-binary==2.9.9
schedule==1.2.1
seaborn==0.13.2
sendgrid==6.10.0
sqlalchemy==2.0.29
twilio==8.15.0
weasyprint==61.1
""")
    
    # Create README.md if it doesn't exist
    if 'README.md' not in os.listdir('.'):
        print("Creating README.md...")
        with open('README.md', 'w') as f:
            f.write("""# neXera Trading Platform

An advanced AI-driven crypto trading intelligence platform that empowers investors with autonomous strategy management and comprehensive performance optimization.

## Installation

1. Extract the ZIP file to your preferred location
2. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Run the platform:
   ```
   python main.py
   ```
4. Open your browser and navigate to http://localhost:5000

## Features

- AI-powered strategy recommendation engine
- Multiple trading strategies with modular architecture
- Performance analytics and attribution overlays
- Investor-ready PDF reports with BTC/USDT benchmark comparison
- Scheduled allocation deployment system
- Real-time alerts and notifications
- Weight allocation simulator
- Auto-rotation engine for optimal strategy performance

## License

Copyright © 2025 neXera Trading Platform. All rights reserved.
""")
    
    # Create LICENSE if it doesn't exist
    if 'LICENSE' not in os.listdir('.'):
        print("Creating LICENSE...")
        with open('LICENSE', 'w') as f:
            f.write(f"""Copyright © {datetime.datetime.now().year} neXera Trading Platform

All rights reserved.

The software and associated documentation files (the "Software") are protected by copyright laws and international copyright treaties, as well as other intellectual property laws and treaties. The Software is licensed, not sold.

UNAUTHORIZED REPRODUCTION OR DISTRIBUTION OF THIS PROGRAM, OR ANY PORTION OF IT, MAY RESULT IN SEVERE CIVIL AND CRIMINAL PENALTIES, AND WILL BE PROSECUTED TO THE MAXIMUM EXTENT POSSIBLE UNDER LAW.
""")
    
    # Create the ZIP file
    try:
        print("Adding files to ZIP archive...")
        
        # Use shutil.make_archive to create the base ZIP
        base_name = zip_filename.replace('.zip', '')
        
        # Define the files to include
        files_to_include = python_files + essential_files
        
        # Create a temporary directory for the extraction
        temp_dir = f"nexera_temp_{timestamp}"
        os.makedirs(temp_dir, exist_ok=True)
        
        # Copy all required files to the temp directory
        for file in files_to_include:
            if os.path.exists(file):
                shutil.copy2(file, os.path.join(temp_dir, file))
                print(f"Added: {file}")
            else:
                print(f"Warning: File {file} not found, skipping")
        
        # Copy all required directories to the temp directory
        for directory in essential_dirs:
            if os.path.exists(directory):
                shutil.copytree(directory, os.path.join(temp_dir, directory))
                print(f"Added directory: {directory}")
            else:
                print(f"Warning: Directory {directory} not found, skipping")
                # Create the directory to avoid errors later
                os.makedirs(os.path.join(temp_dir, directory), exist_ok=True)
        
        # Create the final ZIP archive
        shutil.make_archive(base_name, 'zip', temp_dir)
        
        # Remove the temporary directory
        shutil.rmtree(temp_dir)
        
        print(f"\nExtraction complete! Archive created: {zip_filename}")
        print(f"File size: {os.path.getsize(zip_filename) / (1024*1024):.2f} MB")
        return zip_filename
    
    except Exception as e:
        print(f"Error creating ZIP file: {e}")
        return None

if __name__ == "__main__":
    zip_file = create_nexera_zip()
    if zip_file:
        print("\nNeXera Trading Platform has been successfully extracted!")
        print("To run the platform locally:")
        print("1. Extract the ZIP file")
        print("2. Install dependencies: pip install -r requirements.txt")
        print("3. Start the platform: python main.py")
        print("4. Access the web interface at http://localhost:5000")
    else:
        print("Extraction failed. Please check the error messages above.")