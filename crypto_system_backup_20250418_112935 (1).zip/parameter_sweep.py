"""
Parameter Sweep Module for Trading Strategy Optimization

This module provides functionality to automatically test multiple parameter combinations
for trading strategies to find optimal settings. It supports various optimization methods:
- Grid Search: Test all possible combinations within defined parameter ranges
- Random Search: Test random combinations within defined parameter ranges
- Bayesian Optimization: Intelligently search parameter space (advanced)

Usage:
    optimizer = ParameterOptimizer(strategy_name='dip_buyer')
    optimizer.add_parameter('price_drop_threshold', [1.0, 1.5, 2.0, 2.5, 3.0])
    optimizer.add_parameter('price_drop_timeframe', [5, 10, 15, 20, 30])
    results = optimizer.run(ohlcv_data, method='grid')
    
    # Get best parameters based on a metric
    best_params = optimizer.get_best_params(metric='profit')
"""
import os
import time
import json
import logging
import pandas as pd
import numpy as np
import itertools
from datetime import datetime
from backtest import Backtester, load_sample_data

logger = logging.getLogger(__name__)

class ParameterOptimizer:
    """
    Parameter optimizer for trading strategies.
    
    This class provides functionality to test multiple parameter combinations
    for a trading strategy and find optimal settings.
    """
    
    def __init__(self, strategy_name, initial_balance=1000.0, symbol="BTC/USDT", timeframe="1h"):
        """
        Initialize the parameter optimizer.
        
        Args:
            strategy_name (str): Name of the strategy to optimize
            initial_balance (float, optional): Initial balance for backtests
            symbol (str, optional): Trading pair symbol
            timeframe (str, optional): Timeframe for the data
        """
        self.strategy_name = strategy_name
        self.initial_balance = initial_balance
        self.symbol = symbol
        self.timeframe = timeframe
        self.parameters = {}
        self.results = []
        self.best_results = {}
        
    def add_parameter(self, name, values):
        """
        Add a parameter to optimize.
        
        Args:
            name (str): Parameter name
            values (list): List of values to test for this parameter
        """
        self.parameters[name] = values
        
    def add_parameter_range(self, name, start, stop, num=10, log_scale=False):
        """
        Add a parameter range to optimize.
        
        Args:
            name (str): Parameter name
            start (float): Start value
            stop (float): Stop value
            num (int, optional): Number of values to generate
            log_scale (bool, optional): Whether to use logarithmic scale
        """
        if log_scale:
            values = np.logspace(np.log10(start), np.log10(stop), num)
        else:
            values = np.linspace(start, stop, num)
        
        self.parameters[name] = values.tolist()
        
    def run(self, ohlcv_data=None, method='grid', max_combinations=1000, random_samples=100):
        """
        Run the parameter optimization.
        
        Args:
            ohlcv_data (list or pd.DataFrame, optional): OHLCV data
            method (str, optional): Optimization method ('grid', 'random', 'bayesian')
            max_combinations (int, optional): Maximum number of combinations to test
            random_samples (int, optional): Number of random samples for random search
            
        Returns:
            pd.DataFrame: Results of the optimization
        """
        if not self.parameters:
            raise ValueError("No parameters to optimize. Add parameters using add_parameter() method.")
        
        # Create a directory to store results if it doesn't exist
        os.makedirs('data/optimization_results', exist_ok=True)
        
        # Generate parameter combinations based on the method
        if method == 'grid':
            param_combinations = self._get_grid_combinations(max_combinations)
        elif method == 'random':
            param_combinations = self._get_random_combinations(random_samples)
        elif method == 'bayesian':
            # Placeholder for Bayesian optimization (would require additional libraries)
            logger.warning("Bayesian optimization not implemented yet. Using random search instead.")
            param_combinations = self._get_random_combinations(random_samples)
        else:
            raise ValueError(f"Unknown optimization method: {method}")
        
        # Get OHLCV data if not provided
        if ohlcv_data is None:
            logger.info("No OHLCV data provided. Using sample data.")
            ohlcv_data = load_sample_data()
        
        # Run backtests for all parameter combinations
        total_combinations = len(param_combinations)
        self.results = []
        
        # Calculate estimated time
        estimate_per_test = 0.5  # Estimated time per test in seconds
        estimated_time = estimate_per_test * total_combinations
        
        logger.info(f"Starting parameter optimization with {total_combinations} combinations")
        logger.info(f"Estimated time: {estimated_time:.1f} seconds")
        
        start_time = time.time()
        
        for i, params in enumerate(param_combinations):
            # Log progress
            if i % 10 == 0 or i == total_combinations - 1:
                elapsed = time.time() - start_time
                progress = (i + 1) / total_combinations
                estimated_total = elapsed / progress if progress > 0 else 0
                remaining = estimated_total - elapsed
                
                logger.info(f"Progress: {i+1}/{total_combinations} ({progress:.1%}) - "
                           f"Elapsed: {elapsed:.1f}s - Remaining: {remaining:.1f}s")
            
            # Run backtest with current parameters
            try:
                backtester = Backtester(
                    strategy_name=self.strategy_name,
                    params=params,
                    initial_balance=self.initial_balance
                )
                
                results = backtester.run(
                    ohlcv_data=ohlcv_data,
                    symbol=self.symbol,
                    timeframe=self.timeframe
                )
                
                # Extract key metrics
                metrics = {
                    'total_profit': results['total_profit'],
                    'total_return_pct': results['total_return_pct'],
                    'win_rate': results['win_rate'],
                    'total_trades': results['total_trades'],
                    'max_drawdown': results['max_drawdown'],
                    'sharpe_ratio': results['sharpe_ratio'],
                    'profit_factor': results['profit_factor'],
                    'avg_profit': results['avg_profit'],
                    'avg_loss': results['avg_loss'],
                    'avg_holding_time': results['avg_holding_time'],
                    'winning_trades': results['winning_trades'],
                    'losing_trades': results['losing_trades']
                }
                
                # Add parameters to result
                result = {**params, **metrics}
                self.results.append(result)
                
            except Exception as e:
                logger.error(f"Error running backtest for parameters {params}: {e}")
        
        # Convert results to DataFrame
        results_df = pd.DataFrame(self.results)
        
        # Calculate best parameter sets for different metrics
        self.best_results = self._find_best_parameters(results_df)
        
        # Save results to CSV
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_path = f"data/optimization_results/optimization_{self.strategy_name}_{timestamp}.csv"
        results_df.to_csv(csv_path, index=False)
        
        # Save best parameters to JSON
        json_path = f"data/optimization_results/best_params_{self.strategy_name}_{timestamp}.json"
        with open(json_path, 'w') as f:
            json.dump(self.best_results, f, indent=2)
        
        logger.info(f"Optimization complete. Results saved to {csv_path} and {json_path}")
        
        return results_df
    
    def get_best_params(self, metric='balanced'):
        """
        Get the best parameters based on a metric.
        
        Args:
            metric (str, optional): Metric to use ('balanced', 'profit', 'win_rate', 'sharpe', 'drawdown', 'return')
            
        Returns:
            dict: Best parameters
        """
        if not self.best_results:
            raise ValueError("No optimization results found. Run optimize() first.")
        
        # Default metric map
        metric_map = {
            'profit': 'best_profit',
            'return': 'best_return',
            'win_rate': 'best_win_rate',
            'sharpe': 'best_sharpe',
            'drawdown': 'best_drawdown',
            'balanced': 'best_balanced'
        }
        
        # Use the instance's metric_map if it exists (might have been created in _find_best_parameters)
        if hasattr(self, 'metric_map'):
            metric_map = self.metric_map
        
        if metric not in metric_map:
            raise ValueError(f"Unknown metric: {metric}. Use one of {list(metric_map.keys())}")
        
        # Check if the requested metric result exists
        if metric_map[metric] not in self.best_results:
            # Fall back to profit if the requested metric wasn't calculated
            logger.warning(f"Metric '{metric}' results not available, falling back to 'profit'")
            return self.best_results['best_profit']
            
        return self.best_results[metric_map[metric]]
    
    def _get_grid_combinations(self, max_combinations):
        """
        Generate all possible parameter combinations (grid search).
        
        Args:
            max_combinations (int): Maximum number of combinations to generate
            
        Returns:
            list: List of parameter combinations
        """
        # Calculate total number of combinations
        total_combinations = 1
        for values in self.parameters.values():
            total_combinations *= len(values)
        
        if total_combinations > max_combinations:
            logger.warning(f"Total combinations ({total_combinations}) exceeds maximum ({max_combinations}). "
                         f"Consider using random search or reducing parameter space.")
            return self._get_random_combinations(max_combinations)
        
        # Generate all combinations
        keys = self.parameters.keys()
        values = [self.parameters[key] for key in keys]
        combinations = list(itertools.product(*values))
        
        # Convert to list of dictionaries
        return [dict(zip(keys, combo)) for combo in combinations]
    
    def _get_random_combinations(self, n_samples):
        """
        Generate random parameter combinations.
        
        Args:
            n_samples (int): Number of random samples to generate
            
        Returns:
            list: List of parameter combinations
        """
        param_combinations = []
        
        for _ in range(n_samples):
            params = {}
            for name, values in self.parameters.items():
                params[name] = np.random.choice(values)
            param_combinations.append(params)
        
        return param_combinations
    
    def _find_best_parameters(self, results_df):
        """
        Find the best parameter sets based on different metrics.
        
        Args:
            results_df (pd.DataFrame): Optimization results
            
        Returns:
            dict: Best parameter sets
        """
        best_results = {}
        
        if len(results_df) == 0:
            return best_results
        
        # Best profit
        best_profit_idx = results_df['total_profit'].idxmax()
        best_results['best_profit'] = results_df.iloc[best_profit_idx].to_dict()
        
        # Best return
        best_return_idx = results_df['total_return_pct'].idxmax()
        best_results['best_return'] = results_df.iloc[best_return_idx].to_dict()
        
        # Best win rate
        best_win_rate_idx = results_df['win_rate'].idxmax()
        best_results['best_win_rate'] = results_df.iloc[best_win_rate_idx].to_dict()
        
        # Best Sharpe ratio
        if 'sharpe_ratio' in results_df.columns:
            valid_sharpe = results_df[results_df['sharpe_ratio'].notnull() & (results_df['sharpe_ratio'] != float('inf'))]
            if len(valid_sharpe) > 0:
                best_sharpe_idx = valid_sharpe['sharpe_ratio'].idxmax()
                best_results['best_sharpe'] = results_df.iloc[best_sharpe_idx].to_dict()
        
        # Best drawdown (lowest absolute value)
        if 'max_drawdown' in results_df.columns:
            best_drawdown_idx = results_df['max_drawdown'].abs().idxmin()
            best_results['best_drawdown'] = results_df.iloc[best_drawdown_idx].to_dict()
        
        # Best balanced (weighted combination of metrics)
        try:
            # Create normalized scores for each metric (0-1 range)
            df_normalized = results_df.copy()
            
            # Metrics to normalize (higher is better)
            metrics_higher_better = [
                'total_profit', 'total_return_pct', 'win_rate', 
                'sharpe_ratio', 'profit_factor'
            ]
            
            # Metrics to normalize (lower is better)
            metrics_lower_better = [
                'max_drawdown'
            ]
            
            # Normalize metrics where higher is better
            for metric in metrics_higher_better:
                if metric in df_normalized.columns and df_normalized[metric].max() != df_normalized[metric].min():
                    df_normalized[f'{metric}_norm'] = (df_normalized[metric] - df_normalized[metric].min()) / \
                                                     (df_normalized[metric].max() - df_normalized[metric].min())
                else:
                    # If all values are the same, set normalized value to 1
                    df_normalized[f'{metric}_norm'] = 1.0
            
            # Normalize metrics where lower is better (invert so higher is better)
            for metric in metrics_lower_better:
                if metric in df_normalized.columns and df_normalized[metric].max() != df_normalized[metric].min():
                    df_normalized[f'{metric}_norm'] = 1 - (df_normalized[metric] - df_normalized[metric].min()) / \
                                                        (df_normalized[metric].max() - df_normalized[metric].min())
                else:
                    # If all values are the same, set normalized value to 1
                    df_normalized[f'{metric}_norm'] = 1.0
            
            # Calculate weighted score
            df_normalized['balanced_score'] = (
                df_normalized['total_profit_norm'] * 0.25 +           # 25% weight to total profit
                df_normalized['win_rate_norm'] * 0.25 +               # 25% weight to win rate
                df_normalized['sharpe_ratio_norm'] * 0.20 +           # 20% weight to Sharpe ratio
                df_normalized['max_drawdown_norm'] * 0.20 +           # 20% weight to drawdown
                df_normalized['profit_factor_norm'] * 0.10             # 10% weight to profit factor
            )
            
            # Get parameters with highest balanced score
            best_balanced_idx = df_normalized['balanced_score'].idxmax()
            best_results['best_balanced'] = results_df.iloc[best_balanced_idx].to_dict()
            
            # Add "balanced" to the metric_map
            self.metric_map = {
                'profit': 'best_profit',
                'return': 'best_return',
                'win_rate': 'best_win_rate',
                'sharpe': 'best_sharpe',
                'drawdown': 'best_drawdown',
                'balanced': 'best_balanced'
            }
        except Exception as e:
            logger.warning(f"Could not calculate balanced score: {e}")
        
        return best_results

def run_optimization(strategy_name, parameter_ranges, ohlcv_data=None, method='grid', 
                    symbol="BTC/USDT", timeframe="1h", initial_balance=1000.0,
                    max_combinations=1000, random_samples=100):
    """
    Convenience function to run parameter optimization.
    
    Args:
        strategy_name (str): Name of the strategy to optimize
        parameter_ranges (dict): Parameter ranges to test
        ohlcv_data (list or pd.DataFrame, optional): OHLCV data
        method (str, optional): Optimization method ('grid', 'random', 'bayesian')
        symbol (str, optional): Trading pair symbol
        timeframe (str, optional): Timeframe for the data
        initial_balance (float, optional): Initial balance for backtests
        max_combinations (int, optional): Maximum number of combinations for grid search
        random_samples (int, optional): Number of samples for random search
        
    Returns:
        pd.DataFrame: Optimization results
    """
    optimizer = ParameterOptimizer(
        strategy_name=strategy_name,
        initial_balance=initial_balance,
        symbol=symbol,
        timeframe=timeframe
    )
    
    for param_name, param_range in parameter_ranges.items():
        optimizer.add_parameter(param_name, param_range)
    
    return optimizer.run(
        ohlcv_data=ohlcv_data,
        method=method,
        max_combinations=max_combinations,
        random_samples=random_samples
    )

def run_optimization_from_config(config_file, ohlcv_data=None):
    """
    Run parameter optimization from a configuration file.
    
    Args:
        config_file (str): Path to JSON configuration file
        ohlcv_data (list or pd.DataFrame, optional): OHLCV data
        
    Returns:
        pd.DataFrame: Optimization results
    """
    with open(config_file, 'r') as f:
        config = json.load(f)
    
    return run_optimization(
        strategy_name=config['strategy_name'],
        parameter_ranges=config['parameter_ranges'],
        ohlcv_data=ohlcv_data,
        method=config.get('method', 'grid'),
        symbol=config.get('symbol', "BTC/USDT"),
        timeframe=config.get('timeframe', "1h"),
        initial_balance=config.get('initial_balance', 1000.0),
        max_combinations=config.get('max_combinations', 1000),
        random_samples=config.get('random_samples', 100)
    )

if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    
    # Define parameter ranges
    parameter_ranges = {
        'price_drop_threshold': [1.0, 1.5, 2.0, 2.5, 3.0],
        'price_drop_timeframe': [5, 10, 15, 20, 30],
        'take_profit': [2.0, 3.0, 4.0, 5.0],
        'stop_loss': [1.0, 1.5, 2.0, 2.5]
    }
    
    # Run optimization
    results = run_optimization(
        strategy_name='dip_buyer',
        parameter_ranges=parameter_ranges,
        method='grid'
    )
    
    # Print top 5 results sorted by profit
    print(results.sort_values('total_profit', ascending=False).head())