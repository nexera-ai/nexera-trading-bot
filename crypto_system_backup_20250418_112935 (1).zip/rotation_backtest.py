"""
Auto-Rotation Backtesting Module

This module extends the backtesting engine to simulate and evaluate 
the performance of the Auto-Rotation Engine over historical data.
It allows comparing the performance of static strategy allocations
versus dynamically adjusted weights through auto-rotation policies.

Key features:
- Simulates rotation events over historical data
- Tracks weight changes and their impact
- Compares performance metrics with and without rotation
- Logs detailed rotation history
"""

import os
import json
import logging
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any, Union
from copy import deepcopy

from ensemble_backtest import EnsembleBacktester
from auto_rotation import AutoRotationEngine, RotationPolicy, RotationTrigger
from auto_rotation import PerformanceBasedPolicy, TimeBasedPolicy, DegradationPolicy
from performance_tracker import PerformanceTracker
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Configure logging
logger = logging.getLogger(__name__)

class RotationBacktester:
    """
    Backtester for simulating auto-rotation of strategy weights.
    
    This class simulates how the auto-rotation engine would have performed
    over historical data, comparing performance with and without rotation.
    """
    
    def __init__(self, 
                 ensemble_backtester: EnsembleBacktester,
                 data_dir: str = './data',
                 simulation_interval_hours: int = 24):
        """
        Initialize the rotation backtester.
        
        Args:
            ensemble_backtester (EnsembleBacktester): Ensemble backtester instance
            data_dir (str): Directory for storing backtest data
            simulation_interval_hours (int): How often to check for rotations in simulation
        """
        self.ensemble_backtester = ensemble_backtester
        self.data_dir = data_dir
        self.simulation_interval_hours = simulation_interval_hours
        
        # Create rotation engine
        self.rotation_engine = AutoRotationEngine(data_dir=data_dir)
        
        # Initialize performance tracker for rotation
        self.performance_tracker = PerformanceTracker(data_dir=data_dir)
        
        # Storage for backtest results
        self.rotation_history = []
        self.baseline_results = None
        self.rotation_results = None
        
        # Ensure data directory exists
        os.makedirs(os.path.join(data_dir, 'rotation_backtests'), exist_ok=True)
        
    def add_policy(self, policy: RotationPolicy) -> None:
        """
        Add a rotation policy to be used in backtesting.
        
        Args:
            policy (RotationPolicy): Policy to add
        """
        self.rotation_engine.add_policy(policy)
        logger.info(f"Added policy to rotation backtest: {policy.__class__.__name__}")
        
    def add_default_policies(self) -> None:
        """
        Add a default set of rotation policies for testing.
        """
        # Add performance-based policy
        self.add_policy(PerformanceBasedPolicy(
            metric='win_rate',
            lookback_days=7,
            threshold=0.05,
            check_interval_hours=24
        ))
        
        # Add time-based policy
        self.add_policy(TimeBasedPolicy(
            interval_hours=72,  # Rotate every 3 days
            rotation_fraction=0.2
        ))
        
        # Add degradation detection policy
        self.add_policy(DegradationPolicy(
            metric='total_return_pct',
            lookback_days=10,
            comparison_days=3,
            threshold=5.0,
            check_interval_hours=12
        ))
        
        logger.info("Added default policies to rotation backtest")
        
    def _simulate_rotation_step(self, 
                               timestamp: datetime,
                               current_weights: Dict[str, float],
                               trade_history: List[Dict]
                               ) -> Tuple[Dict[str, float], Optional[Dict]]:
        """
        Simulate a single rotation check and potential weight update.
        
        Args:
            timestamp (datetime): Current simulation timestamp
            current_weights (Dict[str, float]): Current strategy weights
            trade_history (List[Dict]): Trade history up to current timestamp
            
        Returns:
            Tuple[Dict[str, float], Optional[Dict]]: New weights and rotation event info
        """
        # Update the performance tracker with trades up to this point
        self.performance_tracker.clear_trade_history()
        
        # Only include trades that happened before the current timestamp
        filtered_trades = [
            trade for trade in trade_history 
            if datetime.fromisoformat(trade['timestamp']) <= timestamp
        ]
        
        for trade in filtered_trades:
            self.performance_tracker.add_trade(trade)
        
        # Check if any policy triggers a rotation
        rotation_triggered = False
        triggered_policy = None
        new_weights = current_weights.copy()
        
        for policy in self.rotation_engine.get_policies():
            if policy.should_rotate(self.performance_tracker, current_weights):
                rotation_triggered = True
                triggered_policy = policy
                new_weights = policy.get_new_weights(self.performance_tracker, current_weights)
                break
                
        if rotation_triggered and triggered_policy:
            # Record the rotation event
            rotation_event = {
                'timestamp': timestamp.isoformat(),
                'trigger': triggered_policy.rotation_type.value,
                'policy_name': triggered_policy.name,
                'old_weights': current_weights.copy(),
                'new_weights': new_weights.copy(),
                'total_return_before': self.performance_tracker.get_total_return_pct(),
                'win_rate_before': self.performance_tracker.get_win_rate(),
                'sharpe_before': self.performance_tracker.get_sharpe_ratio(),
                'drawdown_before': self.performance_tracker.get_max_drawdown_pct()
            }
            
            return new_weights, rotation_event
        
        return current_weights, None
        
    def run_backtest(self, 
                    symbol: str,
                    timeframe: str,
                    start_date: datetime,
                    end_date: datetime,
                    initial_weights: Dict[str, float] = None,
                    initial_balance: float = 1000.0,
                    commission_pct: float = 0.1,
                    rotation_interval_hours: int = 24
                    ) -> Dict[str, Any]:
        """
        Run a complete rotation backtest with comparative analysis.
        
        This performs two backtests:
        1. Baseline: Fixed strategy weights throughout
        2. Auto-rotation: Weights adjusted according to policies
        
        Args:
            symbol (str): Trading pair symbol (e.g., "BTC/USDT")
            timeframe (str): Timeframe for backtest (e.g., "1h")
            start_date (datetime): Backtest start date
            end_date (datetime): Backtest end date
            initial_weights (Dict[str, float]): Starting strategy weights
            initial_balance (float): Starting account balance
            commission_pct (float): Commission percentage
            rotation_interval_hours (int): Hours between rotation checks
            
        Returns:
            Dict[str, Any]: Complete backtest results
        """
        # Ensure we have some policies
        if not self.rotation_engine.get_policies():
            logger.warning("No rotation policies added. Adding default policies.")
            self.add_default_policies()
            
        # Run the baseline backtest (no rotation)
        logger.info(f"Running baseline backtest for {symbol} from {start_date} to {end_date}")
        self.ensemble_backtester.run_backtest(
            symbol=symbol,
            timeframe=timeframe,
            start_date=start_date,
            end_date=end_date,
            weights=initial_weights,
            initial_balance=initial_balance,
            commission_pct=commission_pct
        )
        self.baseline_results = self.ensemble_backtester.get_results()
        baseline_trades = self.baseline_results.get('trades', [])
        baseline_equity = self.baseline_results.get('equity_curve', [])
        
        # Now run the rotation backtest
        logger.info(f"Running rotation backtest for {symbol} from {start_date} to {end_date}")
        
        # Make a deep copy of initial weights for rotation
        current_weights = initial_weights.copy() if initial_weights else self.ensemble_backtester.get_default_weights()
        
        # Simulation will check for rotations at specified intervals
        current_time = start_date
        rotation_check_times = []
        all_trades = []
        rotation_events = []
        
        # Generate timestamps for rotation checks
        while current_time <= end_date:
            rotation_check_times.append(current_time)
            current_time += timedelta(hours=rotation_interval_hours)
            
        # Clear old trade history
        self.performance_tracker.clear_trade_history()
        
        # Run backtests for each segment between rotation checks
        logger.info(f"Simulating {len(rotation_check_times)} rotation check points")
        
        for i in range(len(rotation_check_times) - 1):
            segment_start = rotation_check_times[i]
            segment_end = rotation_check_times[i+1]
            
            # Run a backtest segment with current weights
            segment_results = self.ensemble_backtester.run_backtest(
                symbol=symbol,
                timeframe=timeframe,
                start_date=segment_start,
                end_date=segment_end,
                weights=current_weights,
                initial_balance=initial_balance if i == 0 else None,  # Only use initial balance for first segment
                commission_pct=commission_pct,
                continue_previous=i > 0  # Continue from previous segment except for first
            )
            
            # Extract trades from this segment
            segment_trades = segment_results.get('trades', [])
            all_trades.extend(segment_trades)
            
            # Simulate rotation at the end of this segment
            new_weights, rotation_event = self._simulate_rotation_step(
                timestamp=segment_end,
                current_weights=current_weights,
                trade_history=all_trades
            )
            
            # If we had a rotation, update weights and record it
            if rotation_event:
                current_weights = new_weights
                rotation_events.append(rotation_event)
                logger.info(f"Rotation at {segment_end}: {rotation_event['policy_name']}")
                
        # Final backtest with rotation-adjusted weights to get complete results
        logger.info("Running final consolidated backtest with rotation-adjusted weights")
        self.ensemble_backtester.run_backtest_with_weight_changes(
            symbol=symbol,
            timeframe=timeframe,
            start_date=start_date,
            end_date=end_date,
            weight_changes=self._convert_rotation_events_to_weight_changes(rotation_events),
            initial_weights=initial_weights,
            initial_balance=initial_balance,
            commission_pct=commission_pct
        )
        
        self.rotation_results = self.ensemble_backtester.get_results()
        self.rotation_history = rotation_events
        
        # Prepare comparative metrics
        comparative_metrics = self._calculate_comparative_metrics()
        
        # Prepare complete results package
        results = {
            'baseline': self.baseline_results,
            'rotation': self.rotation_results,
            'rotation_history': rotation_events,
            'comparative_metrics': comparative_metrics,
            'config': {
                'symbol': symbol,
                'timeframe': timeframe,
                'start_date': start_date.isoformat(),
                'end_date': end_date.isoformat(),
                'initial_weights': initial_weights,
                'initial_balance': initial_balance,
                'commission_pct': commission_pct,
                'rotation_interval_hours': rotation_interval_hours,
                'policies': [p.name for p in self.rotation_engine.get_policies()]
            }
        }
        
        # Save results to file
        self._save_backtest_results(results)
        
        return results
    
    def _convert_rotation_events_to_weight_changes(self, rotation_events: List[Dict]) -> List[Dict]:
        """
        Convert rotation events to the format needed for backtest with weight changes.
        
        Args:
            rotation_events (List[Dict]): List of rotation events
            
        Returns:
            List[Dict]: Weight changes in the format expected by ensemble_backtester
        """
        weight_changes = []
        
        for event in rotation_events:
            weight_changes.append({
                'timestamp': event['timestamp'],
                'weights': event['new_weights']
            })
            
        return weight_changes
        
    def _calculate_comparative_metrics(self) -> Dict[str, Any]:
        """
        Calculate comparative metrics between baseline and rotation results.
        
        Returns:
            Dict[str, Any]: Comparative metrics
        """
        if not self.baseline_results or not self.rotation_results:
            return {}
            
        # Extract metrics
        baseline_metrics = self.baseline_results.get('metrics', {})
        rotation_metrics = self.rotation_results.get('metrics', {})
        
        # Calculate improvements
        comparative = {}
        
        # Handle key metrics with percentage improvements
        for key in ['total_return_pct', 'win_rate', 'profit_factor', 'sharpe_ratio']:
            if key in baseline_metrics and key in rotation_metrics:
                baseline_value = baseline_metrics[key]
                rotation_value = rotation_metrics[key]
                
                # Calculate absolute and percentage difference
                abs_diff = rotation_value - baseline_value
                pct_diff = (abs_diff / abs(baseline_value) * 100) if baseline_value != 0 else float('inf')
                
                comparative[key] = {
                    'baseline': baseline_value,
                    'rotation': rotation_value,
                    'abs_diff': abs_diff,
                    'pct_diff': pct_diff,
                    'improved': abs_diff > 0
                }
                
        # Special case for drawdown (lower is better)
        if 'max_drawdown_pct' in baseline_metrics and 'max_drawdown_pct' in rotation_metrics:
            baseline_dd = baseline_metrics['max_drawdown_pct']
            rotation_dd = rotation_metrics['max_drawdown_pct']
            
            abs_diff = baseline_dd - rotation_dd  # Positive means rotation is better (lower drawdown)
            pct_diff = (abs_diff / abs(baseline_dd) * 100) if baseline_dd != 0 else float('inf')
            
            comparative['max_drawdown_pct'] = {
                'baseline': baseline_dd,
                'rotation': rotation_dd,
                'abs_diff': abs_diff,
                'pct_diff': pct_diff,
                'improved': abs_diff > 0
            }
            
        # Add summary stats
        improved_count = sum(1 for item in comparative.values() if item.get('improved', False))
        total_count = len(comparative)
        
        comparative['summary'] = {
            'improved_metrics_count': improved_count,
            'total_metrics_count': total_count,
            'improved_metrics_pct': (improved_count / total_count * 100) if total_count > 0 else 0,
            'rotation_count': len(self.rotation_history),
            'avg_rotation_interval_days': self._calculate_avg_rotation_interval()
        }
        
        return comparative
    
    def _calculate_avg_rotation_interval(self) -> float:
        """
        Calculate the average interval between rotations in days.
        
        Returns:
            float: Average rotation interval in days
        """
        if len(self.rotation_history) <= 1:
            return 0.0
            
        intervals = []
        
        # Convert timestamps to datetime objects and sort
        timestamps = sorted([
            datetime.fromisoformat(event['timestamp']) 
            for event in self.rotation_history
        ])
        
        # Calculate intervals
        for i in range(1, len(timestamps)):
            interval = (timestamps[i] - timestamps[i-1]).total_seconds() / (60 * 60 * 24)  # Convert to days
            intervals.append(interval)
            
        return sum(intervals) / len(intervals) if intervals else 0.0
    
    def _save_backtest_results(self, results: Dict[str, Any]) -> None:
        """
        Save backtest results to file.
        
        Args:
            results (Dict[str, Any]): Backtest results
        """
        # Generate filename with timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"rotation_backtest_{timestamp}.json"
        file_path = os.path.join(self.data_dir, 'rotation_backtests', filename)
        
        # Ensure all datetime objects are converted to ISO format strings
        results_copy = deepcopy(results)
        
        # Save to file
        with open(file_path, 'w') as f:
            # Use custom JSON encoder that handles datetime objects
            class DateTimeEncoder(json.JSONEncoder):
                def default(self, obj):
                    if isinstance(obj, datetime):
                        return obj.isoformat()
                    return super().default(obj)
                    
            json.dump(results_copy, f, cls=DateTimeEncoder, indent=2)
            
        logger.info(f"Saved rotation backtest results to: {file_path}")
        
    def get_rotation_history(self) -> List[Dict]:
        """
        Get the rotation history from the backtest.
        
        Returns:
            List[Dict]: Rotation history events
        """
        return self.rotation_history
        
    def get_comparative_metrics(self) -> Dict[str, Any]:
        """
        Get comparative metrics between baseline and rotation results.
        
        Returns:
            Dict[str, Any]: Comparative metrics
        """
        return self._calculate_comparative_metrics()
        
    def create_comparison_plots(self) -> Dict[str, Any]:
        """
        Create comparison plots for baseline vs rotation results.
        
        Returns:
            Dict[str, Any]: Plotly figure objects
        """
        if not self.baseline_results or not self.rotation_results:
            return {}
            
        plots = {}
        
        # Equity curve comparison
        baseline_equity = pd.DataFrame(self.baseline_results.get('equity_curve', []))
        rotation_equity = pd.DataFrame(self.rotation_results.get('equity_curve', []))
        
        if not baseline_equity.empty and not rotation_equity.empty:
            # Ensure we have timestamp columns converted to datetime
            for df in [baseline_equity, rotation_equity]:
                if 'timestamp' in df.columns and not pd.api.types.is_datetime64_any_dtype(df['timestamp']):
                    df['timestamp'] = pd.to_datetime(df['timestamp'])
            
            # Create figure
            fig = go.Figure()
            
            fig.add_trace(go.Scatter(
                x=baseline_equity['timestamp'],
                y=baseline_equity['equity'],
                mode='lines',
                name='Baseline (Fixed Weights)',
                line=dict(color='blue')
            ))
            
            fig.add_trace(go.Scatter(
                x=rotation_equity['timestamp'],
                y=rotation_equity['equity'],
                mode='lines',
                name='Auto-Rotation',
                line=dict(color='green')
            ))
            
            # Add rotation event markers
            if self.rotation_history:
                rotation_timestamps = [datetime.fromisoformat(event['timestamp']) for event in self.rotation_history]
                
                # Find equity values at rotation points
                rotation_equity_values = []
                
                for ts in rotation_timestamps:
                    # Find closest equity value
                    idx = rotation_equity['timestamp'].searchsorted(ts)
                    if idx < len(rotation_equity):
                        rotation_equity_values.append(rotation_equity.iloc[idx]['equity'])
                    else:
                        rotation_equity_values.append(None)
                
                # Filter out None values
                valid_indices = [i for i, val in enumerate(rotation_equity_values) if val is not None]
                rotation_timestamps = [rotation_timestamps[i] for i in valid_indices]
                rotation_equity_values = [rotation_equity_values[i] for i in valid_indices]
                
                if rotation_timestamps and rotation_equity_values:
                    fig.add_trace(go.Scatter(
                        x=rotation_timestamps,
                        y=rotation_equity_values,
                        mode='markers',
                        name='Rotation Events',
                        marker=dict(color='red', size=10, symbol='triangle-up')
                    ))
            
            # Update layout
            fig.update_layout(
                title='Equity Curve Comparison: Baseline vs. Auto-Rotation',
                xaxis_title='Date',
                yaxis_title='Account Equity',
                legend=dict(
                    orientation="h",
                    yanchor="bottom",
                    y=1.02,
                    xanchor="center",
                    x=0.5
                ),
                template='plotly_dark'
            )
            
            plots['equity_curve'] = fig
            
        # Create strategy weight evolution chart
        if self.rotation_history:
            # Get all unique strategy names
            all_strategies = set()
            for event in self.rotation_history:
                all_strategies.update(event['new_weights'].keys())
            
            # Build data for each strategy
            weight_fig = go.Figure()
            
            # Initial weights
            initial_weights = self.rotation_history[0]['old_weights'] if self.rotation_history else {}
            
            for strategy in all_strategies:
                timestamps = [datetime.fromisoformat(self.rotation_history[0]['timestamp']) - timedelta(days=1)]  # Add a point before first rotation
                weights = [initial_weights.get(strategy, 0) * 100]  # Convert to percentage
                
                for event in self.rotation_history:
                    timestamps.append(datetime.fromisoformat(event['timestamp']))
                    weights.append(event['new_weights'].get(strategy, 0) * 100)  # Convert to percentage
                
                weight_fig.add_trace(go.Scatter(
                    x=timestamps,
                    y=weights,
                    mode='lines+markers',
                    name=f'{strategy} Weight %',
                    line=dict(width=3),
                    marker=dict(size=8)
                ))
            
            # Update layout
            weight_fig.update_layout(
                title='Strategy Weight Evolution Over Time',
                xaxis_title='Date',
                yaxis_title='Weight (%)',
                legend=dict(
                    orientation="h",
                    yanchor="bottom",
                    y=1.02,
                    xanchor="center",
                    x=0.5
                ),
                template='plotly_dark',
                yaxis=dict(
                    tickformat='.1f',
                    range=[0, 100]  # Set y-axis from 0 to 100%
                )
            )
            
            plots['weight_evolution'] = weight_fig
            
        # Create metrics comparison bar chart
        comparative = self._calculate_comparative_metrics()
        if comparative:
            # Filter out summary
            metric_comparisons = {k: v for k, v in comparative.items() if k != 'summary'}
            
            # Create the bar chart
            metric_fig = go.Figure()
            
            # Add bars for each metric
            metrics = list(metric_comparisons.keys())
            baseline_values = [metric_comparisons[m]['baseline'] for m in metrics]
            rotation_values = [metric_comparisons[m]['rotation'] for m in metrics]
            
            metric_fig.add_trace(go.Bar(
                x=metrics,
                y=baseline_values,
                name='Baseline',
                marker_color='blue'
            ))
            
            metric_fig.add_trace(go.Bar(
                x=metrics,
                y=rotation_values,
                name='Auto-Rotation',
                marker_color='green'
            ))
            
            # Update layout
            metric_fig.update_layout(
                title='Performance Metrics Comparison',
                xaxis=dict(title='Metric'),
                yaxis=dict(title='Value'),
                barmode='group',
                template='plotly_dark'
            )
            
            plots['metrics_comparison'] = metric_fig
            
        return plots

def backtest_with_rotation(
    symbol: str,
    timeframe: str,
    start_date: datetime,
    end_date: datetime,
    initial_weights: Dict[str, float] = None,
    rotation_interval_hours: int = 24,
    add_default_policies: bool = True
) -> Dict[str, Any]:
    """
    Convenience function to run a rotation backtest.
    
    Args:
        symbol (str): Trading pair symbol (e.g., "BTC/USDT")
        timeframe (str): Timeframe for backtest (e.g., "1h")
        start_date (datetime): Backtest start date
        end_date (datetime): Backtest end date
        initial_weights (Dict[str, float]): Starting strategy weights
        rotation_interval_hours (int): Hours between rotation checks
        add_default_policies (bool): Whether to add default rotation policies
        
    Returns:
        Dict[str, Any]: Complete backtest results
    """
    from ensemble_backtest import EnsembleBacktester
    
    # Create ensemble backtester
    ensemble_tester = EnsembleBacktester()
    
    # Create rotation backtester
    rotation_tester = RotationBacktester(
        ensemble_backtester=ensemble_tester,
        simulation_interval_hours=rotation_interval_hours
    )
    
    # Add default policies if requested
    if add_default_policies:
        rotation_tester.add_default_policies()
    
    # Run the backtest
    results = rotation_tester.run_backtest(
        symbol=symbol,
        timeframe=timeframe,
        start_date=start_date,
        end_date=end_date,
        initial_weights=initial_weights,
        rotation_interval_hours=rotation_interval_hours
    )
    
    return results