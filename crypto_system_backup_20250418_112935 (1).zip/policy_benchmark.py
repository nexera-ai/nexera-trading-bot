#!/usr/bin/env python3
"""
Adaptive Policy Benchmark Tool

This tool compares the performance of different rotation policies by
simulating portfolio growth using historical data and visualizing results.
"""

import os
import json
import logging
import datetime
from typing import Dict, List, Any, Tuple, Optional
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from collections import defaultdict

from auto_rotation import (
    AutoRotationEngine, RotationPolicy, PerformanceBasedPolicy, 
    TimeBasedPolicy, DegradationPolicy, AdaptivePerformancePolicy
)
from performance_tracker import PerformanceTracker
from ensemble_engine import EnsembleManager

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('policy_benchmark')

class PolicyBenchmark:
    """
    Compares performance of different rotation policies on historical data.
    """
    
    def __init__(self, 
                data_dir: str = './data',
                test_period_days: int = 90,
                initial_capital: float = 10000.0,
                backtest_interval_hours: int = 24):
        """
        Initialize the policy benchmark tool.
        
        Args:
            data_dir: Directory containing performance data
            test_period_days: Number of days to simulate
            initial_capital: Starting capital amount
            backtest_interval_hours: How often to evaluate rotation policies
        """
        self.data_dir = data_dir
        self.test_period_days = test_period_days
        self.initial_capital = initial_capital
        self.backtest_interval_hours = backtest_interval_hours
        
        # Create tracking directory
        self.benchmark_dir = os.path.join(data_dir, 'policy_benchmarks')
        os.makedirs(self.benchmark_dir, exist_ok=True)
        
        # Load historical trade data
        self.performance_tracker = PerformanceTracker(data_dir=data_dir)
        
        # Load or create historical market data
        self._load_market_data()
        
        # Generate simulated policies for benchmarking
        self.policies = self._create_benchmark_policies()
        
        # Store benchmark results
        self.results = {}
        
    def _load_market_data(self):
        """Load or create market volatility data for simulation."""
        volatility_file = os.path.join(self.data_dir, 'market_volatility.json')
        
        if os.path.exists(volatility_file):
            # Load existing data
            with open(volatility_file, 'r') as f:
                self.market_data = json.load(f)
        else:
            # Generate simulated market volatility data
            logger.info("Generating simulated market volatility data")
            
            # Create timestamp range
            end_date = datetime.datetime.now()
            start_date = end_date - datetime.timedelta(days=self.test_period_days)
            
            # Generate daily timestamps
            days = (end_date - start_date).days
            timestamps = [
                (start_date + datetime.timedelta(days=i)).isoformat()
                for i in range(days)
            ]
            
            # Generate volatility data with realistic patterns
            # Start with low volatility that increases and decreases
            base_volatility = 0.2
            volatility = []
            
            # Create a cyclical pattern with some random noise
            for i in range(days):
                # Cyclical component (30-day cycle)
                cycle = 0.15 * np.sin(i * 2 * np.pi / 30)
                
                # Trend component (increasing over time)
                trend = 0.1 * (i / days)
                
                # Random component
                noise = 0.05 * np.random.randn()
                
                # Combine components and ensure positive
                daily_vol = max(0.05, base_volatility + cycle + trend + noise)
                volatility.append(daily_vol)
            
            # Create the market data dictionary
            self.market_data = {
                'timestamps': timestamps,
                'volatility': volatility
            }
            
            # Save to file
            with open(volatility_file, 'w') as f:
                json.dump(self.market_data, f, indent=2)
    
    def _create_benchmark_policies(self) -> Dict[str, RotationPolicy]:
        """Create policies to benchmark against each other."""
        policies = {}
        
        # Standard performance-based policy (win rate only)
        policies['standard_performance'] = PerformanceBasedPolicy(
            metric='win_rate',
            lookback_days=7,
            check_interval_hours=24,
            min_trades=5,
            threshold=0.1
        )
        
        # Time-based policy (rotates on a schedule)
        policies['time_based'] = TimeBasedPolicy(
            rotation_interval_hours=168  # 7 days
        )
        
        # Degradation policy (rotates when performance drops)
        policies['degradation'] = DegradationPolicy(
            metric='win_rate',
            lookback_days=7,
            check_interval_hours=24,
            degradation_threshold=0.15
        )
        
        # Adaptive performance policy with default settings
        policies['adaptive_default'] = AdaptivePerformancePolicy(
            metrics={
                'win_rate': 0.35,
                'profit_factor': 0.35,
                'sharpe_ratio': 0.3
            },
            lookback_days=7,
            check_interval_hours=24,
            min_trades_required=5,
            base_threshold=0.05,
            adaptive_threshold=True,
            market_volatility_factor=0.5,
            smoothing_factor=0.3,
            max_weight_change=0.2
        )
        
        # Adaptive performance policy - reactive variant
        policies['adaptive_reactive'] = AdaptivePerformancePolicy(
            metrics={
                'win_rate': 0.4,
                'profit_factor': 0.4,
                'sharpe_ratio': 0.2
            },
            lookback_days=3,  # Shorter lookback
            check_interval_hours=12,  # More frequent checks
            min_trades_required=3,  # Fewer trades required
            base_threshold=0.03,  # Lower threshold
            adaptive_threshold=True,
            market_volatility_factor=0.3,  # Less sensitive to volatility
            smoothing_factor=0.1,  # Less smoothing (more reactive)
            max_weight_change=0.3  # Larger weight changes allowed
        )
        
        # Adaptive performance policy - conservative variant
        policies['adaptive_conservative'] = AdaptivePerformancePolicy(
            metrics={
                'win_rate': 0.3,
                'profit_factor': 0.3,
                'sharpe_ratio': 0.4
            },
            lookback_days=14,  # Longer lookback
            check_interval_hours=48,  # Less frequent checks
            min_trades_required=10,  # More trades required
            base_threshold=0.1,  # Higher threshold
            adaptive_threshold=True,
            market_volatility_factor=0.7,  # More sensitive to volatility
            smoothing_factor=0.5,  # More smoothing (less reactive)
            max_weight_change=0.1  # Smaller weight changes allowed
        )
        
        return policies
    
    def _simulate_policy_performance(self, 
                                    policy: RotationPolicy, 
                                    initial_weights: Dict[str, float],
                                    strategy_returns: Dict[str, List[float]]) -> Tuple[List[float], List[Dict[str, float]]]:
        """
        Simulate portfolio performance with the given policy.
        
        Args:
            policy: Rotation policy to test
            initial_weights: Starting strategy weights
            strategy_returns: Daily returns for each strategy
            
        Returns:
            Tuple of (equity_curve, weight_history)
        """
        # Initialize tracking variables
        days = len(next(iter(strategy_returns.values())))
        equity = [self.initial_capital]
        current_weights = initial_weights.copy()
        weight_history = [current_weights.copy()]
        
        # Get all strategy names
        strategies = list(strategy_returns.keys())
        
        # Set up simulated performance tracker
        performance_data = {}
        for strategy in strategies:
            performance_data[strategy] = {
                'win_rate': 0.5,  # Starting values
                'trades': 0,
                'wins': 0,
                'losses': 0,
                'pnl': 0.0,
                'profit_factor': 1.0,
                'trade_list': []
            }
        
        # Mock performance tracker for simulation
        class MockTracker:
            def __init__(self, perf_data):
                self.perf_data = perf_data
                
            def get_strategy_performance(self):
                return self.perf_data
                
            def update_strategy_performance(self, strategy, metrics):
                self.perf_data[strategy].update(metrics)
        
        tracker = MockTracker(performance_data)
        
        # Time tracking
        current_time = datetime.datetime.now() - datetime.timedelta(days=days)
        check_interval = datetime.timedelta(hours=self.backtest_interval_hours)
        next_check_time = current_time + check_interval
        
        # Simulate day by day
        for day in range(days):
            # Update current time
            current_time = current_time + datetime.timedelta(days=1)
            
            # Calculate portfolio return for this day
            daily_return = 0
            for strategy in strategies:
                # Apply current weight to strategy return
                strategy_weight = current_weights.get(strategy, 0)
                strategy_return = strategy_returns[strategy][day]
                daily_return += strategy_weight * strategy_return
            
            # Update equity
            new_equity = equity[-1] * (1 + daily_return)
            equity.append(new_equity)
            
            # Update performance metrics for each strategy
            for strategy in strategies:
                # Simulate trades and update metrics
                return_value = strategy_returns[strategy][day]
                
                # Every return is considered a "trade" for simplicity
                performance_data[strategy]['trades'] += 1
                
                if return_value > 0:
                    performance_data[strategy]['wins'] += 1
                else:
                    performance_data[strategy]['losses'] += 1
                    
                performance_data[strategy]['pnl'] += return_value * self.initial_capital
                performance_data[strategy]['win_rate'] = (
                    performance_data[strategy]['wins'] / performance_data[strategy]['trades']
                )
                
                # Add trade to list
                performance_data[strategy]['trade_list'].append({
                    'pnl': return_value * self.initial_capital,
                    'timestamp': current_time.isoformat()
                })
                
                # Calculate profit factor
                gross_profit = sum(max(0, t['pnl']) for t in performance_data[strategy]['trade_list'])
                gross_loss = abs(sum(min(0, t['pnl']) for t in performance_data[strategy]['trade_list']))
                
                if gross_loss > 0:
                    performance_data[strategy]['profit_factor'] = gross_profit / gross_loss
                else:
                    performance_data[strategy]['profit_factor'] = 5.0  # Cap at reasonable value
            
            # Check if we should run rotation
            if current_time >= next_check_time:
                # Set next check time
                next_check_time = current_time + check_interval
                
                # Apply policy rotation
                if policy.should_rotate(tracker, current_weights):
                    new_weights = policy.get_new_weights(tracker, current_weights)
                    current_weights = new_weights
            
            # Record weights
            weight_history.append(current_weights.copy())
        
        return equity, weight_history
    
    def _generate_random_strategy_returns(self, num_strategies: int = 4, days: int = 90) -> Dict[str, List[float]]:
        """
        Generate simulated daily returns for strategies.
        
        Args:
            num_strategies: Number of strategies to simulate
            days: Number of days to simulate
            
        Returns:
            Dictionary of strategy returns by day
        """
        strategy_returns = {}
        
        # Strategy characteristics
        characteristics = [
            # (mean_return, volatility, momentum_factor)
            (0.0015, 0.02, 0.7),    # Balanced strategy
            (0.002, 0.03, 0.5),     # Higher return, higher risk
            (0.001, 0.015, 0.8),    # Conservative
            (0.003, 0.04, 0.3),     # Aggressive, less momentum
        ]
        
        # Create strategies
        for i in range(num_strategies):
            # Get characteristics
            mean, vol, momentum = characteristics[i % len(characteristics)]
            strategy_name = f"strategy_{i+1}"
            
            # Generate returns with momentum (autocorrelation)
            returns = []
            prev_return = 0
            
            # Use market volatility to scale returns
            market_vol = self.market_data['volatility']
            
            for day in range(days):
                # Scale volatility by market conditions
                day_vol = vol * (market_vol[day] / 0.2)  # Normalize around 0.2
                
                # Generate return with momentum component
                random_component = np.random.normal(mean, day_vol)
                momentum_component = momentum * prev_return
                daily_return = momentum_component + random_component
                
                returns.append(daily_return)
                prev_return = daily_return
            
            strategy_returns[strategy_name] = returns
        
        return strategy_returns
    
    def run_benchmark(self) -> Dict[str, Any]:
        """
        Run the policy benchmark simulation.
        
        Returns:
            Dictionary of benchmark results
        """
        logger.info("Starting policy benchmark simulation")
        
        # Generate simulated strategy returns
        strategy_returns = self._generate_random_strategy_returns(
            num_strategies=4,
            days=self.test_period_days
        )
        
        # Initial equal weights
        strategies = list(strategy_returns.keys())
        initial_weights = {s: 1.0 / len(strategies) for s in strategies}
        
        # Run simulation for each policy
        results = {}
        for policy_name, policy in self.policies.items():
            logger.info(f"Simulating policy: {policy_name}")
            
            # Run simulation
            equity_curve, weight_history = self._simulate_policy_performance(
                policy=policy,
                initial_weights=initial_weights,
                strategy_returns=strategy_returns
            )
            
            # Calculate performance metrics
            total_return = (equity_curve[-1] / equity_curve[0]) - 1
            returns = [(equity_curve[i] / equity_curve[i-1]) - 1 for i in range(1, len(equity_curve))]
            
            # Annualized metrics
            annual_return = (1 + total_return) ** (365 / self.test_period_days) - 1
            volatility = np.std(returns) * np.sqrt(365)
            sharpe = annual_return / volatility if volatility > 0 else 0
            
            # Maximum drawdown
            peak = equity_curve[0]
            max_drawdown = 0
            for value in equity_curve:
                if value > peak:
                    peak = value
                drawdown = (peak - value) / peak
                max_drawdown = max(max_drawdown, drawdown)
            
            # Count rotations (weight changes)
            rotation_count = 0
            for i in range(1, len(weight_history)):
                if weight_history[i] != weight_history[i-1]:
                    rotation_count += 1
            
            # Store results
            results[policy_name] = {
                'equity_curve': equity_curve,
                'weight_history': weight_history,
                'total_return': total_return,
                'annual_return': annual_return,
                'volatility': volatility,
                'sharpe_ratio': sharpe,
                'max_drawdown': max_drawdown,
                'rotation_count': rotation_count
            }
        
        self.results = results
        return results
    
    def plot_results(self, save_path: Optional[str] = None):
        """
        Plot benchmark results.
        
        Args:
            save_path: Path to save the plot, if None, display only
        """
        if not self.results:
            logger.error("No benchmark results to plot. Run benchmark first.")
            return
        
        # Create a larger figure with subplots
        fig = plt.figure(figsize=(15, 10))
        
        # 1. Equity curves
        ax1 = plt.subplot2grid((2, 2), (0, 0), colspan=2)
        for policy_name, result in self.results.items():
            equity = result['equity_curve']
            ax1.plot(equity, label=policy_name)
        
        ax1.set_title('Policy Performance Comparison')
        ax1.set_ylabel('Portfolio Value ($)')
        ax1.legend()
        ax1.grid(True)
        
        # Format y-axis as currency
        ax1.get_yaxis().set_major_formatter(
            plt.FuncFormatter(lambda x, loc: f"${x:,.0f}")
        )
        
        # 2. Performance metrics table
        ax2 = plt.subplot2grid((2, 2), (1, 0))
        metrics = ['total_return', 'annual_return', 'sharpe_ratio', 
                   'volatility', 'max_drawdown', 'rotation_count']
        
        # Prepare data for table
        labels = ['Policy', 'Total Return', 'Annual Return', 'Sharpe Ratio', 
                  'Volatility', 'Max Drawdown', 'Rotations']
        
        table_data = []
        for policy_name in self.results:
            row = [policy_name]
            for metric in metrics:
                value = self.results[policy_name][metric]
                
                # Format as percentage for returns and drawdown
                if metric in ['total_return', 'annual_return', 'max_drawdown']:
                    formatted = f"{value*100:.2f}%"
                elif metric == 'sharpe_ratio':
                    formatted = f"{value:.2f}"
                elif metric == 'volatility':
                    formatted = f"{value*100:.2f}%"
                else:
                    formatted = f"{value}"
                    
                row.append(formatted)
            table_data.append(row)
        
        # No axes needed for table
        ax2.axis('off')
        ax2.table(
            cellText=table_data,
            colLabels=labels,
            loc='center',
            cellLoc='center'
        )
        
        # 3. Weight dynamics
        ax3 = plt.subplot2grid((2, 2), (1, 1))
        
        # Select a policy to show weight changes (adaptive_default)
        policy_to_show = 'adaptive_default'
        if policy_to_show in self.results:
            weight_history = self.results[policy_to_show]['weight_history']
            strategies = list(weight_history[0].keys())
            
            # Convert to dataframe for easier plotting
            weights_df = pd.DataFrame(weight_history)
            
            # Plot stacked area chart
            ax3.stackplot(
                range(len(weight_history)),
                [weights_df[s] for s in strategies],
                labels=strategies,
                alpha=0.7
            )
            
            ax3.set_title(f'Weight Dynamics - {policy_to_show}')
            ax3.set_xlabel('Days')
            ax3.set_ylabel('Weight')
            ax3.legend(loc='upper right', fontsize='small')
            ax3.grid(True)
        
        plt.tight_layout()
        
        # Save or show
        if save_path:
            plt.savefig(save_path)
            logger.info(f"Plot saved to {save_path}")
        else:
            plt.show()
    
    def save_results(self, filename: Optional[str] = None):
        """
        Save benchmark results to a file.
        
        Args:
            filename: Filename to save results, if None, use timestamp
        """
        if not self.results:
            logger.error("No benchmark results to save. Run benchmark first.")
            return
        
        # Generate filename if not provided
        if filename is None:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"policy_benchmark_{timestamp}.json"
        
        filepath = os.path.join(self.benchmark_dir, filename)
        
        # Prepare data for saving (convert numpy arrays to lists)
        save_data = {}
        for policy_name, result in self.results.items():
            save_data[policy_name] = {
                'equity_curve': [float(x) for x in result['equity_curve']],
                'total_return': float(result['total_return']),
                'annual_return': float(result['annual_return']),
                'volatility': float(result['volatility']),
                'sharpe_ratio': float(result['sharpe_ratio']),
                'max_drawdown': float(result['max_drawdown']),
                'rotation_count': int(result['rotation_count'])
            }
        
        # Save to file
        with open(filepath, 'w') as f:
            json.dump(save_data, f, indent=2)
        
        logger.info(f"Benchmark results saved to {filepath}")


def main():
    """Run the policy benchmark tool."""
    # Create benchmark tool
    benchmark = PolicyBenchmark(
        test_period_days=90,
        initial_capital=10000.0,
        backtest_interval_hours=24
    )
    
    # Run benchmark
    benchmark.run_benchmark()
    
    # Save results
    benchmark.save_results()
    
    # Plot and save visualization
    plot_path = os.path.join(benchmark.benchmark_dir, 'policy_comparison.png')
    benchmark.plot_results(save_path=plot_path)
    
    print(f"Benchmark complete. Results saved to {benchmark.benchmark_dir}")


if __name__ == "__main__":
    main()