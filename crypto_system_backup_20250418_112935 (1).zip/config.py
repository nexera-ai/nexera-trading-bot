"""
Configuration settings for the trading bot.
Modify these variables to customize the bot's behavior.
"""
import os
import json
import logging

logger = logging.getLogger(__name__)

class Config:
    # Binance API credentials
    # IMPORTANT: Replace these with your actual API keys or use environment variables
    API_KEY = os.environ.get("BINANCE_API_KEY", "YOUR_BINANCE_API_KEY")
    API_SECRET = os.environ.get("BINANCE_API_SECRET", "YOUR_BINANCE_SECRET_KEY")
    
    # Trading settings
    TRADING_PAIRS = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "DOGE/USDT"]
    BASE_POSITION_SIZE = 20.0  # in USDT
    
    # Strategy selection and parameters
    ACTIVE_STRATEGY = "dip_buyer"  # Options: dip_buyer, mean_reversion, breakout
    
    # Strategy-specific parameters
    # Dip Buyer Strategy
    PRICE_DROP_THRESHOLD = 2.5  # Percentage price drop required for entry (%)
    PRICE_DROP_TIMEFRAME = 15   # Timeframe to check for price drop (minutes)
    
    # Mean Reversion Strategy
    MA_PERIOD = 20              # Moving average period
    STD_DEV_MULTIPLIER = 2.0    # Standard deviation multiplier for bands
    
    # Breakout Strategy
    LOOKBACK_PERIOD = 24        # Period to look back for resistance/support levels
    CONFIRMATION_CANDLES = 3    # Number of candles to confirm breakout
    VOLUME_INCREASE = 1.5       # Minimum volume increase factor for valid breakout
    
    # Common strategy parameters
    TAKE_PROFIT = 3.0           # Take profit percentage (%)
    STOP_LOSS = 1.5             # Stop loss percentage (%)
    
    # Operational settings
    CHECK_INTERVAL = 300  # Time between checks (seconds) - 5 minutes
    MAX_OPEN_POSITIONS = 5  # Maximum number of simultaneous open positions
    
    # Features
    PAPER_TRADING = True  # Set to False for real trading
    REINVEST_PROFITS = True  # Enable profit compounding
    
    # Exchange settings
    EXCHANGE_ID = "binance"  # Exchange to use through CCXT
    TEST_MODE = False  # Use binance testnet if True
    
    # Safety settings
    # Trade size limits
    MAX_TRADE_SIZE_USD = 100.0  # Maximum trade size in USD
    MAX_TRADE_SIZE_PCT = 2.0    # Maximum trade size as percentage of total balance
    
    # Loss limits
    MAX_DAILY_LOSS_USD = 50.0   # Maximum daily loss in USD
    MAX_DAILY_LOSS_PCT = 5.0    # Maximum daily loss as percentage of balance
    
    # Trade frequency limits
    MIN_TRADE_INTERVAL_SECONDS = 60  # Minimum time between trades (cooldown)
    MAX_TRADES_PER_HOUR = 5         # Maximum number of trades per hour
    MAX_TRADES_PER_DAY = 20         # Maximum number of trades per day
    
    # Asset exposure limits
    MAX_SINGLE_ASSET_EXPOSURE_PCT = 15.0  # Maximum exposure to a single asset
    MAX_TOTAL_EXPOSURE_PCT = 50.0         # Maximum total exposure across all assets
    
    # Emergency stop
    EMERGENCY_STOP_ACTIVE = False         # Emergency stop switch
    
    # API safety
    REQUIRE_TRADE_ONLY_API_PERMISSIONS = True  # Require API keys with only trade permissions
    
    # Safety mode
    LIVE_TRADING_ENABLED = False           # Whether live trading is enabled
    SAFETY_MODE_LEVEL = "strict"           # Safety mode: strict, moderate, minimal
    
    # Default parameter values for reset
    @classmethod
    def _get_defaults(cls):
        return {
            # Strategy parameters
            "PRICE_DROP_THRESHOLD": 2.5,
            "PRICE_DROP_TIMEFRAME": 15,
            "MA_PERIOD": 20,
            "STD_DEV_MULTIPLIER": 2.0,
            "LOOKBACK_PERIOD": 24,
            "CONFIRMATION_CANDLES": 3,
            "VOLUME_INCREASE": 1.5,
            "TAKE_PROFIT": 3.0,
            "STOP_LOSS": 1.5,
            "MAX_OPEN_POSITIONS": 5,
            "BASE_POSITION_SIZE": 20.0,
            "REINVEST_PROFITS": True,
            
            # Safety parameters
            "MAX_TRADE_SIZE_USD": 100.0,
            "MAX_TRADE_SIZE_PCT": 2.0,
            "MAX_DAILY_LOSS_USD": 50.0,
            "MAX_DAILY_LOSS_PCT": 5.0,
            "MIN_TRADE_INTERVAL_SECONDS": 60,
            "MAX_TRADES_PER_HOUR": 5,
            "MAX_TRADES_PER_DAY": 20,
            "MAX_SINGLE_ASSET_EXPOSURE_PCT": 15.0,
            "MAX_TOTAL_EXPOSURE_PCT": 50.0,
            "EMERGENCY_STOP_ACTIVE": False,
            "REQUIRE_TRADE_ONLY_API_PERMISSIONS": True,
            "LIVE_TRADING_ENABLED": False,
            "SAFETY_MODE_LEVEL": "strict"
        }
    
    @classmethod
    def reset_to_defaults(cls):
        """Reset parameters to default values."""
        defaults = cls._get_defaults()
        for param, value in defaults.items():
            setattr(cls, param, value)
        logger.info("Config parameters reset to defaults")
        return defaults
    
    @classmethod
    def get_strategy_params(cls):
        """
        Get the parameters for the active strategy.
        
        Returns:
            dict: Strategy parameters
        """
        common_params = {
            'take_profit': cls.TAKE_PROFIT,
            'stop_loss': cls.STOP_LOSS
        }
        
        if cls.ACTIVE_STRATEGY == 'dip_buyer':
            return {
                **common_params,
                'price_drop_threshold': cls.PRICE_DROP_THRESHOLD,
                'price_drop_timeframe': cls.PRICE_DROP_TIMEFRAME
            }
        elif cls.ACTIVE_STRATEGY == 'mean_reversion':
            return {
                **common_params,
                'ma_period': cls.MA_PERIOD,
                'std_dev_multiplier': cls.STD_DEV_MULTIPLIER
            }
        elif cls.ACTIVE_STRATEGY == 'breakout':
            return {
                **common_params,
                'lookback_period': cls.LOOKBACK_PERIOD,
                'confirmation_candles': cls.CONFIRMATION_CANDLES,
                'volume_increase': cls.VOLUME_INCREASE
            }
        else:
            return common_params
            
    @classmethod
    def get_safety_params(cls):
        """
        Get all safety-related parameters.
        
        Returns:
            dict: Safety parameters
        """
        return {
            'max_trade_size_usd': cls.MAX_TRADE_SIZE_USD,
            'max_trade_size_pct': cls.MAX_TRADE_SIZE_PCT,
            'max_daily_loss_usd': cls.MAX_DAILY_LOSS_USD,
            'max_daily_loss_pct': cls.MAX_DAILY_LOSS_PCT,
            'min_trade_interval_seconds': cls.MIN_TRADE_INTERVAL_SECONDS,
            'max_trades_per_hour': cls.MAX_TRADES_PER_HOUR,
            'max_trades_per_day': cls.MAX_TRADES_PER_DAY,
            'max_single_asset_exposure_pct': cls.MAX_SINGLE_ASSET_EXPOSURE_PCT,
            'max_total_exposure_pct': cls.MAX_TOTAL_EXPOSURE_PCT,
            'emergency_stop_active': cls.EMERGENCY_STOP_ACTIVE,
            'require_trade_only_api_permissions': cls.REQUIRE_TRADE_ONLY_API_PERMISSIONS,
            'live_trading_enabled': cls.LIVE_TRADING_ENABLED,
            'safety_mode_level': cls.SAFETY_MODE_LEVEL,
        }
