"""
Auto-Rotation Engine for Crypto Trading Bot

This module provides functionality for automatically adjusting strategy weights
based on performance metrics and other indicators. It enables the trading system
to adapt to changing market conditions by giving more weight to strategies that
are performing well.

Key features:
- Performance-based weight rotation with adaptive thresholds
- Time-based weight rotation
- Multi-metric weighted performance evaluation
- Smoothed weight transitions to prevent abrupt changes
- Degradation detection
- Strategy lock/boost functionality
- Alert generation for rotation events
- Manual override protection

Usage:
    # Initialize the rotation engine
    rotation_engine = AutoRotationEngine()
    
    # Set up a simple performance-based rotation policy
    rotation_engine.add_policy(
        PerformanceBasedPolicy(
            metric='sharpe_ratio',
            threshold=1.0,
            lookback_days=7
        )
    )
    
    # Or use the advanced adaptive policy with multiple metrics
    rotation_engine.add_policy(
        AdaptivePerformancePolicy(
            metrics={
                'win_rate': 0.4,
                'sharpe_ratio': 0.4, 
                'profit_factor': 0.2
            },
            lookback_days=7,
            smoothing_factor=0.2
        )
    )
    
    # Apply rotation
    rotation_engine.check_and_rotate_weights()
"""

import os
import json
import logging
import time
from datetime import datetime, timedelta
from typing import List, Dict, Union, Optional, Any
from enum import Enum
from abc import ABC, abstractmethod

from ensemble_engine import ensemble_manager
from performance_tracker import PerformanceTracker

# Configure logging
logger = logging.getLogger(__name__)

class RotationTrigger(Enum):
    """Types of triggers that can cause a rotation."""
    PERFORMANCE = 'performance'
    TIME = 'time'
    MANUAL = 'manual'
    DEGRADATION = 'degradation'
    VOLATILITY = 'volatility'
    SCHEDULE = 'schedule'

class RotationPolicy(ABC):
    """
    Abstract base class for rotation policies.
    
    A rotation policy defines the criteria for when and how
    strategy weights should be adjusted automatically.
    """
    
    def __init__(self, name: str, rotation_type: RotationTrigger):
        """
        Initialize a rotation policy.
        
        Args:
            name (str): Name of the policy
            rotation_type (RotationTrigger): Type of rotation trigger
        """
        self.name = name
        self.rotation_type = rotation_type
        self.last_check_time = datetime.now()
        self.last_rotation_time = None
        self.is_active = True
        
    @abstractmethod
    def should_rotate(self, tracker: PerformanceTracker, current_weights: Dict[str, float]) -> bool:
        """
        Check if a rotation should be triggered.
        
        Args:
            tracker (PerformanceTracker): Performance tracking instance
            current_weights (Dict[str, float]): Current strategy weights
            
        Returns:
            bool: True if rotation should be triggered
        """
        pass
    
    @abstractmethod
    def get_new_weights(self, tracker: PerformanceTracker, current_weights: Dict[str, float]) -> Dict[str, float]:
        """
        Calculate new weights based on the policy.
        
        Args:
            tracker (PerformanceTracker): Performance tracking instance
            current_weights (Dict[str, float]): Current strategy weights
            
        Returns:
            Dict[str, float]: New strategy weights
        """
        pass


class PerformanceBasedPolicy(RotationPolicy):
    """
    Rotation policy based on strategy performance metrics.
    
    This policy adjusts weights based on performance metrics like
    win rate, ROI, Sharpe ratio, etc.
    """
    
    def __init__(self, 
                 metric: str = 'win_rate',
                 lookback_days: int = 7,
                 check_interval_hours: int = 24,
                 threshold: float = 0.0,
                 min_weight: float = 0.1,
                 max_weight: float = 0.9):
        """
        Initialize a performance-based rotation policy.
        
        Args:
            metric (str): Performance metric to use
                ('win_rate', 'total_return_pct', 'sharpe_ratio', 'profit_factor')
            lookback_days (int): Number of days to look back for performance
            check_interval_hours (int): Hours between rotation checks
            threshold (float): Minimum performance difference to trigger rotation
            min_weight (float): Minimum weight for any strategy
            max_weight (float): Maximum weight for any strategy
        """
        super().__init__(f"Performance ({metric})", RotationTrigger.PERFORMANCE)
        self.metric = metric
        self.lookback_days = lookback_days
        self.check_interval_seconds = check_interval_hours * 3600
        self.threshold = threshold
        self.min_weight = min_weight
        self.max_weight = max_weight
    
    def should_rotate(self, tracker: PerformanceTracker, current_weights: Dict[str, float]) -> bool:
        """
        Check if rotation should be triggered based on performance.
        
        Triggers rotation if:
        1. The check interval has passed since last check
        2. There is significant performance difference between strategies
        
        Args:
            tracker (PerformanceTracker): Performance tracking instance
            current_weights (Dict[str, float]): Current strategy weights
            
        Returns:
            bool: True if rotation should be triggered
        """
        # Check if interval has passed
        now = datetime.now()
        if (now - self.last_check_time).total_seconds() < self.check_interval_seconds:
            return False
        
        # Update last check time
        self.last_check_time = now
        
        # Get performance data by strategy
        strategy_performance = tracker.get_strategy_performance()
        
        # Skip if no performance data or not enough strategies
        if not strategy_performance or len(strategy_performance) < 2:
            return False
        
        # Check if there's sufficient performance data to warrant rotation
        metric_values = {}
        for strategy, perf in strategy_performance.items():
            if strategy in current_weights and perf.get('trades', 0) > 0:
                if self.metric == 'win_rate':
                    metric_values[strategy] = perf.get('win_rate', 0.0)
                elif self.metric == 'total_return_pct':
                    metric_values[strategy] = (perf.get('pnl', 0.0) / perf.get('trades', 1)) * 100
                elif self.metric == 'sharpe_ratio':
                    # A simple approximation - use external backtesting for real Sharpe
                    returns = perf.get('pnl', 0.0)
                    trades = perf.get('trades', 1)
                    wins = perf.get('wins', 0)
                    losses = perf.get('losses', 0)
                    
                    # Avoid division by zero
                    if trades > 0 and (wins + losses) > 0:
                        avg_return = returns / trades
                        win_rate = wins / trades
                        loss_rate = losses / trades
                        
                        # Estimate standard deviation
                        if win_rate > 0 and loss_rate > 0:
                            std_dev = ((win_rate * (1 - win_rate)) ** 0.5) * abs(returns)
                            if std_dev > 0:
                                metric_values[strategy] = avg_return / std_dev
                            else:
                                metric_values[strategy] = 0.0
                        else:
                            metric_values[strategy] = 0.0
                    else:
                        metric_values[strategy] = 0.0
                elif self.metric == 'profit_factor':
                    # Gross profit / gross loss
                    # First check if the direct metric is already available
                    if 'profit_factor' in perf:
                        metric_values[strategy] = perf.get('profit_factor', 0.0)
                        continue
                    
                    # Otherwise calculate from trade_list if available, or fall back to trades for backward compatibility
                    trade_data = perf.get('trade_list', perf.get('trades', []))
                    # Only proceed with calculation if trade_data is iterable (list, not an integer)
                    if isinstance(trade_data, (list, tuple)):
                        gross_profit = sum(trade.get('pnl', 0) for trade in trade_data 
                                        if trade.get('pnl', 0) > 0)
                        gross_loss = abs(sum(trade.get('pnl', 0) for trade in trade_data 
                                          if trade.get('pnl', 0) < 0))
                    
                    if gross_loss > 0:
                        metric_values[strategy] = gross_profit / gross_loss
                    else:
                        # If no losses, profit factor is theoretically infinite
                        metric_values[strategy] = 10.0  # Cap at a high value
                else:
                    # Default to win rate if metric not recognized
                    metric_values[strategy] = perf.get('win_rate', 0.0)
        
        # Skip if not enough valid metrics
        if len(metric_values) < 2:
            return False
        
        # Check for sufficient performance difference
        max_value = max(metric_values.values())
        min_value = min(metric_values.values())
        difference = max_value - min_value
        
        # If the difference is significant, trigger rotation
        if difference > self.threshold:
            logger.info(f"Performance difference triggers rotation: {difference:.2f} > {self.threshold:.2f}")
            return True
            
        return False
    
    def get_new_weights(self, tracker: PerformanceTracker, current_weights: Dict[str, float]) -> Dict[str, float]:
        """
        Calculate new weights based on performance metrics.
        
        Strategies with better performance get higher weights.
        
        Args:
            tracker (PerformanceTracker): Performance tracking instance
            current_weights (Dict[str, float]): Current strategy weights
            
        Returns:
            Dict[str, float]: New strategy weights
        """
        # Get performance data
        strategy_performance = tracker.get_strategy_performance()
        
        # Skip if no performance data
        if not strategy_performance:
            return current_weights
        
        # Calculate metric values
        metric_values = {}
        for strategy, perf in strategy_performance.items():
            if strategy in current_weights and perf.get('trades', 0) > 0:
                if self.metric == 'win_rate':
                    metric_values[strategy] = max(0, perf.get('win_rate', 0.0))
                elif self.metric == 'total_return_pct':
                    metric_values[strategy] = max(0, (perf.get('pnl', 0.0) / perf.get('trades', 1)) * 100)
                elif self.metric == 'sharpe_ratio':
                    # For simplicity, we'll use the same approximation as in should_rotate
                    returns = perf.get('pnl', 0.0)
                    trades = perf.get('trades', 1)
                    wins = perf.get('wins', 0)
                    losses = perf.get('losses', 0)
                    
                    # Avoid division by zero
                    if trades > 0 and (wins + losses) > 0:
                        avg_return = returns / trades
                        win_rate = wins / trades
                        loss_rate = losses / trades
                        
                        # Estimate standard deviation
                        if win_rate > 0 and loss_rate > 0:
                            std_dev = ((win_rate * (1 - win_rate)) ** 0.5) * abs(returns)
                            if std_dev > 0:
                                metric_values[strategy] = max(0, avg_return / std_dev)
                            else:
                                metric_values[strategy] = 0.0
                        else:
                            metric_values[strategy] = 0.0
                    else:
                        metric_values[strategy] = 0.0
                elif self.metric == 'profit_factor':
                    # First check if the direct metric is already available
                    if 'profit_factor' in perf:
                        metric_values[strategy] = max(0, perf.get('profit_factor', 0.0))
                        continue
                    
                    # Otherwise calculate from trade_list if available, or fall back to trades for backward compatibility
                    trade_data = perf.get('trade_list', perf.get('trades', []))
                    # Only proceed with calculation if trade_data is iterable (list, not an integer)
                    if isinstance(trade_data, (list, tuple)):
                        gross_profit = sum(trade.get('pnl', 0) for trade in trade_data 
                                        if trade.get('pnl', 0) > 0)
                        gross_loss = abs(sum(trade.get('pnl', 0) for trade in trade_data 
                                          if trade.get('pnl', 0) < 0))
                    
                    if gross_loss > 0:
                        metric_values[strategy] = max(0, gross_profit / gross_loss)
                    else:
                        # If no losses, profit factor is theoretically infinite
                        metric_values[strategy] = 10.0  # Cap at a high value
                else:
                    # Default to win rate if metric not recognized
                    metric_values[strategy] = max(0, perf.get('win_rate', 0.0))
            else:
                # If no performance data, use current weight
                metric_values[strategy] = current_weights.get(strategy, 0.0)
        
        # Handle missing strategies
        for strategy in current_weights:
            if strategy not in metric_values:
                metric_values[strategy] = current_weights[strategy]
        
        # Calculate new weights proportional to metric values
        total_metric = sum(metric_values.values())
        new_weights = {}
        
        if total_metric > 0:
            for strategy, metric in metric_values.items():
                # Calculate proportional weight
                new_weight = metric / total_metric
                
                # Apply min/max constraints
                new_weight = max(self.min_weight, min(self.max_weight, new_weight))
                
                # Store new weight
                new_weights[strategy] = new_weight
        else:
            # If total metric is 0, use equal weights
            for strategy in metric_values:
                new_weights[strategy] = 1.0 / len(metric_values)
        
        # Normalize to ensure weights sum to 1.0
        weight_sum = sum(new_weights.values())
        if weight_sum > 0:
            for strategy in new_weights:
                new_weights[strategy] /= weight_sum
        
        return new_weights


class TimeBasedPolicy(RotationPolicy):
    """
    Rotation policy based on time intervals.
    
    This policy rotates weights on a fixed schedule or
    after a specified time interval.
    """
    
    def __init__(self, 
                 interval_hours: int = 24,
                 rotation_fraction: float = 0.2):
        """
        Initialize a time-based rotation policy.
        
        Args:
            interval_hours (int): Hours between rotations
            rotation_fraction (float): Fraction of weight to rotate
        """
        super().__init__("Time-based", RotationTrigger.TIME)
        self.interval_seconds = interval_hours * 3600
        self.rotation_fraction = rotation_fraction
    
    def should_rotate(self, tracker: PerformanceTracker, current_weights: Dict[str, float]) -> bool:
        """
        Check if rotation should be triggered based on time.
        
        Args:
            tracker (PerformanceTracker): Performance tracking instance
            current_weights (Dict[str, float]): Current strategy weights
            
        Returns:
            bool: True if rotation should be triggered
        """
        now = datetime.now()
        
        # If this is the first check, store time but don't rotate
        if self.last_rotation_time is None:
            self.last_rotation_time = now
            return False
        
        # Check if interval has passed
        if (now - self.last_rotation_time).total_seconds() >= self.interval_seconds:
            return True
            
        return False
    
    def get_new_weights(self, tracker: PerformanceTracker, current_weights: Dict[str, float]) -> Dict[str, float]:
        """
        Calculate new weights based on time rotation.
        
        For time-based rotation, we'll use recent performance 
        to gradually adjust the weights.
        
        Args:
            tracker (PerformanceTracker): Performance tracking instance
            current_weights (Dict[str, float]): Current strategy weights
            
        Returns:
            Dict[str, float]: New strategy weights
        """
        # Update last rotation time
        self.last_rotation_time = datetime.now()
        
        # Get performance metrics for each strategy
        strategy_performance = tracker.get_strategy_performance()
        
        # If no performance data, keep current weights
        if not strategy_performance:
            return current_weights
            
        # Get win rates for strategies
        win_rates = {}
        for strategy, perf in strategy_performance.items():
            if strategy in current_weights and perf.get('trades', 0) > 0:
                win_rates[strategy] = max(0, perf.get('win_rate', 0.0))
            else:
                win_rates[strategy] = 0.0
        
        # If no win rates, keep current weights
        if not win_rates or sum(win_rates.values()) == 0:
            return current_weights
            
        # Calculate target weights based on win rates
        total_win_rate = sum(win_rates.values())
        target_weights = {}
        
        for strategy, win_rate in win_rates.items():
            if total_win_rate > 0:
                target_weights[strategy] = win_rate / total_win_rate
            else:
                target_weights[strategy] = current_weights.get(strategy, 0.0)
        
        # For strategies not in win_rates, keep current weight
        for strategy in current_weights:
            if strategy not in target_weights:
                target_weights[strategy] = current_weights[strategy]
        
        # Calculate new weights by moving fraction of the way toward target
        new_weights = {}
        for strategy, current_weight in current_weights.items():
            target = target_weights.get(strategy, 0.0)
            
            # Move a fraction of the way toward the target
            weight_change = (target - current_weight) * self.rotation_fraction
            new_weights[strategy] = current_weight + weight_change
        
        # Normalize new weights
        weight_sum = sum(new_weights.values())
        if weight_sum > 0:
            for strategy in new_weights:
                new_weights[strategy] /= weight_sum
        
        return new_weights


class DegradationPolicy(RotationPolicy):
    """
    Rotation policy that detects when strategies are degrading in performance.
    
    This policy reduces the weight of strategies that show significant 
    deterioration in performance over time.
    """
    
    def __init__(self, 
                 metric: str = 'win_rate',
                 lookback_days: int = 14,
                 comparison_days: int = 7,
                 threshold: float = 10.0,
                 check_interval_hours: int = 6):
        """
        Initialize a degradation detection policy.
        
        Args:
            metric (str): Performance metric to monitor
            lookback_days (int): Total days to look back
            comparison_days (int): Days to use for recent comparison
            threshold (float): Percent threshold for degradation
            check_interval_hours (int): Hours between checks
        """
        super().__init__("Degradation Detection", RotationTrigger.DEGRADATION)
        self.metric = metric
        self.lookback_days = lookback_days
        self.comparison_days = comparison_days
        self.threshold = threshold
        self.check_interval_seconds = check_interval_hours * 3600
    
    def should_rotate(self, tracker: PerformanceTracker, current_weights: Dict[str, float]) -> bool:
        """
        Check if any strategy is showing performance degradation.
        
        Args:
            tracker (PerformanceTracker): Performance tracking instance
            current_weights (Dict[str, float]): Current strategy weights
            
        Returns:
            bool: True if degradation is detected
        """
        # Check if interval has passed
        now = datetime.now()
        if (now - self.last_check_time).total_seconds() < self.check_interval_seconds:
            return False
        
        # Update last check time
        self.last_check_time = now
        
        # Get recent trades for analysis
        recent_trades = tracker.get_recent_trades(500)  # Get last 500 trades for analysis
        
        if not recent_trades:
            return False
        
        # Sort trades by exit time
        try:
            recent_trades.sort(key=lambda t: datetime.fromisoformat(t.get('exit_time', '2020-01-01')))
        except (ValueError, TypeError):
            # If sorting fails, try to continue with unsorted trades
            pass
        
        # Split trades into two periods: "older" and "recent"
        cutoff_recent = now - timedelta(days=self.comparison_days)
        cutoff_older = now - timedelta(days=self.lookback_days)
        
        older_trades = []
        recent_trades_filtered = []
        
        for trade in recent_trades:
            try:
                exit_time = datetime.fromisoformat(trade.get('exit_time', '2020-01-01'))
                if cutoff_older < exit_time < cutoff_recent:
                    older_trades.append(trade)
                elif exit_time >= cutoff_recent:
                    recent_trades_filtered.append(trade)
            except (ValueError, TypeError):
                # Skip trades with invalid timestamps
                continue
        
        # Skip if not enough data in either period
        if len(older_trades) < 5 or len(recent_trades_filtered) < 5:
            return False
        
        # Calculate metrics by strategy for each period
        older_metrics = self._calculate_metrics_by_strategy(older_trades)
        recent_metrics = self._calculate_metrics_by_strategy(recent_trades_filtered)
        
        # Check for degradation
        for strategy, recent_metric in recent_metrics.items():
            if strategy in older_metrics and strategy in current_weights:
                older_metric = older_metrics[strategy]
                
                # Skip if older metric is 0
                if older_metric == 0:
                    continue
                
                # Calculate percent change
                percent_change = ((recent_metric - older_metric) / older_metric) * 100
                
                # Check if degradation exceeds threshold
                if percent_change < -self.threshold:
                    logger.info(f"Strategy {strategy} shows degradation: {percent_change:.1f}% (threshold: -{self.threshold}%)")
                    return True
        
        return False
    
    def get_new_weights(self, tracker: PerformanceTracker, current_weights: Dict[str, float]) -> Dict[str, float]:
        """
        Calculate new weights by reducing weight of degrading strategies.
        
        Args:
            tracker (PerformanceTracker): Performance tracking instance
            current_weights (Dict[str, float]): Current strategy weights
            
        Returns:
            Dict[str, float]: New strategy weights
        """
        # Get recent trades for analysis
        recent_trades = tracker.get_recent_trades(500)
        
        if not recent_trades:
            return current_weights
        
        # Sort trades by exit time
        try:
            recent_trades.sort(key=lambda t: datetime.fromisoformat(t.get('exit_time', '2020-01-01')))
        except (ValueError, TypeError):
            # If sorting fails, try to continue with unsorted trades
            pass
        
        # Split trades into two periods
        now = datetime.now()
        cutoff_recent = now - timedelta(days=self.comparison_days)
        cutoff_older = now - timedelta(days=self.lookback_days)
        
        older_trades = []
        recent_trades_filtered = []
        
        for trade in recent_trades:
            try:
                exit_time = datetime.fromisoformat(trade.get('exit_time', '2020-01-01'))
                if cutoff_older < exit_time < cutoff_recent:
                    older_trades.append(trade)
                elif exit_time >= cutoff_recent:
                    recent_trades_filtered.append(trade)
            except (ValueError, TypeError):
                # Skip trades with invalid timestamps
                continue
        
        # Calculate metrics by strategy for each period
        older_metrics = self._calculate_metrics_by_strategy(older_trades)
        recent_metrics = self._calculate_metrics_by_strategy(recent_trades_filtered)
        
        # Calculate degradation factors
        degradation_factors = {}
        for strategy in current_weights:
            if strategy in older_metrics and strategy in recent_metrics:
                older_metric = older_metrics[strategy]
                recent_metric = recent_metrics[strategy]
                
                # Skip if older metric is 0
                if older_metric == 0:
                    degradation_factors[strategy] = 1.0
                    continue
                
                # Calculate percent change
                percent_change = ((recent_metric - older_metric) / older_metric) * 100
                
                # Calculate degradation factor
                if percent_change < -self.threshold:
                    # Apply a stronger fixed weight reduction regardless of severity
                    # Set to 0.5 (50% reduction) for more aggressive strategy rotation
                    degradation_factors[strategy] = 0.5
                else:
                    degradation_factors[strategy] = 1.0
            else:
                degradation_factors[strategy] = 1.0
        
        # Apply degradation factors to weights
        new_weights = {}
        for strategy, weight in current_weights.items():
            factor = degradation_factors.get(strategy, 1.0)
            new_weights[strategy] = weight * factor
        
        # Normalize weights
        weight_sum = sum(new_weights.values())
        if weight_sum > 0:
            for strategy in new_weights:
                new_weights[strategy] /= weight_sum
        
        return new_weights
    
    def _calculate_metrics_by_strategy(self, trades):
        """Calculate performance metrics by strategy."""
        metrics_by_strategy = {}
        trades_by_strategy = {}
        
        for trade in trades:
            strategy = trade.get('strategy', 'unknown')
            if strategy not in trades_by_strategy:
                trades_by_strategy[strategy] = []
            trades_by_strategy[strategy].append(trade)
        
        for strategy, strategy_trades in trades_by_strategy.items():
            if self.metric == 'win_rate':
                wins = sum(1 for t in strategy_trades if t.get('pnl', 0) > 0)
                total = len(strategy_trades)
                if total > 0:
                    metrics_by_strategy[strategy] = (wins / total) * 100
                else:
                    metrics_by_strategy[strategy] = 0.0
            elif self.metric == 'avg_return':
                total_pnl = sum(t.get('pnl', 0) for t in strategy_trades)
                total = len(strategy_trades)
                if total > 0:
                    metrics_by_strategy[strategy] = total_pnl / total
                else:
                    metrics_by_strategy[strategy] = 0.0
            elif self.metric == 'profit_factor':
                gross_profit = sum(t.get('pnl', 0) for t in strategy_trades if t.get('pnl', 0) > 0)
                gross_loss = abs(sum(t.get('pnl', 0) for t in strategy_trades if t.get('pnl', 0) < 0))
                if gross_loss > 0:
                    metrics_by_strategy[strategy] = gross_profit / gross_loss
                else:
                    metrics_by_strategy[strategy] = 10.0  # Cap at high value
            else:
                # Default to win rate
                wins = sum(1 for t in strategy_trades if t.get('pnl', 0) > 0)
                total = len(strategy_trades)
                if total > 0:
                    metrics_by_strategy[strategy] = (wins / total) * 100
                else:
                    metrics_by_strategy[strategy] = 0.0
        
        return metrics_by_strategy


class StrategyLockPolicy(RotationPolicy):
    """
    Policy that allows locking or boosting specific strategies.
    
    This policy maintains fixed weights for specified strategies
    and distributes the remaining weight among others.
    """
    
    def __init__(self, locked_weights: Dict[str, float] = None, duration_hours: int = 24):
        """
        Initialize a strategy lock policy.
        
        Args:
            locked_weights (Dict[str, float]): Fixed weights for locked strategies
            duration_hours (int): How long to maintain the lock
        """
        super().__init__("Strategy Lock", RotationTrigger.MANUAL)
        self.locked_weights = locked_weights or {}
        self.duration_seconds = duration_hours * 3600
        self.lock_start_time = datetime.now()
    
    def should_rotate(self, tracker: PerformanceTracker, current_weights: Dict[str, float]) -> bool:
        """
        Check if the lock duration has expired.
        
        Args:
            tracker (PerformanceTracker): Performance tracking instance
            current_weights (Dict[str, float]): Current strategy weights
            
        Returns:
            bool: True if the lock should expire
        """
        # If no locked weights, nothing to do
        if not self.locked_weights:
            return False
        
        # Check if duration has expired
        now = datetime.now()
        if (now - self.lock_start_time).total_seconds() >= self.duration_seconds:
            # Lock has expired
            logger.info("Strategy lock duration expired")
            self.locked_weights = {}  # Clear the lock
            return True
            
        return False
    
    def get_new_weights(self, tracker: PerformanceTracker, current_weights: Dict[str, float]) -> Dict[str, float]:
        """
        Return weights with locked strategies fixed.
        
        Args:
            tracker (PerformanceTracker): Performance tracking instance
            current_weights (Dict[str, float]): Current strategy weights
            
        Returns:
            Dict[str, float]: New strategy weights
        """
        # If no locked weights, return current weights
        if not self.locked_weights:
            return current_weights
        
        # Start with current weights
        new_weights = dict(current_weights)
        
        # Calculate total weight for locked strategies
        locked_total = sum(weight for strategy, weight in self.locked_weights.items()
                          if strategy in current_weights)
        
        # Apply locked weights
        for strategy, weight in self.locked_weights.items():
            if strategy in current_weights:
                new_weights[strategy] = weight
        
        # If locked total exceeds 1.0, rescale locked weights
        if locked_total > 1.0:
            scale_factor = 1.0 / locked_total
            for strategy in self.locked_weights:
                if strategy in new_weights:
                    new_weights[strategy] *= scale_factor
            locked_total = 1.0
        
        # Distribute remaining weight among non-locked strategies
        remaining_weight = 1.0 - locked_total
        if remaining_weight > 0:
            # Identify non-locked strategies
            non_locked = [s for s in current_weights if s not in self.locked_weights]
            
            if non_locked:
                # Calculate original weight proportion for non-locked strategies
                original_total = sum(current_weights[s] for s in non_locked)
                
                if original_total > 0:
                    # Distribute based on original proportions
                    for strategy in non_locked:
                        proportion = current_weights[strategy] / original_total
                        new_weights[strategy] = remaining_weight * proportion
                else:
                    # Equal distribution if original total is 0
                    equal_weight = remaining_weight / len(non_locked)
                    for strategy in non_locked:
                        new_weights[strategy] = equal_weight
        
        return new_weights
    
    def lock_strategy(self, strategy: str, weight: float):
        """
        Lock a specific strategy at a fixed weight.
        
        Args:
            strategy (str): Strategy name
            weight (float): Fixed weight (0.0 to 1.0)
        """
        self.locked_weights[strategy] = max(0.0, min(1.0, weight))
        self.lock_start_time = datetime.now()
        logger.info(f"Locked strategy {strategy} at weight {weight:.2f}")
    
    def boost_strategy(self, strategy: str, boost_factor: float = 2.0, current_weights: Dict[str, float] = None):
        """
        Boost a strategy by a factor of its current weight.
        
        Args:
            strategy (str): Strategy name
            boost_factor (float): Factor to boost by
            current_weights (dict): Current strategy weights
        """
        if current_weights and strategy in current_weights:
            new_weight = min(0.8, current_weights[strategy] * boost_factor)
            self.lock_strategy(strategy, new_weight)
    
    def release_lock(self, strategy: str = None):
        """
        Release the lock on a strategy or all strategies.
        
        Args:
            strategy (str, optional): Strategy to unlock. If None, unlocks all.
        """
        if strategy is None:
            self.locked_weights = {}
            logger.info("Released all strategy locks")
        elif strategy in self.locked_weights:
            del self.locked_weights[strategy]
            logger.info(f"Released lock on strategy {strategy}")
    
    def extend_lock(self, hours: int):
        """
        Extend the lock duration.
        
        Args:
            hours (int): Additional hours to lock
        """
        self.duration_seconds += hours * 3600
        logger.info(f"Extended strategy lock by {hours} hours")


class RotationHistory:
    """
    Tracks the history of weight rotations.
    """
    
    def __init__(self, max_history: int = 50):
        """
        Initialize rotation history.
        
        Args:
            max_history (int): Maximum number of history entries to keep
        """
        self.history = []
        self.max_history = max_history
    
    def add_rotation(self, 
                    timestamp: datetime,
                    trigger: RotationTrigger,
                    policy_name: str,
                    old_weights: Dict[str, float],
                    new_weights: Dict[str, float]):
        """
        Add a rotation event to the history.
        
        Args:
            timestamp (datetime): When the rotation occurred
            trigger (RotationTrigger): What triggered the rotation
            policy_name (str): Name of the policy that triggered it
            old_weights (Dict[str, float]): Previous weights
            new_weights (Dict[str, float]): New weights
        """
        # Calculate the changes in weights
        weight_changes = {}
        for strategy in set(old_weights.keys()) | set(new_weights.keys()):
            old = old_weights.get(strategy, 0.0)
            new = new_weights.get(strategy, 0.0)
            change = new - old
            weight_changes[strategy] = change
        
        # Create history entry
        entry = {
            'timestamp': timestamp.isoformat(),
            'trigger': trigger.value,
            'policy': policy_name,
            'old_weights': old_weights,
            'new_weights': new_weights,
            'changes': weight_changes
        }
        
        # Add to history
        self.history.append(entry)
        
        # Trim history if needed
        if len(self.history) > self.max_history:
            self.history = self.history[-self.max_history:]
    
    def get_history(self, limit: int = None):
        """
        Get rotation history.
        
        Args:
            limit (int, optional): Maximum number of entries to return
            
        Returns:
            list: Rotation history entries
        """
        if limit:
            return self.history[-limit:]
        return self.history


class AdaptivePerformancePolicy(RotationPolicy):
    """
    Advanced performance-based rotation policy with multi-metric evaluation,
    adaptive thresholds, and smoothed transitions.
    
    This policy evaluates multiple performance metrics with assigned weights,
    adapts thresholds based on market conditions, and smooths transitions to
    prevent abrupt weight changes.
    """
    
    def __init__(self,
                 metrics: Dict[str, float] = None,
                 lookback_days: int = 7,
                 check_interval_hours: int = 12,
                 min_trades_required: int = 5,
                 base_threshold: float = 0.05,
                 adaptive_threshold: bool = True,
                 market_volatility_factor: float = 0.5,
                 smoothing_factor: float = 0.3,
                 max_weight_change: float = 0.2,
                 min_weight: float = 0.05,
                 max_weight: float = 0.7,
                 manual_override_timeout_hours: int = 24):
        """
        Initialize an adaptive performance-based rotation policy.
        
        Args:
            metrics (Dict[str, float], optional): Dict of metrics and their weights
                e.g., {'win_rate': 0.4, 'sharpe_ratio': 0.4, 'profit_factor': 0.2}
            lookback_days (int): Number of days to look back for performance
            check_interval_hours (int): Hours between rotation checks
            min_trades_required (int): Minimum trades required for evaluation
            base_threshold (float): Base threshold for triggering rotation
            adaptive_threshold (bool): Whether to adapt thresholds based on market conditions
            market_volatility_factor (float): How much market volatility affects thresholds
            smoothing_factor (float): Factor to smooth weight changes (0-1)
                0 = no smoothing, 1 = no change (fully smoothed)
            max_weight_change (float): Maximum change allowed per rotation (0-1)
            min_weight (float): Minimum weight for any strategy
            max_weight (float): Maximum weight for any strategy
            manual_override_timeout_hours (int): Hours to pause auto-rotation after manual overrides
        """
        super().__init__("Adaptive Multi-Metric", RotationTrigger.PERFORMANCE)
        
        # Set defaults for metrics if none provided
        self.metrics = metrics or {
            'win_rate': 0.35,
            'profit_factor': 0.35,
            'sharpe_ratio': 0.3
        }
        
        # Normalize metric weights to sum to 1.0
        total_weight = sum(self.metrics.values())
        if total_weight > 0:
            for metric in self.metrics:
                self.metrics[metric] /= total_weight
        
        self.lookback_days = lookback_days
        self.check_interval_seconds = check_interval_hours * 3600
        self.min_trades_required = min_trades_required
        self.base_threshold = base_threshold
        self.adaptive_threshold = adaptive_threshold
        self.market_volatility_factor = market_volatility_factor
        self.smoothing_factor = max(0.0, min(1.0, smoothing_factor))  # Clamp to 0-1 range
        self.max_weight_change = max_weight_change
        self.min_weight = min_weight
        self.max_weight = max_weight
        self.manual_override_timeout = manual_override_timeout_hours * 3600  # Convert to seconds
        self.last_manual_override = None
        self.current_threshold = base_threshold
        self.last_market_volatility = 0.0
    
    def _calculate_metric_value(self, metric: str, perf: Dict[str, Any]) -> float:
        """
        Calculate the value for a specific performance metric.
        
        Args:
            metric (str): Name of the metric to calculate
            perf (Dict[str, Any]): Performance data for a strategy
            
        Returns:
            float: Calculated metric value
        """
        if metric == 'win_rate':
            return max(0, perf.get('win_rate', 0.0))
            
        elif metric == 'total_return_pct':
            return max(0, (perf.get('pnl', 0.0) / perf.get('trades', 1)) * 100)
            
        elif metric == 'sharpe_ratio':
            # For simplicity, we'll use the same approximation as in PerformanceBasedPolicy
            returns = perf.get('pnl', 0.0)
            trades = perf.get('trades', 1)
            wins = perf.get('wins', 0)
            losses = perf.get('losses', 0)
            
            # Avoid division by zero
            if trades > 0 and (wins + losses) > 0:
                avg_return = returns / trades
                win_rate = wins / trades
                loss_rate = losses / trades
                
                # Estimate standard deviation
                if win_rate > 0 and loss_rate > 0:
                    std_dev = ((win_rate * (1 - win_rate)) ** 0.5) * abs(returns)
                    if std_dev > 0:
                        return max(0, avg_return / std_dev)
            return 0.0
            
        elif metric == 'profit_factor':
            # Check if the direct metric is available
            if 'profit_factor' in perf:
                return max(0, perf.get('profit_factor', 0.0))
            
            # Otherwise calculate from trade_list if available
            trade_data = perf.get('trade_list', [])
            if isinstance(trade_data, (list, tuple)):
                gross_profit = sum(trade.get('pnl', 0) for trade in trade_data 
                               if trade.get('pnl', 0) > 0)
                gross_loss = abs(sum(trade.get('pnl', 0) for trade in trade_data 
                                 if trade.get('pnl', 0) < 0))
            
                if gross_loss > 0:
                    return max(0, gross_profit / gross_loss)
                # If no losses, profit factor is theoretically infinite
                return 10.0  # Cap at a high value
            return 0.0
            
        elif metric == 'avg_return_per_trade':
            trades = perf.get('trades', 0)
            if trades > 0:
                return max(0, perf.get('pnl', 0.0) / trades)
            return 0.0
            
        elif metric == 'max_drawdown':
            # For drawdown, lower is better, so we invert it
            drawdown = perf.get('max_drawdown', 0.0)
            if drawdown > 0:
                return max(0, 1.0 / drawdown)  # Invert so higher is better
            return 10.0  # Cap at a high value if no drawdown
            
        # Default if metric not recognized
        return max(0, perf.get('win_rate', 0.0))
    
    def _estimate_market_volatility(self, tracker: PerformanceTracker) -> float:
        """
        Estimate current market volatility from performance data.
        
        Higher values indicate more volatile market conditions.
        
        Args:
            tracker (PerformanceTracker): Performance tracking instance
            
        Returns:
            float: Estimated volatility (0.0-1.0)
        """
        # Get recent trade PnL values
        trades = []
        for strategy, perf in tracker.get_strategy_performance().items():
            trade_list = perf.get('trade_list', [])
            if isinstance(trade_list, (list, tuple)):
                trades.extend(trade.get('pnl', 0) for trade in trade_list)
        
        # If not enough trades, use a default value
        if len(trades) < 10:
            return 0.5  # Default to medium volatility
        
        # Calculate standard deviation of PnL values
        if trades:
            mean_pnl = sum(trades) / len(trades)
            variance = sum((t - mean_pnl) ** 2 for t in trades) / len(trades)
            std_dev = variance ** 0.5
            
            # Normalize to 0-1 range (higher is more volatile)
            # Use a reasonable normalization factor based on typical PnL ranges
            normalized_volatility = min(1.0, std_dev / (abs(mean_pnl) + 0.001) / 5.0)
            
            # Exponential smoothing with previous volatility estimate
            alpha = 0.7  # Smoothing factor for volatility
            smoothed_volatility = alpha * normalized_volatility + (1 - alpha) * self.last_market_volatility
            self.last_market_volatility = smoothed_volatility
            
            return smoothed_volatility
        
        return 0.5  # Default to medium volatility
    
    def _calculate_adaptive_threshold(self, tracker: PerformanceTracker) -> float:
        """
        Calculate an adaptive threshold based on market conditions.
        
        Args:
            tracker (PerformanceTracker): Performance tracking instance
            
        Returns:
            float: Adaptive threshold value
        """
        if not self.adaptive_threshold:
            return self.base_threshold
        
        # Estimate market volatility (0-1 scale)
        volatility = self._estimate_market_volatility(tracker)
        
        # In more volatile markets, we want a higher threshold to avoid
        # overreacting to temporary outperformance
        threshold = self.base_threshold * (1 + volatility * self.market_volatility_factor)
        
        logger.debug(f"Adaptive threshold: {threshold:.4f} (base: {self.base_threshold}, volatility: {volatility:.2f})")
        
        return threshold
    
    def _check_manual_override(self) -> bool:
        """
        Check if a manual override is active.
        
        Returns:
            bool: True if a manual override is active
        """
        if self.last_manual_override is None:
            return False
        
        # Check if override timeout has passed
        time_since_override = (datetime.now() - self.last_manual_override).total_seconds()
        return time_since_override < self.manual_override_timeout
        
    def is_manual_override_active(self) -> bool:
        """
        Public method to check if manual override is currently active.
        Used by the UI to display override status.
        
        Returns:
            bool: True if a manual override is active
        """
        return self._check_manual_override()
        
    def get_override_remaining_seconds(self) -> float:
        """
        Get the remaining time in seconds for the manual override.
        
        Returns:
            float: Remaining time in seconds, or 0 if no override is active
        """
        if not self.last_manual_override:
            return 0.0
            
        elapsed = (datetime.now() - self.last_manual_override).total_seconds()
        return max(0.0, self.manual_override_timeout - elapsed)
    
    def register_manual_override(self):
        """
        Register that a manual override of weights has occurred.
        This will pause auto-rotation for the configured timeout period.
        """
        self.last_manual_override = datetime.now()
        logger.info(f"Manual weight override registered. Auto-rotation paused for {self.manual_override_timeout / 3600:.1f} hours")
    
    def should_rotate(self, tracker: PerformanceTracker, current_weights: Dict[str, float]) -> bool:
        """
        Check if rotation should be triggered based on multi-metric performance.
        
        Args:
            tracker (PerformanceTracker): Performance tracking instance
            current_weights (Dict[str, float]): Current strategy weights
            
        Returns:
            bool: True if rotation should be triggered
        """
        # Check if manual override is active
        if self._check_manual_override():
            logger.debug("Auto-rotation paused due to recent manual override")
            return False
        
        # Check if interval has passed
        now = datetime.now()
        if (now - self.last_check_time).total_seconds() < self.check_interval_seconds:
            return False
        
        # Update last check time
        self.last_check_time = now
        
        # Get performance data by strategy
        strategy_performance = tracker.get_strategy_performance()
        
        # Skip if no performance data or not enough strategies
        if not strategy_performance or len(strategy_performance) < 2:
            return False
        
        # Calculate composite scores for each strategy based on weighted metrics
        composite_scores = {}
        strategies_with_data = 0
        
        for strategy, perf in strategy_performance.items():
            if strategy in current_weights and perf.get('trades', 0) >= self.min_trades_required:
                # Calculate weighted sum of normalized metrics
                score = 0.0
                for metric, weight in self.metrics.items():
                    metric_value = self._calculate_metric_value(metric, perf)
                    score += metric_value * weight
                
                composite_scores[strategy] = score
                strategies_with_data += 1
        
        # Skip if not enough strategies have sufficient data
        if strategies_with_data < 2:
            return False
        
        # Check for sufficient performance difference
        max_score = max(composite_scores.values())
        min_score = min(composite_scores.values())
        difference = max_score - min_score
        
        # Get adaptive threshold based on market conditions
        adaptive_threshold = self._calculate_adaptive_threshold(tracker)
        self.current_threshold = adaptive_threshold  # Store for reference
        
        # If the difference is significant, trigger rotation
        if difference > adaptive_threshold:
            logger.info(f"Performance difference triggers rotation: {difference:.4f} > {adaptive_threshold:.4f}")
            return True
            
        return False
    
    def get_new_weights(self, tracker: PerformanceTracker, current_weights: Dict[str, float]) -> Dict[str, float]:
        """
        Calculate new weights based on multi-metric performance scores.
        
        Implements smoothed transitions to prevent abrupt weight changes.
        
        Args:
            tracker (PerformanceTracker): Performance tracking instance
            current_weights (Dict[str, float]): Current strategy weights
            
        Returns:
            Dict[str, float]: New strategy weights
        """
        # Get performance data
        strategy_performance = tracker.get_strategy_performance()
        
        # Skip if no performance data
        if not strategy_performance:
            return current_weights
        
        # Calculate composite scores for each strategy
        composite_scores = {}
        for strategy, perf in strategy_performance.items():
            if strategy in current_weights and perf.get('trades', 0) > 0:
                # Calculate weighted sum of normalized metrics
                score = 0.0
                for metric, weight in self.metrics.items():
                    metric_value = self._calculate_metric_value(metric, perf)
                    score += metric_value * weight
                
                composite_scores[strategy] = max(0, score)
            else:
                # If no performance data, use current weight as the score
                composite_scores[strategy] = current_weights.get(strategy, 0.0)
        
        # Handle missing strategies
        for strategy in current_weights:
            if strategy not in composite_scores:
                composite_scores[strategy] = current_weights[strategy]
        
        # Calculate raw new weights proportional to scores
        raw_weights = {}
        total_score = sum(composite_scores.values())
        
        if total_score > 0:
            for strategy, score in composite_scores.items():
                raw_weights[strategy] = score / total_score
        else:
            # If total score is 0, use equal weights
            for strategy in composite_scores:
                raw_weights[strategy] = 1.0 / len(composite_scores)
        
        # Apply smoothing to prevent abrupt changes
        smoothed_weights = {}
        for strategy, new_raw_weight in raw_weights.items():
            current_weight = current_weights.get(strategy, 0.0)
            
            # Calculate smoothed weight
            smoothed_weight = current_weight * self.smoothing_factor + new_raw_weight * (1 - self.smoothing_factor)
            
            # Limit maximum change per rotation
            max_change = self.max_weight_change
            if abs(smoothed_weight - current_weight) > max_change:
                if smoothed_weight > current_weight:
                    smoothed_weight = current_weight + max_change
                else:
                    smoothed_weight = current_weight - max_change
            
            # Apply min/max constraints
            smoothed_weight = max(self.min_weight, min(self.max_weight, smoothed_weight))
            
            # Store smoothed weight
            smoothed_weights[strategy] = smoothed_weight
        
        # Normalize to ensure weights sum to 1.0
        weight_sum = sum(smoothed_weights.values())
        normalized_weights = {}
        
        if weight_sum > 0:
            for strategy, weight in smoothed_weights.items():
                normalized_weights[strategy] = weight / weight_sum
        else:
            # Fallback to equal weights if sum is 0
            for strategy in smoothed_weights:
                normalized_weights[strategy] = 1.0 / len(smoothed_weights)
        
        # Log weight changes
        logger.info(f"Adaptive rotation: Metrics used: {list(self.metrics.keys())}")
        for strategy in normalized_weights:
            old_weight = current_weights.get(strategy, 0.0)
            new_weight = normalized_weights[strategy]
            change = new_weight - old_weight
            logger.info(f"  {strategy}: {old_weight:.3f} -> {new_weight:.3f} ({change:+.3f})")
        
        return normalized_weights


class AutoRotationEngine:
    """
    Engine for automatically rotating strategy weights.
    
    This class manages various rotation policies and applies
    them to update strategy weights automatically.
    """
    
    def __init__(self, 
                 data_dir: str = './data',
                 tracker: PerformanceTracker = None):
        """
        Initialize the auto-rotation engine.
        
        Args:
            data_dir (str): Directory for storing data
            tracker (PerformanceTracker, optional): Performance tracker instance
        """
        self.data_dir = data_dir
        self.tracker = tracker or PerformanceTracker(data_dir=data_dir)
        self.policies = []
        self.is_active = False
        self.notification_hooks = []
        self.history = RotationHistory()
        self.last_manual_update = None
        
        # Create data directory if it doesn't exist
        os.makedirs(data_dir, exist_ok=True)
        
        # Load config if available
        self._load_config()
    
    def _load_config(self):
        """Load rotation engine configuration."""
        config_path = os.path.join(self.data_dir, 'auto_rotation_config.json')
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    config = json.load(f)
                
                self.is_active = config.get('is_active', False)
                
                # Load policies (simplified - just loads active state)
                for policy_config in config.get('policies', []):
                    policy_name = policy_config.get('name', '')
                    is_active = policy_config.get('is_active', True)
                    
                    # Find matching policy and update its active state
                    for policy in self.policies:
                        if policy.name == policy_name:
                            policy.is_active = is_active
                
                logger.info(f"Loaded auto-rotation config (active: {self.is_active})")
            except Exception as e:
                logger.error(f"Error loading auto-rotation config: {e}")
    
    def _save_config(self):
        """Save rotation engine configuration."""
        config = {
            'is_active': self.is_active,
            'policies': [
                {
                    'name': policy.name,
                    'type': policy.rotation_type.value,
                    'is_active': policy.is_active
                }
                for policy in self.policies
            ],
            'last_updated': datetime.now().isoformat()
        }
        
        config_path = os.path.join(self.data_dir, 'auto_rotation_config.json')
        try:
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=2)
            logger.debug("Saved auto-rotation config")
        except Exception as e:
            logger.error(f"Error saving auto-rotation config: {e}")
    
    def add_policy(self, policy: RotationPolicy):
        """
        Add a rotation policy.
        
        Args:
            policy (RotationPolicy): Policy to add
        """
        self.policies.append(policy)
        logger.info(f"Added rotation policy: {policy.name}")
        self._save_config()
    
    def remove_policy(self, policy_name: str):
        """
        Remove a rotation policy by name.
        
        Args:
            policy_name (str): Name of the policy to remove
        """
        for i, policy in enumerate(self.policies):
            if policy.name == policy_name:
                self.policies.pop(i)
                logger.info(f"Removed rotation policy: {policy_name}")
                self._save_config()
                return
    
    def get_policies(self):
        """
        Get all rotation policies.
        
        Returns:
            list: Rotation policies
        """
        return self.policies
    
    def activate(self):
        """Activate the auto-rotation engine."""
        self.is_active = True
        logger.info("Activated auto-rotation engine")
        self._save_config()
    
    def deactivate(self):
        """Deactivate the auto-rotation engine."""
        self.is_active = False
        logger.info("Deactivated auto-rotation engine")
        self._save_config()
    
    def add_notification_hook(self, hook):
        """
        Add a notification hook for rotation events.
        
        Args:
            hook (callable): Function to call with rotation info
        """
        self.notification_hooks.append(hook)
    
    def apply_manual_weights(self, weights: Dict[str, float], 
                           ensemble_name: str = None, 
                           duration_hours: int = 24) -> Dict[str, Any]:
        """
        Manually apply strategy weights from the Weight Allocation Simulator.
        
        This creates a Strategy Lock policy with the specified weights and
        applies it immediately to the specified ensemble.
        
        Args:
            weights (Dict[str, float]): Strategy weights (0-1 proportion)
            ensemble_name (str, optional): Name of ensemble to update
            duration_hours (int): How long to maintain the manual weights
            
        Returns:
            Dict[str, Any]: Result of the operation with success flag
        """
        try:
            # Validate weights
            if not weights:
                return {'success': False, 'error': 'No weights provided'}
            
            # Ensure weights sum to 1.0
            total = sum(weights.values())
            if abs(total - 1.0) > 0.01:  # Allow small rounding errors
                # Normalize to 1.0
                weights = {k: v / total for k, v in weights.items()}
                logger.warning(f"Weights did not sum to 1.0, normalized automatically: {weights}")
            
            # Get ensemble to update
            if ensemble_name is None:
                # Use active ensemble
                ensemble = ensemble_manager.get_active_ensemble()
                if ensemble is None:
                    return {'success': False, 'error': 'No active ensemble found'}
                ensemble_name = ensemble.name
            else:
                # Get specified ensemble
                ensemble = ensemble_manager.get_ensemble(ensemble_name)
                if ensemble is None:
                    return {'success': False, 'error': f"Ensemble '{ensemble_name}' not found"}
            
            # Get current weights for tracking changes
            old_weights = dict(ensemble.weights)
            
            # Create a lock policy with the specified weights
            lock_policy = StrategyLockPolicy(locked_weights=weights, duration_hours=duration_hours)
            lock_policy.name = "Manual Weights (Simulator)"
            
            # Apply the weights
            new_weights = lock_policy.get_new_weights(self.tracker, ensemble.weights)
            ensemble.update_parameters({'weights': new_weights})
            
            # Record in history
            self.history.add_rotation(
                timestamp=datetime.now(),
                trigger=RotationTrigger.MANUAL,
                policy_name="Weight Allocation Simulator",
                old_weights=old_weights,
                new_weights=new_weights
            )
            
            # Register manual override 
            if self.manual_override_policy:
                self.manual_override_policy.register_manual_override()
            
            # Send notification
            self._notify_rotation(
                trigger=RotationTrigger.MANUAL,
                policy_name="Weight Allocation Simulator",
                old_weights=old_weights,
                new_weights=new_weights
            )
            
            # Save changes
            self._save_config()
            
            logger.info(f"Manual weights applied from simulator: {weights}")
            
            return {
                'success': True, 
                'ensemble_name': ensemble_name, 
                'old_weights': old_weights,
                'new_weights': new_weights
            }
            
        except Exception as e:
            logger.error(f"Error applying manual weights: {e}")
            return {'success': False, 'error': str(e)}
    
    def _notify_rotation(self, trigger, policy_name, old_weights, new_weights):
        """
        Notify hooks about a rotation event.
        
        Args:
            trigger (RotationTrigger): What triggered the rotation
            policy_name (str): Name of the policy that triggered it
            old_weights (dict): Previous weights
            new_weights (dict): New weights
        """
        for hook in self.notification_hooks:
            try:
                hook(trigger, policy_name, old_weights, new_weights)
            except Exception as e:
                logger.error(f"Error in rotation notification hook: {e}")
    
    def check_and_rotate_weights(self, ensemble_name: str = None) -> Dict[str, float]:
        """
        Check all policies and rotate weights if needed.
        
        Args:
            ensemble_name (str, optional): Name of ensemble to update
                If None, updates the active ensemble
            
        Returns:
            Dict[str, float]: New weights if rotated, None otherwise
        """
        if not self.is_active:
            return None
        
        # Get ensemble to update
        if ensemble_name is None:
            # Use active ensemble
            ensemble = ensemble_manager.get_active_ensemble()
            if ensemble is None:
                logger.warning("No active ensemble found for rotation")
                return None
            ensemble_name = ensemble.name
        else:
            # Get specified ensemble
            ensemble = ensemble_manager.get_ensemble(ensemble_name)
            if ensemble is None:
                logger.warning(f"Ensemble '{ensemble_name}' not found for rotation")
                return None
        
        # Get current weights
        current_weights = ensemble.weights
        
        # Check policies
        rotated = False
        policy_triggered = None
        new_weights = None
        
        for policy in self.policies:
            if policy.is_active and policy.should_rotate(self.tracker, current_weights):
                # Get new weights from policy
                new_weights = policy.get_new_weights(self.tracker, current_weights)
                rotated = True
                policy_triggered = policy
                logger.info(f"Rotation triggered by policy: {policy.name}")
                break
        
        if rotated and new_weights is not None:
            # Apply new weights
            old_weights = dict(current_weights)  # Make copy of old weights
            ensemble.update_parameters({'weights': new_weights})
            
            # Record in history
            self.history.add_rotation(
                timestamp=datetime.now(),
                trigger=policy_triggered.rotation_type,
                policy_name=policy_triggered.name,
                old_weights=old_weights,
                new_weights=new_weights
            )
            
            # Notify hooks
            self._notify_rotation(
                trigger=policy_triggered.rotation_type,
                policy_name=policy_triggered.name,
                old_weights=old_weights,
                new_weights=new_weights
            )
            
            logger.info(f"Rotated weights for ensemble '{ensemble_name}'")
            
            return new_weights
        
        return None
    
    def lock_strategy(self, strategy: str, weight: float, ensemble_name: str = None):
        """
        Lock a strategy at a fixed weight.
        
        Args:
            strategy (str): Strategy name
            weight (float): Fixed weight
            ensemble_name (str, optional): Ensemble name
            
        Returns:
            bool: True if successful
        """
        # Find lock policy or create one
        lock_policy = None
        for policy in self.policies:
            if isinstance(policy, StrategyLockPolicy):
                lock_policy = policy
                break
        
        if lock_policy is None:
            lock_policy = StrategyLockPolicy()
            self.add_policy(lock_policy)
        
        # Get ensemble
        ensemble = None
        if ensemble_name:
            ensemble = ensemble_manager.get_ensemble(ensemble_name)
        else:
            ensemble = ensemble_manager.get_active_ensemble()
        
        if ensemble is None:
            logger.warning("No ensemble found for strategy lock")
            return False
        
        # Check if strategy exists
        if strategy not in ensemble.strategy_names:
            logger.warning(f"Strategy '{strategy}' not found in ensemble")
            return False
        
        # Lock strategy
        lock_policy.lock_strategy(strategy, weight)
        
        # Apply lock immediately
        new_weights = lock_policy.get_new_weights(self.tracker, ensemble.weights)
        ensemble.update_parameters({'weights': new_weights})
        
        # Record in history
        self.history.add_rotation(
            timestamp=datetime.now(),
            trigger=RotationTrigger.MANUAL,
            policy_name="Strategy Lock",
            old_weights=ensemble.weights,
            new_weights=new_weights
        )
        
        return True
    
    def get_rotation_history(self, limit: int = None):
        """
        Get the history of weight rotations.
        
        Args:
            limit (int, optional): Maximum number of entries to return
            
        Returns:
            list: Rotation history
        """
        return self.history.get_history(limit)
        
    def register_manual_override(self, ensemble_name: str = None):
        """
        Register that a manual weight override has occurred.
        
        This notifies adaptive policies to temporarily pause auto-rotation.
        
        Args:
            ensemble_name (str, optional): Name of ensemble that was manually updated
                If None, uses the active ensemble
                
        Returns:
            bool: True if successful
        """
        self.last_manual_update = datetime.now()
        
        # Notify adaptive policies to pause rotation
        for policy in self.policies:
            if isinstance(policy, AdaptivePerformancePolicy) and hasattr(policy, 'register_manual_override'):
                policy.register_manual_override()
                
        # Get ensemble
        ensemble = None
        if ensemble_name:
            ensemble = ensemble_manager.get_ensemble(ensemble_name)
        else:
            ensemble = ensemble_manager.get_active_ensemble()
            
        if ensemble is None:
            logger.warning("No ensemble found to record manual override")
            return False
            
        # Record in history
        self.history.add_rotation(
            timestamp=datetime.now(),
            trigger=RotationTrigger.MANUAL,
            policy_name="Manual User Override",
            old_weights={},  # We don't have the old weights here
            new_weights=ensemble.weights
        )
        
        logger.info(f"Registered manual weight override. Adaptive rotation paused.")
        return True
        
    def get_adaptive_policies(self):
        """
        Get all adaptive performance policies.
        
        Returns:
            list: List of AdaptivePerformancePolicy instances
        """
        return [p for p in self.policies if isinstance(p, AdaptivePerformancePolicy)]
        
    def enable_policy(self, policy_name: str):
        """
        Enable a policy by name.
        
        Args:
            policy_name (str): Name of the policy to enable
            
        Returns:
            bool: True if successful
        """
        for policy in self.policies:
            if policy.name == policy_name:
                policy.is_active = True
                logger.info(f"Enabled policy: {policy_name}")
                self._save_config()
                return True
        
        logger.warning(f"Policy not found: {policy_name}")
        return False
        
    def disable_policy(self, policy_name: str):
        """
        Disable a policy by name.
        
        Args:
            policy_name (str): Name of the policy to disable
            
        Returns:
            bool: True if successful
        """
        for policy in self.policies:
            if policy.name == policy_name:
                policy.is_active = False
                logger.info(f"Disabled policy: {policy_name}")
                self._save_config()
                return True
        
        logger.warning(f"Policy not found: {policy_name}")
        return False


# Singleton instance for global access
auto_rotation_engine = AutoRotationEngine()

# Add default policies
auto_rotation_engine.add_policy(
    PerformanceBasedPolicy(
        metric='win_rate',
        lookback_days=7,
        check_interval_hours=24,
        threshold=0.0,
        min_weight=0.1,
        max_weight=0.9
    )
)

auto_rotation_engine.add_policy(
    TimeBasedPolicy(
        interval_hours=48,
        rotation_fraction=0.2
    )
)

auto_rotation_engine.add_policy(
    DegradationPolicy(
        metric='win_rate',
        lookback_days=14,
        comparison_days=7,
        threshold=10.0,
        check_interval_hours=12
    )
)

# Add the new adaptive performance policy
auto_rotation_engine.add_policy(
    AdaptivePerformancePolicy(
        metrics={
            'win_rate': 0.35,         # Weight for win rate metric
            'profit_factor': 0.35,    # Weight for profit factor metric
            'sharpe_ratio': 0.30      # Weight for sharpe ratio metric
        },
        lookback_days=7,              # Days to look back for performance data
        check_interval_hours=12,      # Hours between rotation checks
        min_trades_required=5,        # Minimum trades required for evaluation
        base_threshold=0.05,          # Base threshold for triggering rotation
        adaptive_threshold=True,      # Use adaptive thresholds based on market conditions
        market_volatility_factor=0.5, # How much volatility affects thresholds
        smoothing_factor=0.3,         # Smooth weight changes (0-1, higher = more smoothing)
        max_weight_change=0.2,        # Maximum weight change allowed per rotation (0-1)
        min_weight=0.05,              # Minimum weight for any strategy
        max_weight=0.7,               # Maximum weight for any strategy
        manual_override_timeout_hours=24  # Hours to pause auto-rotation after manual edits
    )
)