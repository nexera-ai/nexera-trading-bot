"""
Command-line interface for the Parameter Optimizer

This script provides a command-line interface for the parameter optimization module.
It allows users to run optimization for trading strategies from the terminal.

Usage:
    python optimize.py --strategy dip_buyer --method grid
    python optimize.py --strategy mean_reversion --method random --samples 100
    python optimize.py --config optimization_config.json
"""
import os
import argparse
import json
import logging
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns
from parameter_sweep import ParameterOptimizer, run_optimization, run_optimization_from_config
from backtest import load_sample_data, load_csv_data
from strategies import get_available_strategies

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def parse_args():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(description='Parameter Optimization for Trading Strategies')
    
    # Main arguments
    parser.add_argument('--strategy', type=str, help='Strategy name to optimize')
    parser.add_argument('--method', type=str, default='grid', choices=['grid', 'random', 'bayesian'],
                        help='Optimization method: grid, random, or bayesian')
    parser.add_argument('--config', type=str, help='Path to JSON configuration file')
    
    # Data source
    parser.add_argument('--data_source', type=str, default='sample', choices=['sample', 'file'],
                        help='Source of OHLCV data: sample or file')
    parser.add_argument('--file_path', type=str, help='Path to CSV file with OHLCV data')
    
    # Backtest parameters
    parser.add_argument('--symbol', type=str, default='BTC/USDT', help='Trading pair symbol')
    parser.add_argument('--timeframe', type=str, default='1h', help='Timeframe for the data')
    parser.add_argument('--initial_balance', type=float, default=1000.0, help='Initial balance for backtests')
    
    # Optimization parameters
    parser.add_argument('--max_combinations', type=int, default=1000, 
                        help='Maximum number of combinations for grid search')
    parser.add_argument('--samples', type=int, default=100, 
                        help='Number of samples for random search')
    
    # Output
    parser.add_argument('--output', type=str, help='Path to save results CSV')
    parser.add_argument('--visualize', action='store_true', help='Generate visualization of results')
    
    return parser.parse_args()

def generate_default_param_ranges(strategy_name):
    """Generate default parameter ranges for a strategy."""
    if strategy_name == 'dip_buyer':
        return {
            'price_drop_threshold': [1.0, 1.5, 2.0, 2.5, 3.0],
            'price_drop_timeframe': [5, 10, 15, 20, 30],
            'take_profit': [2.0, 3.0, 4.0, 5.0],
            'stop_loss': [1.0, 1.5, 2.0, 2.5]
        }
    elif strategy_name == 'mean_reversion':
        return {
            'ma_period': [10, 20, 30, 40, 50],
            'std_dev_multiplier': [1.0, 1.5, 2.0, 2.5, 3.0],
            'take_profit': [2.0, 3.0, 4.0, 5.0],
            'stop_loss': [1.0, 1.5, 2.0, 2.5]
        }
    elif strategy_name == 'breakout':
        return {
            'lookback_period': [10, 20, 30, 40, 50],
            'confirmation_candles': [1, 2, 3, 4, 5],
            'volume_increase': [1.0, 1.5, 2.0, 2.5, 3.0],
            'take_profit': [2.0, 3.0, 4.0, 5.0],
            'stop_loss': [1.0, 1.5, 2.0, 2.5]
        }
    else:
        return {
            'take_profit': [2.0, 3.0, 4.0, 5.0],
            'stop_loss': [1.0, 1.5, 2.0, 2.5]
        }

def generate_visualization(results_df, output_dir):
    """Generate visualization of optimization results."""
    try:
        
        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        
        # Extract parameter names
        param_cols = [col for col in results_df.columns 
                      if col not in ['total_profit', 'total_return_pct', 'win_rate', 
                                    'total_trades', 'max_drawdown', 'sharpe_ratio',
                                    'profit_factor', 'avg_profit', 'avg_loss',
                                    'avg_holding_time', 'winning_trades', 'losing_trades']]
        
        # Heatmaps for parameter interactions
        if len(param_cols) >= 2:
            # Get all pairs of parameters
            for i, param1 in enumerate(param_cols):
                for param2 in param_cols[i+1:]:
                    # Create pivot tables for different metrics
                    metrics = ['total_profit', 'win_rate', 'sharpe_ratio']
                    
                    for metric in metrics:
                        try:
                            plt.figure(figsize=(10, 8))
                            pivot = results_df.pivot_table(
                                index=param1, 
                                columns=param2, 
                                values=metric,
                                aggfunc='mean'
                            )
                            sns.heatmap(pivot, annot=True, cmap='viridis', fmt='.2f')
                            plt.title(f'{metric} for different {param1} and {param2} values')
                            plt.tight_layout()
                            plt.savefig(f"{output_dir}/{param1}_{param2}_{metric}_heatmap.png")
                            plt.close()
                        except Exception as e:
                            logger.warning(f"Could not create heatmap for {param1} vs {param2}: {e}")
        
        # Violin plots for each parameter's effect on profit
        for param in param_cols:
            try:
                plt.figure(figsize=(10, 6))
                sns.violinplot(x=param, y='total_profit', data=results_df)
                plt.title(f'Effect of {param} on Profit')
                plt.tight_layout()
                plt.savefig(f"{output_dir}/{param}_profit_violin.png")
                plt.close()
                
                plt.figure(figsize=(10, 6))
                sns.boxplot(x=param, y='win_rate', data=results_df)
                plt.title(f'Effect of {param} on Win Rate')
                plt.tight_layout()
                plt.savefig(f"{output_dir}/{param}_winrate_box.png")
                plt.close()
            except Exception as e:
                logger.warning(f"Could not create plots for {param}: {e}")
        
        # Correlation matrix
        try:
            plt.figure(figsize=(12, 10))
            corr = results_df.corr()
            mask = np.triu(np.ones_like(corr, dtype=bool))
            sns.heatmap(corr, mask=mask, annot=True, cmap='coolwarm', fmt='.2f', linewidths=0.5)
            plt.title('Correlation Matrix')
            plt.tight_layout()
            plt.savefig(f"{output_dir}/correlation_matrix.png")
            plt.close()
        except Exception as e:
            logger.warning(f"Could not create correlation matrix: {e}")
        
        logger.info(f"Visualizations saved to {output_dir}")
        
    except ImportError:
        logger.warning("Could not generate visualizations. Make sure matplotlib and seaborn are installed.")

def main():
    """Main function."""
    args = parse_args()
    
    # Ensure data directory exists
    os.makedirs('data/optimization_results', exist_ok=True)
    
    # Check if we're using a configuration file
    if args.config:
        if not os.path.isfile(args.config):
            logger.error(f"Configuration file not found: {args.config}")
            return
        
        # Load OHLCV data
        ohlcv_data = None
        if args.data_source == 'file' and args.file_path:
            try:
                ohlcv_data = load_csv_data(args.file_path)
            except Exception as e:
                logger.error(f"Error loading CSV data: {e}")
                return
        else:
            logger.info("Using sample OHLCV data")
            ohlcv_data = load_sample_data()
        
        # Run optimization from config
        logger.info(f"Running optimization from config: {args.config}")
        results = run_optimization_from_config(args.config, ohlcv_data)
        
    else:
        # Check if strategy is provided
        if not args.strategy:
            logger.error("Strategy name is required when not using a configuration file")
            return
        
        # Check if strategy exists
        available_strategies = [s['id'] for s in get_available_strategies()]
        if args.strategy not in available_strategies:
            logger.error(f"Strategy '{args.strategy}' not found. Available strategies: {', '.join(available_strategies)}")
            return
        
        # Load OHLCV data
        ohlcv_data = None
        if args.data_source == 'file' and args.file_path:
            try:
                ohlcv_data = load_csv_data(args.file_path)
            except Exception as e:
                logger.error(f"Error loading CSV data: {e}")
                return
        else:
            logger.info("Using sample OHLCV data")
            ohlcv_data = load_sample_data()
        
        # Get parameter ranges
        parameter_ranges = generate_default_param_ranges(args.strategy)
        
        # Run optimization
        logger.info(f"Running {args.method} optimization for {args.strategy} strategy")
        results = run_optimization(
            strategy_name=args.strategy,
            parameter_ranges=parameter_ranges,
            ohlcv_data=ohlcv_data,
            method=args.method,
            symbol=args.symbol,
            timeframe=args.timeframe,
            initial_balance=args.initial_balance,
            max_combinations=args.max_combinations,
            random_samples=args.samples
        )
    
    # Save results if output path is provided
    if args.output:
        results.to_csv(args.output, index=False)
        logger.info(f"Results saved to {args.output}")
    
    # Generate visualization if requested
    if args.visualize:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_dir = f"data/optimization_results/visualizations_{timestamp}"
        generate_visualization(results, output_dir)
    
    # Display top results
    logger.info("Top 5 parameter sets by profit:")
    top_results = results.sort_values('total_profit', ascending=False).head(5)
    for i, row in top_results.iterrows():
        params_str = ', '.join([f"{k}: {v}" for k, v in row.items() 
                               if k not in ['total_profit', 'total_return_pct', 'win_rate', 
                                           'total_trades', 'max_drawdown', 'sharpe_ratio',
                                           'profit_factor', 'avg_profit', 'avg_loss',
                                           'avg_holding_time', 'winning_trades', 'losing_trades']])
        
        logger.info(f"#{i+1}: Profit: {row['total_profit']:.2f} USDT, "
                   f"Return: {row['total_return_pct']:.2f}%, "
                   f"Win Rate: {row['win_rate']:.2f}%, "
                   f"Params: {params_str}")

if __name__ == "__main__":
    main()