#!/usr/bin/env python3
"""
Rotation Logic Test Suite - Quality Assurance & Future-Proofing

This module provides comprehensive test cases for the Auto-Rotation Engine, ensuring
that weight adjustment decisions are correctly made across various market conditions.

Key test categories:
1. Policy Validation Tests - Verify each policy acts as expected
2. Edge Case Tests - Test behavior under extreme conditions
3. Integration Tests - Test interaction between multiple policies
4. Regression Tests - Ensure new changes don't break existing functionality
"""

import os
import sys
import unittest
from datetime import datetime, timedelta
import math
import json
import random
from unittest.mock import MagicMock, patch
import logging

# Setup logging
logging.basicConfig(level=logging.ERROR)

# Import rotation policies and engine
from auto_rotation import (
    AutoRotationEngine, RotationPolicy, 
    PerformanceBasedPolicy, TimeBasedPolicy, DegradationPolicy
)

# Mock classes for testing
class MockPerformanceTracker:
    """Mock performance tracker for testing rotation policies"""
    
    def __init__(self, mock_data=None):
        """Initialize with optional mock performance data"""
        self.mock_data = mock_data or {}
        
        # Default data if none provided
        if not mock_data:
            self.mock_data = {
                "strategy1": {
                    "win_rate": 0.65,
                    "profit_factor": 1.8,
                    "sharpe_ratio": 1.2,
                    "sortino_ratio": 1.5,
                    "calmar_ratio": 0.8,
                    "max_drawdown": 15.0,
                    "avg_profit": 2.5,
                    "avg_loss": 1.2,
                    "avg_duration": 120,  # minutes
                    "total_return": 35.0
                },
                "strategy2": {
                    "win_rate": 0.55,
                    "profit_factor": 1.5,
                    "sharpe_ratio": 0.9,
                    "sortino_ratio": 1.1,
                    "calmar_ratio": 0.6,
                    "max_drawdown": 20.0,
                    "avg_profit": 3.2,
                    "avg_loss": 1.8,
                    "avg_duration": 180,
                    "total_return": 28.0
                },
                "strategy3": {
                    "win_rate": 0.72,
                    "profit_factor": 2.1,
                    "sharpe_ratio": 1.5,
                    "sortino_ratio": 1.8,
                    "calmar_ratio": 1.1,
                    "max_drawdown": 12.0,
                    "avg_profit": 2.1,
                    "avg_loss": 1.0,
                    "avg_duration": 90,
                    "total_return": 42.0
                }
            }
    
    def get_win_rate(self, strategy_name=None, days=None):
        """Return mock win rate"""
        if strategy_name:
            return self.mock_data.get(strategy_name, {}).get("win_rate", 0.5)
        return {s: data.get("win_rate", 0.5) for s, data in self.mock_data.items()}
    
    def get_profit_factor(self, strategy_name=None, days=None):
        """Return mock profit factor"""
        if strategy_name:
            return self.mock_data.get(strategy_name, {}).get("profit_factor", 1.0)
        return {s: data.get("profit_factor", 1.0) for s, data in self.mock_data.items()}
    
    def get_sharpe_ratio(self, strategy_name=None, days=None):
        """Return mock sharpe ratio"""
        if strategy_name:
            return self.mock_data.get(strategy_name, {}).get("sharpe_ratio", 0.0)
        return {s: data.get("sharpe_ratio", 0.0) for s, data in self.mock_data.items()}
    
    def get_sortino_ratio(self, strategy_name=None, days=None):
        """Return mock sortino ratio"""
        if strategy_name:
            return self.mock_data.get(strategy_name, {}).get("sortino_ratio", 0.0)
        return {s: data.get("sortino_ratio", 0.0) for s, data in self.mock_data.items()}
    
    def get_calmar_ratio(self, strategy_name=None, days=None):
        """Return mock calmar ratio"""
        if strategy_name:
            return self.mock_data.get(strategy_name, {}).get("calmar_ratio", 0.0)
        return {s: data.get("calmar_ratio", 0.0) for s, data in self.mock_data.items()}
    
    def get_max_drawdown_pct(self, strategy_name=None, days=None):
        """Return mock max drawdown"""
        if strategy_name:
            return self.mock_data.get(strategy_name, {}).get("max_drawdown", 0.0)
        return {s: data.get("max_drawdown", 0.0) for s, data in self.mock_data.items()}
    
    def get_avg_profit_pct(self, strategy_name=None, days=None):
        """Return mock average profit"""
        if strategy_name:
            return self.mock_data.get(strategy_name, {}).get("avg_profit", 0.0)
        return {s: data.get("avg_profit", 0.0) for s, data in self.mock_data.items()}
    
    def get_avg_loss_pct(self, strategy_name=None, days=None):
        """Return mock average loss"""
        if strategy_name:
            return self.mock_data.get(strategy_name, {}).get("avg_loss", 0.0)
        return {s: data.get("avg_loss", 0.0) for s, data in self.mock_data.items()}
    
    def get_avg_trade_duration(self, strategy_name=None, days=None):
        """Return mock trade duration"""
        if strategy_name:
            return self.mock_data.get(strategy_name, {}).get("avg_duration", 0)
        return {s: data.get("avg_duration", 0) for s, data in self.mock_data.items()}
    
    def get_total_return_pct(self, strategy_name=None, days=None):
        """Return mock total return"""
        if strategy_name:
            return self.mock_data.get(strategy_name, {}).get("total_return", 0.0)
        return {s: data.get("total_return", 0.0) for s, data in self.mock_data.items()}


class MockEnsembleStrategy:
    """Mock ensemble strategy for testing rotation policies"""
    
    def __init__(self, strategies=None, weights=None):
        """Initialize with optional strategies and weights"""
        self.strategies = strategies or ["strategy1", "strategy2", "strategy3"]
        self.weights = weights or {
            "strategy1": 0.4,
            "strategy2": 0.3,
            "strategy3": 0.3
        }
    
    def get_strategies(self):
        """Return strategy names"""
        return self.strategies
    
    def get_weights(self):
        """Return current weights"""
        return self.weights
    
    def set_weights(self, new_weights):
        """Update weights"""
        # Validate weights
        if not isinstance(new_weights, dict):
            raise ValueError("Weights must be a dictionary")
        
        # Check if all strategies are present
        for strategy in self.strategies:
            if strategy not in new_weights:
                raise ValueError(f"Missing weight for strategy {strategy}")
        
        # Check if sum is approximately 1.0
        if not math.isclose(sum(new_weights.values()), 1.0, abs_tol=0.0001):
            raise ValueError(f"Weights must sum to 1.0, got {sum(new_weights.values())}")
        
        # Update weights
        self.weights = new_weights.copy()


class RotationPolicyTests(unittest.TestCase):
    """Test cases for individual rotation policies"""
    
    def setUp(self):
        """Set up test environment"""
        self.performance_tracker = MockPerformanceTracker()
        self.ensemble = MockEnsembleStrategy()
        
        # Create policies for testing
        self.win_rate_policy = PerformanceBasedPolicy(
            metric="win_rate",
            threshold=0.1,  # 10% difference triggers rotation
            lookback_days=30,
            min_weight=0.1,
            max_weight=0.8
        )
        
        self.profit_factor_policy = PerformanceBasedPolicy(
            metric="profit_factor",
            threshold=0.3,  # 30% difference triggers rotation
            lookback_days=30,
            min_weight=0.1,
            max_weight=0.8
        )
        
        self.time_policy = TimeBasedPolicy(
            interval_hours=168,  # 7 days
            rotation_fraction=0.1
        )
        
        self.degradation_policy = DegradationPolicy(
            metric="max_drawdown_pct",
            threshold=5.0,  # 5% increase in drawdown triggers reduction
            lookback_days=30,
            comparison_days=7,
            check_interval_hours=6
        )
    
    def test_performance_rotation_win_rate(self):
        """Test performance rotation based on win rate"""
        # Configure mock data to trigger rotation
        mock_data = {
            "strategy1": {"win_rate": 0.65},
            "strategy2": {"win_rate": 0.40},  # Significantly worse
            "strategy3": {"win_rate": 0.70}   # Best performer
        }
        self.performance_tracker.mock_data = mock_data
        
        # Get rotation decision
        should_rotate = self.win_rate_policy.should_rotate(
            self.performance_tracker, self.ensemble.weights
        )
        new_weights = self.win_rate_policy.get_new_weights(
            self.performance_tracker, self.ensemble.weights
        )
        
        # Verify rotation occurs
        self.assertTrue(should_rotate)
        self.assertGreater(new_weights["strategy3"], self.ensemble.weights["strategy3"])
        self.assertLess(new_weights["strategy2"], self.ensemble.weights["strategy2"])
        self.assertAlmostEqual(sum(new_weights.values()), 1.0)
    
    def test_performance_rotation_profit_factor(self):
        """Test performance rotation based on profit factor"""
        # Configure mock data to trigger rotation
        mock_data = {
            "strategy1": {"profit_factor": 1.8},
            "strategy2": {"profit_factor": 2.5},  # Best performer
            "strategy3": {"profit_factor": 1.2}   # Worst performer
        }
        self.performance_tracker.mock_data = mock_data
        
        # Get rotation decision
        should_rotate = self.profit_factor_policy.should_rotate(
            self.performance_tracker, self.ensemble.weights
        )
        new_weights = self.profit_factor_policy.get_new_weights(
            self.performance_tracker, self.ensemble.weights
        )
        
        # Verify rotation occurs
        self.assertTrue(should_rotate)
        self.assertGreater(new_weights["strategy2"], self.ensemble.weights["strategy2"])
        self.assertLess(new_weights["strategy3"], self.ensemble.weights["strategy3"])
        self.assertAlmostEqual(sum(new_weights.values()), 1.0)
    
    def test_time_based_rotation(self):
        """Test time-based rotation policy"""
        # Set last rotation time to 10 days ago
        last_rotation_time = datetime.now() - timedelta(days=10)
        context = {"last_rotation_time": last_rotation_time}
        
        # Set the last rotation time directly on the policy object
        self.time_policy.last_rotation_time = last_rotation_time
        
        # Get rotation decision
        should_rotate = self.time_policy.should_rotate(
            self.performance_tracker, self.ensemble.weights
        )
        new_weights = self.time_policy.get_new_weights(
            self.performance_tracker, self.ensemble.weights
        )
        
        # Verify rotation occurs
        self.assertTrue(should_rotate)
        self.assertNotEqual(new_weights, self.ensemble.weights)
        self.assertAlmostEqual(sum(new_weights.values()), 1.0)
        
        # Test with recent rotation (should not rotate)
        recent_rotation = datetime.now() - timedelta(days=3)
        self.time_policy.last_rotation_time = recent_rotation
        
        should_rotate = self.time_policy.should_rotate(
            self.performance_tracker, self.ensemble.weights
        )
        
        # Verify no rotation
        self.assertFalse(should_rotate)
    
    def test_degradation_detection_policy(self):
        """Test degradation detection policy"""
        # Configure mock data to trigger degradation detection
        mock_data = {
            "strategy1": {"max_drawdown": 25.0},  # Significantly worse
            "strategy2": {"max_drawdown": 10.0},
            "strategy3": {"max_drawdown": 8.0}
        }
        self.performance_tracker.mock_data = mock_data
        
        # Set historical data for comparison
        context = {
            "historical_metrics": {
                "strategy1": {"max_drawdown_pct": 15.0}  # Drawdown increased by 10%
            }
        }
        
        # Set historical metric data on the policy
        self.degradation_policy.historical_metrics = {
            "strategy1": {"max_drawdown_pct": 15.0}
        }
        
        # Get rotation decision
        should_rotate = self.degradation_policy.should_rotate(
            self.performance_tracker, self.ensemble.weights
        )
        new_weights = self.degradation_policy.get_new_weights(
            self.performance_tracker, self.ensemble.weights
        )
        
        # Verify rotation occurs
        self.assertTrue(should_rotate)
        self.assertLess(new_weights["strategy1"], self.ensemble.weights["strategy1"])
        self.assertAlmostEqual(sum(new_weights.values()), 1.0)


class RotationEngineTests(unittest.TestCase):
    """Test cases for the AutoRotationEngine"""
    
    def setUp(self):
        """Set up test environment"""
        self.performance_tracker = MockPerformanceTracker()
        self.ensemble = MockEnsembleStrategy()
        
        # Create rotation engine
        self.engine = AutoRotationEngine()
        
        # Add policies
        self.win_rate_policy = PerformanceBasedPolicy(
            metric="win_rate", threshold=0.1, lookback_days=30, min_weight=0.1, max_weight=0.8
        )
        
        self.time_policy = TimeBasedPolicy(
            interval_hours=168,  # 7 days
            rotation_fraction=0.1
        )
        
        self.degradation_policy = DegradationPolicy(
            metric="max_drawdown_pct", threshold=5.0, lookback_days=30, 
            comparison_days=7, check_interval_hours=6
        )
    
    def test_engine_initialization(self):
        """Test engine initialization"""
        self.assertFalse(self.engine._active)
        self.assertEqual(len(self.engine._policies), 0)
    
    def test_engine_activation(self):
        """Test engine activation"""
        self.engine.activate()
        self.assertTrue(self.engine._active)
        
        self.engine.deactivate()
        self.assertFalse(self.engine._active)
    
    def test_policy_management(self):
        """Test policy management"""
        # Add policies
        policy1_id = self.engine.add_policy(self.win_rate_policy)
        policy2_id = self.engine.add_policy(self.time_policy)
        
        # Verify policies were added
        self.assertEqual(len(self.engine._policies), 2)
        
        # Toggle policy state
        self.engine.toggle_policy(policy1_id, active=False)
        
        # Check if policy was deactivated
        policy1 = self.engine._policies.get(policy1_id)
        self.assertFalse(policy1["active"])
        
        # Remove policy
        self.engine.remove_policy(policy2_id)
        
        # Verify policy was removed
        self.assertEqual(len(self.engine._policies), 1)
    
    def test_check_rotation_inactive(self):
        """Test that no rotation happens when engine is inactive"""
        # Add policies
        self.engine.add_policy(self.win_rate_policy)
        
        # Keep engine inactive
        self.engine.deactivate()
        
        # Configure mock data to trigger rotation
        mock_data = {
            "strategy1": {"win_rate": 0.65},
            "strategy2": {"win_rate": 0.40},  # Significantly worse
            "strategy3": {"win_rate": 0.70}   # Best performer
        }
        self.performance_tracker.mock_data = mock_data
        
        # Get rotation decision
        should_rotate = self.engine.should_rotate(
            self.performance_tracker, self.ensemble.weights
        )
        new_weights = None
        if should_rotate:
            new_weights = self.engine.calculate_new_weights(
                self.performance_tracker, self.ensemble.weights
            )
        
        # Verify no rotation occurs
        self.assertFalse(should_rotate)
        self.assertIsNone(new_weights)
    
    def test_check_rotation_active(self):
        """Test rotation with active engine"""
        # Add policies
        self.engine.add_policy(self.win_rate_policy)
        
        # Activate engine
        self.engine.activate()
        
        # Configure mock data to trigger rotation
        mock_data = {
            "strategy1": {"win_rate": 0.65},
            "strategy2": {"win_rate": 0.40},  # Significantly worse
            "strategy3": {"win_rate": 0.70}   # Best performer
        }
        self.performance_tracker.mock_data = mock_data
        
        # Get rotation decision
        should_rotate = self.engine.should_rotate(
            self.performance_tracker, self.ensemble.weights
        )
        new_weights = None
        if should_rotate:
            new_weights = self.engine.calculate_new_weights(
                self.performance_tracker, self.ensemble.weights
            )
        
        # Verify rotation occurs
        self.assertTrue(should_rotate)
        self.assertGreater(new_weights["strategy3"], self.ensemble.weights["strategy3"])
        self.assertLess(new_weights["strategy2"], self.ensemble.weights["strategy2"])
        self.assertAlmostEqual(sum(new_weights.values()), 1.0)
    
    def test_locked_strategies(self):
        """Test strategy locking feature"""
        # Add policies
        self.engine.add_policy(self.win_rate_policy)
        
        # Activate engine
        self.engine.activate()
        
        # Lock a strategy
        self.engine.lock_strategy("strategy2", 0.4)
        
        # Configure mock data to trigger rotation
        mock_data = {
            "strategy1": {"win_rate": 0.65},
            "strategy2": {"win_rate": 0.40},  # Locked strategy (should not change)
            "strategy3": {"win_rate": 0.70}   # Best performer
        }
        self.performance_tracker.mock_data = mock_data
        
        # Get rotation decision
        should_rotate = self.engine.should_rotate(
            self.performance_tracker, self.ensemble.weights
        )
        new_weights = None
        if should_rotate:
            new_weights = self.engine.calculate_new_weights(
                self.performance_tracker, self.ensemble.weights
            )
        
        # Verify rotation occurs
        self.assertTrue(should_rotate)
        
        # Verify locked strategy weight is preserved
        self.assertEqual(new_weights["strategy2"], 0.4)
        self.assertAlmostEqual(sum(new_weights.values()), 1.0)
        
        # Release lock and verify it's removed
        self.engine.release_strategy_lock("strategy2")
        
        # Get rotation decision again
        should_rotate = self.engine.should_rotate(
            self.performance_tracker, self.ensemble.weights
        )
        new_weights = None
        if should_rotate:
            new_weights = self.engine.calculate_new_weights(
                self.performance_tracker, self.ensemble.weights
            )
        
        # Verify strategy2 weight is now different from locked value
        self.assertNotEqual(new_weights["strategy2"], 0.4)


class EdgeCaseTests(unittest.TestCase):
    """Test cases for edge conditions and error handling"""
    
    def setUp(self):
        """Set up test environment"""
        self.performance_tracker = MockPerformanceTracker()
        self.ensemble = MockEnsembleStrategy()
        self.engine = AutoRotationEngine()
    
    def test_empty_ensemble(self):
        """Test behavior with empty ensemble"""
        # Create empty ensemble
        empty_ensemble = MockEnsembleStrategy(strategies=[], weights={})
        
        # Add a policy
        policy = PerformanceBasedPolicy(
            metric="win_rate", threshold=0.1, lookback_days=30, 
            min_weight=0.1, max_weight=0.8
        )
        self.engine.add_policy(policy)
        self.engine.activate()
        
        # Get rotation decision
        should_rotate = self.engine.should_rotate(
            self.performance_tracker, empty_ensemble.weights
        )
        new_weights = None
        if should_rotate:
            new_weights = self.engine.calculate_new_weights(
                self.performance_tracker, empty_ensemble.weights
            )
        
        # Verify no rotation occurs with empty ensemble
        self.assertFalse(should_rotate)
        self.assertIsNone(new_weights)
    
    def test_single_strategy_ensemble(self):
        """Test behavior with single strategy ensemble"""
        # Create single-strategy ensemble
        single_ensemble = MockEnsembleStrategy(
            strategies=["strategy1"], 
            weights={"strategy1": 1.0}
        )
        
        # Add a policy
        policy = PerformanceBasedPolicy(
            metric="win_rate", threshold=0.1, lookback_days=30, 
            min_weight=0.1, max_weight=0.8
        )
        self.engine.add_policy(policy)
        self.engine.activate()
        
        # Get rotation decision
        should_rotate = self.engine.should_rotate(
            self.performance_tracker, single_ensemble.weights
        )
        new_weights = None
        if should_rotate:
            new_weights = self.engine.calculate_new_weights(
                self.performance_tracker, single_ensemble.weights
            )
        
        # Verify no rotation occurs with single strategy
        self.assertFalse(should_rotate)
        self.assertIsNone(new_weights)
    
    def test_multiple_locked_strategies(self):
        """Test behavior with multiple locked strategies"""
        # Add a policy
        policy = PerformanceBasedPolicy(
            metric="win_rate", threshold=0.1, lookback_days=30, 
            min_weight=0.1, max_weight=0.8
        )
        self.engine.add_policy(policy)
        self.engine.activate()
        
        # Lock multiple strategies
        self.engine.lock_strategy("strategy1", 0.5)
        self.engine.lock_strategy("strategy2", 0.4)
        
        # Configure mock data
        mock_data = {
            "strategy1": {"win_rate": 0.65},
            "strategy2": {"win_rate": 0.40},
            "strategy3": {"win_rate": 0.70}
        }
        self.performance_tracker.mock_data = mock_data
        
        # Get rotation decision
        should_rotate = self.engine.should_rotate(
            self.performance_tracker, self.ensemble.weights
        )
        new_weights = None
        if should_rotate:
            new_weights = self.engine.calculate_new_weights(
                self.performance_tracker, self.ensemble.weights
            )
        
        # Verify rotation occurs
        self.assertTrue(should_rotate)
        
        # Verify locked strategy weights are preserved
        self.assertEqual(new_weights["strategy1"], 0.5)
        self.assertEqual(new_weights["strategy2"], 0.4)
        self.assertAlmostEqual(new_weights["strategy3"], 0.1)
        self.assertAlmostEqual(sum(new_weights.values()), 1.0)
    
    def test_policy_with_invalid_metric(self):
        """Test behavior with invalid metric"""
        # Create policy with invalid metric
        invalid_policy = PerformanceBasedPolicy(
            metric="invalid_metric", threshold=0.1, lookback_days=30, 
            min_weight=0.1, max_weight=0.8
        )
        
        # Add policy to engine
        policy_id = self.engine.add_policy(invalid_policy)
        self.engine.activate()
        
        # Get rotation decision
        should_rotate = self.engine.should_rotate(
            self.performance_tracker, self.ensemble.weights
        )
        new_weights = None
        if should_rotate:
            new_weights = self.engine.calculate_new_weights(
                self.performance_tracker, self.ensemble.weights
            )
        
        # Verify no rotation occurs with invalid metric
        self.assertFalse(should_rotate)
        self.assertIsNone(new_weights)


def run_tests():
    """Run all test cases"""
    suite = unittest.TestSuite()
    
    # Add test cases
    suite.addTest(unittest.makeSuite(RotationPolicyTests))
    suite.addTest(unittest.makeSuite(RotationEngineTests))
    suite.addTest(unittest.makeSuite(EdgeCaseTests))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    return runner.run(suite)


if __name__ == "__main__":
    run_tests()