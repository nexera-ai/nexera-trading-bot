#!/usr/bin/env python3
"""
Binance Trading Bot - Main Entry Point with Web Interface
This script initializes and runs both the Binance trading bot and a Flask web interface.
"""

# Import alert notifier for risk notifications
try:
    from alert_notifier import alert_notifier, AlertType, AlertPriority, AlertChannel
except ImportError:
    # Create a dummy alert_notifier for backwards compatibility
    alert_notifier = None
    AlertType = None
    AlertPriority = None 
    AlertChannel = None
    print("Alert notifier not available, alert functions will be disabled")
import os
import sys
import time
import threading
import logging
from datetime import datetime, timedelta
import json
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, make_response, send_file, session, Response
from markupsafe import Markup
import plotly.graph_objects as go
import plotly.io as pio
from plotly.subplots import make_subplots
import bisect
from sqlalchemy import and_
from chart_utils import generate_ohlc_chart, generate_performance_chart
# PDF generation implemented via printable HTML report
from backtest import Backtester, load_sample_data
from ensemble_backtest import EnsembleBacktester, run_ensemble_backtest
from rotation_backtest import RotationBacktester, backtest_with_rotation
from config import Config
from trading_bot import TradingBot
from allocation_scheduler import AllocationScheduler
from batch_comparison import BatchComparison, run_batch_comparison
from ensemble_engine import ensemble_manager, get_active_ensemble, create_default_ensembles, VotingMethod, SignalType
from auto_rotation import auto_rotation_engine, PerformanceBasedPolicy, TimeBasedPolicy, DegradationPolicy, StrategyLockPolicy, RotationTrigger, AdaptivePerformancePolicy
from strategies import get_available_strategies
import markdown
from models import db, StrategyPreset, PresetEquityHistory, PresetTriggerEvent, PerformanceAlertRule, PerformanceAlertLog, StrategyAttribution, AllocationPreset, AllocationSchedule
from strategy_recommender import strategy_recommender
from alert_service import AlertService
from risk_manager import RiskManager, RiskLevel

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "crypto_bot_secret_key")

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Add a custom strftime filter for Jinja templates
@app.template_filter('strftime')
def _jinja2_filter_strftime(date, fmt='%Y-%m-%d %H:%M:%S'):
    """Custom filter for formatting dates in templates."""
    if not date:
        return None
    return date.strftime(fmt)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize the database
db.init_app(app)

# Create tables with safety check
with app.app_context():
    try:
        db.create_all()
        logger.info("Database tables created successfully")
    except Exception as e:
        logger.warning(f"Database initialization warning (tables may already exist): {e}")
        # Continue execution - tables likely exist already

# Initialize auto policy selector
try:
    from auto_policy_selector import auto_policy_selector
    # Set up auto policy selector (disabled by default until user enables)
    auto_policy_selector.benchmark_period_days = 30
    auto_policy_selector.selection_metric = 'sharpe_ratio'
    auto_policy_selector.schedule_time = '04:00'  # 4 AM daily
    auto_policy_selector.check_interval_minutes = 1440  # 24 hours
    logger.info("Auto policy selector initialized (inactive by default)")
except Exception as e:
    logger.error(f"Error initializing auto policy selector: {e}")

# Initialize smart capital scaler
try:
    from capital_scaler import capital_scaler
    # Set up capital scaler (disabled by default until user enables)
    capital_scaler.lookback_hours = 48
    capital_scaler.schedule_times = ['00:00', '06:00', '12:00', '18:00']  # Check 4 times daily
    capital_scaler.check_interval_minutes = 240  # 4 hours
    capital_scaler.min_trades_required = 5
    logger.info("Smart capital scaler initialized (inactive by default)")
except Exception as e:
    logger.error(f"Error initializing smart capital scaler: {e}")

# Initialize Risk-Off Trigger System
try:
    # Create risk manager instance
    risk_manager = RiskManager()
    # Default to disabled until explicitly enabled by user
    risk_manager.enabled = False
    
    # Set up the risk manager (disabled by default until user enables)
    risk_manager.check_interval_minutes = 5  # Check every 5 minutes
    risk_manager.recovery_check_interval_minutes = 15  # Check for recovery every 15 minutes
    risk_manager.should_scale_positions = True
    risk_manager.should_modify_stop_losses = True
    risk_manager.should_switch_strategies = True
    risk_manager.should_pause_capital_scaling = True
    
    # Set default values for severe risk position size multiplier
    risk_manager.severe_risk_position_multiplier = 0.3  # 30% of normal size during severe risk
    
    # Initialize risk manager (the _initialize_baseline_metrics method is called internally)
    if hasattr(risk_manager, 'start'):
        risk_manager.start()
    
    logger.info("Risk-Off Trigger System initialized (inactive by default)")
except Exception as e:
    logger.error(f"Error initializing Risk-Off Trigger System: {e}")
    # Create a dummy risk manager if initialization fails
    risk_manager = None

# Initialize Allocation Scheduler
try:
    # Initialize the allocation scheduler with the Flask app
    allocation_scheduler = AllocationScheduler.init_app(app, start=True)
    logger.info("Allocation Scheduler service initialized and started")
except Exception as e:
    logger.error(f"Error initializing Allocation Scheduler: {e}")
    allocation_scheduler = None

# Global variables for bot state
bot_instance = None
bot_thread = None
bot_status = "stopped"
trade_logs = []
is_running = False
last_check_time = None

# Custom template filters
@app.template_filter('to_datetime')
def to_datetime(value):
    """Convert a timestamp (string, integer, or float) to a datetime object."""
    if not value:
        return None
        
    if isinstance(value, (datetime)):
        return value
        
    if isinstance(value, (int, float)):
        # Check if milliseconds or seconds
        if value > 1e10:  # Milliseconds
            return datetime.fromtimestamp(value / 1000)
        else:  # Seconds
            return datetime.fromtimestamp(value)
            
    if isinstance(value, str):
        try:
            # Try ISO format first
            return datetime.fromisoformat(value.replace('Z', '+00:00'))
        except ValueError:
            # Try various formats
            formats = [
                '%Y-%m-%d %H:%M:%S',
                '%Y-%m-%d %H:%M',
                '%Y-%m-%d',
                '%m/%d/%Y %H:%M:%S',
                '%m/%d/%Y'
            ]
            
            for fmt in formats:
                try:
                    return datetime.strptime(value, fmt)
                except ValueError:
                    continue
                    
    # Return current time if parsing fails
    logger.warning(f"Could not parse timestamp: {value}. Using current time.")
    return datetime.now()
    
@app.template_filter('strftime')
def strftime(value, format='%Y-%m-%d %H:%M:%S'):
    """Format a datetime object as a string."""
    if value is None:
        return ""
    return value.strftime(format)
    
@app.template_filter('format_number')
def format_number(value, decimals=2):
    """Format a number with the specified number of decimal places."""
    if value is None:
        return ""
    return f"{value:.{decimals}f}"

def run_bot():
    """Function to run the trading bot in a separate thread."""
    global bot_instance, bot_status, is_running, last_check_time, trade_logs
    
    logger.info("Starting Binance Trading Bot...")
    
    # Get API credentials from environment variables with fallbacks to config
    api_key = os.getenv("BINANCE_API_KEY", Config.API_KEY)
    api_secret = os.getenv("BINANCE_API_SECRET", Config.API_SECRET)
    
    if api_key == "YOUR_BINANCE_API_KEY" or api_secret == "YOUR_BINANCE_SECRET_KEY":
        logger.warning("Using placeholder API credentials. Please set your actual Binance API keys.")
        logger.info("Running in paper trading mode for safety.")
        paper_trading = True
    else:
        paper_trading = Config.PAPER_TRADING
    
    try:
        # Initialize the trading bot with the selected strategy
        bot_instance = TradingBot(
            api_key=api_key,
            api_secret=api_secret,
            trading_pairs=Config.TRADING_PAIRS,
            base_position_size=Config.BASE_POSITION_SIZE,
            check_interval=Config.CHECK_INTERVAL,
            paper_trading=paper_trading,
            strategy_name=Config.ACTIVE_STRATEGY
        )
        
        logger.info(f"Bot initialized successfully with the following settings:")
        logger.info(f"Trading pairs: {', '.join(Config.TRADING_PAIRS)}")
        logger.info(f"Base position size: ${Config.BASE_POSITION_SIZE} USDT")
        logger.info(f"Check interval: {Config.CHECK_INTERVAL} seconds")
        logger.info(f"Paper trading mode: {'ON' if paper_trading else 'OFF'}")
        
        bot_status = "running"
        
        # Run the bot in a loop while the thread is supposed to be running
        while is_running:
            try:
                bot_instance.check_and_execute_trades()
                last_check_time = datetime.now()
                
                # Capture trade logs if available
                if hasattr(bot_instance, 'open_positions'):
                    # Add current stats to the logs
                    trade_log = {
                        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        'open_positions': len(bot_instance.open_positions),
                        'total_trades': bot_instance.total_trades,
                        'successful_trades': bot_instance.successful_trades,
                        'failed_trades': bot_instance.failed_trades,
                        'total_profit_usdt': round(bot_instance.total_profit_usdt, 2)
                    }
                    trade_logs.append(trade_log)
                    # Keep only the latest 100 logs
                    if len(trade_logs) > 100:
                        trade_logs = trade_logs[-100:]
                
                logger.debug(f"Sleeping for {Config.CHECK_INTERVAL} seconds")
                time.sleep(Config.CHECK_INTERVAL)
            except Exception as e:
                logger.error(f"Error in main bot loop: {e}")
                logger.info(f"Waiting {Config.CHECK_INTERVAL} seconds before next attempt.")
                time.sleep(Config.CHECK_INTERVAL)
                
        bot_status = "stopped"
        logger.info("Bot thread stopped.")
                
    except Exception as e:
        logger.error(f"Failed to initialize trading bot: {e}")
        bot_status = "error"
        return

def start_bot():
    """Start the bot in a separate thread."""
    global bot_thread, is_running
    
    if bot_thread is None or not bot_thread.is_alive():
        is_running = True
        bot_thread = threading.Thread(target=run_bot)
        bot_thread.daemon = True
        bot_thread.start()
        return True
    return False

def stop_bot():
    """Stop the running bot thread."""
    global is_running
    is_running = False
    return True

@app.context_processor
def inject_globals():
    """Inject global variables into all templates."""
    from strategies import get_available_strategies
    
    strategy_info = None
    if bot_instance and hasattr(bot_instance, 'strategy'):
        strategy_info = {
            'name': bot_instance.strategy.__class__.__name__,
            'description': bot_instance.strategy.get_description(),
            'parameters': bot_instance.strategy.get_parameters()
        }
    
    return {
        'paper_trading': Config.PAPER_TRADING,
        'active_strategy': Config.ACTIVE_STRATEGY,
        'available_strategies': get_available_strategies(),
        'strategy_info': strategy_info
    }

# neXera Routes
@app.route('/')
def nexera_landing():
    """Redirect to equity curve as the primary investor-facing landing page."""
    return redirect(url_for('equity_curve_page'))
    
@app.route('/landing')
def nexera_static_landing():
    """Original static neXera investor-facing landing page (now accessible at /landing)."""
    return render_template('nexera_landing.html')

@app.route('/dashboard')
def nexera_dashboard():
    """neXera trading dashboard."""
    # Get API credential status
    api_key = os.getenv("BINANCE_API_KEY", Config.API_KEY)
    api_secret = os.getenv("BINANCE_API_SECRET", Config.API_SECRET)
    
    api_configured = (api_key != "YOUR_BINANCE_API_KEY" and api_secret != "YOUR_BINANCE_SECRET_KEY")
    
    return render_template(
        'nexera_dashboard.html',
        bot_status=bot_status,
        api_configured=api_configured,
        config=Config,
        trade_logs=trade_logs[-10:] if trade_logs else [],
        last_check_time=last_check_time.strftime('%Y-%m-%d %H:%M:%S') if last_check_time else None,
        bot_stats=get_bot_stats() if bot_instance else None
    )

@app.route('/legacy')
def index():
    """Legacy main dashboard page."""
    # Get API credential status
    api_key = os.getenv("BINANCE_API_KEY", Config.API_KEY)
    api_secret = os.getenv("BINANCE_API_SECRET", Config.API_SECRET)
    
    api_configured = (api_key != "YOUR_BINANCE_API_KEY" and api_secret != "YOUR_BINANCE_SECRET_KEY")
    
    return render_template(
        'index.html',
        bot_status=bot_status,
        api_configured=api_configured,
        config=Config,
        trade_logs=trade_logs[-10:] if trade_logs else [],  # Show most recent 10 logs
        last_check_time=last_check_time.strftime('%Y-%m-%d %H:%M:%S') if last_check_time else None,
        bot_stats=get_bot_stats() if bot_instance else None
    )

@app.route('/start_bot', methods=['POST'])
def start_bot_route():
    """API endpoint to start the bot."""
    if start_bot():
        flash('Bot started successfully!', 'success')
    else:
        flash('Bot is already running!', 'warning')
    return redirect(url_for('index'))

@app.route('/stop_bot', methods=['POST'])
def stop_bot_route():
    """API endpoint to stop the bot."""
    if stop_bot():
        flash('Bot stopping...', 'success')
    else:
        flash('Failed to stop the bot!', 'danger')
    return redirect(url_for('index'))

# neXera API Control Endpoints
@app.route('/api/control/start', methods=['POST'])
def api_start_bot():
    """API endpoint to start the bot."""
    result = start_bot()
    return jsonify({
        'success': result,
        'message': 'Bot started successfully!' if result else 'Bot is already running!',
        'status': 'active' if result else bot_status
    })

@app.route('/api/control/stop', methods=['POST'])
def api_stop_bot():
    """API endpoint to stop the bot."""
    result = stop_bot()
    return jsonify({
        'success': result,
        'message': 'Bot stopping...' if result else 'Failed to stop the bot!',
        'status': 'stopping' if result else bot_status
    })

@app.route('/api/control/emergency-stop', methods=['POST'])
def api_emergency_stop():
    """API endpoint to trigger emergency stop."""
    if bot_instance:
        try:
            # Call emergency stop function
            Config.EMERGENCY_STOP_ACTIVE = True
            
            # Log the action
            logger.warning("Emergency stop triggered via API")
            if alert_notifier:
                alert_notifier.send_alert(
                    AlertType.EMERGENCY_STOP if AlertType else "emergency_stop",
                    "Emergency stop triggered via API",
                    priority=AlertPriority.CRITICAL if AlertPriority else "critical"
                )
            
            return jsonify({
                'success': True,
                'message': 'Emergency stop triggered, all positions will be closed.',
                'status': 'emergency_stopped'
            })
        except Exception as e:
            logger.error(f"Error triggering emergency stop: {e}")
            return jsonify({
                'success': False,
                'message': f'Error triggering emergency stop: {e}',
                'status': bot_status
            })
    else:
        return jsonify({
            'success': False,
            'message': 'Bot is not running, cannot trigger emergency stop.',
            'status': 'stopped'
        })

# Helper functions for report generation
def calculate_performance_metrics(equity_history):
    """
    Calculate performance metrics from equity history data.
    
    Args:
        equity_history: List of PresetEquityHistory objects
        
    Returns:
        dict: Dictionary of performance metrics
    """
    if not equity_history:
        return {
            'total_return': 0,
            'max_drawdown': 0,
            'sharpe_ratio': 0,
            'sortino_ratio': 0,
            'win_rate': 0,
            'avg_trade_return': 0,
            'volatility': 0,
            'alpha': 0,
            'beta': 0
        }
    
    # Get the last entry for most metrics
    latest = equity_history[-1]
    
    # Calculate win rate
    win_rate = 0
    if latest.win_count is not None and latest.loss_count is not None:
        total_trades = latest.win_count + latest.loss_count
        if total_trades > 0:
            win_rate = (latest.win_count / total_trades) * 100
    
    # Get total return
    total_return = 0
    if len(equity_history) > 1:
        initial_equity = equity_history[0].equity
        final_equity = latest.equity
        if initial_equity > 0:
            total_return = ((final_equity - initial_equity) / initial_equity) * 100
    
    # Calculate average trade return
    avg_trade_return = 0
    if latest.win_count is not None and latest.loss_count is not None:
        total_trades = latest.win_count + latest.loss_count
        if total_trades > 0 and total_return != 0:
            avg_trade_return = total_return / total_trades
    
    return {
        'total_return': latest.pnl_percent if latest.pnl_percent is not None else total_return,
        'max_drawdown': latest.max_drawdown if latest.max_drawdown is not None else 0,
        'sharpe_ratio': latest.sharpe_ratio if latest.sharpe_ratio is not None else 0,
        'sortino_ratio': latest.sortino_ratio if latest.sortino_ratio is not None else 0,
        'win_rate': win_rate,
        'avg_trade_return': avg_trade_return,
        'volatility': 0,  # Calculate if needed
        'alpha': 0,  # Calculate if needed
        'beta': 0  # Calculate if needed
    }

def get_btc_comparison_data(equity_history=None):
    """
    Get BTC/USDT comparison data for the same time period as equity history.
    
    Args:
        equity_history: List of PresetEquityHistory objects or None if using bot instance data
        
    Returns:
        dict: BTC comparison data and metrics
    """
    try:
        # If we don't have equity history but have a running bot
        if equity_history is None and bot_instance and bot_status == "running":
            performance_stats = bot_instance.get_performance_stats()
            if performance_stats and 'benchmark_values' in performance_stats and performance_stats['benchmark_values']:
                # Calculate strategy return
                initial_value = performance_stats['equity_curve'][0] if performance_stats['equity_curve'] else 0
                final_value = performance_stats['equity_curve'][-1] if performance_stats['equity_curve'] else 0
                strategy_return = ((final_value - initial_value) / initial_value) * 100 if initial_value > 0 else 0
                
                # Calculate BTC return
                initial_btc = performance_stats['benchmark_values'][0] if performance_stats['benchmark_values'] else 0
                final_btc = performance_stats['benchmark_values'][-1] if performance_stats['benchmark_values'] else 0
                btc_return = ((final_btc - initial_btc) / initial_btc) * 100 if initial_btc > 0 else 0
                
                # Calculate alpha (excess return)
                alpha = strategy_return - btc_return
                
                return {
                    'available': True,
                    'strategy_return': strategy_return,
                    'btc_return': btc_return,
                    'alpha': alpha
                }
            
            try:
                # Try to get BTC data from binance_client
                from binance_client import get_historical_data
                
                # Get first and last timestamp from bot instance
                start_time = datetime.now() - timedelta(days=30)  # Default to last 30 days
                end_time = datetime.now()
                
                if performance_stats and 'timestamps' in performance_stats and performance_stats['timestamps']:
                    start_ts = performance_stats['timestamps'][0]
                    end_ts = performance_stats['timestamps'][-1]
                    start_time = datetime.fromtimestamp(start_ts)
                    end_time = datetime.fromtimestamp(end_ts)
                
                # Get BTC/USDT data
                btc_data = get_historical_data('BTC/USDT', '1d', start_time, end_time)
                
                if btc_data is not None and len(btc_data) > 1:
                    initial_btc = btc_data.iloc[0]['close']
                    final_btc = btc_data.iloc[-1]['close']
                    btc_return = ((final_btc - initial_btc) / initial_btc) * 100
                    
                    # Get strategy return
                    initial_value = performance_stats['equity_curve'][0] if performance_stats['equity_curve'] else 0
                    final_value = performance_stats['equity_curve'][-1] if performance_stats['equity_curve'] else 0
                    strategy_return = ((final_value - initial_value) / initial_value) * 100 if initial_value > 0 else 0
                    
                    # Calculate alpha (excess return)
                    alpha = strategy_return - btc_return
                    
                    return {
                        'available': True,
                        'strategy_return': strategy_return,
                        'btc_return': btc_return,
                        'alpha': alpha
                    }
            except (ImportError, Exception) as e:
                logger.warning(f"Could not import get_historical_data from binance_client: {e}")
                
        # If we have equity history data from database
        if equity_history and len(equity_history) > 0:
            try:
                # Get strategy return from equity history
                initial_value = equity_history[0].equity_value
                final_value = equity_history[-1].equity_value
                strategy_return = ((final_value - initial_value) / initial_value) * 100 if initial_value > 0 else 0
                
                # Try to get BTC data for the same period
                try:
                    from binance_client import get_historical_data
                    
                    # Get start and end timestamps from equity history
                    start_time = equity_history[0].timestamp
                    end_time = equity_history[-1].timestamp
                    
                    # Get BTC/USDT data
                    btc_data = get_historical_data('BTC/USDT', '1d', start_time, end_time)
                    
                    if btc_data is not None and len(btc_data) > 1:
                        initial_btc = btc_data.iloc[0]['close']
                        final_btc = btc_data.iloc[-1]['close']
                        btc_return = ((final_btc - initial_btc) / initial_btc) * 100
                        
                        # Calculate alpha (excess return)
                        alpha = strategy_return - btc_return
                        
                        return {
                            'available': True,
                            'strategy_return': strategy_return,
                            'btc_return': btc_return,
                            'alpha': alpha
                        }
                except (ImportError, Exception) as e:
                    logger.warning(f"Could not get BTC comparison data: {e}")
                
                # Check if we have benchmark values in the equity history
                if hasattr(equity_history[-1], 'benchmark_value') and equity_history[-1].benchmark_value:
                    initial_btc = equity_history[0].benchmark_value
                    final_btc = equity_history[-1].benchmark_value
                    if initial_btc > 0:
                        btc_return = ((final_btc - initial_btc) / initial_btc) * 100
                        alpha = strategy_return - btc_return
                        
                        return {
                            'available': True,
                            'strategy_return': strategy_return,
                            'btc_return': btc_return,
                            'alpha': alpha
                        }
            except Exception as e:
                logger.warning(f"Error calculating BTC comparison from equity history: {e}")
    except Exception as e:
        logger.error(f"Error in get_btc_comparison_data: {e}")
    
    # Return default structure if all else fails
    return {
        'available': False,
        'message': 'BTC comparison data not available for this report',
        'strategy_return': 0,
        'btc_return': 0,
        'alpha': 0
    }

# Allocation Preset API Endpoints
@app.route('/api/allocation-presets', methods=['GET'])
def api_list_allocation_presets():
    """Get a list of saved allocation presets."""
    try:
        presets = AllocationPreset.query.order_by(AllocationPreset.updated_at.desc()).all()
        return jsonify({
            'success': True,
            'presets': [preset.to_dict() for preset in presets]
        })
    except Exception as e:
        logger.error(f"Error listing allocation presets: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/allocation-presets/<int:preset_id>', methods=['GET'])
def api_get_allocation_preset(preset_id):
    """Get a specific allocation preset by ID."""
    try:
        preset = AllocationPreset.query.get(preset_id)
        if not preset:
            return jsonify({
                'success': False,
                'error': f'Preset with ID {preset_id} not found'
            }), 404
            
        return jsonify({
            'success': True,
            'preset': preset.to_dict()
        })
    except Exception as e:
        logger.error(f"Error getting allocation preset: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/allocation-presets', methods=['POST'])
def api_create_allocation_preset():
    """Create a new allocation preset."""
    try:
        data = request.get_json()
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
            
        # Validate required fields
        if 'name' not in data or not data['name']:
            return jsonify({
                'success': False,
                'error': 'Preset name is required'
            }), 400
            
        if 'weights' not in data or not data['weights']:
            return jsonify({
                'success': False,
                'error': 'Strategy weights are required'
            }), 400
            
        # Check for duplicate name
        existing = AllocationPreset.query.filter_by(name=data['name']).first()
        if existing:
            return jsonify({
                'success': False,
                'error': f'A preset with the name "{data["name"]}" already exists'
            }), 400
            
        # Create new preset
        preset = AllocationPreset(
            name=data['name'],
            description=data.get('description'),
            weights=data['weights'],
            equity_curve_data=data.get('equity_curve_data'),
            total_return=data.get('total_return'),
            sharpe_ratio=data.get('sharpe_ratio'),
            max_drawdown=data.get('max_drawdown'),
            volatility=data.get('volatility'),
            tags=','.join(data.get('tags', [])) if data.get('tags') else None,
            is_favorite=data.get('is_favorite', False)
        )
        
        db.session.add(preset)
        db.session.commit()
        
        logger.info(f"Created new allocation preset: {preset.name}")
        
        return jsonify({
            'success': True,
            'message': 'Allocation preset created successfully',
            'preset': preset.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error creating allocation preset: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/allocation-presets/<int:preset_id>', methods=['PUT'])
def api_update_allocation_preset(preset_id):
    """Update an existing allocation preset."""
    try:
        preset = AllocationPreset.query.get(preset_id)
        if not preset:
            return jsonify({
                'success': False,
                'error': f'Preset with ID {preset_id} not found'
            }), 404
            
        data = request.get_json()
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
            
        # Check for name change and duplicate
        if 'name' in data and data['name'] != preset.name:
            existing = AllocationPreset.query.filter_by(name=data['name']).first()
            if existing:
                return jsonify({
                    'success': False,
                    'error': f'A preset with the name "{data["name"]}" already exists'
                }), 400
            preset.name = data['name']
            
        # Update fields if provided
        if 'description' in data:
            preset.description = data['description']
            
        if 'weights' in data:
            preset.weights = data['weights']
            
        if 'equity_curve_data' in data:
            preset.equity_curve_data = data['equity_curve_data']
            
        if 'total_return' in data:
            preset.total_return = data['total_return']
            
        if 'sharpe_ratio' in data:
            preset.sharpe_ratio = data['sharpe_ratio']
            
        if 'max_drawdown' in data:
            preset.max_drawdown = data['max_drawdown']
            
        if 'volatility' in data:
            preset.volatility = data['volatility']
            
        if 'tags' in data:
            preset.tags = ','.join(data['tags']) if data['tags'] else None
            
        if 'is_favorite' in data:
            preset.is_favorite = data['is_favorite']
            
        # Update the updated_at timestamp
        preset.updated_at = datetime.now()
        
        db.session.commit()
        
        logger.info(f"Updated allocation preset: {preset.name}")
        
        return jsonify({
            'success': True,
            'message': 'Allocation preset updated successfully',
            'preset': preset.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error updating allocation preset: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/allocation-presets/<int:preset_id>', methods=['DELETE'])
def api_delete_allocation_preset(preset_id):
    """Delete an allocation preset."""
    try:
        preset = AllocationPreset.query.get(preset_id)
        if not preset:
            return jsonify({
                'success': False,
                'error': f'Preset with ID {preset_id} not found'
            }), 404
            
        preset_name = preset.name
        db.session.delete(preset)
        db.session.commit()
        
        logger.info(f"Deleted allocation preset: {preset_name}")
        
        return jsonify({
            'success': True,
            'message': f'Allocation preset "{preset_name}" deleted successfully'
        })
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting allocation preset: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/allocation-presets/<int:preset_id>/apply', methods=['POST'])
def api_apply_allocation_preset(preset_id):
    """Apply a saved allocation preset to live trading."""
    try:
        preset = AllocationPreset.query.get(preset_id)
        if not preset:
            return jsonify({
                'success': False,
                'error': f'Preset with ID {preset_id} not found'
            }), 404
            
        # Get optional parameters
        data = request.get_json() or {}
        ensemble_name = data.get('ensemble_name')
        duration_hours = data.get('duration_hours', 24)
        
        # Apply weights using the auto rotation engine
        from auto_rotation import AutoRotationEngine
        rotation_engine = AutoRotationEngine()
        
        # The weights should already be in 0-1 format in the database
        result = rotation_engine.apply_manual_weights(
            preset.weights,
            ensemble_name=ensemble_name,
            duration_hours=duration_hours
        )
        
        if not result.get('success', False):
            return jsonify(result), 400
            
        # Update the last_applied_at timestamp
        preset.last_applied_at = datetime.now()
        db.session.commit()
        
        logger.info(f"Applied allocation preset to live trading: {preset.name}")
        
        return jsonify({
            'success': True,
            'message': f'Allocation preset "{preset.name}" applied to live trading',
            'applied_at': preset.last_applied_at.isoformat(),
            'ensemble': result.get('ensemble_name', 'default'),
            'duration_hours': duration_hours
        })
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error applying allocation preset: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/allocation-presets/<int:preset_id>/toggle-favorite', methods=['POST'])
def api_toggle_preset_favorite(preset_id):
    """Toggle the favorite status of an allocation preset."""
    try:
        preset = AllocationPreset.query.get(preset_id)
        if not preset:
            return jsonify({
                'success': False,
                'error': f'Preset with ID {preset_id} not found'
            }), 404
            
        # Toggle favorite status
        preset.is_favorite = not preset.is_favorite
        db.session.commit()
        
        status = 'favorited' if preset.is_favorite else 'unfavorited'
        logger.info(f"Preset {preset.name} {status}")
        
        return jsonify({
            'success': True,
            'message': f'Preset "{preset.name}" {status}',
            'is_favorite': preset.is_favorite
        })
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error toggling preset favorite status: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# AI Strategy Recommender API Endpoints
@app.route('/api/strategy-recommendations', methods=['GET'])
def api_get_strategy_recommendation():
    """
    Get strategy allocation recommendations based on historical performance.
    
    Query Parameters:
        lookback_days (int, optional): Number of days to analyze (default: 30)
        strategy_ids (str, optional): Comma-separated list of strategy IDs to consider
        min_allocation (float, optional): Minimum allocation per strategy (0-1)
        max_allocation (float, optional): Maximum allocation per strategy (0-1)
        optimization_objective (str, optional): Optimization objective 
                                               ('balanced', 'max_return', 'min_risk', 'max_sharpe')
        compare_current (bool, optional): Whether to include comparison with current allocation
                                               
    Returns:
        JSON: Recommendation results with strategy weights and projected metrics
    """
    try:
        # Get query parameters
        lookback_days = request.args.get('lookback_days')
        if lookback_days:
            lookback_days = int(lookback_days)
            
        strategy_ids_str = request.args.get('strategy_ids', '')
        strategy_ids = [int(id) for id in strategy_ids_str.split(',') if id.strip()]
        
        min_allocation = request.args.get('min_allocation')
        if min_allocation:
            min_allocation = float(min_allocation)
            
        max_allocation = request.args.get('max_allocation')
        if max_allocation:
            max_allocation = float(max_allocation)
            
        optimization_objective = request.args.get('optimization_objective', 'balanced')
        compare_current = request.args.get('compare_current', 'false').lower() == 'true'
        
        # Get current allocation weights if requested
        current_weights = None
        if compare_current:
            try:
                # Import auto rotation engine to get current weights
                from auto_rotation import auto_rotation_engine
                
                # Get current weights
                current_allocation = auto_rotation_engine.get_current_allocation()
                if current_allocation:
                    # Convert to format expected by recommender
                    current_weights = {
                        int(strategy_id): float(weight)
                        for strategy_id, weight in current_allocation.items()
                    }
                    
                    # Calculate metrics for current allocation for comparison
                    current_metrics = strategy_recommender._calculate_projected_metrics(
                        current_weights,
                        strategy_recommender.analyze_strategies(lookback_days=lookback_days)
                    ) if current_weights else None
            except Exception as e:
                logger.warning(f"Error getting current allocation weights: {e}")
                # Continue without comparison if there's an error
        
        # Get recommendation
        recommendation = strategy_recommender.recommend_allocation(
            lookback_days=lookback_days,
            strategy_ids=strategy_ids if strategy_ids else None,
            min_allocation=min_allocation,
            max_allocation=max_allocation,
            optimization_objective=optimization_objective,
            current_weights=current_weights
        )
        
        # Add current allocation comparison if requested and available
        if compare_current and current_weights and 'success' in recommendation and recommendation['success']:
            # Format current weights as percentages for response
            current_weight_percentages = {
                str(strategy_id): round(weight * 100, 2)
                for strategy_id, weight in current_weights.items()
            }
            
            # Add current allocation to the response
            recommendation['current_allocation'] = {
                'weights': current_weight_percentages,
                'metrics': current_metrics
            }
            
            # Add delta metrics (improvement from current to recommended)
            if current_metrics and 'projected_metrics' in recommendation:
                recommendation['delta_metrics'] = {
                    'roi': recommendation['projected_metrics']['roi'] - current_metrics['roi'],
                    'sharpe_ratio': recommendation['projected_metrics']['sharpe_ratio'] - current_metrics['sharpe_ratio'],
                    'volatility': recommendation['projected_metrics']['volatility'] - current_metrics['volatility'],
                    'max_drawdown': recommendation['projected_metrics']['max_drawdown'] - current_metrics['max_drawdown'],
                    'win_rate': recommendation['projected_metrics']['win_rate'] - current_metrics['win_rate']
                }
        
        return jsonify(recommendation)
        
    except Exception as e:
        logger.error(f"Error generating strategy recommendation: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/strategy-recommendations/analyze', methods=['GET'])
def api_analyze_strategies():
    """
    Analyze strategy performance without generating weights.
    
    Query Parameters:
        lookback_days (int, optional): Number of days to analyze (default: 30)
        strategy_ids (str, optional): Comma-separated list of strategy IDs to analyze
                                   
    Returns:
        JSON: Analysis results with strategy metrics and scores
    """
    try:
        # Get query parameters
        lookback_days = request.args.get('lookback_days')
        if lookback_days:
            lookback_days = int(lookback_days)
            
        strategy_ids_str = request.args.get('strategy_ids', '')
        strategy_ids = [int(id) for id in strategy_ids_str.split(',') if id.strip()]
        
        # Analyze strategies
        analysis = strategy_recommender.analyze_strategies(
            lookback_days=lookback_days,
            strategy_ids=strategy_ids if strategy_ids else None
        )
        
        # Convert to list for response
        strategies = []
        for strategy_id, data in analysis.items():
            strategies.append({
                'id': strategy_id,
                'name': data['name'],
                'score': data['score'],
                'metrics': data['metrics'],
                'config_type': data['config_type'],
                'tags': data['tags'],
                'description': data['description']
            })
            
        # Sort by score (descending)
        strategies.sort(key=lambda s: s['score'], reverse=True)
        
        return jsonify({
            'success': True,
            'strategies': strategies,
            'lookback_days': lookback_days or strategy_recommender.default_lookback_days,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"Error analyzing strategies: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/strategy-recommendations/save', methods=['POST'])
def api_save_recommendation():
    """
    Save a strategy recommendation as an allocation preset.
    
    Request Body:
        recommendation (dict): Recommendation result from /api/strategy-recommendations
        name (str, optional): Name for the preset
        description (str, optional): Description for the preset
        
    Returns:
        JSON: Created preset details
    """
    try:
        data = request.get_json()
        
        if not data or 'recommendation' not in data:
            return jsonify({
                'success': False,
                'error': 'Missing required parameter: recommendation'
            }), 400
            
        recommendation = data['recommendation']
        name = data.get('name')
        description = data.get('description')
        
        # Save recommendation as preset
        preset = strategy_recommender.save_recommendation_as_preset(
            recommendation=recommendation,
            name=name,
            description=description
        )
        
        if preset:
            return jsonify({
                'success': True,
                'message': f'Recommendation saved as preset "{preset.name}"',
                'preset': preset.to_dict()
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Failed to save recommendation as preset'
            }), 500
            
    except Exception as e:
        logger.error(f"Error saving recommendation as preset: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/strategy-recommendations/apply', methods=['POST'])
def api_apply_recommendation():
    """
    Apply a strategy recommendation directly to the active allocation.
    
    Request Body:
        recommendation (dict): Recommendation result from /api/strategy-recommendations
        transition_speed (str, optional): Speed for weight transition ('immediate', 'gradual', 'slow')
        lock_duration (int, optional): Duration in hours to lock the weights (default: 24)
        
    Returns:
        JSON: Status of weight application
    """
    try:
        data = request.get_json()
        
        if not data or 'recommendation' not in data:
            return jsonify({
                'success': False,
                'error': 'Missing required parameter: recommendation'
            }), 400
            
        recommendation = data['recommendation']
        transition_speed = data.get('transition_speed', 'immediate')
        lock_duration = data.get('lock_duration', 24)
        
        # Convert recommendation weights to format expected by apply_manual_weights
        if 'weights' not in recommendation:
            return jsonify({
                'success': False,
                'error': 'Invalid recommendation: missing weights'
            }), 400
            
        # Convert percentage weights to decimal (0-1)
        weights = {
            int(strategy_id): float(weight) / 100
            for strategy_id, weight in recommendation['weights'].items()
        }
        
        # Import and initialize auto rotation engine
        from auto_rotation import AutoRotationEngine
        rotation_engine = AutoRotationEngine()
        
        # Apply weights
        result = rotation_engine.apply_manual_weights(
            weights, 
            duration_hours=lock_duration
        )
        
        if not result.get('success', False):
            return jsonify({
                'success': False,
                'error': result.get('message', 'Failed to apply weights')
            }), 400
            
        # Log the action
        logger.info(f"Applied AI-recommended weights: {weights}")
        
        return jsonify({
            'success': True,
            'message': f'AI recommendation applied successfully with {len(weights)} strategies',
            'applied_weights': recommendation['weights'],
            'lock_duration_hours': lock_duration,
            'lock_expiry': (datetime.now() + timedelta(hours=lock_duration)).isoformat()
        })
        
    except Exception as e:
        logger.error(f"Error applying recommendation: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/strategy-recommendations/apply-from-report', methods=['POST'])
def api_apply_recommendation_from_report():
    """
    Apply AI recommendation directly from the investor report.
    
    Request Body:
        preset_id (int): The ID of the allocation preset
        lock_duration (int, optional): Duration in hours to lock the weights (default: 24)
        
    Returns:
        JSON: Status of weight application
    """
    try:
        data = request.get_json()
        
        if not data or 'preset_id' not in data:
            return jsonify({
                'success': False,
                'error': 'Missing required parameter: preset_id'
            }), 400
            
        preset_id = data['preset_id']
        lock_duration = data.get('lock_duration', 24)
        
        # Get allocation preset
        allocation_preset = AllocationPreset.query.get(preset_id)
        if not allocation_preset:
            return jsonify({
                'success': False,
                'error': f'Allocation preset with ID {preset_id} not found'
            }), 404
        
        # Get strategy IDs from allocation preset
        strategy_ids = []
        strategy_weights = {}
        
        for strategy_name, weight in allocation_preset.weights.items():
            # Find strategy ID by name
            strategy = Strategy.query.filter_by(name=strategy_name).first()
            if strategy:
                strategy_ids.append(strategy.id)
                strategy_weights[strategy.id] = weight
        
        if not strategy_ids:
            return jsonify({
                'success': False,
                'error': 'No valid strategies found in allocation preset'
            }), 400
        
        # Generate AI recommendation
        from strategy_recommender import StrategyRecommender
        recommender = StrategyRecommender()
        
        # Use default optimization settings
        lookback_days = 30
        optimization_objective = "sharpe_ratio"
        min_allocation = 0.05
        max_allocation = 0.4
        
        # Get recommendation
        recommendation_data = recommender.recommend_allocation(
            lookback_days=lookback_days,
            optimization_objective=optimization_objective,
            min_allocation=min_allocation,
            max_allocation=max_allocation,
            strategy_ids=strategy_ids,
            current_weights=strategy_weights
        )
        
        if not recommendation_data or not recommendation_data.get('success'):
            return jsonify({
                'success': False,
                'error': 'Failed to generate recommendation'
            }), 500
        
        # Extract weights from recommendation
        strategy_results = recommendation_data.get('strategies', [])
        weights = {}
        
        for strategy in strategy_results:
            strategy_id = strategy.get('id')
            weight = strategy.get('weight', 0) / 100.0  # Convert percentage to decimal
            
            if strategy_id and weight > 0:
                weights[strategy_id] = weight
        
        if not weights:
            return jsonify({
                'success': False,
                'error': 'No valid weights found in recommendation'
            }), 400
        
        # Get strategy names for weights
        named_weights = {}
        for strategy_id, weight in weights.items():
            strategy = Strategy.query.get(strategy_id)
            if strategy and strategy.name:
                named_weights[strategy.name] = weight
        
        if not named_weights:
            return jsonify({
                'success': False,
                'error': 'Could not map strategy IDs to names'
            }), 500
        
        # Apply the weights to the auto-rotation engine
        from auto_rotation import auto_rotation_engine
        
        result = auto_rotation_engine.apply_manual_weights(
            weights=named_weights,
            duration_hours=lock_duration
        )
        
        if not result.get('success'):
            return jsonify({
                'success': False,
                'error': result.get('error', 'Failed to apply weights to auto-rotation engine'),
                'details': result
            }), 500
            
        # Create log entry
        try:
            log_entry = SystemActionLog(
                action_type='apply_ai_recommendation_from_report',
                details={
                    'preset_id': preset_id,
                    'weights': named_weights,
                    'lock_duration': lock_duration,
                    'recommendation_data': recommendation_data,
                    'source': 'investor_report'
                },
                status='success',
                message=f'Applied AI recommendation from investor report for preset {preset_id}'
            )
            db.session.add(log_entry)
            db.session.commit()
        except Exception as e:
            logger.error(f"Error creating log entry: {e}")
        
        # Create trigger event for tracking changes
        try:
            trigger_event = PresetTriggerEvent(
                preset_id=preset_id,
                event_type='ai_recommendation_applied',
                title='AI Recommendation Applied',
                description=f'Applied AI-optimized allocation from investor report',
                importance=4,  # Higher importance
                color='#FF6A00',  # neXera orange
                metadata={
                    'recommendation_data': recommendation_data,
                    'comparison': recommendation_data.get('comparison_data'),
                    'applied_weights': named_weights,
                    'lock_duration': lock_duration
                }
            )
            db.session.add(trigger_event)
            db.session.commit()
        except Exception as e:
            logger.error(f"Error creating trigger event: {e}")
        
        return jsonify({
            'success': True,
            'message': 'AI recommendation applied successfully',
            'applied_weights': named_weights,
            'lock_duration_hours': lock_duration,
            'lock_expiry': (datetime.now() + timedelta(hours=lock_duration)).isoformat(),
            'improvement_metrics': recommendation_data.get('comparison_data')
        })
        
    except Exception as e:
        logger.error(f"Error applying recommendation from report: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/strategy-recommendations/schedule', methods=['POST'])
def api_schedule_recommendation():
    """
    Schedule a strategy recommendation for future application.
    
    Request Body:
        recommendation (dict): Recommendation result from /api/strategy-recommendations
        scheduled_time (str): ISO timestamp for scheduled application
        preview_mode (bool, optional): Whether to run in preview mode (default: false)
        notify_before_minutes (int, optional): Minutes before to send notification
        
    Returns:
        JSON: Created schedule details
    """
    try:
        data = request.get_json()
        
        if not data or 'recommendation' not in data or 'scheduled_time' not in data:
            return jsonify({
                'success': False,
                'error': 'Missing required parameters: recommendation and scheduled_time'
            }), 400
            
        recommendation = data['recommendation']
        scheduled_time = data['scheduled_time']
        preview_mode = data.get('preview_mode', False)
        notify_before_minutes = data.get('notify_before_minutes')
        
        # Ensure allocation scheduler is available
        if not allocation_scheduler:
            return jsonify({
                'success': False,
                'error': 'Allocation scheduler service is not available'
            }), 500
            
        # Convert recommendation to an allocation preset
        preset = strategy_recommender.save_recommendation_as_preset(recommendation)
        if not preset:
            return jsonify({
                'success': False,
                'error': 'Failed to create allocation preset from recommendation'
            }), 500
            
        # Create schedule
        schedule = allocation_scheduler.create_schedule(
            preset_id=preset.id,
            scheduled_time=scheduled_time,
            notify_before_minutes=notify_before_minutes,
            preview_mode=preview_mode,
            created_by='ai_recommender'
        )
        
        return jsonify({
            'success': True,
            'message': f'AI recommendation scheduled for {schedule.scheduled_time}',
            'schedule': schedule.to_dict(),
            'preset': preset.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error scheduling recommendation: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/strategy-recommendations/settings', methods=['POST'])
def api_update_recommender_settings():
    """
    Update settings for the AI Strategy Recommender.
    
    Request Body:
        metric_weights (dict): Dictionary mapping metric names to weights (0-1)
        include_negative_performers (bool, optional): Whether to include strategies with negative performance
        volatility_adjusted (bool, optional): Whether to apply volatility-based adjustments
        use_market_context (bool, optional): Whether to use market condition context
        
    Returns:
        JSON: Status of settings update
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'Missing request body'
            }), 400
            
        # Update metric weights if provided
        if 'metric_weights' in data:
            metric_weights = data['metric_weights']
            strategy_recommender.set_metric_weights(metric_weights)
            
        # Update other settings if provided
        if 'include_negative_performers' in data:
            strategy_recommender.include_negative_performers = data['include_negative_performers']
            
        if 'volatility_adjusted' in data:
            strategy_recommender.volatility_adjusted = data['volatility_adjusted']
            
        if 'use_market_context' in data:
            strategy_recommender.use_market_context = data['use_market_context']
            
        return jsonify({
            'success': True,
            'message': 'Recommender settings updated successfully',
            'current_settings': {
                'metric_weights': strategy_recommender.metric_weights,
                'include_negative_performers': strategy_recommender.include_negative_performers,
                'volatility_adjusted': strategy_recommender.volatility_adjusted,
                'use_market_context': strategy_recommender.use_market_context
            }
        })
        
    except Exception as e:
        logger.error(f"Error updating recommender settings: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/strategy-recommendations/custom-weights', methods=['POST'])
def api_custom_weight_recommendation():
    """
    Generate projected metrics for custom strategy weights.
    
    Request Body:
        weights (dict): Dictionary mapping strategy IDs to weights (0-100)
        lookback_days (int, optional): Number of days to analyze for projection
        
    Returns:
        JSON: Projected metrics for the custom weights
    """
    try:
        data = request.get_json()
        
        if not data or 'weights' not in data:
            return jsonify({
                'success': False,
                'error': 'Missing required parameter: weights'
            }), 400
            
        weights = data['weights']
        lookback_days = data.get('lookback_days')
        if lookback_days:
            lookback_days = int(lookback_days)
            
        # Convert weights to appropriate format
        weights_dict = {}
        for strategy_id, weight in weights.items():
            try:
                weights_dict[int(strategy_id)] = float(weight) / 100  # Convert to 0-1 scale
            except (ValueError, TypeError):
                return jsonify({
                    'success': False,
                    'error': f'Invalid weight format for strategy ID {strategy_id}'
                }), 400
                
        # Validate weights
        if not weights_dict:
            return jsonify({
                'success': False,
                'error': 'No valid weights provided'
            }), 400
            
        total_weight = sum(weights_dict.values())
        if abs(total_weight - 1.0) > 0.01:  # Allow small rounding errors
            return jsonify({
                'success': False,
                'error': f'Weights must sum to 1.0 (currently {total_weight:.2f})'
            }), 400
            
        # Get strategy analysis
        strategy_ids = list(weights_dict.keys())
        analysis = strategy_recommender.analyze_strategies(
            lookback_days=lookback_days,
            strategy_ids=strategy_ids
        )
        
        if not analysis:
            return jsonify({
                'success': False,
                'error': 'No strategy data available for the specified weights'
            }), 400
            
        # Calculate projected metrics
        projected_metrics = strategy_recommender._calculate_projected_metrics(weights_dict, analysis)
        
        # Format strategy details
        strategies = []
        for strategy_id, weight in weights_dict.items():
            if strategy_id in analysis:
                strategy_data = analysis[strategy_id]
                strategies.append({
                    'id': strategy_id,
                    'name': strategy_data['name'],
                    'weight': round(weight * 100, 2),
                    'score': strategy_data['score'],
                    'roi': strategy_data['metrics']['roi'],
                    'sharpe_ratio': strategy_data['metrics']['sharpe_ratio'],
                    'volatility': strategy_data['metrics']['volatility'],
                    'max_drawdown': strategy_data['metrics']['max_drawdown'],
                    'win_rate': strategy_data['metrics']['win_rate']
                })
        
        # Sort strategies by weight (descending)
        strategies.sort(key=lambda s: s['weight'], reverse=True)
        
        return jsonify({
            'success': True,
            'timestamp': datetime.now().isoformat(),
            'projected_metrics': projected_metrics,
            'strategies': strategies,
            'lookback_days': lookback_days or strategy_recommender.default_lookback_days
        })
        
    except Exception as e:
        logger.error(f"Error processing custom weights: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Allocation Schedule API Endpoints
@app.route('/api/allocation-schedules', methods=['GET'])
def api_list_allocation_schedules():
    """Get a list of scheduled allocations."""
    try:
        # Get query parameters
        include_executed = request.args.get('include_executed', 'false').lower() == 'true'
        include_inactive = request.args.get('include_inactive', 'false').lower() == 'true'
        limit = int(request.args.get('limit', '100'))
        
        # Ensure allocation scheduler is available
        if not allocation_scheduler:
            return jsonify({
                'success': False,
                'error': 'Allocation scheduler service is not available'
            }), 500
            
        # Get schedules
        schedules = allocation_scheduler.get_schedules(
            include_executed=include_executed,
            include_inactive=include_inactive,
            limit=limit
        )
        
        # Convert to dictionary format
        result = [schedule.to_dict() for schedule in schedules]
        
        return jsonify({
            'success': True,
            'schedules': result
        })
    except Exception as e:
        logger.error(f"Error listing allocation schedules: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/allocation-schedules/<int:schedule_id>', methods=['GET'])
def api_get_allocation_schedule(schedule_id):
    """Get a specific allocation schedule by ID."""
    try:
        # Ensure allocation scheduler is available
        if not allocation_scheduler:
            return jsonify({
                'success': False,
                'error': 'Allocation scheduler service is not available'
            }), 500
            
        # Get schedule
        schedule = allocation_scheduler.get_schedule(schedule_id)
        if not schedule:
            return jsonify({
                'success': False,
                'error': f'Schedule with ID {schedule_id} not found'
            }), 404
            
        # Return schedule data
        return jsonify({
            'success': True,
            'schedule': schedule.to_dict()
        })
    except Exception as e:
        logger.error(f"Error getting allocation schedule {schedule_id}: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/allocation-schedules', methods=['POST'])
def api_create_allocation_schedule():
    """Create a new allocation schedule."""
    try:
        # Ensure allocation scheduler is available
        if not allocation_scheduler:
            return jsonify({
                'success': False,
                'error': 'Allocation scheduler service is not available'
            }), 500
            
        # Get request data
        data = request.get_json()
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
            
        # Validate required fields
        required_fields = ['preset_id', 'scheduled_time']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
                
        # Check if preset exists
        preset = AllocationPreset.query.get(data['preset_id'])
        if not preset:
            return jsonify({
                'success': False,
                'error': f'Allocation preset with ID {data["preset_id"]} not found'
            }), 404
            
        # Create schedule
        schedule = allocation_scheduler.create_schedule(
            preset_id=data['preset_id'],
            scheduled_time=data['scheduled_time'],
            notify_before_minutes=data.get('notify_before_minutes'),
            preview_mode=data.get('preview_mode', False),
            created_by=data.get('created_by', 'web_api')
        )
        
        return jsonify({
            'success': True,
            'message': f'Allocation schedule created for {preset.name} at {schedule.scheduled_time}',
            'schedule': schedule.to_dict()
        }), 201
    except Exception as e:
        logger.error(f"Error creating allocation schedule: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/allocation-schedules/<int:schedule_id>', methods=['PUT'])
def api_update_allocation_schedule(schedule_id):
    """Update an existing allocation schedule."""
    try:
        # Ensure allocation scheduler is available
        if not allocation_scheduler:
            return jsonify({
                'success': False,
                'error': 'Allocation scheduler service is not available'
            }), 500
            
        # Get schedule
        schedule = allocation_scheduler.get_schedule(schedule_id)
        if not schedule:
            return jsonify({
                'success': False,
                'error': f'Schedule with ID {schedule_id} not found'
            }), 404
            
        # Get request data
        data = request.get_json()
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
            
        # Update schedule
        updated_schedule = allocation_scheduler.update_schedule(
            schedule_id=schedule_id,
            scheduled_time=data.get('scheduled_time'),
            notify_before_minutes=data.get('notify_before_minutes'),
            is_active=data.get('is_active'),
            preview_mode=data.get('preview_mode')
        )
        
        return jsonify({
            'success': True,
            'message': f'Allocation schedule updated',
            'schedule': updated_schedule.to_dict()
        })
    except Exception as e:
        logger.error(f"Error updating allocation schedule {schedule_id}: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/allocation-schedules/<int:schedule_id>', methods=['DELETE'])
def api_delete_allocation_schedule(schedule_id):
    """Delete an allocation schedule."""
    try:
        # Ensure allocation scheduler is available
        if not allocation_scheduler:
            return jsonify({
                'success': False,
                'error': 'Allocation scheduler service is not available'
            }), 500
            
        # Get schedule for logging
        schedule = allocation_scheduler.get_schedule(schedule_id)
        if not schedule:
            return jsonify({
                'success': False,
                'error': f'Schedule with ID {schedule_id} not found'
            }), 404
            
        # Get preset name for response message
        preset_name = schedule.preset.name if schedule.preset else "Unknown"
            
        # Delete schedule
        result = allocation_scheduler.delete_schedule(schedule_id)
        
        if result:
            return jsonify({
                'success': True,
                'message': f'Allocation schedule for preset "{preset_name}" deleted'
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Failed to delete allocation schedule'
            }), 500
    except Exception as e:
        logger.error(f"Error deleting allocation schedule {schedule_id}: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/allocation-schedules/<int:schedule_id>/cancel', methods=['POST'])
def api_cancel_allocation_schedule(schedule_id):
    """Cancel an allocation schedule without deleting it."""
    try:
        # Ensure allocation scheduler is available
        if not allocation_scheduler:
            return jsonify({
                'success': False,
                'error': 'Allocation scheduler service is not available'
            }), 500
            
        # Get request data for optional note
        data = request.get_json() or {}
        cancellation_note = data.get('note', 'Cancelled via API')
            
        # Cancel schedule
        schedule = allocation_scheduler.cancel_schedule(schedule_id, note=cancellation_note)
        
        if schedule:
            return jsonify({
                'success': True,
                'message': f'Allocation schedule for preset "{schedule.preset.name}" cancelled',
                'schedule': schedule.to_dict()
            })
        else:
            return jsonify({
                'success': False,
                'error': f'Schedule with ID {schedule_id} not found'
            }), 404
    except Exception as e:
        logger.error(f"Error cancelling allocation schedule {schedule_id}: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/allocation-schedules/<int:schedule_id>/execute-now', methods=['POST'])
def api_execute_schedule_now(schedule_id):
    """Execute an allocation schedule immediately."""
    try:
        # Ensure allocation scheduler is available
        if not allocation_scheduler:
            return jsonify({
                'success': False,
                'error': 'Allocation scheduler service is not available'
            }), 500
            
        # Execute schedule
        result = allocation_scheduler.execute_now(schedule_id)
        
        if result:
            return jsonify({
                'success': True,
                'message': f'Allocation schedule executed successfully'
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Failed to execute allocation schedule. It may be inactive, already executed, or not found.'
            }), 400
    except Exception as e:
        logger.error(f"Error executing allocation schedule {schedule_id}: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# neXera API Endpoints
@app.route('/api/apply-strategy-weights', methods=['POST'])
def api_apply_strategy_weights():
    """
    API endpoint to apply strategy weights from the Weight Allocation Simulator to live trading.
    
    Request Body:
        weights (Dict[str, float]): Dictionary mapping strategy IDs to weight values (0-100)
        transition_speed (str, optional): Speed for weight transition ('immediate', 'gradual', 'slow')
        ensemble_name (str, optional): Name of the ensemble to update (defaults to active ensemble)
        lock_duration (int, optional): Duration in hours to lock the weights (default: 24)
    
    Returns:
        JSON: Status of weight application
    """
    try:
        # Get request data
        data = request.get_json()
        if not data or 'weights' not in data:
            return jsonify({
                'success': False,
                'error': 'Missing required parameter: weights'
            }), 400
        
        # Extract parameters
        weights = data['weights']
        transition_speed = data.get('transition_speed', 'immediate')
        ensemble_name = data.get('ensemble_name', None)  # Defaults to active ensemble
        lock_duration = data.get('lock_duration', 24)  # 24 hours default
        
        # Validate weights
        if not isinstance(weights, dict) or not weights:
            return jsonify({
                'success': False,
                'error': 'Invalid weights format: must be a non-empty dictionary'
            }), 400
        
        # Ensure weights add up to 100
        total_weight = sum(weights.values())
        if abs(total_weight - 100.0) > 0.1:  # Allow small rounding errors
            return jsonify({
                'success': False,
                'error': f'Weights must sum to 100% (currently {total_weight:.2f}%)'
            }), 400
        
        # Scale weights from percentages (0-100) to proportions (0-1)
        normalized_weights = {k: v / 100.0 for k, v in weights.items()}
        
        # Import and initialize auto rotation engine
        from auto_rotation import AutoRotationEngine
        rotation_engine = AutoRotationEngine()
        
        # Create a Strategy Lock policy with the specified weights
        result = rotation_engine.apply_manual_weights(
            normalized_weights, 
            ensemble_name=ensemble_name,
            duration_hours=lock_duration
        )
        
        if not result['success']:
            return jsonify(result), 400
        
        # Log the action
        logger.info(f"Applied manual weights from simulator: {weights}")
        
        # Return success response with details
        return jsonify({
            'success': True,
            'message': 'Strategy weights applied successfully',
            'applied_weights': weights,
            'ensemble': result.get('ensemble_name', 'default'),
            'lock_duration_hours': lock_duration,
            'lock_expiry': (datetime.now() + timedelta(hours=lock_duration)).isoformat()
        })
        
    except Exception as e:
        logger.error(f"Error applying strategy weights: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/strategy-performance')
def api_strategy_performance():
    """
    API endpoint to get performance data for multiple strategies.
    
    Query Parameters:
        strategy_ids (str): Comma-separated list of strategy IDs to include (default: all)
        period (str): Time period to analyze ('1d', '1w', '1m', '3m', '6m', '1y', 'all') - default 'all'
        normalized (bool): Whether to normalize equity curves to percentage returns - default False
    
    Returns:
        JSON: Strategy performance data for visualization
    """
    # Get query parameters
    strategy_ids_str = request.args.get('strategy_ids', '')
    strategy_ids = [id.strip() for id in strategy_ids_str.split(',') if id.strip()]
    period = request.args.get('period', 'all')
    normalized = request.args.get('normalized', 'false').lower() == 'true'
    
    response = {
        'success': True,
        'strategies': {},
        'time_range': period,
        'normalized': normalized
    }
    
    try:
        # Get available strategies
        available_strategies = get_available_strategies()
        strategy_map = {s['id']: s for s in available_strategies}
        
        # If no specific strategies requested, include all available
        if not strategy_ids:
            strategy_ids = [s['id'] for s in available_strategies]
        
        # Define time range based on period parameter
        cutoff_date = None
        if period != 'all':
            current_time = datetime.now()
            
            if period == '1d':
                cutoff_date = current_time - timedelta(days=1)
            elif period == '1w':
                cutoff_date = current_time - timedelta(weeks=1)
            elif period == '1m':
                cutoff_date = current_time - timedelta(days=30)
            elif period == '3m':
                cutoff_date = current_time - timedelta(days=90)
            elif period == '6m':
                cutoff_date = current_time - timedelta(days=180)
            elif period == '1y':
                cutoff_date = current_time - timedelta(days=365)
        
        # Get strategy attributions from database
        strategy_attribution_query = StrategyAttribution.query
        
        if cutoff_date:
            strategy_attribution_query = strategy_attribution_query.filter(
                (StrategyAttribution.end_time >= cutoff_date) | 
                (StrategyAttribution.end_time == None)
            )
        
        strategy_attributions = strategy_attribution_query.all()
        
        # Group attributions by strategy_id
        strategy_attribution_map = {}
        for attribution in strategy_attributions:
            if attribution.strategy_id not in strategy_attribution_map:
                strategy_attribution_map[attribution.strategy_id] = []
            strategy_attribution_map[attribution.strategy_id].append(attribution)
        
        # Get equity history data for each requested strategy
        for strategy_id in strategy_ids:
            if strategy_id not in strategy_map:
                continue
            
            strategy_info = strategy_map[strategy_id]
            attributions = strategy_attribution_map.get(strategy_id, [])
            
            # If there are no attributions for this strategy, skip it
            if not attributions:
                continue
            
            # Get preset IDs that used this strategy
            preset_ids = [attr.preset_id for attr in attributions]
            
            # Get equity history for these presets
            equity_data = []
            
            for preset_id in preset_ids:
                # Build query for equity history
                query = PresetEquityHistory.query.filter_by(preset_id=preset_id)
                
                # Apply date filter if specified
                if cutoff_date:
                    query = query.filter(PresetEquityHistory.timestamp >= cutoff_date)
                
                # Get equity history records
                equity_records = query.order_by(PresetEquityHistory.timestamp.asc()).all()
                
                for record in equity_records:
                    # Only include points that fall within the attribution period
                    for attr in attributions:
                        if attr.preset_id == preset_id and attr.start_time <= record.timestamp and \
                           (attr.end_time is None or record.timestamp <= attr.end_time):
                            equity_data.append({
                                'timestamp': record.timestamp,
                                'equity': record.equity,
                                'pnl_percent': record.pnl_percent,
                                'drawdown_percent': record.drawdown_percent,
                                'sharpe_ratio': record.sharpe_ratio,
                                'win_count': record.win_count,
                                'loss_count': record.loss_count
                            })
                            break
            
            # Sort equity data by timestamp
            equity_data.sort(key=lambda x: x['timestamp'])
            
            # Calculate performance metrics
            start_equity = equity_data[0]['equity'] if equity_data else 0
            current_equity = equity_data[-1]['equity'] if equity_data else 0
            
            win_rate = 0
            if equity_data:
                total_trades = sum(1 for point in equity_data if point.get('win_count', 0) > 0 or point.get('loss_count', 0) > 0)
                win_count = sum(point.get('win_count', 0) for point in equity_data)
                if total_trades > 0:
                    win_rate = (win_count / total_trades) * 100
            
            # Calculate max drawdown
            max_drawdown = max([point.get('drawdown_percent', 0) or 0 for point in equity_data]) if equity_data else 0
            
            # Calculate Sharpe ratio (average across data points)
            sharpe_values = [point.get('sharpe_ratio', 0) or 0 for point in equity_data]
            avg_sharpe = sum(sharpe_values) / len(sharpe_values) if sharpe_values else 0
            
            # Prepare timestamps and equity values for the chart
            timestamps = [point['timestamp'].isoformat() for point in equity_data]
            
            if normalized and equity_data and start_equity > 0:
                # Calculate percentage change from initial value
                equity_values = [(point['equity'] / start_equity - 1) * 100 for point in equity_data]
            else:
                equity_values = [point['equity'] for point in equity_data]
            
            # Add to response
            response['strategies'][strategy_id] = {
                'name': strategy_info['name'],
                'description': strategy_info['description'],
                'color': attributions[0].color if attributions and attributions[0].color else '#FF6A00',  # neXera orange as default
                'timestamps': timestamps,
                'equity_values': equity_values,
                'metrics': {
                    'start_equity': start_equity,
                    'current_equity': current_equity,
                    'total_return': ((current_equity / start_equity) - 1) * 100 if start_equity > 0 else 0,
                    'win_rate': win_rate,
                    'max_drawdown': max_drawdown,
                    'sharpe_ratio': avg_sharpe
                }
            }
        
        # If no strategies had data, return an empty response
        if not response['strategies']:
            response['success'] = False
            response['error'] = 'No strategy performance data available for the selected period'
        
        return jsonify(response)
    
    except Exception as e:
        logger.error(f"Error getting strategy performance data: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/equity-curve')
def api_equity_curve():
    """API endpoint to get detailed equity curve data for visualization."""
    period = request.args.get('period', 'all')
    
    # Initialize response structure
    response = {
        'timestamps': [],
        'values': [],
        'benchmark_values': [],  # For BTC/USDT performance comparison
        'metrics': {
            'total_return': 0,
            'drawdown': 0,
            'sharpe_ratio': 0,
            'winning_days': 0,
            'total_days': 0,
            'vs_benchmark': 0  # Performance vs BTC/USDT
        },
        'key_events': [],
        'strategy_attributions': [],  # Strategy periods for attribution overlay
        'initial_investment': 1000  # Default value
    }
    
    try:
        # Get bot instance data if available
        if bot_instance and bot_status == "running":
            performance_stats = bot_instance.get_performance_stats()
            
            # Process equity curve data based on selected period
            if performance_stats and 'equity_curve' in performance_stats:
                equity_data = performance_stats['equity_curve']
                timestamps = list(equity_data.keys())
                values = list(equity_data.values())
                
                # Filter based on selected time period
                if period != 'all':
                    cutoff_date = None
                    current_time = datetime.now()
                    
                    if period == '1d':
                        cutoff_date = current_time - timedelta(days=1)
                    elif period == '1w':
                        cutoff_date = current_time - timedelta(weeks=1)
                    elif period == '1m':
                        cutoff_date = current_time - timedelta(days=30)
                    elif period == '3m':
                        cutoff_date = current_time - timedelta(days=90)
                    elif period == '6m':
                        cutoff_date = current_time - timedelta(days=180)
                    elif period == '1y':
                        cutoff_date = current_time - timedelta(days=365)
                    
                    if cutoff_date:
                        filtered_data = {}
                        for ts, value in equity_data.items():
                            try:
                                timestamp = datetime.strptime(ts, '%Y-%m-%d %H:%M:%S')
                                if timestamp >= cutoff_date:
                                    filtered_data[ts] = value
                            except ValueError:
                                continue
                        
                        timestamps = list(filtered_data.keys())
                        values = list(filtered_data.values())
                
                # Sort data chronologically
                if timestamps and values:
                    sorted_data = sorted(zip(timestamps, values), key=lambda x: x[0])
                    timestamps = [item[0] for item in sorted_data]
                    values = [item[1] for item in sorted_data]
                
                # Update response with equity curve data
                response['timestamps'] = timestamps
                response['values'] = values
                
                # Calculate performance metrics
                if values:
                    # Initial investment
                    response['initial_investment'] = values[0] if values else 1000
                    
                    # Total return
                    if values[0] > 0:
                        total_return = ((values[-1] - values[0]) / values[0]) * 100
                        response['metrics']['total_return'] = total_return
                    
                    # Maximum drawdown
                    peak = values[0]
                    max_drawdown = 0
                    for value in values:
                        if value > peak:
                            peak = value
                        drawdown = (peak - value) / peak * 100 if peak > 0 else 0
                        max_drawdown = max(max_drawdown, drawdown)
                    response['metrics']['drawdown'] = -max_drawdown
                    
                    # Daily win rate (simplified calculation)
                    daily_changes = []
                    for i in range(1, len(values)):
                        daily_changes.append(values[i] - values[i-1])
                    
                    winning_days = sum(1 for change in daily_changes if change > 0)
                    response['metrics']['winning_days'] = winning_days
                    response['metrics']['total_days'] = len(daily_changes)
                    
                    # Simplified Sharpe ratio (if we have enough data points)
                    if len(daily_changes) > 1:
                        import numpy as np
                        returns_array = np.array(daily_changes)
                        if values[0] > 0:
                            returns_array = returns_array / values[0]  # Normalize by initial investment
                            mean_return = np.mean(returns_array)
                            std_return = np.std(returns_array)
                            sharpe = mean_return / std_return * np.sqrt(252) if std_return > 0 else 0
                            response['metrics']['sharpe_ratio'] = sharpe
            
            # Get key events (strategy changes, risk events, etc.)
            if hasattr(bot_instance, 'get_trigger_events'):
                events = bot_instance.get_trigger_events() or []
                response['key_events'] = events
                
            # Get strategy attributions for overlay visualization if available from bot
            if hasattr(bot_instance, 'get_strategy_attributions'):
                strategy_attributions = bot_instance.get_strategy_attributions() or []
                response['strategy_attributions'] = strategy_attributions
        
        # If no data from bot instance, use database records as fallback
        elif db:
            try:
                # Get equity history records
                query = PresetEquityHistory.query
                
                # Filter based on selected time period
                if period != 'all':
                    cutoff_date = None
                    current_time = datetime.now()
                    
                    if period == '1d':
                        cutoff_date = current_time - timedelta(days=1)
                    elif period == '1w':
                        cutoff_date = current_time - timedelta(weeks=1)
                    elif period == '1m':
                        cutoff_date = current_time - timedelta(days=30)
                    elif period == '3m':
                        cutoff_date = current_time - timedelta(days=90)
                    elif period == '6m':
                        cutoff_date = current_time - timedelta(days=180)
                    elif period == '1y':
                        cutoff_date = current_time - timedelta(days=365)
                    
                    if cutoff_date:
                        query = query.filter(PresetEquityHistory.timestamp >= cutoff_date)
                
                # Execute query and get results
                equity_records = query.order_by(PresetEquityHistory.timestamp.asc()).all()
                
                if equity_records:
                    # Extract timestamps and values
                    for record in equity_records:
                        ts = record.timestamp.strftime('%Y-%m-%d %H:%M:%S')
                        response['timestamps'].append(ts)
                        response['values'].append(record.equity)
                    
                    # Set initial investment
                    if response['values']:
                        response['initial_investment'] = response['values'][0]
                    
                    # Calculate performance metrics
                    if response['values']:
                        # Total return
                        if response['values'][0] > 0:
                            total_return = ((response['values'][-1] - response['values'][0]) / response['values'][0]) * 100
                            response['metrics']['total_return'] = total_return
                        
                        # Maximum drawdown calculation
                        peak = response['values'][0]
                        max_drawdown = 0
                        for value in response['values']:
                            if value > peak:
                                peak = value
                            drawdown = (peak - value) / peak * 100 if peak > 0 else 0
                            max_drawdown = max(max_drawdown, drawdown)
                        response['metrics']['drawdown'] = -max_drawdown
                        
                        # Get daily changes for win rate
                        daily_changes = []
                        for i in range(1, len(response['values'])):
                            daily_changes.append(response['values'][i] - response['values'][i-1])
                        
                        winning_days = sum(1 for change in daily_changes if change > 0)
                        response['metrics']['winning_days'] = winning_days
                        response['metrics']['total_days'] = len(daily_changes)
                
                # Get key events from trigger events table
                trigger_events = PresetTriggerEvent.query.all()
                for event in trigger_events:
                    response['key_events'].append({
                        'timestamp': event.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                        'type': event.event_type,
                        'description': event.description
                    })
                    
                # Get strategy attributions for overlay visualization
                strategy_attributions = StrategyAttribution.query.order_by(StrategyAttribution.start_time.asc()).all()
                for attribution in strategy_attributions:
                    attribution_data = {
                        'start_time': attribution.start_time.strftime('%Y-%m-%d %H:%M:%S'),
                        'end_time': attribution.end_time.strftime('%Y-%m-%d %H:%M:%S') if attribution.end_time else None,
                        'strategy_name': attribution.strategy_name,
                        'strategy_id': attribution.strategy_id,
                        'color': attribution.color or '#3498db',  # Default blue if no color specified
                        'display_name': attribution.display_name or attribution.strategy_name,
                        'performance': attribution.performance_data
                    }
                    response['strategy_attributions'].append(attribution_data)
            except Exception as e:
                logger.error(f"Error getting equity data from database: {e}")
        
        # Fetch BTC/USDT data for the same time period (if we have timestamps)
        try:
            if response['timestamps'] and response['values']:
                # Get start and end dates from existing timestamps
                if len(response['timestamps']) > 1:
                    try:
                        # Parse timestamps to datetime objects
                        start_ts = min(response['timestamps'])
                        end_ts = max(response['timestamps'])
                        
                        # Determine the appropriate format based on timestamp format
                        date_format = '%Y-%m-%d %H:%M:%S' if ':' in start_ts else '%Y-%m-%d'
                        
                        start_date = datetime.strptime(start_ts, date_format)
                        end_date = datetime.strptime(end_ts, date_format)
                        
                        # Import necessary functions
                        try:
                            from binance_client import get_historical_data
                            
                            # Fetch BTC/USDT price history
                            btc_data = get_historical_data('BTC/USDT', '1d', start_date, end_date)
                            
                            if btc_data and len(btc_data) > 0:
                                # Extract close prices and timestamps
                                btc_timestamps = [entry['timestamp'].strftime(date_format) for entry in btc_data]
                                btc_prices = [entry['close'] for entry in btc_data]
                                
                                # Normalize BTC prices to start at the same value as portfolio
                                initial_portfolio = response['values'][0]
                                initial_btc = btc_prices[0] if btc_prices else 1
                                
                                # Scale factor to match starting value
                                scale_factor = initial_portfolio / initial_btc
                                
                                # Scale all BTC prices
                                btc_values = [price * scale_factor for price in btc_prices]
                                
                                # Align timestamps with portfolio data
                                aligned_btc_values = []
                                
                                for ts in response['timestamps']:
                                    if ts in btc_timestamps:
                                        idx = btc_timestamps.index(ts)
                                        aligned_btc_values.append(btc_values[idx])
                                    else:
                                        # Try to find closest timestamp
                                        closest_ts = min(btc_timestamps, key=lambda x: abs(datetime.strptime(x, date_format) - datetime.strptime(ts, date_format)))
                                        idx = btc_timestamps.index(closest_ts)
                                        aligned_btc_values.append(btc_values[idx])
                                
                                # Add to response
                                response['benchmark_values'] = aligned_btc_values
                                
                                # Calculate outperformance vs BTC
                                if response['values'] and aligned_btc_values and len(response['values']) > 0 and len(aligned_btc_values) > 0:
                                    portfolio_return = ((response['values'][-1] - response['values'][0]) / response['values'][0]) * 100
                                    btc_return = ((aligned_btc_values[-1] - aligned_btc_values[0]) / aligned_btc_values[0]) * 100
                                    
                                    # Calculate outperformance (positive means we're beating Bitcoin)
                                    outperformance = portfolio_return - btc_return
                                    response['metrics']['vs_benchmark'] = outperformance
                        except ImportError:
                            logger.warning("Could not import get_historical_data from binance_client, skipping BTC benchmark")
                    except (ValueError, KeyError) as e:
                        logger.warning(f"Error processing timestamps for BTC comparison: {e}")
        except Exception as e:
            logger.error(f"Error fetching BTC benchmark data: {e}")
                
        # If no real data available, generate sample data for demo purposes
        if not response['timestamps'] or not response['values']:
            # Generate a simple upward trending curve with some volatility
            import random
            import numpy as np
            
            num_points = 100
            base_value = 1000
            timestamps = [(datetime.now() - timedelta(days=num_points-i)).strftime('%Y-%m-%d') for i in range(num_points)]
            
            # Create a trending series with some random fluctuation
            trend = np.linspace(0, 0.3, num_points)  # 30% uptrend
            noise = [random.uniform(-0.02, 0.03) for _ in range(num_points)]  # Daily noise
            
            values = [base_value * (1 + trend[i] + noise[i]) for i in range(num_points)]
            
            # Generate BTC benchmark data (with slightly lower performance)
            btc_trend = np.linspace(0, 0.2, num_points)  # 20% uptrend (underperforms portfolio)
            btc_noise = [random.uniform(-0.025, 0.025) for _ in range(num_points)]  # Daily noise
            btc_values = [base_value * (1 + btc_trend[i] + btc_noise[i]) for i in range(num_points)]
            
            response['benchmark_values'] = btc_values
            
            # Calculate portfolio vs BTC performance
            portfolio_return = ((values[-1] - values[0]) / values[0]) * 100
            btc_return = ((btc_values[-1] - btc_values[0]) / btc_values[0]) * 100
            outperformance = portfolio_return - btc_return
            response['metrics']['vs_benchmark'] = outperformance
            
            # Add a few key events
            response['key_events'] = [
                {
                    'timestamp': timestamps[int(num_points * 0.25)],
                    'type': 'strategy_change',
                    'description': 'Switched to Dip-Buyer Strategy'
                },
                {
                    'timestamp': timestamps[int(num_points * 0.6)],
                    'type': 'risk_event',
                    'description': 'Risk level increased to MEDIUM'
                },
                {
                    'timestamp': timestamps[int(num_points * 0.8)],
                    'type': 'system_event',
                    'description': 'Auto-scaling activated'
                }
            ]
            
            # Add strategy attribution data for demo purposes
            response['strategy_attributions'] = [
                {
                    'start_time': timestamps[0],
                    'end_time': timestamps[int(num_points * 0.25)],
                    'strategy_name': 'Mean Reversion Alpha',
                    'strategy_id': 'mean_reversion',
                    'color': '#3498db',  # Blue
                    'display_name': 'Mean Reversion Alpha',
                    'performance': {
                        'win_rate': 65,
                        'avg_return': 3.2,
                        'max_drawdown': -8.4
                    }
                },
                {
                    'start_time': timestamps[int(num_points * 0.25)],
                    'end_time': timestamps[int(num_points * 0.6)],
                    'strategy_name': 'Dip Buyer Strategy',
                    'strategy_id': 'dip_buyer',
                    'color': '#2ecc71',  # Green
                    'display_name': 'Dip Buyer Strategy',
                    'performance': {
                        'win_rate': 72,
                        'avg_return': 4.5,
                        'max_drawdown': -6.2
                    }
                },
                {
                    'start_time': timestamps[int(num_points * 0.6)],
                    'end_time': timestamps[-1],
                    'strategy_name': 'Momentum Engine V2',
                    'strategy_id': 'momentum',
                    'color': '#e74c3c',  # Red
                    'display_name': 'Momentum Engine V2',
                    'performance': {
                        'win_rate': 68,
                        'avg_return': 5.1,
                        'max_drawdown': -9.7
                    }
                }
            ]
            
            response['timestamps'] = timestamps
            response['values'] = values
            response['initial_investment'] = base_value
            
            # Calculate sample metrics
            if values:
                total_return = ((values[-1] - values[0]) / values[0]) * 100
                response['metrics']['total_return'] = total_return
                
                daily_changes = [values[i] - values[i-1] for i in range(1, len(values))]
                winning_days = sum(1 for change in daily_changes if change > 0)
                
                response['metrics']['winning_days'] = winning_days
                response['metrics']['total_days'] = len(daily_changes)
                response['metrics']['sharpe_ratio'] = 1.75  # Sample value
                
                # Max drawdown
                peak = values[0]
                max_drawdown = 0
                for value in values:
                    if value > peak:
                        peak = value
                    drawdown = (peak - value) / peak * 100 if peak > 0 else 0
                    max_drawdown = max(max_drawdown, drawdown)
                response['metrics']['drawdown'] = -max_drawdown
        
        return jsonify(response)
    except Exception as e:
        logger.error(f"Error in equity curve API: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/trade-export')
def api_trade_export():
    """API endpoint to export trade data in CSV format."""
    try:
        trades = []
        
        # Get trades from bot instance if available
        if bot_instance and bot_status == "running":
            # Get trades from bot's trade history
            if hasattr(bot_instance, 'get_trade_history'):
                bot_trades = bot_instance.get_trade_history() or []
                
                # Process trade history
                for trade in bot_trades:
                    trade_record = {
                        'date': trade.get('timestamp', ''),
                        'symbol': trade.get('symbol', ''),
                        'side': trade.get('side', ''),
                        'entry_price': trade.get('entry_price', 0),
                        'exit_price': trade.get('exit_price', 0),
                        'quantity': trade.get('quantity', 0),
                        'pnl': trade.get('pnl', 0),
                        'pnl_percent': trade.get('pnl_percent', 0),
                        'strategy': trade.get('strategy', ''),
                        'status': trade.get('status', ''),
                        'notes': trade.get('notes', '')
                    }
                    trades.append(trade_record)
        
        # If no trades from bot instance, create a sample dataset
        if not trades:
            # Sample trade data for demo
            import random
            from datetime import datetime, timedelta
            
            symbols = ['BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'BNB/USDT', 'DOGE/USDT']
            strategies = ['DipBuyer', 'MeanReversion', 'TrendFollower', 'BreakoutTrader']
            statuses = ['CLOSED', 'CLOSED', 'CLOSED', 'CLOSED', 'FAILED']
            
            # Generate 20 sample trades over the last 30 days
            end_date = datetime.now()
            start_date = end_date - timedelta(days=30)
            days_range = (end_date - start_date).days
            
            for i in range(20):
                random_days = random.randint(0, days_range)
                trade_date = start_date + timedelta(days=random_days)
                
                symbol = random.choice(symbols)
                side = random.choice(['BUY', 'SELL'])
                
                base_price = 0
                if symbol == 'BTC/USDT':
                    base_price = random.uniform(35000, 50000)
                elif symbol == 'ETH/USDT':
                    base_price = random.uniform(2000, 3000)
                elif symbol == 'SOL/USDT':
                    base_price = random.uniform(80, 150)
                elif symbol == 'BNB/USDT':
                    base_price = random.uniform(300, 500)
                else:  # DOGE
                    base_price = random.uniform(0.05, 0.15)
                
                entry_price = base_price
                
                # Determine if trade is profitable (70% win rate)
                is_profitable = random.random() < 0.7
                
                # Calculate exit price based on profitability
                price_change = random.uniform(0.01, 0.05)
                exit_price = entry_price * (1 + price_change) if is_profitable else entry_price * (1 - price_change)
                
                # Calculate pnl
                quantity = random.uniform(0.1, 2) if symbol in ['BTC/USDT', 'ETH/USDT'] else random.uniform(5, 20)
                pnl = (exit_price - entry_price) * quantity
                pnl_percent = (exit_price - entry_price) / entry_price * 100
                
                status = random.choice(statuses)
                
                trade_record = {
                    'date': trade_date.strftime('%Y-%m-%d %H:%M:%S'),
                    'symbol': symbol,
                    'side': side,
                    'entry_price': round(entry_price, 2),
                    'exit_price': round(exit_price, 2) if status == 'CLOSED' else None,
                    'quantity': round(quantity, 4),
                    'pnl': round(pnl, 2) if status == 'CLOSED' else None,
                    'pnl_percent': round(pnl_percent, 2) if status == 'CLOSED' else None,
                    'strategy': random.choice(strategies),
                    'status': status,
                    'notes': ''
                }
                trades.append(trade_record)
            
            # Sort by date
            trades = sorted(trades, key=lambda x: x['date'], reverse=True)
        
        return jsonify({
            'success': True,
            'trades': trades
        })
    except Exception as e:
        logger.error(f"Error in trade export API: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/status')
def api_status():
    """API endpoint to get bot status and dashboard data."""
    # Get performance metrics
    win_rate = 0
    profit_factor = 0
    success_rate = 0
    profitable_trades = 0
    loss_making_trades = 0
    total_pl = 0
    total_trades = 0
    equity_curve = {
        'labels': [],
        'values': []
    }
    recent_trades = []
    
    # Manual override lock status
    manual_override_active = False
    manual_override_remaining = 0
    manual_override_preset = None
    manual_override_expiry = None
    
    # Check rotation engine for manual override status
    if 'auto_rotation' in sys.modules:
        try:
            from auto_rotation import auto_rotation_engine
            if hasattr(auto_rotation_engine, 'is_manual_override_active'):
                manual_override_active = auto_rotation_engine.is_manual_override_active()
            
            if hasattr(auto_rotation_engine, 'get_manual_override_remaining_seconds'):
                manual_override_remaining = auto_rotation_engine.get_manual_override_remaining_seconds()
                if manual_override_remaining > 0:
                    # Calculate expiry time
                    manual_override_expiry = (datetime.now() + timedelta(seconds=manual_override_remaining)).isoformat()
                    
            # Get preset info if available
            if manual_override_active:
                try:
                    # Get most recently applied preset
                    recent_preset = AllocationPreset.query.order_by(AllocationPreset.last_applied_at.desc()).first()
                    if recent_preset:
                        manual_override_preset = {
                            'id': recent_preset.id,
                            'name': recent_preset.name,
                            'applied_at': recent_preset.last_applied_at.isoformat() if recent_preset.last_applied_at else None
                        }
                except Exception as e:
                    logger.warning(f"Error getting manual override preset: {e}")
        except Exception as e:
            logger.warning(f"Error getting manual override status: {e}")
    
    # Try to get data from bot instance
    if bot_instance and bot_status == "running":
        try:
            # Get performance data
            performance_stats = bot_instance.get_performance_stats()
            
            # Extract metrics
            if performance_stats:
                win_rate = performance_stats.get('win_rate', 0)
                profit_factor = performance_stats.get('profit_factor', 0)
                success_rate = performance_stats.get('win_rate', 0)
                total_trades = performance_stats.get('total_trades', 0)
                profitable_trades = performance_stats.get('winning_trades', 0)
                loss_making_trades = total_trades - profitable_trades
                total_pl = performance_stats.get('total_profit_loss', 0)
                
                # Get equity curve data
                if 'equity_curve' in performance_stats:
                    # Format data for chart.js
                    timestamps = []
                    values = []
                    for timestamp, value in performance_stats['equity_curve'].items():
                        # Convert timestamp to readable format
                        try:
                            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                            formatted_time = dt.strftime('%H:%M')
                            timestamps.append(formatted_time)
                            values.append(value)
                        except (ValueError, AttributeError):
                            pass
                    
                    equity_curve = {
                        'labels': timestamps,
                        'values': values
                    }
                
                # Get recent trades
                if 'recent_trades' in performance_stats:
                    recent_trades = performance_stats['recent_trades'][:10]  # Limit to 10 most recent
        except Exception as e:
            logger.error(f"Error getting performance stats: {e}")
    
    # Get portfolio data
    portfolio_value = 1000.0
    available_balance = 1000.0
    in_position_balance = 0.0
    portfolio_change = 0.0
    
    if bot_instance and bot_status == "running":
        try:
            portfolio_info = bot_instance.get_portfolio_info()
            if portfolio_info:
                portfolio_value = portfolio_info.get('total_value', 1000.0)
                available_balance = portfolio_info.get('available_balance', 1000.0)
                in_position_balance = portfolio_value - available_balance
                portfolio_change = portfolio_info.get('portfolio_change', 0.0)
        except Exception as e:
            logger.error(f"Error getting portfolio info: {e}")
    
    # Return all dashboard data
    return jsonify({
        'status': bot_status,
        'last_check': last_check_time.strftime('%Y-%m-%d %H:%M:%S') if last_check_time else None,
        'system_status': 'active' if bot_status == 'running' else 'stopped',
        'account_balance': portfolio_value,
        'available_balance': available_balance,
        'in_position_balance': in_position_balance,
        'portfolio_change': portfolio_change,
        'strategy_name': 'Ensemble Strategy',
        'strategy_active': bot_status == 'running',
        'win_rate': win_rate,
        'profit_factor': profit_factor,
        'total_trades': total_trades,
        'success_rate': success_rate, 
        'profitable_trades': profitable_trades,
        'loss_making_trades': loss_making_trades,
        'total_pl': total_pl,
        'equity_curve': equity_curve,
        'recent_trades': recent_trades,
        'paper_trading': Config.PAPER_TRADING,
        # Add manual override lock status
        'manual_override_active': manual_override_active,
        'manual_override_remaining_seconds': manual_override_remaining,
        'manual_override_expiry': manual_override_expiry,
        'manual_override_preset': manual_override_preset
    })

@app.route('/api/logs')
def api_logs():
    """API endpoint to get trade logs."""
    return jsonify(trade_logs)

@app.route('/api/trade-log')
def api_trade_log():
    """API endpoint to get detailed trade logs for neXera dashboard."""
    trades = []
    
    if bot_instance and bot_status == "running":
        try:
            # Get performance data
            performance_stats = bot_instance.get_performance_stats()
            
            # Extract trades
            if performance_stats and 'recent_trades' in performance_stats:
                trades = performance_stats['recent_trades']
                
                # Format trades for display
                for trade in trades:
                    # Calculate duration if entry_time and exit_time are available
                    if 'entry_time' in trade and 'exit_time' in trade:
                        try:
                            entry_time = datetime.fromisoformat(trade['entry_time'].replace('Z', '+00:00'))
                            exit_time = datetime.fromisoformat(trade['exit_time'].replace('Z', '+00:00'))
                            duration = exit_time - entry_time
                            trade['duration'] = f"{duration.days * 24 + duration.seconds // 3600}h {(duration.seconds % 3600) // 60}m"
                        except (ValueError, AttributeError):
                            trade['duration'] = "N/A"
                    
                    # Format timestamps for display
                    if 'entry_time' in trade:
                        try:
                            dt = datetime.fromisoformat(trade['entry_time'].replace('Z', '+00:00'))
                            trade['timestamp'] = dt.strftime('%Y-%m-%d %H:%M')
                        except (ValueError, AttributeError):
                            trade['timestamp'] = trade.get('entry_time', 'N/A')
                    
                    # Add status field
                    if 'exit_price' in trade and trade['exit_price'] > 0:
                        trade['status'] = 'Closed'
                    else:
                        trade['status'] = 'Open'
                    
                    # Add total value
                    trade['total'] = trade.get('entry_price', 0) * trade.get('quantity', 0)
        except Exception as e:
            logger.error(f"Error getting trade log data: {e}")
    
    return jsonify(trades)
    
@app.route('/api/safety')
def api_safety():
    """API endpoint to get safety status."""
    if bot_instance:
        safety_stats = bot_instance.get_safety_status()
        return jsonify(safety_stats)
    return jsonify({
        'error': 'Bot is not running',
        'emergency_stop_active': Config.EMERGENCY_STOP_ACTIVE,
        'live_trading_enabled': Config.LIVE_TRADING_ENABLED,
        'safety_mode': Config.SAFETY_MODE_LEVEL
    })

@app.route('/portfolio')
def portfolio():
    """Portfolio page showing account balance and open positions."""
    return render_template(
        'portfolio.html', 
        bot_status=bot_status, 
        last_check_time=last_check_time.strftime('%Y-%m-%d %H:%M:%S') if last_check_time else None,
        portfolio=bot_instance.get_portfolio_info() if bot_instance and bot_status == "running" else None,
        paper_trading=Config.PAPER_TRADING
    )

@app.route('/trade_history')
def trade_history():
    """Page showing trade history."""
    trades = []
    performance_trades = []
    
    if bot_instance and bot_status == "running":
        # First try to get trades from performance tracker
        try:
            performance_stats = bot_instance.get_performance_stats()
            if 'recent_trades' in performance_stats:
                performance_trades = performance_stats['recent_trades']
        except Exception as e:
            logger.error(f"Error getting trade history from performance tracker: {e}")
            
        # Fall back to legacy method if no trades found
        if not performance_trades:
            # Get trade history from the paper trading exchange
            if hasattr(bot_instance, 'client') and hasattr(bot_instance.client, 'exchange'):
                if hasattr(bot_instance.client.exchange, 'trade_history'):
                    trades = bot_instance.client.exchange.trade_history
                elif hasattr(bot_instance.client.exchange, 'fetch_my_trades'):
                    try:
                        trades = bot_instance.client.exchange.fetch_my_trades()
                    except Exception as e:
                        logger.error(f"Error fetching trade history: {e}")
    
    # Use performance trades if available, otherwise use legacy trades
    display_trades = performance_trades if performance_trades else trades
    
    return render_template(
        'trade_history.html',
        bot_status=bot_status,
        last_check_time=last_check_time.strftime('%Y-%m-%d %H:%M:%S') if last_check_time else None,
        trades=display_trades,
        paper_trading=Config.PAPER_TRADING
    )

@app.route('/trade_log')
def trade_log():
    """Enhanced trade log with detailed analytics and filtering."""
    trades = []
    strategies = []
    trading_pairs = Config.TRADING_PAIRS
    trade_stats = {
        'total_trades': 0,
        'win_rate': 0,
        'avg_pnl': 0,
        'total_pnl': 0
    }
    
    # Get filter parameters
    strategy_filter = request.args.get('strategy', '')
    symbol_filter = request.args.get('symbol', '')
    result_filter = request.args.get('result', '')
    exit_reason_filter = request.args.get('exitReason', '')
    sort_by = request.args.get('sort', 'exit_time')
    sort_direction = request.args.get('direction', 'desc')
    
    # Store selected filters for UI
    selected_filters = {
        'strategy': strategy_filter,
        'symbol': symbol_filter,
        'result': result_filter,
        'exit_reason': exit_reason_filter
    }
    
    # Pagination parameters
    page = int(request.args.get('page', 1))
    per_page = 20
    
    if bot_instance and bot_status == "running":
        try:
            # Get performance data which includes trades
            performance_stats = bot_instance.get_performance_stats()
            if 'recent_trades' in performance_stats:
                all_trades = performance_stats['recent_trades']
                
                # Extract unique strategies for filter dropdown
                strategies = list(set(trade['strategy'] for trade in all_trades if 'strategy' in trade))
                
                # Apply filters
                filtered_trades = all_trades
                
                if strategy_filter:
                    filtered_trades = [t for t in filtered_trades if t.get('strategy') == strategy_filter]
                
                if symbol_filter:
                    filtered_trades = [t for t in filtered_trades if t.get('symbol') == symbol_filter]
                
                if result_filter == 'profit':
                    filtered_trades = [t for t in filtered_trades if t.get('pnl', 0) > 0]
                elif result_filter == 'loss':
                    filtered_trades = [t for t in filtered_trades if t.get('pnl', 0) < 0]
                
                if exit_reason_filter:
                    filtered_trades = [t for t in filtered_trades if t.get('exit_reason') == exit_reason_filter]
                
                # Apply sorting
                if sort_by in ['entry_time', 'exit_time', 'pnl', 'pnl_percent']:
                    reverse = sort_direction == 'desc'
                    filtered_trades = sorted(filtered_trades, key=lambda x: x.get(sort_by, 0), reverse=reverse)
                
                # Calculate statistics for filtered trades
                if filtered_trades:
                    winning_trades = [t for t in filtered_trades if t.get('pnl', 0) > 0]
                    trade_stats['total_trades'] = len(filtered_trades)
                    trade_stats['win_rate'] = (len(winning_trades) / len(filtered_trades)) * 100 if filtered_trades else 0
                    trade_stats['total_pnl'] = sum(t.get('pnl', 0) for t in filtered_trades)
                    trade_stats['avg_pnl'] = trade_stats['total_pnl'] / len(filtered_trades) if filtered_trades else 0
                
                # Apply pagination
                total_pages = (len(filtered_trades) + per_page - 1) // per_page
                page = min(max(1, page), total_pages if total_pages > 0 else 1)
                
                start_idx = (page - 1) * per_page
                end_idx = start_idx + per_page
                
                trades = filtered_trades[start_idx:end_idx]
                
                # Add trade details for modal display if not present
                for trade in trades:
                    if 'details' not in trade:
                        # Create placeholder details based on strategy
                        trade['details'] = {}
                        
                        if trade['strategy'] == 'dip_buyer':
                            trade['details'] = {
                                'price_drop': round(abs((trade['entry_price'] / trade['exit_price'] - 1) * 100), 2),
                                'timeframe': Config.PRICE_DROP_TIMEFRAME,
                                'ma_value': Config.MA_PERIOD,
                                'market_trend': 'Bearish' if trade['pnl'] < 0 else 'Bullish'
                            }
                        elif trade['strategy'] == 'mean_reversion':
                            trade['details'] = {
                                'std_dev': Config.STD_DEV_MULTIPLIER,
                                'rsi_value': 30,
                                'market_trend': 'Range-bound'
                            }
                        elif trade['strategy'] == 'breakout':
                            trade['details'] = {
                                'resistance_level': trade['entry_price'] * 0.98,
                                'volume_increase': Config.VOLUME_INCREASE,
                                'confirmation_candles': Config.CONFIRMATION_CANDLES,
                                'market_trend': 'Bullish'
                            }
                        
                        # Add common details
                        trade['details']['volatility'] = 'High' if abs(trade['pnl_percent']) > 5 else 'Medium' if abs(trade['pnl_percent']) > 2 else 'Low'
                        
            else:
                logger.warning("No trade data found in performance tracker")
                
        except Exception as e:
            logger.error(f"Error getting trade log data: {e}")
    
    return render_template(
        'trade_log.html',
        bot_status=bot_status,
        last_check_time=last_check_time.strftime('%Y-%m-%d %H:%M:%S') if last_check_time else None,
        trades=trades,
        paper_trading=Config.PAPER_TRADING,
        trade_stats=trade_stats,
        strategies=strategies,
        trading_pairs=trading_pairs,
        selected_filters=selected_filters,
        page=page,
        total_pages=(len(trades) + per_page - 1) // per_page if trades else 1
    )

@app.route('/export_trade_log')
def export_trade_log():
    """Export detailed trade log as CSV."""
    if bot_instance and bot_status == "running":
        try:
            # Get filter parameters
            strategy_filter = request.args.get('strategy', '')
            symbol_filter = request.args.get('symbol', '')
            result_filter = request.args.get('result', '')
            exit_reason_filter = request.args.get('exitReason', '')
            
            # Get all trades from performance tracker
            performance_stats = bot_instance.get_performance_stats()
            all_trades = performance_stats.get('recent_trades', [])
            
            # Apply filters
            filtered_trades = all_trades
            
            if strategy_filter:
                filtered_trades = [t for t in filtered_trades if t.get('strategy') == strategy_filter]
            
            if symbol_filter:
                filtered_trades = [t for t in filtered_trades if t.get('symbol') == symbol_filter]
            
            if result_filter == 'profit':
                filtered_trades = [t for t in filtered_trades if t.get('pnl', 0) > 0]
            elif result_filter == 'loss':
                filtered_trades = [t for t in filtered_trades if t.get('pnl', 0) < 0]
            
            if exit_reason_filter:
                filtered_trades = [t for t in filtered_trades if t.get('exit_reason') == exit_reason_filter]
            
            if not filtered_trades:
                flash("No trade data available to export.", "warning")
                return redirect(url_for('trade_log'))
            
            # Create CSV with enhanced data
            csv_data = []
            
            # Add header row with additional columns
            header = [
                "Symbol", "Strategy", "Entry Time", "Exit Time", "Duration", 
                "Entry Price", "Exit Price", "Quantity", "Position Size (USDT)",
                "P&L (%)", "P&L (USDT)", "Exit Reason", "Market Trend", "Volatility"
            ]
            csv_data.append(",".join(header))
            
            # Add trade data rows with calculated fields
            for trade in filtered_trades:
                # Calculate duration
                try:
                    entry_time = datetime.fromisoformat(trade.get('entry_time').replace('Z', '+00:00'))
                    exit_time = datetime.fromisoformat(trade.get('exit_time').replace('Z', '+00:00'))
                    duration = exit_time - entry_time
                    duration_str = f"{duration.days * 24 + duration.seconds // 3600}h {(duration.seconds % 3600) // 60}m"
                except (ValueError, AttributeError):
                    duration_str = "N/A"
                
                # Calculate position size
                position_size = trade.get('entry_price', 0) * trade.get('quantity', 0)
                
                # Get market context from details or set defaults
                details = trade.get('details', {})
                market_trend = details.get('market_trend', 'Unknown')
                volatility = details.get('volatility', 'Medium')
                
                row = [
                    trade.get('symbol', ''),
                    trade.get('strategy', ''),
                    trade.get('entry_time', '').replace('T', ' ').replace('Z', ''),
                    trade.get('exit_time', '').replace('T', ' ').replace('Z', ''),
                    duration_str,
                    str(trade.get('entry_price', '')),
                    str(trade.get('exit_price', '')),
                    str(trade.get('quantity', '')),
                    f"{position_size:.2f}",
                    f"{trade.get('pnl_percent', 0):.2f}%",
                    str(trade.get('pnl', '')),
                    trade.get('exit_reason', ''),
                    market_trend,
                    volatility
                ]
                csv_data.append(','.join(row))
            
            # Join rows with newlines
            csv_content = '\n'.join(csv_data)
            
            # Generate timestamp for filename
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            
            # Create response with CSV data
            response = make_response(csv_content)
            response.headers['Content-Disposition'] = f'attachment; filename=trade_log_{timestamp}.csv'
            response.headers['Content-Type'] = 'text/csv'
            
            return response
            
        except Exception as e:
            logger.error(f"Error exporting trade log: {e}")
            flash(f"Error exporting trade log: {e}", "danger")
    else:
        flash("Bot is not running. Please start the bot first.", "warning")
    
    return redirect(url_for('trade_log'))

@app.route('/performance')
def performance_dashboard():
    """Performance metrics dashboard showing trading statistics."""
    performance_data = {}
    
    if bot_instance and bot_status == "running":
        try:
            performance_data = bot_instance.get_performance_stats()
        except Exception as e:
            logger.error(f"Error getting performance data: {e}")
            flash(f"Error retrieving performance data: {e}", "danger")
    
    return render_template(
        'performance_dashboard.html',
        bot_status=bot_status,
        bot_instance=bot_instance,
        last_check_time=last_check_time.strftime('%Y-%m-%d %H:%M:%S') if last_check_time else None,
        performance=performance_data,
        paper_trading=Config.PAPER_TRADING
    )

@app.route('/reset_performance', methods=['POST'])
def reset_performance():
    """Reset performance statistics."""
    reset_all = request.form.get('reset_all', 'false').lower() == 'true'
    
    if bot_instance and bot_status == "running":
        try:
            success = bot_instance.reset_performance_tracker(reset_all=reset_all)
            if success:
                if reset_all:
                    flash("All performance statistics have been reset.", "success")
                else:
                    flash("Session performance statistics have been reset.", "success")
            else:
                flash("Failed to reset performance statistics.", "danger")
        except Exception as e:
            logger.error(f"Error resetting performance stats: {e}")
            flash(f"Error resetting performance statistics: {e}", "danger")
    else:
        flash("Bot is not running. Please start the bot first.", "warning")
    
    return redirect(url_for('performance_dashboard'))

@app.route('/export_performance', methods=['GET'])
def export_performance():
    """Export performance data as CSV."""
    if bot_instance and bot_status == "running":
        try:
            # Get recent trades from performance tracker
            performance_data = bot_instance.get_performance_stats()
            recent_trades = performance_data.get('recent_trades', [])
            
            if not recent_trades:
                flash("No trade data available to export.", "warning")
                return redirect(url_for('performance_dashboard'))
            
            # Create CSV content
            csv_data = []
            
            # Add header row
            csv_data.append("Symbol,Strategy,Entry Time,Exit Time,Entry Price,Exit Price,Quantity,P&L,P&L %,Exit Reason")
            
            # Add trade data rows
            for trade in recent_trades:
                row = [
                    trade.get('symbol', ''),
                    trade.get('strategy', ''),
                    trade.get('entry_time', ''),
                    trade.get('exit_time', ''),
                    str(trade.get('entry_price', '')),
                    str(trade.get('exit_price', '')),
                    str(trade.get('quantity', '')),
                    str(trade.get('pnl', '')),
                    str(trade.get('pnl_percent', '')) + '%',
                    trade.get('exit_reason', '')
                ]
                csv_data.append(','.join(row))
            
            # Join rows with newlines
            csv_content = '\n'.join(csv_data)
            
            # Generate timestamp for filename
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            
            # Create response with CSV data
            response = make_response(csv_content)
            response.headers['Content-Disposition'] = f'attachment; filename=trade_report_{timestamp}.csv'
            response.headers['Content-Type'] = 'text/csv'
            
            return response
            
        except Exception as e:
            logger.error(f"Error exporting performance data: {e}")
            flash(f"Error exporting performance data: {e}", "danger")
    else:
        flash("Bot is not running. Please start the bot first.", "warning")
    
    return redirect(url_for('performance_dashboard'))

@app.route('/switch_strategy', methods=['POST'])
def switch_strategy():
    """Switch the active trading strategy."""
    strategy_name = request.form.get('strategy_name')
    
    # Update the config
    if strategy_name in ['dip_buyer', 'mean_reversion', 'breakout']:
        Config.ACTIVE_STRATEGY = strategy_name
        
        # If the bot is running, update its strategy
        if bot_instance and bot_status == "running":
            try:
                # Get strategy parameters from config
                strategy_params = Config.get_strategy_params()
                
                # Initialize the selected strategy
                from strategies import get_strategy
                bot_instance.strategy = get_strategy(strategy_name, **strategy_params)
                bot_instance.active_strategy = strategy_name
                
                flash(f'Successfully switched to {strategy_name} strategy!', 'success')
                logger.info(f"Strategy switched to: {strategy_name}")
            except Exception as e:
                logger.error(f"Error switching strategy: {e}")
                flash(f'Error switching strategy: {e}', 'danger')
        else:
            flash(f'Strategy set to {strategy_name}. Will take effect when bot is started.', 'info')
    else:
        flash(f'Invalid strategy: {strategy_name}', 'danger')
    
    return redirect(url_for('index'))

def load_strategy_description(strategy_id):
    """
    Load and convert the markdown description for a strategy.
    
    Args:
        strategy_id (str): Strategy ID (e.g., 'dip_buyer')
        
    Returns:
        Markup: HTML content or None if file doesn't exist
    """
    desc_path = f'strategies/descriptions/{strategy_id}.md'
    try:
        with open(desc_path, 'r') as f:
            content = f.read()
            html_content = markdown.markdown(content)
            return Markup(html_content)
    except (FileNotFoundError, IOError):
        logger.warning(f"No description file found for strategy {strategy_id}")
        return None

@app.route('/strategy_settings')
def strategy_settings():
    """Page for configuring strategy parameters."""
    from strategies import get_available_strategies
    
    # Get the active strategy info
    active_strategy_name = Config.ACTIVE_STRATEGY
    active_strategy_info = None
    for strategy in get_available_strategies():
        if strategy['id'] == active_strategy_name:
            active_strategy_info = strategy
            break
    
    # Get strategy-specific parameters
    strategy_params = {}
    
    if active_strategy_name == 'dip_buyer':
        strategy_params = {
            'price_drop_threshold': {
                'label': 'Price Drop Threshold',
                'value': Config.PRICE_DROP_THRESHOLD,
                'step': 0.1,
                'min': 0.5,
                'max': 10.0,
                'unit': '%',
                'description': 'Minimum price drop percentage to consider entry'
            },
            'price_drop_timeframe': {
                'label': 'Price Drop Timeframe',
                'value': Config.PRICE_DROP_TIMEFRAME,
                'step': 1,
                'min': 1,
                'max': 60,
                'unit': 'minutes',
                'description': 'Timeframe to check for price drop'
            }
        }
    elif active_strategy_name == 'mean_reversion':
        strategy_params = {
            'ma_period': {
                'label': 'Moving Average Period',
                'value': Config.MA_PERIOD,
                'step': 1,
                'min': 5,
                'max': 200,
                'unit': 'candles',
                'description': 'Period for calculating moving average'
            },
            'std_dev_multiplier': {
                'label': 'Standard Deviation Multiplier',
                'value': Config.STD_DEV_MULTIPLIER,
                'step': 0.1,
                'min': 0.5,
                'max': 5.0,
                'unit': '',
                'description': 'Multiplier for standard deviation bands'
            }
        }
    elif active_strategy_name == 'breakout':
        strategy_params = {
            'lookback_period': {
                'label': 'Lookback Period',
                'value': Config.LOOKBACK_PERIOD,
                'step': 1,
                'min': 5,
                'max': 100,
                'unit': 'candles',
                'description': 'Period to look back for support/resistance levels'
            },
            'confirmation_candles': {
                'label': 'Confirmation Candles',
                'value': Config.CONFIRMATION_CANDLES,
                'step': 1,
                'min': 1,
                'max': 10,
                'unit': 'candles',
                'description': 'Number of candles needed to confirm breakout'
            },
            'volume_increase': {
                'label': 'Volume Increase Factor',
                'value': Config.VOLUME_INCREASE,
                'step': 0.1,
                'min': 1.0,
                'max': 5.0,
                'unit': 'x',
                'description': 'Minimum volume increase factor for valid breakout'
            }
        }
    
    # Get strategy performance if bot is running
    strategy_performance = None
    if bot_instance and bot_status == "running":
        win_rate = 0
        if bot_instance.total_trades > 0:
            win_rate = (bot_instance.successful_trades / bot_instance.total_trades) * 100
        
        strategy_performance = {
            'win_rate': round(win_rate, 2),
            'total_trades': bot_instance.total_trades,
            'total_profit': round(bot_instance.total_profit_usdt, 2),
            'avg_duration': '0h 0m'  # This would need to be calculated from trade data
        }
    
    # Get recent strategy logs
    strategy_logs = []
    
    # Load the detailed markdown description
    strategy_description = load_strategy_description(active_strategy_name)
    
    return render_template(
        'strategy_settings.html',
        bot_status=bot_status,
        active_strategy=active_strategy_name,
        active_strategy_info=active_strategy_info,
        available_strategies=get_available_strategies(),
        strategy_params=strategy_params,
        strategy_performance=strategy_performance,
        strategy_logs=strategy_logs,
        strategy_description=strategy_description,
        config=Config,
        last_check_time=last_check_time.strftime('%Y-%m-%d %H:%M:%S') if last_check_time else None
    )
    
@app.route('/update_strategy_params', methods=['POST'])
def update_strategy_params():
    """Update strategy parameters."""
    strategy_name = request.form.get('strategy_name')
    
    # Validate strategy
    if strategy_name not in ['dip_buyer', 'mean_reversion', 'breakout']:
        flash('Invalid strategy specified', 'danger')
        return redirect(url_for('strategy_settings'))
    
    try:
        # Store original values for feedback message
        original_values = {}
        updated_values = {}
        
        # Update common parameters
        original_values['take_profit'] = Config.TAKE_PROFIT
        updated_values['take_profit'] = float(request.form.get('take_profit', Config.TAKE_PROFIT))
        Config.TAKE_PROFIT = updated_values['take_profit']
        
        original_values['stop_loss'] = Config.STOP_LOSS
        updated_values['stop_loss'] = float(request.form.get('stop_loss', Config.STOP_LOSS))
        Config.STOP_LOSS = updated_values['stop_loss']
        
        original_values['max_positions'] = Config.MAX_OPEN_POSITIONS
        updated_values['max_positions'] = int(request.form.get('max_positions', Config.MAX_OPEN_POSITIONS))
        Config.MAX_OPEN_POSITIONS = updated_values['max_positions']
        
        original_values['base_position_size'] = Config.BASE_POSITION_SIZE
        updated_values['base_position_size'] = float(request.form.get('base_position_size', Config.BASE_POSITION_SIZE))
        Config.BASE_POSITION_SIZE = updated_values['base_position_size']
        
        original_values['reinvest_profits'] = Config.REINVEST_PROFITS
        updated_values['reinvest_profits'] = 'reinvest_profits' in request.form
        Config.REINVEST_PROFITS = updated_values['reinvest_profits']
        
        # Update strategy-specific parameters
        if strategy_name == 'dip_buyer':
            original_values['price_drop_threshold'] = Config.PRICE_DROP_THRESHOLD
            updated_values['price_drop_threshold'] = float(request.form.get('price_drop_threshold', Config.PRICE_DROP_THRESHOLD))
            Config.PRICE_DROP_THRESHOLD = updated_values['price_drop_threshold']
            
            original_values['price_drop_timeframe'] = Config.PRICE_DROP_TIMEFRAME
            updated_values['price_drop_timeframe'] = int(request.form.get('price_drop_timeframe', Config.PRICE_DROP_TIMEFRAME))
            Config.PRICE_DROP_TIMEFRAME = updated_values['price_drop_timeframe']
        elif strategy_name == 'mean_reversion':
            original_values['ma_period'] = Config.MA_PERIOD
            updated_values['ma_period'] = int(request.form.get('ma_period', Config.MA_PERIOD))
            Config.MA_PERIOD = updated_values['ma_period']
            
            original_values['std_dev_multiplier'] = Config.STD_DEV_MULTIPLIER
            updated_values['std_dev_multiplier'] = float(request.form.get('std_dev_multiplier', Config.STD_DEV_MULTIPLIER))
            Config.STD_DEV_MULTIPLIER = updated_values['std_dev_multiplier']
        elif strategy_name == 'breakout':
            original_values['lookback_period'] = Config.LOOKBACK_PERIOD
            updated_values['lookback_period'] = int(request.form.get('lookback_period', Config.LOOKBACK_PERIOD))
            Config.LOOKBACK_PERIOD = updated_values['lookback_period']
            
            original_values['confirmation_candles'] = Config.CONFIRMATION_CANDLES
            updated_values['confirmation_candles'] = int(request.form.get('confirmation_candles', Config.CONFIRMATION_CANDLES))
            Config.CONFIRMATION_CANDLES = updated_values['confirmation_candles']
            
            original_values['volume_increase'] = Config.VOLUME_INCREASE
            updated_values['volume_increase'] = float(request.form.get('volume_increase', Config.VOLUME_INCREASE))
            Config.VOLUME_INCREASE = updated_values['volume_increase']
        
        # If bot is running, update the strategy
        if bot_instance and bot_status == "running":
            # Get updated strategy parameters
            strategy_params = Config.get_strategy_params()
            
            # Initialize the strategy with new parameters
            from strategies import get_strategy
            bot_instance.strategy = get_strategy(strategy_name, **strategy_params)
            
            # Build detailed log message
            changes = []
            for key in updated_values:
                if original_values[key] != updated_values[key]:
                    changes.append(f"{key.replace('_', ' ').title()}: {original_values[key]} → {updated_values[key]}")
            
            change_msg = ", ".join(changes)
            logger.info(f"Strategy parameters updated for {strategy_name}: {change_msg}")
            
            # Generate success message showing key changes
            if len(changes) > 0:
                # Select up to 3 of the most important changes for the flash message
                strategy_specific_changes = []
                if strategy_name == 'dip_buyer':
                    if 'price_drop_threshold' in updated_values and original_values['price_drop_threshold'] != updated_values['price_drop_threshold']:
                        strategy_specific_changes.append(f"Dip Threshold: {updated_values['price_drop_threshold']}%")
                elif strategy_name == 'mean_reversion':
                    if 'std_dev_multiplier' in updated_values and original_values['std_dev_multiplier'] != updated_values['std_dev_multiplier']:
                        strategy_specific_changes.append(f"Std Dev Multiplier: {updated_values['std_dev_multiplier']}")
                elif strategy_name == 'breakout':
                    if 'volume_increase' in updated_values and original_values['volume_increase'] != updated_values['volume_increase']:
                        strategy_specific_changes.append(f"Volume Trigger: {updated_values['volume_increase']}x")
                
                # Add common important parameters
                if original_values['take_profit'] != updated_values['take_profit']:
                    strategy_specific_changes.append(f"Take Profit: {updated_values['take_profit']}%")
                if original_values['stop_loss'] != updated_values['stop_loss']:
                    strategy_specific_changes.append(f"Stop Loss: {updated_values['stop_loss']}%")
                
                change_highlights = ", ".join(strategy_specific_changes[:3])
                if change_highlights:
                    flash(f'Strategy parameters updated successfully! {change_highlights}', 'success')
                else:
                    flash('Strategy parameters updated successfully!', 'success')
            else:
                flash('No changes detected in strategy parameters.', 'info')
        else:
            flash('Strategy parameters updated. Changes will take effect when the bot is started.', 'success')
    except Exception as e:
        logger.error(f"Error updating strategy parameters: {e}")
        flash(f'Error updating parameters: {e}', 'danger')
    
    return redirect(url_for('strategy_settings'))

@app.route('/reset_strategy_params')
def reset_strategy_params():
    """Reset strategy parameters to default values."""
    try:
        defaults = Config.reset_to_defaults()
        
        # If bot is running, update its strategy with default parameters
        if bot_instance and bot_status == "running":
            strategy_name = Config.ACTIVE_STRATEGY
            strategy_params = Config.get_strategy_params()
            
            from strategies import get_strategy
            bot_instance.strategy = get_strategy(strategy_name, **strategy_params)
            
            message = ", ".join([f"{key.replace('_', ' ').title()}: {value}" for key, value in defaults.items()])
            logger.info(f"Strategy parameters reset to defaults: {message}")
        
        flash(f'Strategy parameters reset to defaults successfully!', 'success')
        
    except Exception as e:
        logger.error(f"Error resetting strategy parameters: {e}")
        flash(f'Error resetting strategy parameters: {e}', 'danger')
    
    return redirect(url_for('strategy_settings'))

@app.route('/charts')
def charts():
    """Trade charts page showing price charts with entry/exit points."""
    # Get the selected trading pair from query parameters or use default
    selected_pair = request.args.get('symbol', Config.TRADING_PAIRS[0])
    selected_trade_id = request.args.get('trade_id')
    
    recent_trades = []
    selected_trade = None
    
    if bot_instance and bot_status == "running":
        try:
            # Get performance data which includes trades
            performance_stats = bot_instance.get_performance_stats()
            if 'recent_trades' in performance_stats:
                # Get recent trades for the symbol
                all_trades = performance_stats['recent_trades']
                
                # Add a unique ID for each trade if not present
                for i, trade in enumerate(all_trades):
                    if 'id' not in trade:
                        # Create a simple ID based on index and hash of entry/exit times
                        trade_hash = hash(f"{trade.get('entry_time', '')}-{trade.get('exit_time', '')}")
                        trade['id'] = f"trade_{i}_{abs(trade_hash) % 10000}"
                
                # Get trades for the selected symbol if specified
                if selected_pair:
                    symbol_trades = [t for t in all_trades if t.get('symbol') == selected_pair]
                    recent_trades = sorted(symbol_trades, 
                                         key=lambda x: x.get('exit_time', ''), 
                                         reverse=True)[:20]  # Get most recent 20
                
                # Get selected trade details if specified
                if selected_trade_id:
                    selected_trade = next((t for t in all_trades if t.get('id') == selected_trade_id), None)
        except Exception as e:
            logger.error(f"Error getting chart data: {e}")
            flash(f"Error retrieving chart data: {e}", "danger")
    
    return render_template(
        'chart_view.html',
        bot_status=bot_status,
        last_check_time=last_check_time.strftime('%Y-%m-%d %H:%M:%S') if last_check_time else None,
        trading_pairs=Config.TRADING_PAIRS,
        selected_pair=selected_pair,
        recent_trades=recent_trades,
        selected_trade=selected_trade,
        paper_trading=Config.PAPER_TRADING
    )

@app.route('/api/chart_data')
def api_chart_data():
    """API endpoint to get chart data for a specific symbol and timeframe."""
    symbol = request.args.get('symbol', Config.TRADING_PAIRS[0])
    timeframe = request.args.get('timeframe', '1h')
    chart_type = request.args.get('chart_type', 'candle')
    show_volume = request.args.get('show_volume', 'true').lower() == 'true'
    show_trades = request.args.get('show_trades', 'true').lower() == 'true'
    
    if not bot_instance or bot_status != "running":
        return jsonify({
            'error': 'Bot is not running. Please start the bot to access chart data.'
        })
    
    try:
        # Get OHLCV data for the symbol
        ohlcv_data = None
        if hasattr(bot_instance.client, 'get_historical_prices'):
            try:
                # Try to get historical prices from the API
                ohlcv_data = bot_instance.client.get_historical_prices(
                    symbol=symbol,
                    timeframe=timeframe,
                    limit=100  # Get the last 100 candles
                )
            except Exception as e:
                logger.error(f"Error getting historical prices: {e}")
                # Use simulated data if real data is not available
                if hasattr(bot_instance.client, 'exchange') and hasattr(bot_instance.client.exchange, 'generate_ohlcv'):
                    ohlcv_data = bot_instance.client.exchange.generate_ohlcv(
                        symbol=symbol,
                        timeframe=timeframe,
                        limit=100
                    )
        
        # If no OHLCV data is available, return an error
        if ohlcv_data is None or len(ohlcv_data) == 0:
            return jsonify({
                'error': f'No price data available for {symbol} with timeframe {timeframe}.'
            })
        
        # Get trades for the symbol
        trades = []
        if show_trades:
            try:
                performance_stats = bot_instance.get_performance_stats()
                if 'recent_trades' in performance_stats:
                    all_trades = performance_stats['recent_trades']
                    trades = [t for t in all_trades if t.get('symbol') == symbol]
            except Exception as e:
                logger.error(f"Error getting trade data: {e}")
        
        # Generate chart JSON
        chart_json = generate_ohlc_chart(
            ohlc_data=ohlcv_data,
            trades=trades,
            timeframe=timeframe,
            symbol=symbol,
            show_volume=show_volume,
            chart_type=chart_type
        )
        
        # Parse the chart JSON
        chart_data = json.loads(chart_json)
        
        # Return the chart data
        return jsonify(chart_data)
        
    except Exception as e:
        logger.error(f"Error generating chart: {e}")
        return jsonify({
            'error': f'Failed to generate chart: {str(e)}'
        })

@app.route('/api/performance_chart_data')
def api_performance_chart_data():
    """API endpoint to get performance chart data."""
    timeframe = request.args.get('timeframe', 'day')
    
    if not bot_instance or bot_status != "running":
        return jsonify({
            'error': 'Bot is not running. Please start the bot to access performance data.'
        })
    
    try:
        # Get performance data
        performance_stats = bot_instance.get_performance_stats()
        
        # Get balance history for the timeframe
        balance_history = None
        if 'balance_history' in performance_stats:
            balance_history = performance_stats['balance_history'].get(timeframe)
        
        # If no balance history is available, return an error
        if not balance_history:
            return jsonify({
                'error': f'No balance history available for timeframe {timeframe}.'
            })
        
        # Get trades for the timeframe
        trades = []
        if 'recent_trades' in performance_stats:
            trades = performance_stats['recent_trades']
        
        # Generate performance chart JSON
        chart_json = generate_performance_chart(
            balance_history=balance_history,
            trades=trades,
            show_trades=True
        )
        
        # Parse the chart JSON
        chart_data = json.loads(chart_json)
        
        # Return the chart data
        return jsonify(chart_data)
        
    except Exception as e:
        logger.error(f"Error generating performance chart: {e}")
        return jsonify({
            'error': f'Failed to generate performance chart: {str(e)}'
        })

@app.route('/api/trade_details')
def api_trade_details():
    """API endpoint to get details for a specific trade."""
    trade_id = request.args.get('id')
    
    if not trade_id:
        return jsonify({
            'error': 'Trade ID is required.'
        })
    
    if not bot_instance or bot_status != "running":
        return jsonify({
            'error': 'Bot is not running. Please start the bot to access trade data.'
        })
    
    try:
        # Get all trades
        performance_stats = bot_instance.get_performance_stats()
        all_trades = performance_stats.get('recent_trades', [])
        
        # Add IDs to trades if not present
        for i, trade in enumerate(all_trades):
            if 'id' not in trade:
                trade_hash = hash(f"{trade.get('entry_time', '')}-{trade.get('exit_time', '')}")
                trade['id'] = f"trade_{i}_{abs(trade_hash) % 10000}"
        
        # Find the trade with the specified ID
        selected_trade = next((t for t in all_trades if t.get('id') == trade_id), None)
        
        if not selected_trade:
            return jsonify({
                'error': f'Trade with ID {trade_id} not found.'
            })
        
        # Return the trade details
        return jsonify({
            'trade': selected_trade
        })
        
    except Exception as e:
        logger.error(f"Error getting trade details: {e}")
        return jsonify({
            'error': f'Failed to get trade details: {str(e)}'
        })

@app.route('/backtest')
def backtest():
    """Page for running backtests on historical data."""
    from strategies import get_available_strategies
    
    # Get available strategies for the dropdown
    strategies = get_available_strategies()
    strategy_info = None
    
    # Get the active strategy info if specified
    active_strategy = request.args.get('strategy', Config.ACTIVE_STRATEGY)
    
    for strategy in strategies:
        if strategy['id'] == active_strategy:
            strategy_info = strategy
            break
    
    # Get all ensemble strategies for the dropdown
    all_ensembles = ensemble_manager.get_all_ensembles()
    active_ensemble = ensemble_manager.active_ensemble
    
    # Check if we want to show ensemble tab by default
    show_ensemble = request.args.get('tab', '') == 'ensemble'
    
    return render_template(
        'backtest.html',
        available_strategies={s['id']: s for s in strategies},
        active_strategy=active_strategy,
        strategy_info=strategy_info,
        ensembles=all_ensembles,
        active_ensemble=active_ensemble,
        show_ensemble_tab=show_ensemble,
        backtest_results=None
    )

@app.route('/run_ensemble_backtest', methods=['POST'])
def run_ensemble_backtest():
    """Run a backtest on an ensemble strategy."""
    try:
        # Get form parameters
        ensemble_name = request.form.get('ensemble')
        symbol = request.form.get('symbol', 'BTC/USDT')
        timeframe = request.form.get('timeframe', '1h')
        initial_balance = float(request.form.get('initial_balance', 1000))
        data_source = request.form.get('data_source', 'sample')
        compare_components = request.form.get('compare_components', 'true') == 'true'
        
        # Initialize ensemble backtester
        backtester = EnsembleBacktester(
            ensemble_name=ensemble_name,
            initial_balance=initial_balance
        )
        
        # Get data and run backtest
        if data_source == 'file':
            # Handle file upload
            if 'csv_file' not in request.files:
                flash('No file selected', 'danger')
                return redirect(url_for('backtest', tab='ensemble'))
                
            file = request.files['csv_file']
            
            if file.filename == '':
                flash('No file selected', 'danger')
                return redirect(url_for('backtest', tab='ensemble'))
            
            # Save uploaded file temporarily
            file_path = os.path.join('data', 'backtest_results', 'uploaded_data.csv')
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            file.save(file_path)
            
            # Run backtest from CSV
            results = backtester.run_from_csv(file_path, symbol, timeframe)
            
        elif data_source == 'api':
            # Get date range
            date_range = request.form.get('date_range', '30d')
            days = int(date_range.replace('d', ''))
            
            # Fetch data from API (this would normally use ccxt or similar)
            # For now, just use sample data
            ohlcv_data = load_sample_data()
            
            # Run backtest
            results = backtester.run(ohlcv_data, symbol, timeframe)
            
        else:  # 'sample'
            # Use sample data
            ohlcv_data = load_sample_data()
            
            # Run backtest
            results = backtester.run(ohlcv_data, symbol, timeframe)
        
        # Compare with component strategies if requested
        component_comparison = None
        if compare_components:
            try:
                component_comparison = backtester.compare_with_components()
            except Exception as e:
                logger.error(f"Error comparing with component strategies: {e}")
                flash(f"Could not compare with component strategies: {str(e)}", 'warning')
        
        # Store the results in the session
        session['ensemble_backtest_results'] = results
        session['component_comparison'] = component_comparison
        
        # Generate charts
        strategy_contribution_chart = None
        component_comparison_chart = None
        
        try:
            if backtester.signal_history:
                strategy_contribution_chart = backtester.generate_strategy_contribution_chart()
            
            if component_comparison and backtester.component_results:
                component_comparison_chart = backtester.generate_component_comparison_chart()
        except Exception as e:
            logger.error(f"Error generating ensemble charts: {e}")
        
        # Store charts in session
        session['strategy_contribution_chart'] = strategy_contribution_chart
        session['component_comparison_chart'] = component_comparison_chart
        
        # Get all ensemble strategies for the dropdown
        all_ensembles = ensemble_manager.get_all_ensembles()
        active_ensemble = ensemble_manager.active_ensemble
        
        # Render the backtest template with results
        return render_template(
            'backtest.html',
            show_ensemble_tab=True,
            ensembles=all_ensembles,
            active_ensemble=ensemble_name,
            ensemble_backtest_results=results,
            component_comparison=component_comparison,
            strategy_contribution_chart=strategy_contribution_chart,
            component_comparison_chart=component_comparison_chart
        )
        
    except Exception as e:
        logger.error(f"Error running ensemble backtest: {e}")
        flash(f"Error running ensemble backtest: {str(e)}", 'danger')
        return redirect(url_for('backtest', tab='ensemble'))

@app.route('/run_backtest', methods=['POST'])
def run_backtest():
    """Run a backtest on historical data."""
    from strategies import get_available_strategies
    
    try:
        # Get form parameters
        strategy = request.form.get('strategy')
        symbol = request.form.get('symbol', 'BTC/USDT')
        timeframe = request.form.get('timeframe', '1h')
        initial_balance = float(request.form.get('initial_balance', 1000))
        data_source = request.form.get('data_source', 'sample')
        
        # Parse strategy parameters
        # Find all param_* fields in the form
        strategy_params = {}
        for key, value in request.form.items():
            if key.startswith('param_'):
                param_name = key[6:]  # Remove 'param_' prefix
                
                # Convert value to appropriate type
                if value.replace('.', '', 1).isdigit():  # Check if it's a number
                    if '.' in value:
                        strategy_params[param_name] = float(value)
                    else:
                        strategy_params[param_name] = int(value)
                elif value.lower() in ('true', 'false'):  # Check if it's a boolean
                    strategy_params[param_name] = (value.lower() == 'true')
                else:
                    strategy_params[param_name] = value
        
        # Initialize backtester
        backtester = Backtester(
            strategy_name=strategy,
            params=strategy_params,
            initial_balance=initial_balance
        )
        
        # Get data and run backtest
        if data_source == 'file':
            # Handle file upload
            if 'csv_file' not in request.files:
                flash('No file selected', 'danger')
                return redirect(url_for('backtest'))
                
            file = request.files['csv_file']
            
            if file.filename == '':
                flash('No file selected', 'danger')
                return redirect(url_for('backtest'))
            
            # Save uploaded file temporarily
            file_path = os.path.join('data', 'backtest_results', 'uploaded_data.csv')
            file.save(file_path)
            
            # Run backtest from CSV
            results = backtester.run_from_csv(file_path, symbol, timeframe)
            
        elif data_source == 'api':
            # Get date range
            date_range = request.form.get('date_range', '30d')
            days = int(date_range.replace('d', ''))
            
            # Fetch data from API (this would normally use ccxt or similar)
            # For now, just use sample data
            ohlcv_data = load_sample_data()
            
            # Run backtest
            results = backtester.run(ohlcv_data, symbol, timeframe)
            
        else:  # 'sample'
            # Use sample data
            ohlcv_data = load_sample_data()
            
            # Run backtest
            results = backtester.run(ohlcv_data, symbol, timeframe)
        
        # Store the results in the session
        session['backtest_results'] = results
        
        # Get available strategies for the dropdown
        strategies = get_available_strategies()
        strategy_info = None
        
        # Get the active strategy info
        for s in strategies:
            if s['id'] == strategy:
                strategy_info = s
                break
        
        # Render the backtest template with results
        return render_template(
            'backtest.html',
            available_strategies={s['id']: s for s in strategies},
            active_strategy=strategy,
            strategy_info=strategy_info,
            backtest_results=results
        )
        
    except Exception as e:
        logger.error(f"Error running backtest: {e}")
        flash(f"Error running backtest: {str(e)}", 'danger')
        return redirect(url_for('backtest'))

@app.route('/api/backtest_equity_chart')
def api_backtest_equity_chart():
    """API endpoint to get equity chart data for the backtest."""
    backtest_results = session.get('backtest_results')
    
    if not backtest_results:
        return jsonify({'error': 'No backtest results found. Run a backtest first.'})
    
    try:
        # Convert equity curve to format expected by chart_utils
        balance_history = []
        for point in backtest_results['equity_curve']:
            balance_history.append({
                'timestamp': point['timestamp'],
                'balance': point['equity']  # Use equity rather than balance
            })
        
        # Generate chart using chart_utils
        chart_json = generate_performance_chart(
            balance_history=balance_history,
            trades=backtest_results['trades'],
            height=400,
            show_trades=True
        )
        
        return chart_json
        
    except Exception as e:
        logger.error(f"Error generating equity chart: {e}")
        return jsonify({'error': f'Error generating chart: {str(e)}'})

@app.route('/api/backtest_price_chart')
def api_backtest_price_chart():
    """API endpoint to get price chart data for the backtest."""
    backtest_results = session.get('backtest_results')
    
    if not backtest_results:
        return jsonify({'error': 'No backtest results found. Run a backtest first.'})
    
    try:
        # Get chart parameters
        chart_type = request.args.get('chart_type', 'candle')
        show_volume = request.args.get('show_volume', 'true').lower() == 'true'
        show_trades = request.args.get('show_trades', 'true').lower() == 'true'
        
        # We need OHLCV data for the chart, which is not stored in results
        # Use sample data if we don't have the actual data
        ohlcv_data = load_sample_data()
        
        # Generate chart using chart_utils
        chart_json = generate_ohlc_chart(
            ohlc_data=ohlcv_data,
            trades=backtest_results['trades'] if show_trades else None,
            timeframe=backtest_results['timeframe'],
            symbol=backtest_results['symbol'],
            show_volume=show_volume,
            height=600,
            chart_type=chart_type
        )
        
        return chart_json
        
    except Exception as e:
        logger.error(f"Error generating price chart: {e}")
        return jsonify({'error': f'Error generating chart: {str(e)}'})

@app.route('/api/ensemble_contribution_chart')
def api_ensemble_contribution_chart():
    """API endpoint to get contribution chart data for ensemble backtest."""
    chart_json = session.get('strategy_contribution_chart')
    
    if not chart_json:
        return jsonify({'error': 'No ensemble contribution chart available. Run an ensemble backtest first.'})
    
    try:
        return Response(chart_json, content_type='application/json')
    except Exception as e:
        logger.error(f"Error retrieving ensemble contribution chart: {e}")
        return jsonify({'error': f'Error retrieving chart: {str(e)}'})

@app.route('/api/ensemble_comparison_chart')
def api_ensemble_comparison_chart():
    """API endpoint to get comparison chart data for ensemble backtest."""
    chart_json = session.get('component_comparison_chart')
    
    if not chart_json:
        return jsonify({'error': 'No component comparison chart available. Run an ensemble backtest with component comparison enabled.'})
    
    try:
        return Response(chart_json, content_type='application/json')
    except Exception as e:
        logger.error(f"Error retrieving component comparison chart: {e}")
        return jsonify({'error': f'Error retrieving chart: {str(e)}'})

@app.route('/api/strategy_params')
def api_strategy_params():
    """API endpoint to get parameters for a specific strategy."""
    from strategies import get_available_strategies
    
    strategy_id = request.args.get('strategy')
    
    if not strategy_id:
        return jsonify({'error': 'Strategy ID is required'})
    
    strategies = get_available_strategies()
    
    for strategy in strategies:
        if strategy['id'] == strategy_id:
            # Convert key_parameters to the format expected by the UI
            parameters = {}
            
            # Add default parameters for all strategies
            parameters['take_profit'] = {
                'name': 'Take Profit (%)',
                'value': Config.TAKE_PROFIT,
                'type': 'number',
                'min': 0.1,
                'max': 100,
                'step': 0.1,
                'description': 'Price increase percentage to close position with profit'
            }
            
            parameters['stop_loss'] = {
                'name': 'Stop Loss (%)',
                'value': Config.STOP_LOSS,
                'type': 'number',
                'min': 0.1,
                'max': 100,
                'step': 0.1,
                'description': 'Price decrease percentage to close position with loss'
            }
            
            # Add strategy-specific parameters
            if strategy_id == 'dip_buyer':
                parameters['price_drop_threshold'] = {
                    'name': 'Price Drop Threshold (%)',
                    'value': Config.PRICE_DROP_THRESHOLD,
                    'type': 'number',
                    'min': 0.1,
                    'max': 20,
                    'step': 0.1,
                    'description': 'Minimum percentage price drop required to trigger entry'
                }
                
                parameters['price_drop_timeframe'] = {
                    'name': 'Price Drop Timeframe (minutes)',
                    'value': Config.PRICE_DROP_TIMEFRAME,
                    'type': 'number',
                    'min': 1,
                    'max': 1440,
                    'step': 1,
                    'description': 'Period to evaluate the price drop'
                }
                
            elif strategy_id == 'mean_reversion':
                parameters['ma_period'] = {
                    'name': 'MA Period',
                    'value': Config.MA_PERIOD,
                    'type': 'number',
                    'min': 2,
                    'max': 200,
                    'step': 1,
                    'description': 'Number of candles to calculate moving average'
                }
                
                parameters['std_dev_multiplier'] = {
                    'name': 'Std Dev Multiplier',
                    'value': Config.STD_DEV_MULTIPLIER,
                    'type': 'number',
                    'min': 0.1,
                    'max': 10,
                    'step': 0.1,
                    'description': 'Standard deviation multiplier for bands'
                }
                
            elif strategy_id == 'breakout':
                parameters['lookback_period'] = {
                    'name': 'Lookback Period',
                    'value': Config.LOOKBACK_PERIOD,
                    'type': 'number',
                    'min': 1,
                    'max': 100,
                    'step': 1,
                    'description': 'Period to look back for support/resistance levels'
                }
                
                parameters['confirmation_candles'] = {
                    'name': 'Confirmation Candles',
                    'value': Config.CONFIRMATION_CANDLES,
                    'type': 'number',
                    'min': 1,
                    'max': 10,
                    'step': 1,
                    'description': 'Number of candles to confirm breakout'
                }
                
                parameters['volume_increase'] = {
                    'name': 'Volume Increase',
                    'value': Config.VOLUME_INCREASE,
                    'type': 'number',
                    'min': 1,
                    'max': 10,
                    'step': 0.1,
                    'description': 'Minimum volume increase factor for valid breakout'
                }
            
            return jsonify({
                'id': strategy['id'],
                'name': strategy['name'],
                'description': strategy['description'],
                'parameters': parameters
            })
    
    return jsonify({'error': f'Strategy {strategy_id} not found'})

@app.route('/export_ensemble_backtest')
def export_ensemble_backtest():
    """Export ensemble backtest results in various formats."""
    backtest_results = session.get('ensemble_backtest_results')
    component_comparison = session.get('component_comparison')
    
    if not backtest_results:
        flash('No ensemble backtest results found. Run an ensemble backtest first.', 'warning')
        return redirect(url_for('backtest', tab='ensemble'))
    
    export_format = request.args.get('format', 'csv')
    
    try:
        if export_format == 'csv':
            # Create temporary directory if it doesn't exist
            os.makedirs('data/backtest_results', exist_ok=True)
            
            # Initialize a new ensemble backtester
            backtester = EnsembleBacktester(
                ensemble_name=backtest_results['ensemble'],
                initial_balance=backtest_results['initial_balance']
            )
            
            # Set the results so we can export them
            backtester.results = backtest_results
            backtester.trades = backtest_results.get('trades', [])
            backtester.equity_curve = backtest_results.get('equity_curve', [])
            
            # Export to CSV
            csv_files = backtester.export_results_csv()
            
            # Create a ZIP file with all CSVs
            import zipfile
            zip_path = os.path.join('data', 'backtest_results', 'ensemble_backtest_export.zip')
            
            with zipfile.ZipFile(zip_path, 'w') as zipf:
                for file_path in csv_files.values():
                    zipf.write(file_path, os.path.basename(file_path))
                
                # Add component comparison if available
                if component_comparison:
                    # Write component comparison to CSV
                    comparison_path = os.path.join('data', 'backtest_results', 'component_comparison.csv')
                    with open(comparison_path, 'w') as f:
                        f.write("Strategy,Profit %,Win Rate,Max Drawdown,Sharpe Ratio,Total Trades\n")
                        # Write ensemble data
                        ensemble_metrics = component_comparison['ensemble']['metrics']
                        f.write(f"{component_comparison['ensemble']['name']},{ensemble_metrics['profit_loss_percent']:.2f},{ensemble_metrics['win_rate']:.2f},{ensemble_metrics['max_drawdown_percent']:.2f},{ensemble_metrics['sharpe_ratio']:.2f},{ensemble_metrics['total_trades']}\n")
                        
                        # Write component data
                        for name, metrics in component_comparison['components'].items():
                            f.write(f"{name},{metrics['profit_loss_percent']:.2f},{metrics['win_rate']:.2f},{metrics['max_drawdown_percent']:.2f},{metrics['sharpe_ratio']:.2f},{metrics['total_trades']}\n")
                    
                    zipf.write(comparison_path, os.path.basename(comparison_path))
            
            # Return the ZIP file
            return send_file(
                zip_path,
                as_attachment=True,
                download_name=f"ensemble_backtest_{backtest_results['symbol'].replace('/', '_')}_{backtest_results['timeframe']}.zip"
            )
            
        elif export_format == 'json':
            # Return JSON with the whole result set
            response_data = {
                'backtest_results': backtest_results,
                'component_comparison': component_comparison
            }
            return jsonify(response_data)
            
        else:
            flash(f'Unsupported export format: {export_format}', 'danger')
            return redirect(url_for('backtest', tab='ensemble'))
            
    except Exception as e:
        logger.error(f"Error exporting ensemble backtest results: {e}")
        flash(f"Error exporting results: {str(e)}", 'danger')
        return redirect(url_for('backtest', tab='ensemble'))

@app.route('/export_backtest')
def export_backtest():
    """Export backtest results in various formats."""
    backtest_results = session.get('backtest_results')
    
    if not backtest_results:
        flash('No backtest results found. Run a backtest first.', 'warning')
        return redirect(url_for('backtest'))
    
    export_format = request.args.get('format', 'csv')
    
    try:
        if export_format == 'csv':
            # Create temporary directory if it doesn't exist
            os.makedirs('data/backtest_results', exist_ok=True)
            
            # Initialize a new backtester with the same parameters
            backtester = Backtester(
                strategy_name=backtest_results['strategy'],
                params=backtest_results.get('params', {}),
                initial_balance=backtest_results['initial_balance']
            )
            
            # Set the results so we can export them
            backtester.results = backtest_results
            backtester.trades = backtest_results.get('trades', [])
            backtester.equity_curve = backtest_results.get('equity_curve', [])
            
            # Export to CSV
            csv_files = backtester.export_results_csv()
            
            # Create a ZIP file with all CSVs
            import zipfile
            zip_path = os.path.join('data', 'backtest_results', 'backtest_export.zip')
            
            with zipfile.ZipFile(zip_path, 'w') as zipf:
                for file_path in csv_files.values():
                    zipf.write(file_path, os.path.basename(file_path))
            
            # Return the ZIP file
            return send_file(
                zip_path,
                as_attachment=True,
                download_name=f"backtest_{backtest_results['symbol'].replace('/', '_')}_{backtest_results['timeframe']}.zip"
            )
            
        elif export_format == 'json':
            # Return JSON directly
            return jsonify(backtest_results)
            
        elif export_format == 'pdf':
            # For PDF export, we would need to generate a PDF report
            # This is more complex and would require a library like ReportLab
            # For now, just return a message
            flash('PDF export is not implemented yet.', 'info')
            return redirect(url_for('backtest'))
            
        else:
            flash(f'Unsupported export format: {export_format}', 'danger')
            return redirect(url_for('backtest'))
            
    except Exception as e:
        logger.error(f"Error exporting backtest results: {e}")
        flash(f"Error exporting results: {str(e)}", 'danger')
        return redirect(url_for('backtest'))

# Parameter Optimization Routes
import uuid
from parameter_sweep import ParameterOptimizer, run_optimization
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend for server environment

# Storage for optimization results
optimization_results = {}
strategy_recommendations = {}

@app.route('/optimize')
def optimize():
    """Parameter optimization page."""
    from strategies import get_available_strategies
    
    # Get available strategies for the dropdown
    strategies = get_available_strategies()
    strategy_info = None
    
    # Get the active strategy info if specified
    active_strategy = request.args.get('strategy', Config.ACTIVE_STRATEGY)
    
    for strategy in strategies:
        if strategy['id'] == active_strategy:
            strategy_info = strategy
            break
    
    # Get the optimization results if they exist in the query
    result_id = request.args.get('id')
    optimization_result = None
    
    if result_id and result_id in optimization_results:
        optimization_result = optimization_results[result_id]
    
    return render_template(
        'optimize.html',
        available_strategies={s['id']: s for s in strategies},
        active_strategy=active_strategy,
        strategy_info=strategy_info,
        optimization_results=optimization_result
    )

@app.route('/run_optimization', methods=['POST'])
def run_optimization_route():
    """Run parameter optimization."""
    from strategies import get_available_strategies
    
    try:
        # Get form parameters
        strategy = request.form.get('strategy')
        symbol = request.form.get('symbol', 'BTC/USDT')
        timeframe = request.form.get('timeframe', '1h')
        initial_balance = float(request.form.get('initial_balance', 1000))
        optimization_method = request.form.get('optimization_method', 'grid')
        max_combinations = int(request.form.get('max_combinations', 500))
        random_samples = int(request.form.get('random_samples', 100))
        data_source = request.form.get('data_source', 'sample')
        create_visualizations = 'create_visualizations' in request.form
        
        # Parse parameter ranges
        parameter_ranges = {}
        
        # Find all parameter range inputs
        for key in request.form:
            if key.endswith('_min') and key.startswith('param_'):
                # Extract parameter name from param_X_min
                param_name = key[6:-4]  # Remove 'param_' and '_min'
                
                if f'param_{param_name}_max' in request.form and f'param_{param_name}_step' in request.form:
                    try:
                        min_val = float(request.form[f'param_{param_name}_min'])
                        max_val = float(request.form[f'param_{param_name}_max'])
                        step = float(request.form[f'param_{param_name}_step'])
                        
                        # Generate range values
                        values = []
                        current = min_val
                        while current <= max_val:
                            values.append(current)
                            current += step
                        
                        parameter_ranges[param_name] = values
                    except Exception as e:
                        logger.error(f"Error parsing parameter range for {param_name}: {e}")
            
            # Handle boolean parameters
            elif key.startswith('param_') and key.endswith('_values'):
                param_name = key[6:-7]  # Remove 'param_' and '_values'
                
                # Boolean parameters have true/false values
                if request.form.getlist(key) == ['true', 'false']:
                    parameter_ranges[param_name] = [True, False]
                else:
                    # Handle custom value lists
                    value_str = request.form[key]
                    try:
                        # Try to parse as comma-separated values
                        values = [v.strip() for v in value_str.split(',')]
                        
                        # Convert to appropriate types if possible
                        typed_values = []
                        for v in values:
                            if v.replace('.', '', 1).isdigit():
                                if '.' in v:
                                    typed_values.append(float(v))
                                else:
                                    typed_values.append(int(v))
                            elif v.lower() in ('true', 'false'):
                                typed_values.append(v.lower() == 'true')
                            else:
                                typed_values.append(v)
                                
                        parameter_ranges[param_name] = typed_values
                    except Exception as e:
                        logger.error(f"Error parsing parameter values for {param_name}: {e}")
        
        # If no parameter ranges were specified, use defaults
        if not parameter_ranges:
            flash('No parameter ranges specified. Using default ranges.', 'info')
            # Set default ranges based on strategy
            if strategy == 'dip_buyer':
                parameter_ranges = {
                    'price_drop_threshold': [1.0, 1.5, 2.0, 2.5, 3.0],
                    'price_drop_timeframe': [5, 10, 15, 20, 30],
                    'take_profit': [2.0, 3.0, 4.0, 5.0],
                    'stop_loss': [1.0, 1.5, 2.0, 2.5]
                }
            elif strategy == 'mean_reversion':
                parameter_ranges = {
                    'ma_period': [10, 20, 30, 40, 50],
                    'std_dev_multiplier': [1.0, 1.5, 2.0, 2.5, 3.0],
                    'take_profit': [2.0, 3.0, 4.0, 5.0],
                    'stop_loss': [1.0, 1.5, 2.0, 2.5]
                }
            elif strategy == 'breakout':
                parameter_ranges = {
                    'lookback_period': [10, 20, 30, 40, 50],
                    'confirmation_candles': [1, 2, 3, 4, 5],
                    'volume_increase': [1.0, 1.5, 2.0, 2.5, 3.0],
                    'take_profit': [2.0, 3.0, 4.0, 5.0],
                    'stop_loss': [1.0, 1.5, 2.0, 2.5]
                }
            else:
                parameter_ranges = {
                    'take_profit': [2.0, 3.0, 4.0, 5.0],
                    'stop_loss': [1.0, 1.5, 2.0, 2.5]
                }
        
        # Get OHLCV data
        ohlcv_data = None
        if data_source == 'file':
            # Handle file upload
            if 'csv_file' not in request.files:
                flash('No file selected', 'danger')
                return redirect(url_for('optimize'))
                
            file = request.files['csv_file']
            
            if file.filename == '':
                flash('No file selected', 'danger')
                return redirect(url_for('optimize'))
            
            # Save uploaded file temporarily
            file_path = os.path.join('data', 'backtest_results', 'uploaded_data.csv')
            file.save(file_path)
            
            # Load OHLCV data from CSV
            try:
                from backtest import load_csv_data
                ohlcv_data = load_csv_data(file_path)
            except Exception as e:
                logger.error(f"Error loading CSV data: {e}")
                flash(f"Error loading CSV data: {str(e)}", 'danger')
                return redirect(url_for('optimize'))
        else:
            # Use sample data
            from backtest import load_sample_data
            ohlcv_data = load_sample_data()
        
        # Initialize parameter optimizer
        optimizer = ParameterOptimizer(
            strategy_name=strategy,
            initial_balance=initial_balance,
            symbol=symbol,
            timeframe=timeframe
        )
        
        # Add parameter ranges
        for param_name, values in parameter_ranges.items():
            optimizer.add_parameter(param_name, values)
        
        # Run optimization
        flash(f"Starting {optimization_method} optimization for {strategy} strategy with {len(parameter_ranges)} parameters...", 'info')
        
        results_df = optimizer.run(
            ohlcv_data=ohlcv_data,
            method=optimization_method,
            max_combinations=max_combinations,
            random_samples=random_samples
        )
        
        # Store results with a unique ID
        result_id = str(uuid.uuid4())
        
        # Extract best parameters for different metrics
        best_results = optimizer.best_results
        
        # For visualization, create charts if requested
        visualizations = []
        if create_visualizations and len(results_df) > 1:
            import matplotlib.pyplot as plt
            import seaborn as sns
            
            # Create output directory
            visualization_dir = f"static/optimization_charts/{result_id}"
            os.makedirs(visualization_dir, exist_ok=True)
            
            # Extract parameter names
            param_cols = list(parameter_ranges.keys())
            
            # Create heatmaps for parameter interactions
            if len(param_cols) >= 2:
                # Get all pairs of parameters
                for i, param1 in enumerate(param_cols):
                    for param2 in param_cols[i+1:]:
                        # Create pivot tables for different metrics
                        metrics = ['total_profit', 'win_rate', 'sharpe_ratio']
                        
                        for metric in metrics:
                            try:
                                plt.figure(figsize=(10, 8))
                                pivot = results_df.pivot_table(
                                    index=param1, 
                                    columns=param2, 
                                    values=metric,
                                    aggfunc='mean'
                                )
                                sns.heatmap(pivot, annot=True, cmap='viridis', fmt='.2f')
                                plt.title(f'{metric} for different {param1} and {param2} values')
                                plt.tight_layout()
                                
                                # Save figure
                                chart_path = os.path.join(visualization_dir, f"{param1}_{param2}_{metric}_heatmap.png")
                                plt.savefig(f"static/optimization_charts/{result_id}/{param1}_{param2}_{metric}_heatmap.png")
                                plt.close()
                                
                                # Add to visualizations list
                                visualizations.append({
                                    'title': f'{metric.replace("_", " ").title()} Heatmap: {param1} vs {param2}',
                                    'path': f"/static/optimization_charts/{result_id}/{param1}_{param2}_{metric}_heatmap.png"
                                })
                            except Exception as e:
                                logger.warning(f"Could not create heatmap for {param1} vs {param2}: {e}")
            
            # Create violin plots for each parameter's effect on profit
            for param in param_cols:
                try:
                    plt.figure(figsize=(10, 6))
                    sns.boxplot(x=param, y='total_profit', data=results_df)
                    plt.title(f'Effect of {param} on Profit')
                    plt.tight_layout()
                    
                    # Save figure
                    plt.savefig(f"static/optimization_charts/{result_id}/{param}_profit_box.png")
                    plt.close()
                    
                    # Add to visualizations list
                    visualizations.append({
                        'title': f'Profit Distribution by {param}',
                        'path': f"/static/optimization_charts/{result_id}/{param}_profit_box.png"
                    })
                    
                    plt.figure(figsize=(10, 6))
                    sns.boxplot(x=param, y='win_rate', data=results_df)
                    plt.title(f'Effect of {param} on Win Rate')
                    plt.tight_layout()
                    
                    # Save figure
                    plt.savefig(f"static/optimization_charts/{result_id}/{param}_winrate_box.png")
                    plt.close()
                    
                    # Add to visualizations list
                    visualizations.append({
                        'title': f'Win Rate Distribution by {param}',
                        'path': f"/static/optimization_charts/{result_id}/{param}_winrate_box.png"
                    })
                except Exception as e:
                    logger.warning(f"Could not create plots for {param}: {e}")
        
        # Get top results sorted by profit
        top_results = results_df.sort_values('total_profit', ascending=False).head(10).to_dict('records')
        
        # Store the results
        optimization_results[result_id] = {
            'id': result_id,
            'strategy_name': strategy,
            'symbol': symbol,
            'timeframe': timeframe,
            'method': optimization_method,
            'initial_balance': initial_balance,
            'parameter_ranges': parameter_ranges,
            'param_names': list(parameter_ranges.keys()),
            'combinations': len(results_df),
            'timestamp': datetime.now().isoformat(),
            'best_profit': best_results.get('best_profit', {}),
            'best_win_rate': best_results.get('best_win_rate', {}),
            'best_sharpe': best_results.get('best_sharpe', {}),
            'best_drawdown': best_results.get('best_drawdown', {}),
            'best_return': best_results.get('best_return', {}),
            'best_balanced': best_results.get('best_balanced', {}),  # Add balanced metric
            'top_results': top_results,
            'visualizations': visualizations
        }
        
        # Update strategy recommendations
        # Store the best parameters based on balanced metric (preferred) or profit if balanced not available
        if 'best_balanced' in best_results:
            # Extract only strategy parameters, not metrics
            params = {k: v for k, v in best_results['best_balanced'].items() 
                     if k not in ['total_profit', 'total_return_pct', 'win_rate', 
                                 'total_trades', 'max_drawdown', 'sharpe_ratio',
                                 'profit_factor', 'avg_profit', 'avg_loss',
                                 'avg_holding_time', 'winning_trades', 'losing_trades',
                                 'balanced_score']}
            
            # Get strategy name
            strategy_name = next((s['name'] for s in get_available_strategies() if s['id'] == strategy), strategy)
            
            strategy_recommendations[strategy] = {
                'name': strategy_name,
                'parameters': params,
                'metric': 'balanced',
                'value': best_results['best_balanced'].get('balanced_score', 0),
                'timestamp': datetime.now().isoformat()
            }
        # Fall back to profit if balanced metric not available
        elif 'best_profit' in best_results:
            # Extract only strategy parameters, not metrics
            params = {k: v for k, v in best_results['best_profit'].items() 
                     if k not in ['total_profit', 'total_return_pct', 'win_rate', 
                                 'total_trades', 'max_drawdown', 'sharpe_ratio',
                                 'profit_factor', 'avg_profit', 'avg_loss',
                                 'avg_holding_time', 'winning_trades', 'losing_trades']}
            
            # Get strategy name
            strategy_name = next((s['name'] for s in get_available_strategies() if s['id'] == strategy), strategy)
            
            strategy_recommendations[strategy] = {
                'name': strategy_name,
                'parameters': params,
                'metric': 'profit',
                'value': best_results['best_profit'].get('total_profit', 0),
                'timestamp': datetime.now().isoformat()
            }
        
        flash(f"Optimization completed with {len(results_df)} parameter combinations. Best profit: {best_results.get('best_profit', {}).get('total_profit', 0):.2f} USDT", 'success')
        
        # Get available strategies for the UI
        strategies = get_available_strategies()
        
        return render_template(
            'optimize.html',
            available_strategies={s['id']: s for s in strategies},
            active_strategy=strategy,
            strategy_info=next((s for s in strategies if s['id'] == strategy), None),
            optimization_results=optimization_results[result_id]
        )
        
    except Exception as e:
        logger.error(f"Error running optimization: {e}")
        flash(f"Error running optimization: {str(e)}", 'danger')
        return redirect(url_for('optimize'))

@app.route('/optimization_history')
def optimization_history():
    """Page showing optimization run history."""
    # Convert dictionary to list and sort by timestamp
    history = list(optimization_results.values())
    history.sort(key=lambda x: x['timestamp'], reverse=True)
    
    return render_template(
        'optimization_history.html',
        optimization_history=history,
        strategy_recommendations=strategy_recommendations
    )

@app.route('/view_optimization')
def view_optimization():
    """View details of a specific optimization run."""
    result_id = request.args.get('id')
    
    if not result_id or result_id not in optimization_results:
        flash('Optimization run not found.', 'danger')
        return redirect(url_for('optimization_history'))
    
    return render_template(
        'optimize.html',
        available_strategies={},  # Not needed for viewing results
        active_strategy=optimization_results[result_id]['strategy_name'],
        strategy_info=None,
        optimization_results=optimization_results[result_id]
    )

@app.route('/export_optimization')
def export_optimization():
    """Export optimization results."""
    result_id = request.args.get('id')
    export_format = request.args.get('format', 'csv')
    
    if not result_id or result_id not in optimization_results:
        flash('Optimization run not found.', 'danger')
        return redirect(url_for('optimization_history'))
    
    result = optimization_results[result_id]
    
    try:
        if export_format == 'csv':
            # Create a CSV from the top results
            import csv
            import io
            
            # Create a string buffer
            output = io.StringIO()
            writer = csv.writer(output)
            
            # Get all parameter names and metrics
            param_names = result['param_names']
            metrics = ['total_profit', 'total_return_pct', 'win_rate', 'total_trades',
                      'max_drawdown', 'sharpe_ratio', 'profit_factor', 'avg_profit',
                      'avg_loss', 'winning_trades', 'losing_trades']
            
            # Write header
            header = param_names + metrics
            writer.writerow(header)
            
            # Write rows
            for row in result['top_results']:
                writer_row = [row.get(param, '') for param in param_names]
                writer_row += [row.get(metric, '') for metric in metrics]
                writer.writerow(writer_row)
            
            # Return CSV
            output.seek(0)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            return Response(
                output.getvalue(),
                mimetype="text/csv",
                headers={"Content-Disposition": f"attachment;filename=optimization_{result['strategy_name']}_{timestamp}.csv"}
            )
            
        elif export_format == 'json':
            # Return JSON
            return jsonify(result)
            
        else:
            flash(f'Unsupported export format: {export_format}', 'danger')
            return redirect(url_for('view_optimization', id=result_id))
            
    except Exception as e:
        logger.error(f"Error exporting optimization results: {e}")
        flash(f"Error exporting results: {str(e)}", 'danger')
        return redirect(url_for('view_optimization', id=result_id))

@app.route('/apply_parameters')
def apply_parameters():
    """Apply optimization results to the current strategy."""
    result_id = request.args.get('id')
    metric = request.args.get('metric', 'profit')
    
    if not result_id or result_id not in optimization_results:
        flash('Optimization run not found.', 'danger')
        return redirect(url_for('optimization_history'))
    
    result = optimization_results[result_id]
    strategy_name = result['strategy_name']
    
    # Get parameters based on metric
    if metric == 'profit' and 'best_profit' in result:
        parameters = result['best_profit']
    elif metric == 'win_rate' and 'best_win_rate' in result:
        parameters = result['best_win_rate']
    elif metric == 'sharpe' and 'best_sharpe' in result:
        parameters = result['best_sharpe']
    elif metric == 'drawdown' and 'best_drawdown' in result:
        parameters = result['best_drawdown']
    elif metric == 'return' and 'best_return' in result:
        parameters = result['best_return']
    elif metric == 'balanced' and 'best_balanced' in result:
        parameters = result['best_balanced']
    else:
        flash(f'Invalid metric or no results available for {metric}', 'danger')
        return redirect(url_for('view_optimization', id=result_id))
    
    # Extract only strategy parameters, not metrics
    params = {k: v for k, v in parameters.items() 
             if k not in ['total_profit', 'total_return_pct', 'win_rate', 
                         'total_trades', 'max_drawdown', 'sharpe_ratio',
                         'profit_factor', 'avg_profit', 'avg_loss',
                         'avg_holding_time', 'winning_trades', 'losing_trades']}
    
    # Apply parameters to config
    try:
        # Update strategy to use these parameters
        if strategy_name == 'dip_buyer':
            if 'price_drop_threshold' in params:
                Config.PRICE_DROP_THRESHOLD = params['price_drop_threshold']
            if 'price_drop_timeframe' in params:
                Config.PRICE_DROP_TIMEFRAME = params['price_drop_timeframe']
        elif strategy_name == 'mean_reversion':
            if 'ma_period' in params:
                Config.MA_PERIOD = params['ma_period']
            if 'std_dev_multiplier' in params:
                Config.STD_DEV_MULTIPLIER = params['std_dev_multiplier']
        elif strategy_name == 'breakout':
            if 'lookback_period' in params:
                Config.LOOKBACK_PERIOD = params['lookback_period']
            if 'confirmation_candles' in params:
                Config.CONFIRMATION_CANDLES = params['confirmation_candles']
            if 'volume_increase' in params:
                Config.VOLUME_INCREASE = params['volume_increase']
        
        # Common parameters
        if 'take_profit' in params:
            Config.TAKE_PROFIT = params['take_profit']
        if 'stop_loss' in params:
            Config.STOP_LOSS = params['stop_loss']
        
        # Update active strategy if different
        if Config.ACTIVE_STRATEGY != strategy_name:
            Config.ACTIVE_STRATEGY = strategy_name
            if bot_instance:
                bot_instance.switch_strategy(strategy_name)
        
        flash(f"Successfully applied {metric} parameters to {strategy_name} strategy.", 'success')
        return redirect(url_for('strategy_settings'))
        
    except Exception as e:
        logger.error(f"Error applying parameters: {e}")
        flash(f"Error applying parameters: {str(e)}", 'danger')
        return redirect(url_for('view_optimization', id=result_id))

@app.route('/apply_parameters_direct')
def apply_parameters_direct():
    """Apply parameters directly from the JSON representation."""
    try:
        params_json = request.args.get('params')
        if not params_json:
            flash('No parameters provided.', 'danger')
            return redirect(url_for('optimization_history'))
        
        params = json.loads(params_json)
        
        # Extract strategy name from params
        strategy_name = request.args.get('strategy')
        if not strategy_name:
            # Try to determine from the avialable strategies based on parameters
            for s in get_available_strategies():
                if s['id'] == 'dip_buyer' and 'price_drop_threshold' in params:
                    strategy_name = 'dip_buyer'
                    break
                elif s['id'] == 'mean_reversion' and 'ma_period' in params:
                    strategy_name = 'mean_reversion'
                    break
                elif s['id'] == 'breakout' and 'lookback_period' in params:
                    strategy_name = 'breakout'
                    break
        
        if not strategy_name:
            flash('Could not determine strategy from parameters.', 'danger')
            return redirect(url_for('optimization_history'))
        
        # Extract only strategy parameters, not metrics
        clean_params = {k: v for k, v in params.items() 
                      if k not in ['total_profit', 'total_return_pct', 'win_rate', 
                                  'total_trades', 'max_drawdown', 'sharpe_ratio',
                                  'profit_factor', 'avg_profit', 'avg_loss',
                                  'avg_holding_time', 'winning_trades', 'losing_trades']}
        
        # Apply parameters to config
        if strategy_name == 'dip_buyer':
            if 'price_drop_threshold' in clean_params:
                Config.PRICE_DROP_THRESHOLD = clean_params['price_drop_threshold']
            if 'price_drop_timeframe' in clean_params:
                Config.PRICE_DROP_TIMEFRAME = clean_params['price_drop_timeframe']
        elif strategy_name == 'mean_reversion':
            if 'ma_period' in clean_params:
                Config.MA_PERIOD = clean_params['ma_period']
            if 'std_dev_multiplier' in clean_params:
                Config.STD_DEV_MULTIPLIER = clean_params['std_dev_multiplier']
        elif strategy_name == 'breakout':
            if 'lookback_period' in clean_params:
                Config.LOOKBACK_PERIOD = clean_params['lookback_period']
            if 'confirmation_candles' in clean_params:
                Config.CONFIRMATION_CANDLES = clean_params['confirmation_candles']
            if 'volume_increase' in clean_params:
                Config.VOLUME_INCREASE = clean_params['volume_increase']
        
        # Common parameters
        if 'take_profit' in clean_params:
            Config.TAKE_PROFIT = clean_params['take_profit']
        if 'stop_loss' in clean_params:
            Config.STOP_LOSS = clean_params['stop_loss']
        
        # Update active strategy if different
        if Config.ACTIVE_STRATEGY != strategy_name:
            Config.ACTIVE_STRATEGY = strategy_name
            if bot_instance:
                bot_instance.switch_strategy(strategy_name)
        
        flash(f"Successfully applied parameters to {strategy_name} strategy.", 'success')
        return redirect(url_for('strategy_settings'))
        
    except Exception as e:
        logger.error(f"Error applying parameters: {e}")
        flash(f"Error applying parameters: {str(e)}", 'danger')
        return redirect(url_for('optimization_history'))

@app.route('/apply_recommendation')
def apply_recommendation():
    """Apply recommended parameters for a strategy."""
    strategy = request.args.get('strategy')
    
    if not strategy or strategy not in strategy_recommendations:
        flash('No recommendation found for this strategy.', 'danger')
        return redirect(url_for('optimization_history'))
    
    recommendation = strategy_recommendations[strategy]
    params = recommendation['parameters']
    
    # Apply parameters to config
    try:
        if strategy == 'dip_buyer':
            if 'price_drop_threshold' in params:
                Config.PRICE_DROP_THRESHOLD = params['price_drop_threshold']
            if 'price_drop_timeframe' in params:
                Config.PRICE_DROP_TIMEFRAME = params['price_drop_timeframe']
        elif strategy == 'mean_reversion':
            if 'ma_period' in params:
                Config.MA_PERIOD = params['ma_period']
            if 'std_dev_multiplier' in params:
                Config.STD_DEV_MULTIPLIER = params['std_dev_multiplier']
        elif strategy == 'breakout':
            if 'lookback_period' in params:
                Config.LOOKBACK_PERIOD = params['lookback_period']
            if 'confirmation_candles' in params:
                Config.CONFIRMATION_CANDLES = params['confirmation_candles']
            if 'volume_increase' in params:
                Config.VOLUME_INCREASE = params['volume_increase']
        
        # Common parameters
        if 'take_profit' in params:
            Config.TAKE_PROFIT = params['take_profit']
        if 'stop_loss' in params:
            Config.STOP_LOSS = params['stop_loss']
        
        # Update active strategy if different
        if Config.ACTIVE_STRATEGY != strategy:
            Config.ACTIVE_STRATEGY = strategy
            if bot_instance:
                bot_instance.switch_strategy(strategy)
        
        flash(f"Successfully applied recommended parameters to {recommendation['name']} strategy.", 'success')
        return redirect(url_for('strategy_settings'))
        
    except Exception as e:
        logger.error(f"Error applying recommendation: {e}")
        flash(f"Error applying recommendation: {str(e)}", 'danger')
        return redirect(url_for('optimization_history'))

@app.route('/ensemble_config')
def ensemble_config():
    """Page for configuring ensemble strategies."""
    # Create default ensembles if none exist yet
    create_default_ensembles()
    
    # Get all available ensembles
    available_ensembles = ensemble_manager.get_all_ensembles()
    active_ensemble_name = ensemble_manager.active_ensemble
    
    # Check if we have performance data for ensembles
    ensemble_performance = None
    ensemble_decisions = []
    
    # Get the active ensemble
    active_ensemble = ensemble_manager.get_ensemble(active_ensemble_name)

@app.route('/strategy_weight_editor')
def strategy_weight_editor():
    """Live Strategy Weight Editor interface."""
    # Create default ensembles if none exist yet
    create_default_ensembles()
    
    # Get all ensembles and the active ensemble name
    available_ensembles = ensemble_manager.get_all_ensembles()
    active_ensemble_name = ensemble_manager.active_ensemble
    active_ensemble = ensemble_manager.get_ensemble(active_ensemble_name)
    
    return render_template(
        'strategy_weight_editor.html',
        bot_status=bot_status,
        paper_trading=Config.PAPER_TRADING,
        ensembles=available_ensembles,
        active_ensemble_name=active_ensemble_name,
        active_ensemble=active_ensemble,
        available_strategies=get_available_strategies()
    )
    
    # If bot is running, try to get performance data
    if bot_instance and bot_status == "running" and active_ensemble:
        try:
            # Get performance data for the ensemble
            if hasattr(active_ensemble, 'get_performance_data'):
                ensemble_performance = active_ensemble.get_performance_data()
            
            # Get recent decisions
            if hasattr(active_ensemble, 'get_recent_decisions'):
                ensemble_decisions = active_ensemble.get_recent_decisions(10)  # Get last 10 decisions
        except Exception as e:
            logger.error(f"Error getting ensemble performance data: {e}")
    
    return render_template(
        'ensemble_config.html',
        bot_status=bot_status,
        last_check_time=last_check_time.strftime('%Y-%m-%d %H:%M:%S') if last_check_time else None,
        ensembles=available_ensembles,
        active_ensemble=active_ensemble_name,
        ensemble_performance=ensemble_performance,
        ensemble_decisions=ensemble_decisions,
        available_strategies=get_available_strategies()
    )

@app.route('/api/get_ensemble_weights', methods=['GET'])
def get_ensemble_weights():
    """Get the current weights of strategies in an ensemble."""
    try:
        ensemble_name = request.args.get('ensemble_name')
        
        # If no ensemble name provided, use the active ensemble
        if not ensemble_name:
            ensemble_name = ensemble_manager.active_ensemble
            
        if not ensemble_name:
            return jsonify({'success': False, 'error': 'No active ensemble found'}), 404
        
        # Get the ensemble strategy from the manager
        ensemble = ensemble_manager.get_ensemble(ensemble_name)
        if not ensemble:
            return jsonify({'success': False, 'error': f'Ensemble {ensemble_name} not found'}), 404
        
        # Return the weights and strategies
        return jsonify({
            'success': True, 
            'ensemble_name': ensemble_name,
            'weights': ensemble.weights,
            'strategies': list(ensemble.strategies.keys())
        })
    except Exception as e:
        logger.error(f"Error retrieving ensemble weights: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/update_ensemble_weights', methods=['POST'])
def update_ensemble_weights():
    """Update the weights of strategies in an ensemble."""
    try:
        data = request.json
        ensemble_name = data.get('ensemble_name')
        new_weights = data.get('weights', {})
        
        if not ensemble_name or not new_weights:
            return jsonify({'success': False, 'error': 'Missing ensemble name or weights'}), 400
        
        # Get the ensemble strategy from the manager
        ensemble = ensemble_manager.get_ensemble(ensemble_name)
        if not ensemble:
            return jsonify({'success': False, 'error': f'Ensemble {ensemble_name} not found'}), 404
        
        # Validate the weights
        for strategy_name, weight in new_weights.items():
            if strategy_name not in ensemble.strategies:
                return jsonify({'success': False, 'error': f'Strategy {strategy_name} not in ensemble {ensemble_name}'}), 400
            try:
                weight_value = float(weight)
                if weight_value < 0:
                    return jsonify({'success': False, 'error': f'Weight for {strategy_name} must be non-negative'}), 400
            except ValueError:
                return jsonify({'success': False, 'error': f'Invalid weight value for {strategy_name}'}), 400
        
        # Update the weights
        ensemble.weights = new_weights
        
        # Normalize the weights to sum to 1.0
        weight_sum = sum(ensemble.weights.values())
        if weight_sum > 0:
            for strategy_name in ensemble.weights:
                ensemble.weights[strategy_name] /= weight_sum
        
        logger.info(f"Updated weights for ensemble {ensemble_name}: {ensemble.weights}")
        
        # Return the normalized weights
        return jsonify({
            'success': True, 
            'ensemble_name': ensemble_name,
            'weights': ensemble.weights
        })
    except Exception as e:
        logger.error(f"Error updating ensemble weights: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/estimate_weight_performance', methods=['POST'])
def estimate_weight_performance():
    """Estimate how weight changes would affect historical performance."""
    try:
        data = request.json
        ensemble_name = data.get('ensemble_name')
        test_weights = data.get('weights', {})
        timeframe = data.get('timeframe', '1h')
        days = int(data.get('days', 30))
        
        if not ensemble_name or not test_weights:
            return jsonify({'success': False, 'error': 'Missing ensemble name or weights'}), 400
        
        # Get the ensemble configuration from the ensemble_manager
        ensembles = ensemble_manager.get_all_ensembles()
        if ensemble_name not in ensembles:
            return jsonify({'success': False, 'error': f'Ensemble {ensemble_name} not found'}), 404
        
        # Create a temporary ensemble with the test weights for backtesting
        import copy
        ensemble_config = ensembles[ensemble_name]
        ensemble_config_copy = copy.deepcopy(ensemble_config)
        # Apply the test weights to the strategies in the config (don't use direct assignment)
        
        # Run a quick backtest with the modified weights
        try:
            from ensemble_backtest import EnsembleBacktester
            symbol = "BTC/USDT"  # Default symbol for quick testing
            
            # Get historical data for the backtest
            import datetime
            from utils import generate_historical_data
            
            end_date = datetime.datetime.now()
            start_date = end_date - datetime.timedelta(days=days)
            
            # Generate historical data
            ohlcv_data = generate_historical_data(
                symbol, 
                timeframe, 
                start_date=start_date,
                end_date=end_date
            )
            
            # Create an ensemble strategy with modified weights
            from ensemble_engine import EnsembleStrategy, VotingMethod
            
            # Extract strategy names and weights from test_weights
            strategy_names = list(test_weights.keys())
            
            # Get voting method from original ensemble
            voting_method_str = 'weighted_vote'  # Default
            if ensemble_config is not None and 'voting_method' in ensemble_config:
                voting_method_str = ensemble_config['voting_method']
            voting_method = VotingMethod.WEIGHTED_VOTE  # Default
            
            # Map string to enum
            if voting_method_str == 'majority_vote':
                voting_method = VotingMethod.MAJORITY_VOTE
            elif voting_method_str == 'performance_weighted':
                voting_method = VotingMethod.PERFORMANCE_WEIGHTED
            
            # Create a temporary ensemble instance
            temp_ensemble = EnsembleStrategy(
                strategy_names=strategy_names,
                weights=test_weights,
                voting_method=voting_method,
                name="temp_test_ensemble"
            )
            
            # Set other parameters from original ensemble if available
            if ensemble_config is not None:
                if 'min_agreement_pct' in ensemble_config:
                    temp_ensemble.min_agreement_pct = float(ensemble_config['min_agreement_pct'])
                    
                if 'performance_lookback' in ensemble_config:
                    temp_ensemble.performance_lookback = int(ensemble_config['performance_lookback'])
            
            # Initialize backtester with the temporary ensemble instance
            backtester = EnsembleBacktester(
                ensemble_instance=temp_ensemble,
                initial_balance=1000.0
            )
            
            # Run the backtest with our historical data
            results = backtester.run(ohlcv_data=ohlcv_data)
            
            # Extract key metrics for comparison
            metrics = {
                'total_return_pct': results.get('total_return_pct', 0),
                'win_rate': results.get('win_rate', 0),
                'profit_factor': results.get('profit_factor', 0),
                'max_drawdown_pct': results.get('max_drawdown_pct', 0),
                'sharpe_ratio': results.get('sharpe_ratio', 0),
                'total_trades': results.get('total_trades', 0)
            }
            
            return jsonify({
                'success': True,
                'ensemble_name': ensemble_name,
                'metrics': metrics
            })
        except Exception as e:
            logger.error(f"Error estimating performance with new weights: {e}")
            return jsonify({
                'success': True,
                'ensemble_name': ensemble_name,
                'error': f"Could not estimate performance: {str(e)}",
                'metrics': None
            })
            
    except Exception as e:
        logger.error(f"Error in estimating weight performance: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/auto_rotation/status', methods=['GET'])
def auto_rotation_status():
    """Get the current status of the Auto-Rotation Engine."""
    try:
        policies = []
        for policy in auto_rotation_engine.get_policies():
            policies.append({
                'name': policy.name,
                'type': policy.rotation_type.value,
                'is_active': policy.is_active,
                'last_check': policy.last_check_time.isoformat() if hasattr(policy, 'last_check_time') else None,
                'last_rotation': policy.last_rotation_time.isoformat() if hasattr(policy, 'last_rotation_time') and policy.last_rotation_time else None
            })
            
        # Get rotation history
        history = auto_rotation_engine.get_rotation_history(limit=10)
        
        return jsonify({
            'success': True,
            'is_active': auto_rotation_engine.is_active,
            'policies': policies,
            'history': history
        })
        
    except Exception as e:
        logger.error(f"Error getting auto-rotation status: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/auto_rotation/toggle', methods=['POST'])
def toggle_auto_rotation():
    """Toggle the Auto-Rotation Engine on or off."""
    try:
        data = request.json
        active = data.get('active')
        
        if active is None:
            return jsonify({'success': False, 'error': 'Missing active parameter'}), 400
        
        if active:
            auto_rotation_engine.activate()
        else:
            auto_rotation_engine.deactivate()
            
        return jsonify({
            'success': True,
            'is_active': auto_rotation_engine.is_active,
            'message': f'Auto-Rotation Engine is now {"active" if auto_rotation_engine.is_active else "inactive"}'
        })
        
    except Exception as e:
        logger.error(f"Error toggling auto-rotation: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/auto_rotation/toggle_policy', methods=['POST'])
def toggle_rotation_policy():
    """Toggle a specific rotation policy on or off."""
    try:
        data = request.json
        policy_name = data.get('policy_name')
        active = data.get('active')
        
        if policy_name is None or active is None:
            return jsonify({'success': False, 'error': 'Missing policy_name or active parameter'}), 400
        
        # Find the policy
        policy_found = False
        for policy in auto_rotation_engine.get_policies():
            if policy.name == policy_name:
                policy.is_active = active
                policy_found = True
                break
                
        if not policy_found:
            return jsonify({'success': False, 'error': f'Policy {policy_name} not found'}), 404
            
        # Save the updated configuration
        auto_rotation_engine._save_config()
            
        return jsonify({
            'success': True,
            'policy_name': policy_name,
            'is_active': active,
            'message': f'Policy {policy_name} is now {"active" if active else "inactive"}'
        })
        
    except Exception as e:
        logger.error(f"Error toggling rotation policy: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/auto_rotation/update_policy_params', methods=['POST'])
def update_policy_parameters():
    """Update parameters for a specific rotation policy."""
    try:
        data = request.json
        policy_name = data.get('policy_name')
        parameters = data.get('parameters', {})
        
        if not policy_name:
            return jsonify({'success': False, 'error': 'Missing policy_name parameter'}), 400
        
        if not parameters:
            return jsonify({'success': False, 'error': 'No parameters provided for update'}), 400
        
        # Find the policy
        policy_found = False
        updated_params = []
        
        for policy in auto_rotation_engine.get_policies():
            if policy.name == policy_name:
                policy_found = True
                
                # Update parameters based on policy type
                for param_name, param_value in parameters.items():
                    if hasattr(policy, param_name):
                        # Convert value to appropriate type
                        if isinstance(getattr(policy, param_name), int):
                            param_value = int(param_value)
                        elif isinstance(getattr(policy, param_name), float):
                            param_value = float(param_value)
                            
                        # Set the new value
                        setattr(policy, param_name, param_value)
                        updated_params.append(param_name)
                
                break
                
        if not policy_found:
            return jsonify({'success': False, 'error': f'Policy {policy_name} not found'}), 404
            
        # Save the updated configuration
        auto_rotation_engine._save_config()
            
        return jsonify({
            'success': True,
            'policy_name': policy_name,
            'updated_params': updated_params,
            'message': f'Policy {policy_name} parameters updated successfully'
        })
        
    except Exception as e:
        logger.error(f"Error updating policy parameters: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/auto_rotation/run_rotation', methods=['POST'])
def run_rotation():
    """Manually trigger a weight rotation."""
    try:
        data = request.json
        ensemble_name = data.get('ensemble_name')
        
        # Check if engine is active
        if not auto_rotation_engine.is_active:
            auto_rotation_engine.activate()
            
        # Run rotation
        new_weights = auto_rotation_engine.check_and_rotate_weights(ensemble_name)
        
        if new_weights:
            return jsonify({
                'success': True,
                'rotated': True,
                'message': 'Rotation completed successfully',
                'new_weights': new_weights
            })
        else:
            return jsonify({
                'success': True,
                'rotated': False,
                'message': 'No rotation was needed based on current policies'
            })
            
    except Exception as e:
        logger.error(f"Error running manual rotation: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/auto_rotation/lock_strategy', methods=['POST'])
def lock_strategy():
    """Lock a strategy at a specific weight."""
    try:
        data = request.json
        strategy_name = data.get('strategy_name')
        weight = data.get('weight')
        ensemble_name = data.get('ensemble_name')
        duration_hours = data.get('duration_hours', 24)
        
        if strategy_name is None or weight is None:
            return jsonify({'success': False, 'error': 'Missing strategy_name or weight parameter'}), 400
            
        try:
            weight = float(weight)
            if weight < 0 or weight > 1:
                return jsonify({'success': False, 'error': 'Weight must be between 0 and 1'}), 400
        except ValueError:
            return jsonify({'success': False, 'error': 'Invalid weight value'}), 400
            
        # Find or create a StrategyLockPolicy
        lock_policy = None
        for policy in auto_rotation_engine.get_policies():
            if isinstance(policy, StrategyLockPolicy):
                lock_policy = policy
                break
                
        if lock_policy is None:
            lock_policy = StrategyLockPolicy(duration_hours=duration_hours)
            auto_rotation_engine.add_policy(lock_policy)
            
        # Lock the strategy
        lock_policy.lock_strategy(strategy_name, weight)
        
        # Apply the lock
        success = auto_rotation_engine.lock_strategy(strategy_name, weight, ensemble_name)
        
        if success:
            return jsonify({
                'success': True,
                'message': f'Strategy {strategy_name} locked at weight {weight}',
                'duration_hours': duration_hours
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Failed to lock strategy'
            }), 500
            
    except Exception as e:
        logger.error(f"Error locking strategy: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/auto_rotation/release_lock', methods=['POST'])
def release_strategy_lock():
    """Release the lock on a strategy."""
    try:
        data = request.json
        strategy_name = data.get('strategy_name')
        
        # Find StrategyLockPolicy
        lock_policy = None
        for policy in auto_rotation_engine.get_policies():
            if isinstance(policy, StrategyLockPolicy):
                lock_policy = policy
                break
                
        if not lock_policy:
            return jsonify({'success': False, 'error': 'No strategy lock policy found'}), 404
            
        # Release the lock
        lock_policy.release_lock(strategy_name)
        
        # Check if we need to reload weights
        if auto_rotation_engine.is_active:
            auto_rotation_engine.check_and_rotate_weights()
            
        return jsonify({
            'success': True,
            'message': f'Lock released for strategy {strategy_name if strategy_name else "all strategies"}'
        })
        
    except Exception as e:
        logger.error(f"Error releasing strategy lock: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/auto_rotation/policies', methods=['GET'])
def get_rotation_policies():
    """Get all rotation policies and their status."""
    try:
        policies = []
        for policy in auto_rotation_engine.get_policies():
            policy_data = {
                'name': policy.name,
                'type': policy.rotation_type.value,
                'active': policy.is_active
            }
            
            # Add policy-specific attributes
            if policy.rotation_type.value == 'performance':
                policy_data.update({
                    'metric': getattr(policy, 'metric', 'win_rate'),
                    'lookback_days': getattr(policy, 'lookback_days', 7),
                    'threshold': getattr(policy, 'threshold', 0.0)
                })
            elif policy.rotation_type.value == 'time':
                policy_data.update({
                    'interval_hours': getattr(policy, 'interval_hours', 24),
                    'rotation_fraction': getattr(policy, 'rotation_fraction', 0.2)
                })
            elif policy.rotation_type.value == 'degradation':
                policy_data.update({
                    'metric': getattr(policy, 'metric', 'win_rate'),
                    'lookback_days': getattr(policy, 'lookback_days', 14),
                    'comparison_days': getattr(policy, 'comparison_days', 7),
                    'threshold': getattr(policy, 'threshold', 10.0)
                })
                
            # Add last check/rotation times if available
            if hasattr(policy, 'last_check_time') and policy.last_check_time:
                policy_data['last_check'] = policy.last_check_time.isoformat()
            if hasattr(policy, 'last_rotation_time') and policy.last_rotation_time:
                policy_data['last_rotation'] = policy.last_rotation_time.isoformat()
                
            policies.append(policy_data)
            
        # Get any locked strategies
        locked_strategies = {}
        for policy in auto_rotation_engine.get_policies():
            if isinstance(policy, StrategyLockPolicy) and policy.locked_weights:
                for strategy, details in policy.locked_weights.items():
                    weight = details.get('weight', 0.0)
                    expiration = details.get('expiration')
                    locked_strategies[strategy] = {
                        'weight': weight,
                        'expiration': expiration.isoformat() if expiration else None
                    }
                
        return jsonify({
            'success': True,
            'policies': policies,
            'locked_strategies': locked_strategies
        })
        
    except Exception as e:
        logger.error(f"Error getting rotation policies: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/auto_rotation/history', methods=['GET'])
def get_rotation_history():
    """Get the history of weight rotations."""
    try:
        limit = request.args.get('limit', 10, type=int)
        history = auto_rotation_engine.get_rotation_history(limit)
        
        # Format history for JSON serialization
        formatted_history = []
        for entry in history:
            formatted_entry = {
                'timestamp': entry.get('timestamp').isoformat(),
                'trigger': entry.get('trigger').value,
                'policy_name': entry.get('policy_name'),
                'old_weights': entry.get('old_weights'),
                'new_weights': entry.get('new_weights')
            }
            formatted_history.append(formatted_entry)
            
        return jsonify({
            'success': True,
            'history': formatted_history
        })
        
    except Exception as e:
        logger.error(f"Error getting rotation history: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/auto_rotation/rotate_now', methods=['POST'])
def manual_rotation():
    """Manually trigger a weight rotation right now."""
    try:
        data = request.json
        ensemble_name = data.get('ensemble_name')
        
        # Get current weights before rotation
        ensemble = ensemble_manager.get_active_ensemble() if ensemble_name is None else ensemble_manager.get_ensemble(ensemble_name)
        old_weights = None
        if ensemble:
            old_weights = dict(ensemble.weights)
            
        # Run rotation with manual trigger
        new_weights = auto_rotation_engine.check_and_rotate_weights(ensemble_name)
        
        if new_weights:
            return jsonify({
                'success': True,
                'rotated': True,
                'message': 'Manual rotation completed successfully',
                'old_weights': old_weights,
                'new_weights': new_weights
            })
        else:
            return jsonify({
                'success': True,
                'rotated': False,
                'message': 'No rotation was performed'
            })
            
    except Exception as e:
        logger.error(f"Error running manual rotation: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/auto_rotation/release_locks', methods=['POST'])
def release_all_strategy_locks():
    """Release all strategy locks."""
    try:
        # Find StrategyLockPolicy
        lock_policy = None
        for policy in auto_rotation_engine.get_policies():
            if isinstance(policy, StrategyLockPolicy):
                lock_policy = policy
                break
                
        if not lock_policy:
            return jsonify({'success': False, 'error': 'No strategy lock policy found'}), 404
            
        # Release all locks
        lock_policy.release_lock()
        
        # Check if we need to reload weights
        if auto_rotation_engine.is_active:
            auto_rotation_engine.check_and_rotate_weights()
            
        return jsonify({
            'success': True,
            'message': 'All strategy locks released'
        })
        
    except Exception as e:
        logger.error(f"Error releasing all strategy locks: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
        
@app.route('/api/auto_rotation/register_manual_override', methods=['POST'])
def register_manual_override():
    """
    Register a manual override of strategy weights.
    
    This notifies the adaptive policies to temporarily pause
    auto-rotation after manual weight edits.
    """
    try:
        data = request.json
        ensemble_name = data.get('ensemble_name')
        
        # Register the override
        result = auto_rotation_engine.register_manual_override(ensemble_name)
        
        if result:
            # Get all adaptive policies
            adaptive_policies = auto_rotation_engine.get_adaptive_policies()
            pause_hours = 24  # Default
            
            # Get timeout from the first adaptive policy
            if adaptive_policies:
                pause_hours = adaptive_policies[0].manual_override_timeout / 3600
            
            return jsonify({
                'success': True,
                'message': f'Manual override registered. Auto-rotation paused for {pause_hours:.1f} hours',
                'paused_for_hours': pause_hours
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Failed to register manual override'
            }), 400
            
    except Exception as e:
        logger.error(f"Error registering manual override: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
        
@app.route('/api/auto_rotation/check_manual_override_status', methods=['GET'])
def check_manual_override_status():
    """
    Check if manual override is currently active and return remaining time.
    
    This is used to display the override status in the UI.
    """
    try:
        # Get manual override status
        is_active = False
        hours_remaining = 0
        
        # Get all adaptive policies
        adaptive_policies = auto_rotation_engine.get_adaptive_policies()
        
        # Check if any policy has active override
        if adaptive_policies:
            for policy in adaptive_policies:
                if hasattr(policy, 'is_manual_override_active') and policy.is_manual_override_active():
                    is_active = True
                    # Calculate remaining time
                    if hasattr(policy, 'get_override_remaining_seconds'):
                        remaining_seconds = policy.get_override_remaining_seconds()
                        hours_remaining = round(remaining_seconds / 3600, 1)
                    elif hasattr(policy, 'manual_override_time') and policy.manual_override_time:
                        # Calculate remaining time based on timestamp and timeout
                        elapsed = (datetime.now() - policy.manual_override_time).total_seconds()
                        remaining = max(0, policy.manual_override_timeout - elapsed)
                        hours_remaining = round(remaining / 3600, 1)
                    break
        
        return jsonify({
            'success': True,
            'is_active': is_active,
            'hours_remaining': hours_remaining
        })
            
    except Exception as e:
        logger.error(f"Error checking manual override status: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
        
@app.route('/policy_benchmark', methods=['GET'])
def policy_benchmark_page():
    """Show the policy benchmark page with simulation tools."""
    return render_template('policy_benchmark.html')
    
@app.route('/run_policy_benchmark', methods=['POST'])
def run_policy_benchmark():
    """Run a benchmark simulation of rotation policies."""
    try:
        # Get form parameters
        test_period = int(request.form.get('test_period', 90))
        initial_capital = float(request.form.get('initial_capital', 10000))
        check_interval = int(request.form.get('check_interval', 24))
        data_source = request.form.get('data_source', 'simulated')
        
        # Get selected policies to compare (or use all if none selected)
        selected_policies = request.form.getlist('policies')
        
        # Import benchmark tool
        from policy_benchmark import PolicyBenchmark
        
        # Create benchmark
        benchmark = PolicyBenchmark(
            test_period_days=test_period,
            initial_capital=initial_capital,
            backtest_interval_hours=check_interval
        )
        
        # Run benchmark
        results = benchmark.run_benchmark()
        
        # Save results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        results_filename = f"benchmark_{timestamp}.json"
        benchmark.save_results(results_filename)
        
        # Generate visualization
        plot_path = os.path.join(benchmark.benchmark_dir, f"benchmark_{timestamp}.png")
        benchmark.plot_results(save_path=plot_path)
        
        # Return template with results
        flash(f"Benchmark completed successfully! Results saved to data/policy_benchmarks/{results_filename}", "success")
        return render_template('policy_benchmark.html', results=results)
        
    except Exception as e:
        logger.error(f"Error running policy benchmark: {e}")
        flash(f"Error running benchmark: {e}", "error")
        return render_template('policy_benchmark.html')

@app.route('/auto_policy_selector', methods=['GET'])
def auto_policy_selector_page():
    """Show the auto policy selector dashboard."""
    try:
        from auto_policy_selector import auto_policy_selector
        
        # Get selector status
        status = auto_policy_selector.get_status()
        
        # Get selection history
        history = auto_policy_selector.get_history(limit=20)
        
        return render_template('auto_policy_selector.html', status=status, history=history)
    except Exception as e:
        logger.error(f"Error loading auto policy selector page: {e}")
        flash(f"Error loading Auto Policy Selector: {e}", "error")
        return render_template('auto_policy_selector.html')

# API endpoints for Auto Policy Selector
@app.route('/api/auto_policy_selector/status', methods=['GET'])
def get_auto_policy_selector_status():
    """Get the current status of the auto policy selector."""
    try:
        from auto_policy_selector import auto_policy_selector
        
        status = auto_policy_selector.get_status()
        return jsonify({'success': True, 'status': status})
    except Exception as e:
        logger.error(f"Error getting auto policy selector status: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/auto_policy_selector/toggle', methods=['POST'])
def toggle_auto_policy_selector():
    """Enable or disable the auto policy selector."""
    try:
        from auto_policy_selector import auto_policy_selector
        
        data = request.json
        enable = data.get('enable', False)
        
        if enable:
            auto_policy_selector.enable()
            message = "Auto Policy Selector enabled and scheduled"
        else:
            auto_policy_selector.disable()
            message = "Auto Policy Selector disabled"
        
        status = auto_policy_selector.get_status()
        
        return jsonify({
            'success': True, 
            'message': message,
            'status': status
        })
    except Exception as e:
        logger.error(f"Error toggling auto policy selector: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/auto_policy_selector/update_settings', methods=['POST'])
def update_auto_policy_selector_settings():
    """Update auto policy selector settings."""
    try:
        from auto_policy_selector import auto_policy_selector
        
        data = request.json
        
        # Update settings
        if 'benchmark_period_days' in data:
            auto_policy_selector.benchmark_period_days = int(data['benchmark_period_days'])
            
        if 'selection_metric' in data:
            auto_policy_selector.selection_metric = data['selection_metric']
            
        if 'schedule_time' in data:
            auto_policy_selector.schedule_time = data['schedule_time']
            
        if 'check_interval_minutes' in data:
            auto_policy_selector.check_interval_minutes = int(data['check_interval_minutes'])
        
        # Restart scheduler if running
        if auto_policy_selector.scheduler_running:
            auto_policy_selector.stop_scheduler()
            auto_policy_selector.start_scheduler()
        
        status = auto_policy_selector.get_status()
        
        return jsonify({
            'success': True, 
            'message': "Auto Policy Selector settings updated",
            'status': status
        })
    except Exception as e:
        logger.error(f"Error updating auto policy selector settings: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/auto_policy_selector/run_now', methods=['POST'])
def run_auto_policy_selector_now():
    """Run the auto policy selection cycle immediately."""
    try:
        from auto_policy_selector import auto_policy_selector
        
        # Force selection cycle even if disabled
        was_enabled = auto_policy_selector.is_enabled
        auto_policy_selector.is_enabled = True
        
        # Run selection
        result = auto_policy_selector.run_selection()
        
        # Restore enabled state
        auto_policy_selector.is_enabled = was_enabled
        
        if result['success']:
            flash(f"Auto Policy Selector selected '{result['policy_name']}' successfully!", "success")
            message = f"Selected policy: {result['policy_name']}"
        else:
            flash(f"Auto Policy Selector failed: {result.get('reason', 'unknown error')}", "error")
            message = f"Selection failed: {result.get('reason', 'unknown error')}"
        
        return jsonify({
            'success': result['success'], 
            'message': message,
            'result': result
        })
    except Exception as e:
        logger.error(f"Error running auto policy selector: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/auto_policy_selector/history', methods=['GET'])
def get_auto_policy_selector_history():
    """Get the history of auto policy selections."""
    try:
        from auto_policy_selector import auto_policy_selector
        
        limit = int(request.args.get('limit', 50))
        history = auto_policy_selector.get_history(limit=limit)
        
        return jsonify({
            'success': True, 
            'history': history
        })
    except Exception as e:
        logger.error(f"Error getting auto policy selector history: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/capital_scaling', methods=['GET'])
def capital_scaling_page():
    """Smart Capital Scaling dashboard."""
    try:
        from capital_scaler import capital_scaler
        
        # Get capital scaler status
        status = capital_scaler.get_status()
        # Get active boosts
        active_boosts = capital_scaler.get_active_boosts()
        # Get boost history
        boost_history = capital_scaler.get_boost_history(limit=20)

        # Get current strategy weights (for manual boost dropdown)
        strategy_weights = {}
        ensemble = ensemble_manager.get_active_ensemble()
        if ensemble:
            strategy_weights = ensemble.get_strategy_weights()

        return render_template(
            'capital_scaling.html',
            status=status,
            active_boosts=active_boosts,
            boost_history=boost_history,
            strategy_weights=strategy_weights
        )
    except Exception as e:
        logger.error(f"Error rendering capital scaling page: {e}")
        flash(f"Error: {str(e)}", "danger")
        return redirect(url_for('index'))

# API endpoints for Capital Scaling
@app.route('/api/capital_scaling/status', methods=['GET'])
def api_capital_scaling_status():
    """Get capital scaling status."""
    try:
        from capital_scaler import capital_scaler
        
        status = capital_scaler.get_status()
        return jsonify({'success': True, 'status': status})
    except Exception as e:
        logger.error(f"Error getting capital scaling status: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/capital_scaling/enable', methods=['POST'])
def api_capital_scaling_enable():
    """Enable capital scaling."""
    try:
        from capital_scaler import capital_scaler
        
        capital_scaler.enable()
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Error enabling capital scaling: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/capital_scaling/disable', methods=['POST'])
def api_capital_scaling_disable():
    """Disable capital scaling."""
    try:
        from capital_scaler import capital_scaler
        
        capital_scaler.disable()
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Error disabling capital scaling: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/capital_scaling/update_parameters', methods=['POST'])
def api_capital_scaling_update_parameters():
    """Update capital scaling parameters."""
    try:
        from capital_scaler import capital_scaler
        
        params = request.json
        success = capital_scaler.update_parameters(params)
        return jsonify({'success': success})
    except Exception as e:
        logger.error(f"Error updating capital scaling parameters: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/capital_scaling/update_thresholds', methods=['POST'])
def api_capital_scaling_update_thresholds():
    """Update capital scaling thresholds."""
    try:
        from capital_scaler import capital_scaler
        
        thresholds = request.json
        success = capital_scaler.update_thresholds(thresholds)
        return jsonify({'success': success})
    except Exception as e:
        logger.error(f"Error updating capital scaling thresholds: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/capital_scaling/manual_boost', methods=['POST'])
def api_capital_scaling_manual_boost():
    """Apply a manual capital boost."""
    try:
        from capital_scaler import capital_scaler
        
        boost_data = request.json
        result = capital_scaler.manually_boost_strategy(
            strategy=boost_data['strategy'],
            boost_factor=boost_data['boost_factor'],
            duration_hours=boost_data['duration_hours']
        )
        return jsonify(result)
    except Exception as e:
        logger.error(f"Error applying manual capital boost: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/capital_scaling/remove_boost/<strategy>', methods=['POST'])
def api_capital_scaling_remove_boost(strategy):
    """Remove a capital boost from a strategy."""
    try:
        from capital_scaler import capital_scaler
        
        success = capital_scaler._remove_boost(strategy)
        return jsonify({'success': success})
    except Exception as e:
        logger.error(f"Error removing capital boost: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/capital_scaling/active_boosts', methods=['GET'])
def api_capital_scaling_active_boosts():
    """Get active capital boosts."""
    try:
        from capital_scaler import capital_scaler
        
        active_boosts = capital_scaler.get_active_boosts()
        return jsonify({'success': True, 'active_boosts': active_boosts})
    except Exception as e:
        logger.error(f"Error getting active capital boosts: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/capital_scaling/boost_history', methods=['GET'])
def api_capital_scaling_boost_history():
    """Get capital boost history."""
    try:
        from capital_scaler import capital_scaler
        
        limit = request.args.get('limit', 20, type=int)
        history = capital_scaler.get_boost_history(limit=limit)
        return jsonify({'success': True, 'history': history})
    except Exception as e:
        logger.error(f"Error getting capital boost history: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/capital_scaling/check_now', methods=['POST'])
def api_capital_scaling_check_now():
    """Run capital scaling check manually."""
    try:
        from capital_scaler import capital_scaler
        
        results = capital_scaler.check_and_apply_scaling()
        return jsonify(results)
    except Exception as e:
        logger.error(f"Error running capital scaling check: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/capital_scaling/reset_all', methods=['POST'])
def api_capital_scaling_reset_all():
    """Reset all active capital boosts."""
    try:
        from capital_scaler import capital_scaler
        
        success = capital_scaler.reset_all_boosts()
        return jsonify({'success': success})
    except Exception as e:
        logger.error(f"Error resetting capital boosts: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
        
@app.route('/api/auto_rotation/adaptive_policies', methods=['GET'])
def get_adaptive_policies():
    """Get details about the adaptive performance policies."""
    try:
        adaptive_policies = auto_rotation_engine.get_adaptive_policies()
        
        result = []
        for policy in adaptive_policies:
            # Get basic policy info
            policy_data = {
                'name': policy.name,
                'is_active': policy.is_active,
                'metrics': policy.metrics,
                'base_threshold': policy.base_threshold,
                'current_threshold': policy.current_threshold,
                'adaptive_threshold': policy.adaptive_threshold,
                'smoothing_factor': policy.smoothing_factor,
                'max_weight_change': policy.max_weight_change,
                'min_weight': policy.min_weight,
                'max_weight': policy.max_weight,
                'lookback_days': policy.lookback_days,
                'min_trades_required': policy.min_trades_required,
                'check_interval_hours': policy.check_interval_seconds / 3600
            }
            
            # Add override status
            policy_data['manual_override_active'] = policy._check_manual_override()
            
            # Calculate time remaining in override if active
            if policy.last_manual_override:
                time_since_override = (datetime.now() - policy.last_manual_override).total_seconds()
                remaining_time = max(0, policy.manual_override_timeout - time_since_override)
                policy_data['override_remaining_seconds'] = remaining_time
                policy_data['override_hours'] = policy.manual_override_timeout / 3600
            
            result.append(policy_data)
        
        return jsonify({
            'success': True,
            'policies': result
        })
            
    except Exception as e:
        logger.error(f"Error getting adaptive policies: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
        
@app.route('/api/auto_rotation/update_adaptive_policy', methods=['POST'])
def update_adaptive_policy():
    """Update settings for an adaptive performance policy."""
    try:
        data = request.json
        policy_name = data.get('policy_name')
        
        if not policy_name:
            return jsonify({'success': False, 'error': 'Policy name is required'}), 400
            
        # Find matching policy
        policy = None
        for p in auto_rotation_engine.get_adaptive_policies():
            if p.name == policy_name:
                policy = p
                break
                
        if not policy:
            return jsonify({'success': False, 'error': f'Adaptive policy not found: {policy_name}'}), 404
            
        # Update policy settings
        updated = False
        
        # Update metrics weights
        if 'metrics' in data:
            metrics = data['metrics']
            if isinstance(metrics, dict) and metrics:
                policy.metrics = metrics
                # Normalize to sum to 1.0
                total_weight = sum(policy.metrics.values())
                if total_weight > 0:
                    for metric in policy.metrics:
                        policy.metrics[metric] /= total_weight
                updated = True
                
        # Update threshold settings
        if 'base_threshold' in data:
            policy.base_threshold = float(data['base_threshold'])
            updated = True
            
        if 'adaptive_threshold' in data:
            policy.adaptive_threshold = bool(data['adaptive_threshold'])
            updated = True
            
        if 'market_volatility_factor' in data:
            policy.market_volatility_factor = float(data['market_volatility_factor'])
            updated = True
            
        # Update smoothing settings
        if 'smoothing_factor' in data:
            value = float(data['smoothing_factor'])
            policy.smoothing_factor = max(0.0, min(1.0, value))  # Clamp to 0-1
            updated = True
            
        if 'max_weight_change' in data:
            value = float(data['max_weight_change'])
            policy.max_weight_change = max(0.0, min(1.0, value))  # Clamp to 0-1
            updated = True
            
        # Update weight constraints
        if 'min_weight' in data:
            policy.min_weight = float(data['min_weight'])
            updated = True
            
        if 'max_weight' in data:
            policy.max_weight = float(data['max_weight'])
            updated = True
            
        # Update lookback and check settings
        if 'lookback_days' in data:
            policy.lookback_days = int(data['lookback_days'])
            updated = True
            
        if 'min_trades_required' in data:
            policy.min_trades_required = int(data['min_trades_required'])
            updated = True
            
        if 'check_interval_hours' in data:
            hours = float(data['check_interval_hours'])
            policy.check_interval_seconds = hours * 3600
            updated = True
            
        if 'manual_override_timeout_hours' in data:
            hours = float(data['manual_override_timeout_hours'])
            policy.manual_override_timeout = hours * 3600
            updated = True
            
        # Update active state
        if 'is_active' in data:
            if data['is_active']:
                auto_rotation_engine.enable_policy(policy_name)
            else:
                auto_rotation_engine.disable_policy(policy_name)
            updated = True
            
        if updated:
            return jsonify({
                'success': True,
                'message': f'Adaptive policy {policy_name} updated successfully'
            })
        else:
            return jsonify({
                'success': False,
                'error': 'No settings were updated'
            }), 400
            
    except Exception as e:
        logger.error(f"Error updating adaptive policy: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

# ===== STRATEGY PRESETS API ENDPOINTS =====

@app.route('/api/strategy_presets', methods=['GET'])
def get_strategy_presets():
    """Get all saved strategy presets."""
    try:
        # Filter by type if provided
        config_type = request.args.get('type')
        query = StrategyPreset.query
        
        if config_type:
            query = query.filter_by(config_type=config_type)
            
        # Include optional favorites filter
        favorites_only = request.args.get('favorites', 'false').lower() == 'true'
        if favorites_only:
            query = query.filter_by(is_favorite=True)
        
        presets = query.order_by(StrategyPreset.created_at.desc()).all()
        return jsonify({
            'success': True,
            'presets': [preset.to_dict() for preset in presets]
        })
    except Exception as e:
        logger.error(f"Error fetching strategy presets: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/strategy_presets/<int:preset_id>', methods=['GET'])
def get_strategy_preset(preset_id):
    """Get a specific strategy preset by ID."""
    try:
        preset = StrategyPreset.query.get(preset_id)
        if not preset:
            return jsonify({'success': False, 'error': 'Preset not found'}), 404
            
        return jsonify({
            'success': True,
            'preset': preset.to_dict()
        })
    except Exception as e:
        logger.error(f"Error fetching strategy preset {preset_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/strategy_presets', methods=['POST'])
def create_strategy_preset():
    """Create a new strategy preset."""
    try:
        data = request.json
        
        # Validate required fields
        if not data.get('name') or not data.get('config_type') or not data.get('config_data'):
            return jsonify({
                'success': False, 
                'error': 'Name, config_type, and config_data are required'
            }), 400
            
        # Check for duplicate name
        existing_preset = StrategyPreset.query.filter_by(name=data['name']).first()
        if existing_preset:
            return jsonify({
                'success': False, 
                'error': f"A preset with name '{data['name']}' already exists"
            }), 409
            
        # Create new preset
        preset = StrategyPreset.from_dict(data)
        db.session.add(preset)
        db.session.commit()
        
        flash(f"Strategy preset '{preset.name}' saved successfully!", 'success')
        return jsonify({
            'success': True,
            'preset': preset.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error creating strategy preset: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/strategy_presets/<int:preset_id>', methods=['PUT'])
def update_strategy_preset(preset_id):
    """Update an existing strategy preset."""
    try:
        preset = StrategyPreset.query.get(preset_id)
        if not preset:
            return jsonify({'success': False, 'error': 'Preset not found'}), 404
            
        data = request.json
        
        # Check for name conflict if name is being changed
        if data.get('name') and data['name'] != preset.name:
            existing_preset = StrategyPreset.query.filter_by(name=data['name']).first()
            if existing_preset and existing_preset.id != preset_id:
                return jsonify({
                    'success': False, 
                    'error': f"A preset with name '{data['name']}' already exists"
                }), 409
        
        # Update fields
        if data.get('name'):
            preset.name = data['name']
        if data.get('description') is not None:
            preset.description = data['description']
        if data.get('config_data'):
            preset.config_data = data['config_data']
        if data.get('tags') is not None:
            preset.tags = ','.join(data['tags']) if data['tags'] else None
        if data.get('is_favorite') is not None:
            preset.is_favorite = data['is_favorite']
        if data.get('performance_metrics') is not None:
            preset.performance_metrics = data['performance_metrics']
            
        preset.updated_at = datetime.utcnow()
        db.session.commit()
        
        flash(f"Strategy preset '{preset.name}' updated successfully!", 'success')
        return jsonify({
            'success': True,
            'preset': preset.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error updating strategy preset {preset_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/strategy_presets/<int:preset_id>', methods=['DELETE'])
def delete_strategy_preset(preset_id):
    """Delete a strategy preset."""
    try:
        preset = StrategyPreset.query.get(preset_id)
        if not preset:
            return jsonify({'success': False, 'error': 'Preset not found'}), 404
            
        preset_name = preset.name
        db.session.delete(preset)
        db.session.commit()
        
        flash(f"Strategy preset '{preset_name}' deleted successfully!", 'success')
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting strategy preset {preset_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/strategy_presets/<int:preset_id>/apply', methods=['POST'])
def apply_strategy_preset(preset_id):
    """Apply a strategy preset configuration."""
    try:
        preset = StrategyPreset.query.get(preset_id)
        if not preset:
            return jsonify({'success': False, 'error': 'Preset not found'}), 404
            
        config_data = preset.config_data
        config_type = preset.config_type
        
        # Apply different types of presets
        if config_type == 'ensemble':
            # Apply ensemble configuration
            ensemble_name = config_data.get('name')
            if not ensemble_name:
                return jsonify({'success': False, 'error': 'Ensemble name not found in preset data'}), 400
                
            weights = config_data.get('weights', {})
            if not weights:
                return jsonify({'success': False, 'error': 'No strategy weights found in preset data'}), 400
                
            # Update ensemble weights
            ensemble_manager.update_ensemble_weights(ensemble_name, weights)
            
            # Activate this ensemble if specified
            if config_data.get('activate', False):
                ensemble_manager.set_active_ensemble(ensemble_name)
                
            flash(f"Ensemble configuration '{preset.name}' applied successfully!", 'success')
            
        elif config_type == 'rotation':
            # Apply rotation policy configuration
            policies = config_data.get('policies', {})
            if not policies:
                return jsonify({'success': False, 'error': 'No rotation policies found in preset data'}), 400
                
            # Update each policy setting
            for policy_id, settings in policies.items():
                # Find matching policy
                policy = None
                for p in auto_rotation_engine.get_policies():
                    if p.id == policy_id:
                        policy = p
                        break
                        
                if policy:
                    # Enable/disable policy
                    if 'enabled' in settings:
                        if settings['enabled']:
                            auto_rotation_engine.enable_policy(policy.id)
                        else:
                            auto_rotation_engine.disable_policy(policy.id)
                    
                    # Update parameters
                    if 'parameters' in settings:
                        for param, value in settings['parameters'].items():
                            policy.set_parameter(param, value)
            
            # Set rotation engine state
            if 'enabled' in config_data:
                auto_rotation_engine.enabled = config_data['enabled']
                
            flash(f"Rotation configuration '{preset.name}' applied successfully!", 'success')
            
        elif config_type == 'strategy':
            # Apply strategy parameters
            strategy_id = config_data.get('strategy_id')
            parameters = config_data.get('parameters', {})
            
            if not strategy_id or not parameters:
                return jsonify({'success': False, 'error': 'Missing strategy_id or parameters in preset data'}), 400
                
            # Apply parameters to strategy
            from strategies import get_strategy_class
            strategy_class = get_strategy_class(strategy_id)
            
            if not strategy_class:
                return jsonify({'success': False, 'error': f'Strategy {strategy_id} not found'}), 404
                
            # Update strategy parameters in Config
            for param, value in parameters.items():
                setattr(Config, param.upper(), value)
                
            flash(f"Strategy parameters '{preset.name}' applied successfully!", 'success')
            
        else:
            return jsonify({'success': False, 'error': f'Unsupported configuration type: {config_type}'}), 400
            
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Error applying strategy preset {preset_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/strategy_presets/<int:preset_id>/toggle_favorite', methods=['POST'])
def toggle_favorite_preset(preset_id):
    """Toggle the favorite status of a strategy preset."""
    try:
        preset = StrategyPreset.query.get(preset_id)
        if not preset:
            return jsonify({'success': False, 'error': 'Preset not found'}), 404
            
        preset.is_favorite = not preset.is_favorite
        db.session.commit()
        
        return jsonify({
            'success': True,
            'is_favorite': preset.is_favorite
        })
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error toggling favorite status for preset {preset_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

# ===== PERFORMANCE ALERTS API ENDPOINTS =====

@app.route('/api/alerts/metrics')
def get_alert_metrics():
    """
    Get a list of available metrics for alert rules.
    
    Returns:
        JSON: Dictionary of metrics with descriptions
    """
    try:
        metrics = AlertService.get_available_metrics()
        return jsonify({
            'success': True,
            'metrics': metrics
        })
    except Exception as e:
        logger.error(f"Error getting alert metrics: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/alerts/conditions')
def get_alert_conditions():
    """
    Get a list of available conditions for alert rules.
    
    Returns:
        JSON: Dictionary of conditions with descriptions
    """
    try:
        conditions = AlertService.get_available_conditions()
        return jsonify({
            'success': True,
            'conditions': conditions
        })
    except Exception as e:
        logger.error(f"Error getting alert conditions: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/alerts/rules', methods=['GET'])
def get_alert_rules():
    """
    Get all alert rules for a specific preset or all presets.
    
    Query Parameters:
        preset_id (int, optional): ID of the strategy preset to filter by
        enabled (bool, optional): Filter by enabled/disabled status
        
    Returns:
        JSON: List of alert rules
    """
    try:
        preset_id = request.args.get('preset_id', type=int)
        enabled = request.args.get('enabled')
        
        # Build the query
        query = PerformanceAlertRule.query
        
        # Apply filters if provided
        if preset_id:
            query = query.filter_by(preset_id=preset_id)
            
        if enabled is not None:
            enabled_bool = enabled.lower() in ['true', '1', 'yes']
            query = query.filter_by(enabled=enabled_bool)
            
        # Execute the query
        rules = query.all()
        
        return jsonify({
            'success': True,
            'rules': [rule.to_dict() for rule in rules]
        })
        
    except Exception as e:
        logger.error(f"Error getting alert rules: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/alerts/rules/<int:rule_id>', methods=['GET'])
def get_alert_rule(rule_id):
    """
    Get a specific alert rule by ID.
    
    Args:
        rule_id (int): ID of the alert rule
        
    Returns:
        JSON: Alert rule details
    """
    try:
        rule = PerformanceAlertRule.query.get(rule_id)
        
        if not rule:
            return jsonify({'success': False, 'error': 'Alert rule not found'}), 404
            
        return jsonify({
            'success': True,
            'rule': rule.to_dict()
        })
        
    except Exception as e:
        logger.error(f"Error getting alert rule {rule_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/alerts/rules', methods=['POST'])
def create_alert_rule():
    """
    Create a new alert rule.
    
    Request Body:
        preset_id (int): ID of the strategy preset
        name (str): Name of the alert rule
        description (str, optional): Description of the alert rule
        metric (str): Metric to monitor
        condition (str): Condition to check
        threshold (float): Threshold value
        comparison_window (int, optional): Number of data points to consider
        timeframe (str, optional): Timeframe for comparison
        consecutive_triggers (int, optional): Number of consecutive times condition must be met
        cool_down_minutes (int, optional): Minutes before alert can trigger again
        severity (str, optional): Alert severity
        enabled (bool, optional): Whether the alert is enabled
        create_trigger_event (bool, optional): Create a trigger event when alert fires
        trigger_event_importance (int, optional): Importance level for trigger events
        
    Returns:
        JSON: Created alert rule
    """
    try:
        data = request.json
        
        # Validate required fields
        required_fields = ['preset_id', 'name', 'metric', 'condition', 'threshold']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'error': f'Missing required field: {field}'}), 400
                
        # Get the preset
        preset = StrategyPreset.query.get(data['preset_id'])
        if not preset:
            return jsonify({'success': False, 'error': 'Preset not found'}), 404
            
        # Create new alert rule
        alert_rule = PerformanceAlertRule(
            preset_id=data['preset_id'],
            name=data['name'],
            description=data.get('description'),
            metric=data['metric'],
            condition=data['condition'],
            threshold=float(data['threshold']),
            comparison_window=data.get('comparison_window'),
            timeframe=data.get('timeframe'),
            consecutive_triggers=data.get('consecutive_triggers', 1),
            cool_down_minutes=data.get('cool_down_minutes', 60),
            severity=data.get('severity', 'medium'),
            enabled=data.get('enabled', True),
            create_trigger_event=data.get('create_trigger_event', True),
            trigger_event_importance=data.get('trigger_event_importance', 3)
        )
        
        db.session.add(alert_rule)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Alert rule created successfully',
            'rule': alert_rule.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error creating alert rule: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/alerts/rules/<int:rule_id>', methods=['PUT'])
def update_alert_rule(rule_id):
    """
    Update an existing alert rule.
    
    Args:
        rule_id (int): ID of the alert rule to update
        
    Request Body:
        name (str, optional): Name of the alert rule
        description (str, optional): Description of the alert rule
        metric (str, optional): Metric to monitor
        condition (str, optional): Condition to check
        threshold (float, optional): Threshold value
        comparison_window (int, optional): Number of data points to consider
        timeframe (str, optional): Timeframe for comparison
        consecutive_triggers (int, optional): Number of consecutive times condition must be met
        cool_down_minutes (int, optional): Minutes before alert can trigger again
        severity (str, optional): Alert severity
        enabled (bool, optional): Whether the alert is enabled
        create_trigger_event (bool, optional): Create a trigger event when alert fires
        trigger_event_importance (int, optional): Importance level for trigger events
        
    Returns:
        JSON: Updated alert rule
    """
    try:
        data = request.json
        
        # Get the alert rule
        alert_rule = PerformanceAlertRule.query.get(rule_id)
        
        if not alert_rule:
            return jsonify({'success': False, 'error': 'Alert rule not found'}), 404
            
        # Update fields
        if 'name' in data:
            alert_rule.name = data['name']
            
        if 'description' in data:
            alert_rule.description = data['description']
            
        if 'metric' in data:
            alert_rule.metric = data['metric']
            
        if 'condition' in data:
            alert_rule.condition = data['condition']
            
        if 'threshold' in data:
            alert_rule.threshold = float(data['threshold'])
            
        if 'comparison_window' in data:
            alert_rule.comparison_window = data['comparison_window']
            
        if 'timeframe' in data:
            alert_rule.timeframe = data['timeframe']
            
        if 'consecutive_triggers' in data:
            alert_rule.consecutive_triggers = data['consecutive_triggers']
            
        if 'cool_down_minutes' in data:
            alert_rule.cool_down_minutes = data['cool_down_minutes']
            
        if 'severity' in data:
            alert_rule.severity = data['severity']
            
        if 'enabled' in data:
            alert_rule.enabled = data['enabled']
            
        if 'create_trigger_event' in data:
            alert_rule.create_trigger_event = data['create_trigger_event']
            
        if 'trigger_event_importance' in data:
            alert_rule.trigger_event_importance = data['trigger_event_importance']
            
        # Update timestamp
        alert_rule.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Alert rule updated successfully',
            'rule': alert_rule.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error updating alert rule {rule_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/alerts/rules/<int:rule_id>', methods=['DELETE'])
def delete_alert_rule(rule_id):
    """
    Delete an alert rule.
    
    Args:
        rule_id (int): ID of the alert rule to delete
        
    Returns:
        JSON: Success status
    """
    try:
        # Get the alert rule
        alert_rule = PerformanceAlertRule.query.get(rule_id)
        
        if not alert_rule:
            return jsonify({'success': False, 'error': 'Alert rule not found'}), 404
            
        # Delete the rule (cascade will delete associated logs)
        db.session.delete(alert_rule)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Alert rule deleted successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting alert rule {rule_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/alerts/rules/<int:rule_id>/toggle', methods=['POST'])
def toggle_alert_rule(rule_id):
    """
    Toggle an alert rule's enabled status.
    
    Args:
        rule_id (int): ID of the alert rule to toggle
        
    Request Body:
        enabled (bool, optional): Explicitly set the enabled status
        
    Returns:
        JSON: Updated alert rule
    """
    try:
        # Get the alert rule
        alert_rule = PerformanceAlertRule.query.get(rule_id)
        
        if not alert_rule:
            return jsonify({'success': False, 'error': 'Alert rule not found'}), 404
            
        # Check if an explicit enabled state was provided
        data = request.json
        if data and 'enabled' in data:
            alert_rule.enabled = data['enabled']
        else:
            # Otherwise toggle the current state
            alert_rule.enabled = not alert_rule.enabled
            
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'Alert rule {"enabled" if alert_rule.enabled else "disabled"} successfully',
            'rule': alert_rule.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error toggling alert rule {rule_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/alerts/logs', methods=['GET'])
def get_alert_logs():
    """
    Get alert logs filtered by various criteria.
    
    Query Parameters:
        preset_id (int, optional): ID of the strategy preset to filter by
        rule_id (int, optional): ID of the alert rule to filter by
        status (str, optional): Filter by status ('new', 'acknowledged', 'resolved')
        from_date (str, optional): Start date for filtering
        to_date (str, optional): End date for filtering
        
    Returns:
        JSON: List of alert logs
    """
    try:
        # Get query parameters
        preset_id = request.args.get('preset_id', type=int)
        rule_id = request.args.get('rule_id', type=int)
        status = request.args.get('status')
        from_date = request.args.get('from_date')
        to_date = request.args.get('to_date')
        
        # Start building the query
        query = PerformanceAlertLog.query
        
        # If preset_id is specified, join with rules table to filter by preset
        if preset_id:
            query = query.join(PerformanceAlertRule).filter(PerformanceAlertRule.preset_id == preset_id)
            
        # Apply other filters
        if rule_id:
            query = query.filter(PerformanceAlertLog.alert_rule_id == rule_id)
            
        if status:
            query = query.filter(PerformanceAlertLog.status == status)
            
        # Apply date filters
        if from_date:
            try:
                from_datetime = datetime.fromisoformat(from_date.replace('Z', '+00:00'))
                query = query.filter(PerformanceAlertLog.timestamp >= from_datetime)
            except ValueError:
                pass
                
        if to_date:
            try:
                to_datetime = datetime.fromisoformat(to_date.replace('Z', '+00:00'))
                query = query.filter(PerformanceAlertLog.timestamp <= to_datetime)
            except ValueError:
                pass
                
        # Order by timestamp descending (newest first)
        query = query.order_by(PerformanceAlertLog.timestamp.desc())
        
        # Execute the query
        logs = query.all()
        
        # For each log, include the rule name and metric for easier display
        log_data = []
        for log in logs:
            log_dict = log.to_dict()
            
            # Add the rule info
            try:
                rule = PerformanceAlertRule.query.get(log.alert_rule_id)
                if rule:
                    log_dict['rule_name'] = rule.name
                    log_dict['metric'] = rule.metric
                    log_dict['condition'] = rule.condition
                    log_dict['severity'] = rule.severity
                    
                    # Also add the preset name
                    preset = StrategyPreset.query.get(rule.preset_id)
                    if preset:
                        log_dict['preset_name'] = preset.name
            except:
                pass
                
            log_data.append(log_dict)
        
        return jsonify({
            'success': True,
            'logs': log_data
        })
        
    except Exception as e:
        logger.error(f"Error getting alert logs: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/alerts/logs/<int:log_id>/acknowledge', methods=['POST'])
def acknowledge_alert_log(log_id):
    """
    Acknowledge an alert log.
    
    Args:
        log_id (int): ID of the alert log to acknowledge
        
    Returns:
        JSON: Updated alert log
    """
    try:
        result = AlertService.acknowledge_alert(log_id)
        
        if 'success' in result and not result['success']:
            return jsonify(result), 404
            
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error acknowledging alert log {log_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/alerts/logs/<int:log_id>/resolve', methods=['POST'])
def resolve_alert_log(log_id):
    """
    Resolve an alert log.
    
    Args:
        log_id (int): ID of the alert log to resolve
        
    Returns:
        JSON: Updated alert log
    """
    try:
        result = AlertService.resolve_alert(log_id)
        
        if 'success' in result and not result['success']:
            return jsonify(result), 404
            
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error resolving alert log {log_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/alerts/evaluate/<int:preset_id>', methods=['POST'])
def evaluate_alerts(preset_id):
    """
    Manually trigger alert evaluation for a specific preset.
    
    Args:
        preset_id (int): ID of the strategy preset to evaluate
        
    Returns:
        JSON: List of triggered alerts
    """
    try:
        # Get the preset
        preset = StrategyPreset.query.get(preset_id)
        
        if not preset:
            return jsonify({'success': False, 'error': 'Preset not found'}), 404
            
        # Evaluate alerts
        triggered_alerts = AlertService.evaluate_alerts_for_preset(preset_id)
        
        return jsonify({
            'success': True,
            'message': f'Evaluated alerts for preset {preset_id}',
            'triggered_alerts': triggered_alerts
        })
        
    except Exception as e:
        logger.error(f"Error evaluating alerts for preset {preset_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

# ===== ROTATION BACKTEST API ENDPOINTS =====

@app.route('/api/rotation_backtest/run', methods=['POST'])
def run_rotation_backtest_api():
    """
    API endpoint to run a rotation backtest simulation.
    This simulates how auto-rotation would have performed over historical data.
    """
    try:
        # Parse JSON data
        data = request.get_json()
        
        # Get required parameters
        symbol = data.get('symbol', 'BTC/USDT')
        timeframe = data.get('timeframe', '1h')
        days = int(data.get('days', 30))
        rotation_interval_hours = int(data.get('rotation_interval_hours', 24))
        
        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        # Get initial weights (optional)
        initial_weights = data.get('initial_weights', None)
        
        # Run backtest
        results = backtest_with_rotation(
            symbol=symbol,
            timeframe=timeframe,
            start_date=start_date,
            end_date=end_date,
            initial_weights=initial_weights,
            rotation_interval_hours=rotation_interval_hours,
            add_default_policies=True
        )
        
        # Return results
        return jsonify({
            'success': True,
            'results': results
        })
        
    except Exception as e:
        logger.error(f"Error running rotation backtest: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/rotation_backtest/comparison_chart')
def rotation_backtest_comparison_chart():
    """
    Generate an enhanced comparison chart showing performance with and without rotation.
    """
    try:
        # Get rotation backtest results from session
        if 'rotation_backtest_results' not in session:
            return jsonify({'success': False, 'error': 'No rotation backtest results found. Run a backtest first.'}), 404
            
        results = session['rotation_backtest_results']
        
        # Extract baseline equity data
        baseline_results = results.get('baseline_results', {})
        baseline_equity_curve = baseline_results.get('equity_curve', [])
        
        # Format baseline data
        baseline_timestamps = []
        baseline_equity = []
        baseline_pct_change = []
        
        for point in baseline_equity_curve:
            timestamp = point[0]
            equity = point[1]
            pct_change = ((equity / baseline_results.get('initial_balance', 1000)) - 1) * 100
            
            baseline_timestamps.append(timestamp)
            baseline_equity.append(equity)
            baseline_pct_change.append(pct_change)
        
        # Extract rotation equity data
        rotation_results = results.get('rotation_results', {})
        rotation_equity_curve = rotation_results.get('equity_curve', [])
        
        # Format rotation data
        rotation_timestamps = []
        rotation_equity = []
        rotation_pct_change = []
        
        for point in rotation_equity_curve:
            timestamp = point[0]
            equity = point[1]
            pct_change = ((equity / rotation_results.get('initial_balance', 1000)) - 1) * 100
            
            rotation_timestamps.append(timestamp)
            rotation_equity.append(equity)
            rotation_pct_change.append(pct_change)
        
        # Get rotation events
        rotation_events = results.get('rotation_history', [])
        
        # Import new chart creation function
        from chart_templates import create_rotation_equity_chart
        
        # Create the enhanced equity chart
        chart_json = create_rotation_equity_chart(
            baseline_equity={
                'timestamps': baseline_timestamps,
                'equity': baseline_equity,
                'pct_change': baseline_pct_change
            },
            rotation_equity={
                'timestamps': rotation_timestamps,
                'equity': rotation_equity,
                'pct_change': rotation_pct_change
            },
            rotation_events=rotation_events,
            height=500
        )
        
        return jsonify({
            'success': True,
            'chart': chart_json
        })
        
    except Exception as e:
        logger.error(f"Error generating enhanced rotation comparison chart: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/rotation_backtest/rotation_events_chart')
def rotation_events_chart():
    """
    Generate a chart showing rotation events over time with their impact.
    """
    try:
        # Get rotation backtest results from session
        if 'rotation_backtest_results' not in session:
            return jsonify({'success': False, 'error': 'No rotation backtest results found. Run a backtest first.'}), 404
            
        results = session['rotation_backtest_results']
        rotation_events = results.get('rotation_history', [])
        
        if not rotation_events:
            return jsonify({'success': False, 'error': 'No rotation events found in backtest results.'}), 404
        
        # Format rotation events for our chart
        formatted_events = []
        
        for event in rotation_events:
            # Convert timestamp if needed
            timestamp = event['timestamp']
            if isinstance(timestamp, str):
                timestamp = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            
            # Calculate the impact (performance change) if available
            impact = event.get('performance_impact', 0)
            
            # Format weight changes
            weight_changes = {}
            prev_weights = event.get('prev_weights', {})
            new_weights = event.get('new_weights', {})
            
            for strategy in new_weights:
                prev = prev_weights.get(strategy, 0) * 100
                new = new_weights.get(strategy, 0) * 100
                weight_changes[strategy] = new - prev
            
            # Create formatted event
            formatted_event = {
                'timestamp': timestamp,
                'policy': event.get('trigger', 'Unknown'),
                'reason': event.get('reason', 'Weight adjustment'),
                'weight_changes': weight_changes,
                'impact': impact
            }
            
            formatted_events.append(formatted_event)
        
        # Import chart creation function
        from chart_templates import create_rotation_events_chart
        
        # Create the events chart
        chart_json = create_rotation_events_chart(
            rotation_events=formatted_events,
            height=400
        )
        
        return jsonify({
            'success': True,
            'chart': chart_json
        })
        
    except Exception as e:
        logger.error(f"Error generating rotation events chart: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/rotation_backtest/strategy_weights_chart')
def rotation_strategy_weights_chart():
    """
    Generate a chart showing strategy weight evolution over time.
    """
    try:
        # Get rotation backtest results from session
        if 'rotation_backtest_results' not in session:
            return jsonify({'success': False, 'error': 'No rotation backtest results found. Run a backtest first.'}), 404
            
        results = session['rotation_backtest_results']
        rotation_events = results.get('rotation_history', [])
        
        if not rotation_events:
            return jsonify({'success': False, 'error': 'No rotation events found in backtest results.'}), 404
        
        # Create weight history from rotation events
        weight_history = []
        
        # Add initial weights
        initial_weights = results.get('initial_weights', {})
        if initial_weights:
            weight_history.append({
                'timestamp': pd.to_datetime(results.get('start_time', datetime.now())),
                'weights': initial_weights
            })
        
        # Add weights for each rotation event
        for event in rotation_events:
            # Convert timestamp if needed
            timestamp = event['timestamp']
            if isinstance(timestamp, str):
                timestamp = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            
            # Add weights after rotation
            weight_history.append({
                'timestamp': timestamp,
                'weights': event.get('new_weights', {})
            })
        
        # Format rotation events for our chart
        formatted_events = []
        
        for event in rotation_events:
            # Convert timestamp if needed
            timestamp = event['timestamp']
            if isinstance(timestamp, str):
                timestamp = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            
            # Format weight changes
            weight_changes = {}
            prev_weights = event.get('prev_weights', {})
            new_weights = event.get('new_weights', {})
            
            for strategy in new_weights:
                prev = prev_weights.get(strategy, 0) * 100
                new = new_weights.get(strategy, 0) * 100
                weight_changes[strategy] = new - prev
            
            # Create formatted event
            formatted_event = {
                'timestamp': timestamp,
                'policy': event.get('trigger', 'Unknown'),
                'reason': event.get('reason', 'Weight adjustment'),
                'weight_changes': weight_changes
            }
            
            formatted_events.append(formatted_event)
        
        # Import chart creation function
        from chart_templates import create_strategy_weight_chart
        
        # Create the strategy weights chart
        chart_json = create_strategy_weight_chart(
            weight_history=weight_history,
            rotation_events=formatted_events,
            height=400
        )
        
        return jsonify({
            'success': True,
            'chart': chart_json
        })
        
    except Exception as e:
        logger.error(f"Error generating strategy weights chart: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/rotation_backtest/available_policies', methods=['GET'])
def get_backtest_rotation_policies():
    """
    Get the list of available rotation policies for backtesting.
    """
    try:
        # Create a temp rotation backtester to get default policies
        ensemble_backtester = EnsembleBacktester(
            ensemble_name=get_active_ensemble()
        )
        rotation_backtester = RotationBacktester(ensemble_backtester)
        rotation_backtester.add_default_policies()
        
        # Get policies
        policies = []
        for policy in rotation_backtester._policies:
            policies.append({
                'name': policy.name,
                'type': policy.__class__.__name__,
                'description': policy.description
            })
        
        return jsonify({
            'success': True,
            'policies': policies
        })
        
    except Exception as e:
        logger.error(f"Error getting rotation policies for backtesting: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/ensemble_config/create', methods=['POST'])
def create_ensemble():
    """Create a new ensemble strategy."""
    name = request.form.get('name')
    voting_method = request.form.get('voting_method')
    min_agreement_pct = float(request.form.get('min_agreement_pct', 0.5))
    performance_lookback = int(request.form.get('performance_lookback', 14))
    
    # Get selected strategies and weights
    selected_strategies = request.form.getlist('strategies')
    
    # Create dictionary of strategy configs with weights
    strategies_config = []
    for strategy_id in selected_strategies:
        weight = float(request.form.get(f'weight_{strategy_id}', 1.0))
        strategies_config.append({
            'name': strategy_id,
            'weight': weight
        })
    
    if not name or not selected_strategies:
        flash('Please provide a name and select at least one strategy', 'danger')
        return redirect(url_for('ensemble_config'))
    
    try:
        # Create the ensemble strategy
        ensemble = ensemble_manager.create_ensemble_strategy(
            ensemble_name=name,
            strategies_config=strategies_config,
            voting_method=voting_method
        )
        
        # Set additional parameters
        ensemble.min_agreement_pct = min_agreement_pct
        if hasattr(ensemble, 'performance_lookback'):
            ensemble.performance_lookback = performance_lookback
        
        # Save ensembles to disk
        ensemble_manager.save_ensembles()
        
        flash(f'Ensemble strategy "{name}" created successfully', 'success')
    except Exception as e:
        logger.error(f"Error creating ensemble strategy: {e}")
        flash(f'Error creating ensemble strategy: {str(e)}', 'danger')
    
    return redirect(url_for('ensemble_config'))

@app.route('/ensemble_config/activate', methods=['POST'])
def activate_ensemble():
    """Activate an ensemble strategy."""
    ensemble_name = request.form.get('ensemble_name')
    
    if not ensemble_name:
        flash('No ensemble strategy specified', 'danger')
        return redirect(url_for('ensemble_config'))
    
    try:
        # Set active ensemble
        success = ensemble_manager.set_active_ensemble(ensemble_name)
        
        if success:
            # Update bot if running
            if bot_instance and bot_status == "running":
                bot_instance.switch_to_ensemble(ensemble_name)
            
            flash(f'Ensemble strategy "{ensemble_name}" activated successfully', 'success')
        else:
            flash(f'Could not activate ensemble strategy "{ensemble_name}"', 'danger')
            
        # Save ensembles to disk
        ensemble_manager.save_ensembles()
    except Exception as e:
        logger.error(f"Error activating ensemble strategy: {e}")
        flash(f'Error activating ensemble strategy: {str(e)}', 'danger')
    
    return redirect(url_for('ensemble_config'))

@app.route('/ensemble_config/delete', methods=['POST'])
def delete_ensemble():
    """Delete an ensemble strategy."""
    ensemble_name = request.form.get('ensemble_name')
    
    if not ensemble_name:
        flash('No ensemble strategy specified', 'danger')
        return redirect(url_for('ensemble_config'))
    
    try:
        # Delete the ensemble
        success = ensemble_manager.delete_ensemble(ensemble_name)
        
        if success:
            flash(f'Ensemble strategy "{ensemble_name}" deleted successfully', 'success')
        else:
            flash(f'Could not delete ensemble strategy "{ensemble_name}"', 'danger')
            
        # Save ensembles to disk
        ensemble_manager.save_ensembles()
    except Exception as e:
        logger.error(f"Error deleting ensemble strategy: {e}")
        flash(f'Error deleting ensemble strategy: {str(e)}', 'danger')
    
    return redirect(url_for('ensemble_config'))

@app.route('/safety_settings')
def safety_settings():
    """Page for configuring safety guardrails."""
    safety_data = {}
    
    if bot_instance and bot_status == "running":
        try:
            safety_data = bot_instance.get_safety_status()
        except Exception as e:
            logger.error(f"Error getting safety data: {e}")
            flash(f"Error retrieving safety data: {e}", "danger")
    
    return render_template(
        'safety_settings.html',
        bot_status=bot_status,
        last_check_time=last_check_time.strftime('%Y-%m-%d %H:%M:%S') if last_check_time else None,
        safety=safety_data,
        paper_trading=Config.PAPER_TRADING
    )

@app.route('/update_safety_settings', methods=['POST'])
def update_safety_settings():
    """Update safety settings."""
    if bot_instance and bot_status == "running":
        try:
            # Get form data
            max_trade_size_usd = float(request.form.get('max_trade_size_usd', Config.MAX_TRADE_SIZE_USD))
            max_trade_size_pct = float(request.form.get('max_trade_size_pct', Config.MAX_TRADE_SIZE_PCT))
            max_daily_loss_usd = float(request.form.get('max_daily_loss_usd', Config.MAX_DAILY_LOSS_USD))
            max_daily_loss_pct = float(request.form.get('max_daily_loss_pct', Config.MAX_DAILY_LOSS_PCT))
            max_trades_per_hour = int(request.form.get('max_trades_per_hour', Config.MAX_TRADES_PER_HOUR))
            max_trades_per_day = int(request.form.get('max_trades_per_day', Config.MAX_TRADES_PER_DAY))
            min_trade_interval_seconds = int(request.form.get('min_trade_interval_seconds', Config.MIN_TRADE_INTERVAL_SECONDS))
            max_single_asset_exposure_pct = float(request.form.get('max_single_asset_exposure_pct', Config.MAX_SINGLE_ASSET_EXPOSURE_PCT))
            max_total_exposure_pct = float(request.form.get('max_total_exposure_pct', Config.MAX_TOTAL_EXPOSURE_PCT))
            emergency_stop_active = request.form.get('emergency_stop_active', 'false').lower() == 'true'
            live_trading_enabled = request.form.get('live_trading_enabled', 'false').lower() == 'true'
            safety_mode = request.form.get('safety_mode', Config.SAFETY_MODE_LEVEL)
            
            # Update safety config
            safety_config = {
                'max_trade_size_usd': max_trade_size_usd,
                'max_trade_size_pct': max_trade_size_pct,
                'max_daily_loss_usd': max_daily_loss_usd,
                'max_daily_loss_pct': max_daily_loss_pct,
                'max_trades_per_hour': max_trades_per_hour,
                'max_trades_per_day': max_trades_per_day,
                'min_trade_interval_seconds': min_trade_interval_seconds,
                'max_single_asset_exposure_pct': max_single_asset_exposure_pct,
                'max_total_exposure_pct': max_total_exposure_pct,
                'emergency_stop_active': emergency_stop_active,
                'live_trading_enabled': live_trading_enabled,
                'safety_mode_level': safety_mode
            }
            
            # Update both Config class and safety module
            for key, value in safety_config.items():
                if hasattr(Config, key.upper()):
                    setattr(Config, key.upper(), value)
            
            # Update safety module
            bot_instance.safety.update_config(safety_config)
            
            flash("Safety settings updated successfully.", "success")
        except Exception as e:
            logger.error(f"Error updating safety settings: {e}")
            flash(f"Error updating safety settings: {e}", "danger")
    else:
        flash("Bot is not running. Please start the bot first.", "warning")
    
    return redirect(url_for('safety_settings'))

@app.route('/toggle_emergency_stop', methods=['POST'])
def toggle_emergency_stop():
    """Toggle emergency stop switch."""
    if bot_instance and bot_status == "running":
        try:
            # Get current state
            current_state = bot_instance.safety.config.emergency_stop_active
            
            # Toggle state
            new_state = not current_state
            
            # Update safety module
            bot_instance.safety.update_config({'emergency_stop_active': new_state})
            
            # Update Config class
            Config.EMERGENCY_STOP_ACTIVE = new_state
            
            if new_state:
                flash("Emergency stop activated. All trading is halted.", "warning")
            else:
                flash("Emergency stop deactivated. Trading can resume.", "success")
                
        except Exception as e:
            logger.error(f"Error toggling emergency stop: {e}")
            flash(f"Error toggling emergency stop: {e}", "danger")
    else:
        flash("Bot is not running. Please start the bot first.", "warning")
    
    return redirect(url_for('safety_settings'))

@app.route('/reset_paper_trading', methods=['POST'])
def reset_paper_trading():
    """Reset paper trading balance and history."""
    if bot_instance and hasattr(bot_instance, 'client') and hasattr(bot_instance.client, 'exchange'):
        if hasattr(bot_instance.client.exchange, 'reset_balance'):
            try:
                initial_balance = float(request.form.get('initial_balance', 1000))
                bot_instance.client.exchange.reset_balance(initial_balance)
                
                # Also clear trade history if available
                if hasattr(bot_instance.client.exchange, 'trade_history'):
                    bot_instance.client.exchange.trade_history = []
                
                # Also clear order history if available
                if hasattr(bot_instance.client.exchange, 'order_history'):
                    bot_instance.client.exchange.order_history = []
                
                # Save the updated data
                if hasattr(bot_instance.client.exchange, 'save_data'):
                    bot_instance.client.exchange.save_data()
                    
                flash(f'Paper trading account has been reset to {initial_balance} USDT balance. All trade history and positions have been cleared.', 'success')
                
                # Reset bot stats
                bot_instance.total_trades = 0
                bot_instance.successful_trades = 0
                bot_instance.failed_trades = 0
                bot_instance.total_profit_usdt = 0.0
                bot_instance.initial_portfolio_value = initial_balance
                bot_instance.current_portfolio_value = initial_balance
                
                # Clear open positions
                bot_instance.open_positions = {}
                
                logger.info(f"Paper trading reset: balance set to {initial_balance} USDT, history cleared")
                
            except Exception as e:
                logger.error(f"Error resetting paper trading balance: {e}")
                flash(f'Error resetting paper trading account: {e}', 'danger')
        else:
            flash('Reset function not available for this exchange', 'warning')
    else:
        flash('Bot must be running to reset paper trading balance', 'warning')
    
    return redirect(url_for('portfolio'))

def get_bot_stats():
    """Get current bot statistics."""
    if not bot_instance:
        return None
    
    stats = {
        'open_positions': len(bot_instance.open_positions) if hasattr(bot_instance, 'open_positions') else 0,
        'total_trades': bot_instance.total_trades,
        'successful_trades': bot_instance.successful_trades,
        'failed_trades': bot_instance.failed_trades,
        'total_profit_usdt': round(bot_instance.total_profit_usdt, 2),
        'win_rate': round((bot_instance.successful_trades / bot_instance.total_trades) * 100, 2) if bot_instance.total_trades > 0 else 0,
        'trading_pairs': Config.TRADING_PAIRS,
        'base_position_size': Config.BASE_POSITION_SIZE,
        'paper_trading': Config.PAPER_TRADING
    }
    
    # Add safety status if available
    try:
        safety_status = bot_instance.get_safety_status()
        stats['safety_status'] = safety_status
    except Exception as e:
        logger.error(f"Error getting safety status: {e}")
        # Create a minimal safety status structure that matches what the template expects
        stats['safety_status'] = {
            'error': str(e),
            'config': {
                'emergency_stop_active': Config.EMERGENCY_STOP_ACTIVE,
                'live_trading_enabled': Config.LIVE_TRADING_ENABLED,
                'safety_mode_level': Config.SAFETY_MODE_LEVEL,
                'max_total_exposure_pct': 50.0  # Default value
            },
            'current_exposure_pct': 0.0,  # Default value
            'daily_loss': 0.0,  # Default value
            'trades_today': 0  # Default value
        }
    
    return stats

# Batch Strategy Comparison Routes
@app.route('/batch_comparison')
def batch_comparison():
    """Page for comparing multiple strategies."""
    from strategies import get_available_strategies
    
    return render_template(
        'batch_comparison.html',
        available_strategies=get_available_strategies(),
        trading_pairs=Config.TRADING_PAIRS,
        comparison_results=session.get('comparison_results')
    )

@app.route('/run_batch_comparison', methods=['POST'])
def run_batch_comparison_route():
    """Run a batch comparison of strategies."""
    # Get form data
    strategies = request.form.getlist('strategies')
    symbol = request.form.get('symbol')
    timeframe = request.form.get('timeframe')
    initial_balance = float(request.form.get('initial_balance', 1000))
    use_optimal_params = 'use_optimal_params' in request.form
    start_date = request.form.get('start_date') or None
    end_date = request.form.get('end_date') or None
    
    if not strategies:
        flash('Please select at least one strategy', 'danger')
        return redirect(url_for('batch_comparison'))
    
    logger.info(f"Running batch comparison for strategies: {', '.join(strategies)}")
    
    # Run comparison
    comparison_id = int(time.time())
    batch = BatchComparison(
        strategies=strategies,
        symbol=symbol,
        timeframe=timeframe,
        initial_balance=initial_balance,
        start_date=start_date,
        end_date=end_date
    )
    
    try:
        batch.load_data()
        batch.run_comparison(use_optimal_params=use_optimal_params)
        
        comparison_table = batch.generate_comparison_table()
        charts = batch.generate_comparison_charts()
        
        # Prepare results for template
        comparison_results = {
            'id': comparison_id,
            'symbol': symbol,
            'timeframe': timeframe,
            'strategies': strategies,
            'charts': charts,
            'metrics': {},
            'parameters': {}
        }
        
        # Extract metrics and parameters for each strategy
        for strategy_name, result in batch.results.items():
            comparison_results['metrics'][strategy_name] = result['metrics']
            comparison_results['parameters'][strategy_name] = result['parameters']
        
        # Store results in session for retrieval
        session['comparison_results'] = comparison_results
        session['comparison_data'] = {
            'batch': {
                'symbol': batch.symbol,
                'timeframe': batch.timeframe,
                'initial_balance': batch.initial_balance,
                'start_date': batch.start_date,
                'end_date': batch.end_date
            },
            'results': batch.results
        }
        
        flash('Batch comparison completed successfully', 'success')
        
    except Exception as e:
        logger.error(f"Error running batch comparison: {e}")
        flash(f'Error running comparison: {str(e)}', 'danger')
    
    return redirect(url_for('batch_comparison'))

@app.route('/view_strategy_details/<strategy>')
def view_strategy_details(strategy):
    """View detailed results for a specific strategy."""
    comparison_id = request.args.get('comparison_id')
    comparison_data = session.get('comparison_data', {})
    
    if 'results' not in comparison_data or strategy not in comparison_data['results']:
        flash('Strategy details not found', 'danger')
        return redirect(url_for('batch_comparison'))
    
    result = comparison_data['results'][strategy]
    
    return render_template(
        'strategy_comparison_details.html',
        strategy_name=strategy,
        comparison_id=comparison_id,
        metrics=result['metrics'],
        parameters=result['parameters'],
        trades=result['trades'],
        equity_chart=result['equity_chart'],
        trade_chart=result['trade_chart']
    )

@app.route('/apply_comparison_parameters/<strategy>')
def apply_comparison_parameters(strategy):
    """Apply parameters from comparison to the live strategy."""
    comparison_data = session.get('comparison_data', {})
    
    if 'results' not in comparison_data or strategy not in comparison_data['results']:
        flash('Strategy parameters not found', 'danger')
        return redirect(url_for('batch_comparison'))
    
    parameters = comparison_data['results'][strategy]['parameters']
    
    if parameters:
        logger.info(f"Applying parameters from comparison to {strategy}: {parameters}")
        
        # Update active strategy
        Config.ACTIVE_STRATEGY = strategy
        
        # Apply strategy-specific parameters
        if strategy == 'dip_buyer':
            Config.PRICE_DROP_THRESHOLD = parameters.get('price_drop_threshold', Config.PRICE_DROP_THRESHOLD)
            Config.PRICE_DROP_TIMEFRAME = parameters.get('price_drop_timeframe', Config.PRICE_DROP_TIMEFRAME)
            Config.TAKE_PROFIT = parameters.get('take_profit', Config.TAKE_PROFIT)
            Config.STOP_LOSS = parameters.get('stop_loss', Config.STOP_LOSS)
        
        elif strategy == 'mean_reversion':
            Config.MA_PERIOD = parameters.get('ma_period', Config.MA_PERIOD)
            Config.STD_DEV_MULTIPLIER = parameters.get('std_dev_multiplier', Config.STD_DEV_MULTIPLIER)
            Config.TAKE_PROFIT = parameters.get('take_profit', Config.TAKE_PROFIT)
            Config.STOP_LOSS = parameters.get('stop_loss', Config.STOP_LOSS)
        
        elif strategy == 'breakout':
            Config.LOOKBACK_PERIOD = parameters.get('lookback_period', Config.LOOKBACK_PERIOD)
            Config.CONFIRMATION_CANDLES = parameters.get('confirmation_candles', Config.CONFIRMATION_CANDLES)
            Config.VOLUME_INCREASE = parameters.get('volume_increase', Config.VOLUME_INCREASE)
            Config.TAKE_PROFIT = parameters.get('take_profit', Config.TAKE_PROFIT)
            Config.STOP_LOSS = parameters.get('stop_loss', Config.STOP_LOSS)
        
        # Restart bot if running with new parameters
        global bot_instance, bot_status
        if bot_status == "running":
            stop_bot()
            time.sleep(1)  # Give time for the bot to stop
            start_bot()
            flash(f'Applied {strategy} parameters and restarted the bot', 'success')
        else:
            flash(f'Applied {strategy} parameters. Start the bot to use them.', 'success')
    
    else:
        flash('No parameters found to apply', 'warning')
    
    return redirect(url_for('batch_comparison'))

@app.route('/export_comparison_data/<format>')
def export_comparison_data(format):
    """Export comparison data as CSV or JSON."""
    comparison_data = session.get('comparison_data', {})
    
    if 'results' not in comparison_data:
        flash('No comparison data available to export', 'danger')
        return redirect(url_for('batch_comparison'))
    
    # Recreate batch comparison object
    batch_data = comparison_data['batch']
    batch = BatchComparison(
        symbol=batch_data['symbol'],
        timeframe=batch_data['timeframe'],
        initial_balance=batch_data['initial_balance'],
        start_date=batch_data['start_date'],
        end_date=batch_data['end_date']
    )
    
    # Add results back
    batch.results = comparison_data['results']
    
    # Export data
    if format == 'csv':
        # Create CSV in memory
        comparison_df = batch.generate_comparison_table()
        if comparison_df is None:
            flash('Error generating comparison table', 'danger')
            return redirect(url_for('batch_comparison'))
        
        csv_data = comparison_df.to_csv(index=False)
        
        response = make_response(csv_data)
        response.headers['Content-Disposition'] = f'attachment; filename=strategy_comparison_{int(time.time())}.csv'
        response.headers['Content-Type'] = 'text/csv'
        return response
    
    elif format == 'json':
        # Create JSON in memory
        serializable_results = {}
        for strategy, result in batch.results.items():
            serializable_results[strategy] = {
                'metrics': result['metrics'],
                'parameters': result['parameters'],
                'trades': [vars(trade) if hasattr(trade, '__dict__') else trade for trade in result['trades']]
            }
        
        json_data = json.dumps(serializable_results, indent=2, default=str)
        
        response = make_response(json_data)
        response.headers['Content-Disposition'] = f'attachment; filename=strategy_comparison_{int(time.time())}.json'
        response.headers['Content-Type'] = 'application/json'
        return response
    
    flash('Invalid export format', 'danger')
    return redirect(url_for('batch_comparison'))

@app.route('/export_strategy_trades/<strategy>')
def export_strategy_trades(strategy):
    """Export trades for a specific strategy."""
    comparison_data = session.get('comparison_data', {})
    
    if 'results' not in comparison_data or strategy not in comparison_data['results']:
        flash('Strategy data not found', 'danger')
        return redirect(url_for('batch_comparison'))
    
    trades = comparison_data['results'][strategy]['trades']
    
    # Convert trades to CSV
    csv_data = "entry_time,exit_time,entry_price,exit_price,position_size,profit_usdt,profit_pct,exit_reason\n"
    for trade in trades:
        trade_dict = trade if isinstance(trade, dict) else vars(trade)
        csv_data += f"{trade_dict.get('entry_time', '')},{trade_dict.get('exit_time', '')},"
        csv_data += f"{trade_dict.get('entry_price', '')},{trade_dict.get('exit_price', '')},"
        csv_data += f"{trade_dict.get('position_size', '')},{trade_dict.get('profit_usdt', '')},"
        csv_data += f"{trade_dict.get('profit_pct', '')}%,{trade_dict.get('exit_reason', '')}\n"
    
    response = make_response(csv_data)
    response.headers['Content-Disposition'] = f'attachment; filename={strategy}_trades_{int(time.time())}.csv'
    response.headers['Content-Type'] = 'text/csv'
    return response

# Equity Dashboard Routes and Endpoints
@app.route('/equity_dashboard')
def equity_dashboard():
    """
    Long-Term Equity Dashboard showing performance of strategy presets over time.
    """
    return render_template(
        'equity_dashboard.html',
        presets=StrategyPreset.query.all()
    )

@app.route('/alerts')
def alerts_redirect():
    """
    Redirects /alerts to /alerts_dashboard for navigation menu compatibility
    """
    return redirect(url_for('alerts_dashboard'))

@app.route('/alerts_dashboard')
def alerts_dashboard():
    """
    Performance Alerts Dashboard for monitoring strategy health and performance alerts.
    """
    return render_template(
        'alerts_dashboard.html',
        presets=StrategyPreset.query.all()
    )

@app.route('/equity-curve')
def equity_curve_page():
    """
    Equity Curve visualization and CSV export page with advanced performance metrics.
    """
    return render_template('equity_curve.html')

@app.route('/investor-report')
def investor_report():
    """
    Generate a printable investor report with equity curve, BTC comparison, strategy attribution data,
    and allocation preset information.
    This page is designed for printing/saving as PDF from the browser.
    """
    # Get preset or use default
    preset_id = request.args.get('preset_id', None)
    if preset_id:
        preset_id = int(preset_id)
        
    # Use default preset if not specified
    if not preset_id:
        preset = StrategyPreset.query.order_by(StrategyPreset.id.desc()).first()
        if preset:
            preset_id = preset.id
            
    # If still no preset, redirect to dashboard
    if not preset_id:
        flash("No presets found to generate a report", "warning")
        return redirect(url_for('nexera_dashboard'))
        
    # Get preset data for the report
    preset = StrategyPreset.query.get(preset_id)
    if not preset:
        flash("Preset not found", "danger")
        return redirect(url_for('nexera_dashboard'))
    
    # Get equity history
    equity_history = PresetEquityHistory.query.filter_by(preset_id=preset_id).order_by(PresetEquityHistory.timestamp).all()
    
    # Get strategy attributions for the preset
    attributions = StrategyAttribution.query.filter_by(preset_id=preset_id).order_by(StrategyAttribution.start_time).all()
    
    # Get trigger events
    trigger_events = PresetTriggerEvent.query.filter_by(preset_id=preset_id).order_by(PresetTriggerEvent.timestamp).all()
    
    # Calculate metrics
    metrics = calculate_performance_metrics(equity_history)
    
    # Get BTC/USDT comparison data if available
    btc_comparison_data = get_btc_comparison_data(equity_history)
    
    # Get the most recently applied allocation preset
    allocation_preset = None
    try:
        # Try to find the most recently applied allocation preset
        allocation_preset = AllocationPreset.query.order_by(AllocationPreset.last_applied_at.desc()).first()
        
        # If no applied preset, just get the most recent favorite one
        if not allocation_preset:
            allocation_preset = AllocationPreset.query.filter_by(is_favorite=True).order_by(AllocationPreset.updated_at.desc()).first()
            
        # If still no preset, just get the most recent one
        if not allocation_preset:
            allocation_preset = AllocationPreset.query.order_by(AllocationPreset.updated_at.desc()).first()
    except Exception as e:
        # Log the error but continue without allocation preset data
        print(f"Error getting allocation preset data: {e}")
    
    # Generate the current date for the report
    report_date = datetime.now().strftime('%Y-%m-%d')
    
    # Get AI recommendation for current allocation if available
    ai_recommendation = None
    ai_comparison = None
    if allocation_preset:
        try:
            # Get strategy IDs from allocation preset
            strategy_ids = []
            strategy_weights = {}
            
            for strategy_name, weight in allocation_preset.weights.items():
                # Find strategy ID by name
                strategy = Strategy.query.filter_by(name=strategy_name).first()
                if strategy:
                    strategy_ids.append(strategy.id)
                    strategy_weights[strategy.id] = weight
            
            if strategy_ids:
                # Get AI recommendation with comparison data
                from strategy_recommender import StrategyRecommender
                recommender = StrategyRecommender()
                
                # Use default optimization settings
                lookback_days = 30
                optimization_objective = "sharpe_ratio"
                min_allocation = 0.05
                max_allocation = 0.4
                
                # Get recommendation with comparison to current allocation
                recommendation_data = recommender.recommend_allocation(
                    lookback_days=lookback_days,
                    optimization_objective=optimization_objective,
                    min_allocation=min_allocation,
                    max_allocation=max_allocation,
                    strategy_ids=strategy_ids,
                    current_weights=strategy_weights
                )
                
                if recommendation_data and recommendation_data.get('success'):
                    ai_recommendation = recommendation_data
                    ai_comparison = recommendation_data.get('comparison_data')
        except Exception as e:
            print(f"Error getting AI recommendation: {e}")
    
    return render_template(
        'investor_report.html',
        preset=preset,
        equity_history=equity_history,
        attributions=attributions,
        trigger_events=trigger_events,
        metrics=metrics,
        btc_comparison=btc_comparison_data,
        report_date=report_date,
        allocation_preset=allocation_preset,
        ai_recommendation=ai_recommendation,
        ai_comparison=ai_comparison
    )

def get_available_strategies():
    """
    Retrieve a list of all available strategies for the selection panel.
    
    Returns:
        list: List of strategy objects with id, name, and description
    """
    # Get all strategy presets from the database
    presets = StrategyPreset.query.all()
    
    # Format each preset for the UI
    strategies = []
    for preset in presets:
        strategy_obj = {
            'id': preset.id,
            'name': preset.name,
            'description': f"{preset.config_type.capitalize()} strategy",
        }
        strategies.append(strategy_obj)
    
    # If no presets found, add some dummy strategies for UI testing
    if not strategies:
        # For demo/testing purposes only
        strategies = [
            {'id': 1, 'name': 'Dip Buyer', 'description': 'Buy on significant dips, sell on recovery'},
            {'id': 2, 'name': 'Mean Reversion', 'description': 'Capitalize on price reverting to moving average'},
            {'id': 3, 'name': 'Breakout Momentum', 'description': 'Buy on breakouts with volume confirmation'},
            {'id': 4, 'name': 'Ensemble Strategy', 'description': 'Weighted voting from multiple strategies'},
            {'id': 5, 'name': 'Adaptive Strategy', 'description': 'Auto-rotates based on performance metrics'}
        ]
    
    return strategies

@app.route('/scheduled-allocations')
def scheduled_allocations_page():
    """Page for managing scheduled allocations."""
    return render_template('scheduled_allocations.html')

@app.route('/strategy-recommender')
def strategy_recommender_page():
    """AI Strategy Recommender page."""
    return render_template('strategy_recommender.html')

@app.route('/strategy-performance')
def strategy_performance_page():
    """
    Multi-Strategy Performance Dashboard showing side-by-side comparison of strategies.
    """
    # Get available strategies for the selection panel
    available_strategies = get_available_strategies()
    
    return render_template('strategy_performance.html', 
                          available_strategies=available_strategies,
                          time_periods=[
                              {'id': '1w', 'name': '1 Week'},
                              {'id': '1m', 'name': '1 Month'},
                              {'id': '3m', 'name': '3 Months'},
                              {'id': '6m', 'name': '6 Months'},
                              {'id': '1y', 'name': '1 Year'},
                              {'id': 'all', 'name': 'All Time'}
                          ])

@app.route('/api/strategy-performance')
def get_strategy_performance():
    """
    API endpoint to provide strategy performance data for the dashboard.
    
    Query Parameters:
        strategy_ids (str): Comma-separated list of strategy IDs
        period (str): Time period ('1w', '1m', '3m', '6m', '1y', 'all')
        normalized (bool): Whether to normalize returns - default False
        
    Returns:
        JSON: Strategy performance data including equity history and metrics
    """
    try:
        # Get query parameters
        strategy_ids_str = request.args.get('strategy_ids', '')
        strategy_ids = [int(id) for id in strategy_ids_str.split(',') if id.strip()]
        
        period = request.args.get('period', 'all')
        normalized = request.args.get('normalized', 'false').lower() == 'true'
        
        if not strategy_ids:
            return jsonify({'success': False, 'error': 'No strategy IDs provided'}), 400
        
        # Calculate date range based on period
        end_date = datetime.now()
        start_date = None
        
        if period == '1w':
            start_date = end_date - timedelta(days=7)
        elif period == '1m':
            start_date = end_date - timedelta(days=30)
        elif period == '3m':
            start_date = end_date - timedelta(days=90)
        elif period == '6m':
            start_date = end_date - timedelta(days=180)
        elif period == '1y':
            start_date = end_date - timedelta(days=365)
        # 'all' does not set a start_date, so we get all data
        
        # Prepare results container
        result = {'success': True, 'strategies': {}}
        
        # Custom colors for strategies for consistent visualization
        strategy_colors = [
            '#FF6A00',  # neXera orange
            '#3498db',  # blue
            '#2ecc71',  # green
            '#9b59b6',  # purple
            '#e74c3c',  # red
            '#f1c40f',  # yellow
            '#1abc9c',  # teal
            '#34495e',  # dark blue
            '#d35400',  # orange
            '#8e44ad'   # violet
        ]
        
        # Process each strategy
        for idx, strategy_id in enumerate(strategy_ids):
            # Get the preset
            preset = StrategyPreset.query.get(strategy_id)
            if not preset:
                continue
                
            # Assign a consistent color based on strategy index
            color_idx = idx % len(strategy_colors)
            
            # Build query for equity history
            query = PresetEquityHistory.query.filter_by(preset_id=strategy_id)
            
            # Apply date filter if start date was set
            if start_date:
                query = query.filter(PresetEquityHistory.timestamp >= start_date)
                
            # Order by timestamp
            query = query.order_by(PresetEquityHistory.timestamp)
            
            # Execute query
            equity_history = query.all()
            
            # Prepare data for response
            if equity_history:
                timestamps = []
                equity_values = []
                drawdown_values = []
                
                # Process equity history
                base_equity = equity_history[0].equity if normalized and equity_history else 0
                
                for entry in equity_history:
                    timestamps.append(entry.timestamp.isoformat())
                    
                    if normalized and base_equity > 0:
                        # Calculate percentage return
                        equity_values.append((entry.equity / base_equity * 100) - 100)
                    else:
                        equity_values.append(entry.equity)
                    
                    # Add drawdown if available
                    if hasattr(entry, 'drawdown_percent') and entry.drawdown_percent is not None:
                        drawdown_values.append(entry.drawdown_percent)
                
                # Calculate metrics
                latest_entry = equity_history[-1]
                total_return = ((latest_entry.equity / equity_history[0].equity) - 1) * 100 if len(equity_history) > 1 else 0
                
                # Add strategy data to result
                result['strategies'][strategy_id] = {
                    'name': preset.name,
                    'description': f"{preset.config_type.capitalize() if preset.config_type else 'Trading'} strategy",
                    'color': strategy_colors[color_idx],
                    'timestamps': timestamps,
                    'equity_values': equity_values,
                    'drawdown_values': drawdown_values if drawdown_values else None,
                    'metrics': {
                        'total_return': total_return,
                        'sharpe_ratio': latest_entry.sharpe_ratio if hasattr(latest_entry, 'sharpe_ratio') else None,
                        'sortino_ratio': latest_entry.sortino_ratio if hasattr(latest_entry, 'sortino_ratio') else None,
                        'max_drawdown': latest_entry.max_drawdown if hasattr(latest_entry, 'max_drawdown') else None,
                        'win_rate': ((latest_entry.win_count / (latest_entry.win_count + latest_entry.loss_count)) * 100) 
                                  if (hasattr(latest_entry, 'win_count') and hasattr(latest_entry, 'loss_count') and
                                     latest_entry.win_count is not None and latest_entry.loss_count is not None and
                                     (latest_entry.win_count + latest_entry.loss_count) > 0) else None
                    }
                }
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error getting strategy performance: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/preset_equity/<int:preset_id>')
def get_preset_equity(preset_id):
    """
    Get equity history for a specific preset.
    
    Args:
        preset_id (int): ID of the strategy preset
        
    Query Parameters:
        start_date (str, optional): Start date in ISO format (YYYY-MM-DD)
        end_date (str, optional): End date in ISO format (YYYY-MM-DD)
        interval (str, optional): Data interval ('daily', 'hourly', 'all') - default 'daily'
        normalize (bool, optional): Whether to normalize values to percentages - default False
        
    Returns:
        JSON: Equity history data
    """
    try:
        # Get query parameters
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        interval = request.args.get('interval', 'daily')
        normalize = request.args.get('normalize', 'false').lower() == 'true'
        
        # Get the preset
        preset = StrategyPreset.query.get(preset_id)
        if not preset:
            return jsonify({'success': False, 'error': 'Preset not found'}), 404
        
        # Build query
        query = PresetEquityHistory.query.filter_by(preset_id=preset_id)
        
        # Apply date filters if provided
        if start_date:
            start_datetime = datetime.fromisoformat(start_date)
            query = query.filter(PresetEquityHistory.timestamp >= start_datetime)
            
        if end_date:
            end_datetime = datetime.fromisoformat(end_date)
            query = query.filter(PresetEquityHistory.timestamp <= end_datetime)
        
        # Order by timestamp
        query = query.order_by(PresetEquityHistory.timestamp)
        
        # Execute query
        equity_history = query.all()
        
        # Apply interval filtering
        if interval == 'daily':
            # Group by day and select the last entry per day
            daily_data = {}
            for entry in equity_history:
                date_key = entry.timestamp.date().isoformat()
                daily_data[date_key] = entry
            
            # Convert back to list
            equity_history = list(daily_data.values())
            
        elif interval == 'hourly':
            # Group by hour and select the last entry per hour
            hourly_data = {}
            for entry in equity_history:
                hour_key = entry.timestamp.replace(minute=0, second=0, microsecond=0).isoformat()
                hourly_data[hour_key] = entry
            
            # Convert back to list
            equity_history = list(hourly_data.values())
        
        # Convert to dict for JSON serialization
        equity_data = [entry.to_dict() for entry in equity_history]
        
        # Normalize data if requested
        if normalize and equity_data:
            base_equity = equity_data[0]['equity']
            for entry in equity_data:
                entry['normalized_equity'] = (entry['equity'] / base_equity * 100) - 100  # Percentage change
        
        return jsonify({
            'success': True, 
            'preset': preset.to_dict(),
            'equity_history': equity_data
        })
        
    except Exception as e:
        logger.error(f"Error getting equity history for preset {preset_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/preset_equity/<int:preset_id>', methods=['POST'])
def add_preset_equity(preset_id):
    """
    Add a new equity history entry for a preset.
    
    Args:
        preset_id (int): ID of the strategy preset
        
    Request Body:
        equity (float): Current equity value
        pnl_percent (float, optional): Profit/loss percentage
        drawdown_percent (float, optional): Current drawdown percentage
        win_count (int, optional): Number of winning trades
        loss_count (int, optional): Number of losing trades
        base_currency (str, optional): Base currency (e.g., USDT, USD)
        sharpe_ratio (float, optional): Sharpe ratio
        sortino_ratio (float, optional): Sortino ratio
        max_drawdown (float, optional): Maximum drawdown percentage
        market_conditions (str, optional): Market conditions (bull, bear, sideways)
        vix_value (float, optional): Volatility index value
        
    Returns:
        JSON: Created equity history entry
    """
    try:
        data = request.json
        
        # Get the preset
        preset = StrategyPreset.query.get(preset_id)
        if not preset:
            return jsonify({'success': False, 'error': 'Preset not found'}), 404
        
        # Create new equity history entry
        equity_entry = PresetEquityHistory(
            preset_id=preset_id,
            equity=data.get('equity'),
            pnl_percent=data.get('pnl_percent'),
            drawdown_percent=data.get('drawdown_percent'),
            win_count=data.get('win_count'),
            loss_count=data.get('loss_count'),
            base_currency=data.get('base_currency', 'USDT'),
            sharpe_ratio=data.get('sharpe_ratio'),
            sortino_ratio=data.get('sortino_ratio'),
            max_drawdown=data.get('max_drawdown'),
            market_conditions=data.get('market_conditions'),
            vix_value=data.get('vix_value')
        )
        
        db.session.add(equity_entry)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Equity history entry added successfully',
            'entry': equity_entry.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error adding equity history for preset {preset_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/preset_equity/compare')
def compare_preset_equity():
    """
    Compare equity curves of multiple presets.
    
    Query Parameters:
        preset_ids (str): Comma-separated list of preset IDs
        start_date (str, optional): Start date in ISO format (YYYY-MM-DD)
        end_date (str, optional): End date in ISO format (YYYY-MM-DD)
        interval (str, optional): Data interval ('daily', 'hourly', 'all') - default 'daily'
        normalize (bool, optional): Whether to normalize values - default True
        
    Returns:
        JSON: Equity comparison data for multiple presets
    """
    try:
        # Get query parameters
        preset_ids_str = request.args.get('preset_ids', '')
        preset_ids = [int(id) for id in preset_ids_str.split(',') if id.strip()]
        
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        interval = request.args.get('interval', 'daily')
        normalize = request.args.get('normalize', 'true').lower() == 'true'
        
        if not preset_ids:
            return jsonify({'success': False, 'error': 'No preset IDs provided'}), 400
        
        result = {'success': True, 'presets': {}}
        
        for preset_id in preset_ids:
            # Get the preset
            preset = StrategyPreset.query.get(preset_id)
            if not preset:
                continue
                
            # Build query for equity history
            query = PresetEquityHistory.query.filter_by(preset_id=preset_id)
            
            # Apply date filters if provided
            if start_date:
                start_datetime = datetime.fromisoformat(start_date)
                query = query.filter(PresetEquityHistory.timestamp >= start_datetime)
                
            if end_date:
                end_datetime = datetime.fromisoformat(end_date)
                query = query.filter(PresetEquityHistory.timestamp <= end_datetime)
            
            # Order by timestamp
            query = query.order_by(PresetEquityHistory.timestamp)
            
            # Execute query
            equity_history = query.all()
            
            # Apply interval filtering (same logic as in get_preset_equity)
            if interval == 'daily':
                daily_data = {}
                for entry in equity_history:
                    date_key = entry.timestamp.date().isoformat()
                    daily_data[date_key] = entry
                
                equity_history = list(daily_data.values())
                
            elif interval == 'hourly':
                hourly_data = {}
                for entry in equity_history:
                    hour_key = entry.timestamp.replace(minute=0, second=0, microsecond=0).isoformat()
                    hourly_data[hour_key] = entry
                
                equity_history = list(hourly_data.values())
            
            # Convert to dict for JSON serialization
            equity_data = [entry.to_dict() for entry in equity_history]
            
            # Normalize data if requested
            if normalize and equity_data:
                base_equity = equity_data[0]['equity']
                for entry in equity_data:
                    entry['normalized_equity'] = (entry['equity'] / base_equity * 100) - 100  # Percentage change
            
            # Add to result
            result['presets'][preset_id] = {
                'name': preset.name,
                'equity_history': equity_data,
                'config_type': preset.config_type,
                'performance_metrics': {
                    'sharpe_ratio': equity_data[-1]['sharpe_ratio'] if equity_data else None,
                    'sortino_ratio': equity_data[-1]['sortino_ratio'] if equity_data else None,
                    'max_drawdown': equity_data[-1]['max_drawdown'] if equity_data else None,
                    'final_pnl_percent': equity_data[-1]['pnl_percent'] if equity_data else None
                }
            }
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error comparing preset equity: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/preset_equity/latest_metrics')
def get_latest_metrics():
    """
    Get the latest performance metrics for all presets or a filtered subset.
    
    Query Parameters:
        preset_type (str, optional): Filter by preset type ('ensemble', 'rotation', 'combined')
        favorites (bool, optional): Filter to show only favorites - default False
        
    Returns:
        JSON: Latest metrics for each preset
    """
    try:
        # Get query parameters
        preset_type = request.args.get('preset_type')
        favorites = request.args.get('favorites', 'false').lower() == 'true'
        
        # Build query
        query = StrategyPreset.query
        
        if preset_type:
            query = query.filter_by(config_type=preset_type)
            
        if favorites:
            query = query.filter_by(is_favorite=True)
        
        presets = query.all()
        result = {'success': True, 'metrics': []}
        
        for preset in presets:
            # Get the latest equity history entry
            latest_entry = PresetEquityHistory.query.filter_by(preset_id=preset.id).order_by(PresetEquityHistory.timestamp.desc()).first()
            
            if latest_entry:
                result['metrics'].append({
                    'preset_id': preset.id,
                    'preset_name': preset.name,
                    'config_type': preset.config_type,
                    'is_favorite': preset.is_favorite,
                    'latest_equity': latest_entry.equity,
                    'pnl_percent': latest_entry.pnl_percent,
                    'max_drawdown': latest_entry.max_drawdown,
                    'sharpe_ratio': latest_entry.sharpe_ratio,
                    'sortino_ratio': latest_entry.sortino_ratio,
                    'win_count': latest_entry.win_count,
                    'loss_count': latest_entry.loss_count,
                    'win_rate': (latest_entry.win_count / (latest_entry.win_count + latest_entry.loss_count) * 100) 
                               if (latest_entry.win_count is not None and latest_entry.loss_count is not None and 
                                  (latest_entry.win_count + latest_entry.loss_count) > 0) else None,
                    'last_updated': latest_entry.timestamp.isoformat()
                })
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error getting latest metrics: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

# Trigger Event API Endpoints
@app.route('/api/trigger_events/<int:preset_id>')
def get_trigger_events(preset_id):
    """
    Get trigger events for a specific preset.
    
    Args:
        preset_id (int): ID of the strategy preset
        
    Query Parameters:
        start_date (str, optional): Start date in ISO format (YYYY-MM-DD)
        end_date (str, optional): End date in ISO format (YYYY-MM-DD)
        event_type (str, optional): Filter by event type
        importance (int, optional): Filter by minimum importance level
        
    Returns:
        JSON: Trigger events data
    """
    try:
        # Get query parameters
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        event_type = request.args.get('event_type')
        importance = request.args.get('importance')
        
        # Get the preset
        preset = StrategyPreset.query.get(preset_id)
        if not preset:
            return jsonify({'success': False, 'error': 'Preset not found'}), 404
        
        # Build query
        query = PresetTriggerEvent.query.filter_by(preset_id=preset_id)
        
        # Apply filters if provided
        if start_date:
            start_datetime = datetime.fromisoformat(start_date)
            query = query.filter(PresetTriggerEvent.timestamp >= start_datetime)
            
        if end_date:
            end_datetime = datetime.fromisoformat(end_date)
            query = query.filter(PresetTriggerEvent.timestamp <= end_datetime)
            
        if event_type:
            query = query.filter(PresetTriggerEvent.event_type == event_type)
            
        if importance and importance.isdigit():
            query = query.filter(PresetTriggerEvent.importance >= int(importance))
            
        # Order by timestamp
        query = query.order_by(PresetTriggerEvent.timestamp)
        
        # Execute query
        trigger_events = query.all()
        
        # Convert to dict for JSON serialization
        events_data = [event.to_dict() for event in trigger_events]
        
        return jsonify({
            'success': True,
            'preset': preset.to_dict(),
            'trigger_events': events_data
        })
        
    except Exception as e:
        logger.error(f"Error getting trigger events for preset {preset_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/trigger_events/<int:preset_id>', methods=['POST'])
def add_trigger_event(preset_id):
    """
    Add a new trigger event for a preset.
    
    Args:
        preset_id (int): ID of the strategy preset
        
    Request Body:
        event_type (str): Event type (e.g., 'policy_activation', 'market_shift', 'parameter_change')
        event_subtype (str, optional): More specific categorization
        title (str): Short event title
        description (str, optional): Detailed description
        timestamp (str, optional): Event timestamp (defaults to current time if not provided)
        color (str, optional): CSS color for the trigger point
        icon (str, optional): Icon identifier
        importance (int, optional): Importance level (1-5)
        context_data (dict, optional): Additional event-specific data
        is_auto_generated (bool, optional): Whether the event was auto-generated
        created_by (str, optional): User or system component that created the event
        
    Returns:
        JSON: Created trigger event
    """
    try:
        data = request.json
        
        # Get the preset
        preset = StrategyPreset.query.get(preset_id)
        if not preset:
            return jsonify({'success': False, 'error': 'Preset not found'}), 404
        
        # Validate required fields
        required_fields = ['event_type', 'title']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'error': f'Missing required field: {field}'}), 400
                
        # Parse timestamp if provided
        timestamp = None
        if 'timestamp' in data:
            try:
                timestamp = datetime.fromisoformat(data['timestamp'].replace('Z', '+00:00'))
            except ValueError:
                return jsonify({'success': False, 'error': 'Invalid timestamp format'}), 400
                
        # Create new trigger event
        trigger_event = PresetTriggerEvent(
            preset_id=preset_id,
            event_type=data.get('event_type'),
            event_subtype=data.get('event_subtype'),
            title=data.get('title'),
            description=data.get('description'),
            timestamp=timestamp or datetime.utcnow(),
            color=data.get('color'),
            icon=data.get('icon'),
            importance=data.get('importance', 1),
            context_data=data.get('context_data'),
            is_auto_generated=data.get('is_auto_generated', False),
            created_by=data.get('created_by', 'user')
        )
        
        db.session.add(trigger_event)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Trigger event added successfully',
            'event': trigger_event.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error adding trigger event for preset {preset_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/trigger_events/<int:event_id>', methods=['DELETE'])
def delete_trigger_event(event_id):
    """
    Delete a trigger event.
    
    Args:
        event_id (int): ID of the trigger event to delete
        
    Returns:
        JSON: Success status
    """
    try:
        # Get the trigger event
        trigger_event = PresetTriggerEvent.query.get(event_id)
        if not trigger_event:
            return jsonify({'success': False, 'error': 'Trigger event not found'}), 404
            
        # Delete the trigger event
        db.session.delete(trigger_event)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Trigger event deleted successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting trigger event {event_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/trigger_events/<int:event_id>', methods=['PUT'])
def update_trigger_event(event_id):
    """
    Update a trigger event.
    
    Args:
        event_id (int): ID of the trigger event to update
        
    Request Body:
        event_type (str, optional): Event type
        event_subtype (str, optional): More specific categorization
        title (str, optional): Short event title
        description (str, optional): Detailed description
        timestamp (str, optional): Event timestamp
        color (str, optional): CSS color for the trigger point
        icon (str, optional): Icon identifier
        importance (int, optional): Importance level (1-5)
        context_data (dict, optional): Additional event-specific data
        is_auto_generated (bool, optional): Whether the event was auto-generated
        created_by (str, optional): User or system component that created the event
        
    Returns:
        JSON: Updated trigger event
    """
    try:
        data = request.json
        
        # Get the trigger event
        trigger_event = PresetTriggerEvent.query.get(event_id)
        if not trigger_event:
            return jsonify({'success': False, 'error': 'Trigger event not found'}), 404
            
        # Update fields if provided
        if 'event_type' in data:
            trigger_event.event_type = data['event_type']
            
        if 'event_subtype' in data:
            trigger_event.event_subtype = data['event_subtype']
            
        if 'title' in data:
            trigger_event.title = data['title']
            
        if 'description' in data:
            trigger_event.description = data['description']
            
        if 'timestamp' in data:
            try:
                trigger_event.timestamp = datetime.fromisoformat(data['timestamp'].replace('Z', '+00:00'))
            except ValueError:
                return jsonify({'success': False, 'error': 'Invalid timestamp format'}), 400
                
        if 'color' in data:
            trigger_event.color = data['color']
            
        if 'icon' in data:
            trigger_event.icon = data['icon']
            
        if 'importance' in data:
            trigger_event.importance = data['importance']
            
        if 'context_data' in data:
            trigger_event.context_data = data['context_data']
            
        if 'is_auto_generated' in data:
            trigger_event.is_auto_generated = data['is_auto_generated']
            
        if 'created_by' in data:
            trigger_event.created_by = data['created_by']
            
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Trigger event updated successfully',
            'event': trigger_event.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error updating trigger event {event_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/trigger_events/types')
def get_trigger_event_types():
    """
    Get all trigger event types used in the system.
    
    Returns:
        JSON: List of event types with counters
    """
    try:
        # Get all distinct event types and count how many events of each type exist
        result = db.session.query(
            PresetTriggerEvent.event_type,
            db.func.count(PresetTriggerEvent.id).label('count')
        ).group_by(PresetTriggerEvent.event_type).all()
        
        # Format the result
        event_types = [{'type': event_type, 'count': count} for event_type, count in result]
        
        # Make sure alert type is included for new installations
        found_alert = False
        for evt in event_types:
            if evt['type'] == 'alert':
                found_alert = True
                break
                
        if not found_alert:
            event_types.append({'type': 'alert', 'count': 0})
        
        return jsonify({
            'success': True,
            'event_types': event_types
        })
        
    except Exception as e:
        logger.error(f"Error getting trigger event types: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/trigger_events/create', methods=['POST'])
def create_custom_trigger_event():
    """
    Create a custom user-defined trigger event.
    
    This endpoint allows users to manually add annotations to the equity charts.
    
    Request Body:
        preset_id (int): ID of the strategy preset to create the event for
        event_type (str): Event type (e.g., 'user_note', 'entry_exit', 'custom')
        title (str): Short event title
        description (str, optional): Detailed description
        timestamp (str): Event timestamp in ISO format
        color (str, optional): CSS color for the trigger point
        icon (str, optional): Icon identifier
        importance (int, optional): Importance level (1-5)
        
    Returns:
        JSON: Created trigger event
    """
    try:
        data = request.json
        
        # Validate required fields
        required_fields = ['preset_id', 'event_type', 'title', 'timestamp']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'error': f'Missing required field: {field}'}), 400
                
        preset_id = data.get('preset_id')
        
        # Get the preset
        preset = StrategyPreset.query.get(preset_id)
        if not preset:
            return jsonify({'success': False, 'error': 'Preset not found'}), 404
            
        # Parse timestamp
        try:
            timestamp = datetime.fromisoformat(data['timestamp'].replace('Z', '+00:00'))
        except ValueError:
            return jsonify({'success': False, 'error': 'Invalid timestamp format'}), 400
            
        # Create new trigger event
        trigger_event = PresetTriggerEvent(
            preset_id=preset_id,
            event_type=data.get('event_type'),
            event_subtype=data.get('event_subtype'),
            title=data.get('title'),
            description=data.get('description'),
            timestamp=timestamp,
            color=data.get('color'),
            icon=data.get('icon'),
            importance=data.get('importance', 3),  # Default to importance level 3
            context_data=data.get('context_data'),
            is_auto_generated=False,  # Custom events are never auto-generated
            created_by=data.get('created_by', 'user')
        )
        
        db.session.add(trigger_event)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Custom event created successfully',
            'event': trigger_event.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error creating custom trigger event: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/trigger_events/generate_auto', methods=['POST'])
def generate_auto_trigger_events():
    """
    Generate automated trigger events based on system data.
    
    This endpoint analyzes the system state and generates appropriate trigger events
    for things like significant rotation events, policy activations, etc.
    
    Request Body:
        preset_id (int): ID of the strategy preset to generate events for
        lookback_days (int, optional): Number of days to look back for generating events
        types (list, optional): List of event types to generate (defaults to all)
        
    Returns:
        JSON: Generated trigger events
    """
    try:
        data = request.json
        
        # Validate required fields
        if 'preset_id' not in data:
            return jsonify({'success': False, 'error': 'Missing required field: preset_id'}), 400
            
        preset_id = data['preset_id']
        
        # Get the preset
        preset = StrategyPreset.query.get(preset_id)
        if not preset:
            return jsonify({'success': False, 'error': 'Preset not found'}), 404
            
        # Determine lookback period
        lookback_days = data.get('lookback_days', 30)
        start_date = datetime.utcnow() - timedelta(days=lookback_days)
        
        # Types of events to generate
        event_types = data.get('types', ['policy_activation', 'market_shift', 'weight_change'])
        
        # Store generated events
        generated_events = []
        
        # 1. Generate policy activation events if requested
        if 'policy_activation' in event_types and preset.config_type == 'rotation':
            # Find rotation events from auto_rotation_engine logs or history
            if hasattr(auto_rotation_engine, 'get_rotation_history'):
                rotation_history = auto_rotation_engine.get_rotation_history()
                
                for rotation_event in rotation_history:
                    if rotation_event.get('timestamp') >= start_date.timestamp():
                        # Create a trigger event for each rotation
                        trigger_event = PresetTriggerEvent(
                            preset_id=preset_id,
                            event_type='policy_activation',
                            event_subtype=rotation_event.get('trigger_type', 'unknown'),
                            title=f"Rotation: {rotation_event.get('description', 'Policy Activated')}",
                            description=f"Automatic rotation triggered by {rotation_event.get('trigger_type')} policy.",
                            timestamp=datetime.fromtimestamp(rotation_event.get('timestamp')),
                            color='#007bff',  # Blue
                            icon='bi-shuffle',
                            importance=3,
                            context_data=rotation_event,
                            is_auto_generated=True,
                            created_by='system'
                        )
                        
                        db.session.add(trigger_event)
                        generated_events.append(trigger_event)
        
        # 2. Generate market shift events if requested
        if 'market_shift' in event_types:
            # Look at equity history to find significant market shifts
            equity_history = PresetEquityHistory.query.filter_by(preset_id=preset_id) \
                .filter(PresetEquityHistory.timestamp >= start_date) \
                .order_by(PresetEquityHistory.timestamp).all()
                
            if equity_history:
                # Find points where market conditions changed
                prev_condition = None
                for entry in equity_history:
                    if entry.market_conditions and entry.market_conditions != prev_condition:
                        if prev_condition:  # Only generate event if there was a change
                            trigger_event = PresetTriggerEvent(
                                preset_id=preset_id,
                                event_type='market_shift',
                                event_subtype=entry.market_conditions,
                                title=f"Market Shift: {prev_condition} → {entry.market_conditions}",
                                description=f"Market conditions changed from {prev_condition} to {entry.market_conditions}.",
                                timestamp=entry.timestamp,
                                color='#ffc107',  # Yellow/warning
                                icon='bi-graph-up-arrow',
                                importance=4,
                                context_data={
                                    'previous_condition': prev_condition,
                                    'new_condition': entry.market_conditions,
                                    'equity': entry.equity,
                                    'drawdown': entry.drawdown_percent
                                },
                                is_auto_generated=True,
                                created_by='system'
                            )
                            
                            db.session.add(trigger_event)
                            generated_events.append(trigger_event)
                            
                        prev_condition = entry.market_conditions
        
        # 3. Generate significant weight change events if requested
        if 'weight_change' in event_types and preset.config_type == 'ensemble':
            config_data = preset.config_data
            if 'weights_history' in config_data:
                weights_history = config_data['weights_history']
                
                # Process each weights change event
                prev_weights = None
                for weight_event in weights_history:
                    event_time = datetime.fromisoformat(weight_event.get('timestamp').replace('Z', '+00:00'))
                    
                    if event_time >= start_date:
                        current_weights = weight_event.get('weights', {})
                        
                        # Skip if this is the first entry (no change to detect)
                        if prev_weights:
                            # Calculate the magnitude of change
                            significant_change = False
                            change_description = []
                            
                            for strategy, weight in current_weights.items():
                                prev_weight = prev_weights.get(strategy, 0)
                                change = weight - prev_weight
                                
                                # Consider significant if >10% change
                                if abs(change) > 0.1:
                                    significant_change = True
                                    change_str = f"+{change:.2f}" if change > 0 else f"{change:.2f}"
                                    change_description.append(f"{strategy}: {change_str}")
                            
                            if significant_change:
                                trigger_event = PresetTriggerEvent(
                                    preset_id=preset_id,
                                    event_type='weight_change',
                                    event_subtype='significant',
                                    title=f"Significant Weight Change",
                                    description="Strategy weights changed: " + ", ".join(change_description),
                                    timestamp=event_time,
                                    color='#17a2b8',  # Info color
                                    icon='bi-sliders',
                                    importance=2,
                                    context_data={
                                        'previous_weights': prev_weights,
                                        'new_weights': current_weights,
                                        'changes': {
                                            s: current_weights.get(s, 0) - prev_weights.get(s, 0) 
                                            for s in set(list(current_weights.keys()) + list(prev_weights.keys()))
                                        }
                                    },
                                    is_auto_generated=True,
                                    created_by='system'
                                )
                                
                                db.session.add(trigger_event)
                                generated_events.append(trigger_event)
                        
                        prev_weights = current_weights
        
        # Commit all generated events
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'Generated {len(generated_events)} trigger events',
            'events': [event.to_dict() for event in generated_events]
        })
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error generating auto trigger events: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500




def run_bot_script():
    """Run the bot script directly (for command line use)."""
    logger.info("Starting Binance Trading Bot in script mode...")
    
    # Get API credentials from environment variables with fallbacks to config
    api_key = os.getenv("BINANCE_API_KEY", Config.API_KEY)
    api_secret = os.getenv("BINANCE_API_SECRET", Config.API_SECRET)
    
    if api_key == "YOUR_BINANCE_API_KEY" or api_secret == "YOUR_BINANCE_SECRET_KEY":
        logger.warning("Using placeholder API credentials. Please set your actual Binance API keys.")
        logger.info("Running in paper trading mode for safety.")
        paper_trading = True
    else:
        paper_trading = Config.PAPER_TRADING
    
    try:
        # Initialize the trading bot
        bot = TradingBot(
            api_key=api_key,
            api_secret=api_secret,
            trading_pairs=Config.TRADING_PAIRS,
            base_position_size=Config.BASE_POSITION_SIZE,
            check_interval=Config.CHECK_INTERVAL,
            paper_trading=paper_trading
        )
        
        logger.info(f"Bot initialized successfully with the following settings:")
        logger.info(f"Trading pairs: {', '.join(Config.TRADING_PAIRS)}")
        logger.info(f"Base position size: ${Config.BASE_POSITION_SIZE} USDT")
        logger.info(f"Check interval: {Config.CHECK_INTERVAL} seconds")
        logger.info(f"Paper trading mode: {'ON' if paper_trading else 'OFF'}")
        
        # Run the bot in an infinite loop
        while True:
            try:
                bot.check_and_execute_trades()
                logger.debug(f"Sleeping for {Config.CHECK_INTERVAL} seconds")
                time.sleep(Config.CHECK_INTERVAL)
            except KeyboardInterrupt:
                logger.info("Bot stopped by user.")
                break
            except Exception as e:
                logger.error(f"Error in main bot loop: {e}")
                logger.info(f"Waiting {Config.CHECK_INTERVAL} seconds before next attempt.")
                time.sleep(Config.CHECK_INTERVAL)
                
    except Exception as e:
        logger.error(f"Failed to initialize trading bot: {e}")
        return

# Risk Management Routes and Functions

@app.route('/risk_management')
def risk_management():
    """Risk Management Dashboard Page."""
    # Generate risk status data for the dashboard
    risk_status = get_risk_status()
    
    return render_template(
        'risk_management.html',
        risk_status=risk_status,
        bot_status=bot_status,
        last_check_time=last_check_time.strftime('%Y-%m-%d %H:%M:%S') if last_check_time else None
    )

@app.route('/api/risk/status')
def api_risk_status():
    """API endpoint to get risk management status."""
    return jsonify(get_risk_status())

@app.route('/api/risk/toggle', methods=['POST'])
def api_risk_toggle():
    """API endpoint to enable/disable the risk management system."""
    data = request.json
    enabled = data.get('enabled', False)
    
    if risk_manager:
        try:
            risk_manager.enabled = enabled
            return jsonify({
                'success': True,
                'enabled': risk_manager.enabled
            })
        except Exception as e:
            logger.error(f"Error toggling risk management system: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    else:
        return jsonify({
            'success': False,
            'error': 'Risk management system is not available'
        }), 500

@app.route('/manual_risk_off', methods=['POST'])
def manual_risk_off():
    """Manually trigger a risk-off event."""
    if risk_manager:
        try:
            risk_level = request.form.get('risk_level', 'ELEVATED')
            reason = request.form.get('reason', 'Manual trigger by user')
            
            # Convert string to enum
            risk_enum = getattr(RiskLevel, risk_level)
            
            # Trigger risk-off manually
            risk_manager.manual_risk_off(risk_enum, reason)
            
            flash(f'Risk-Off triggered manually at level: {risk_level}', 'warning')
        except Exception as e:
            logger.error(f"Error manually triggering risk-off: {e}")
            flash(f'Error triggering Risk-Off: {str(e)}', 'danger')
    else:
        flash('Risk management system is not available', 'danger')
        
    return redirect(url_for('risk_management'))

@app.route('/reset_to_normal', methods=['POST'])
def reset_to_normal():
    """Reset risk level to normal."""
    if risk_manager:
        try:
            risk_manager.manual_reset_to_normal('Manual reset by user')
            flash('Risk level reset to NORMAL', 'success')
        except Exception as e:
            logger.error(f"Error resetting risk level to normal: {e}")
            flash(f'Error resetting risk level: {str(e)}', 'danger')
    else:
        flash('Risk management system is not available', 'danger')
        
    return redirect(url_for('risk_management'))

@app.route('/update_risk_config', methods=['POST'])
def update_risk_config():
    """Update risk management configuration."""
    if risk_manager:
        try:
            # Get form data
            check_interval = int(request.form.get('check_interval_minutes', 5))
            recovery_interval = int(request.form.get('recovery_check_interval_minutes', 15))
            should_scale = 'should_scale_positions' in request.form
            should_modify_sl = 'should_modify_stop_losses' in request.form
            should_switch = 'should_switch_strategies' in request.form
            should_pause = 'should_pause_capital_scaling' in request.form
            
            # Update risk manager configuration
            risk_manager.check_interval_minutes = check_interval
            risk_manager.recovery_check_interval_minutes = recovery_interval
            risk_manager.should_scale_positions = should_scale
            risk_manager.should_modify_stop_losses = should_modify_sl
            risk_manager.should_switch_strategies = should_switch
            risk_manager.should_pause_capital_scaling = should_pause
            
            # Handle severe risk multiplier if it exists
            if hasattr(risk_manager, 'severe_risk_position_multiplier'):
                severe_multiplier = float(request.form.get('severe_risk_position_multiplier', 0.3))
                risk_manager.severe_risk_position_multiplier = severe_multiplier
            
            flash('Risk management configuration updated successfully', 'success')
        except Exception as e:
            logger.error(f"Error updating risk management configuration: {e}")
            flash(f'Error updating configuration: {str(e)}', 'danger')
    else:
        flash('Risk management system is not available', 'danger')
        
    return redirect(url_for('risk_management'))

# Risk Alert Management Endpoints
@app.route('/api/risk/alerts', methods=['GET'])
def get_risk_alerts():
    """API endpoint to get recent risk alerts."""
    if not alert_notifier:
        return jsonify({
            'success': False,
            'error': 'Alert notification system not available'
        }), 404
        
    try:
        # Get query parameters
        limit = request.args.get('limit', default=20, type=int)
        alert_type = request.args.get('type', default=None, type=str)
        
        # Fetch recent alerts
        alerts = alert_notifier.get_recent_alerts(limit=limit, alert_type=alert_type)
        
        return jsonify({
            'success': True,
            'alerts': alerts
        })
    except Exception as e:
        logger.error(f"Error getting risk alerts: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/risk/alerts/count', methods=['GET'])
def get_risk_alerts_count():
    """API endpoint to get alert counts by priority."""
    if not alert_notifier:
        return jsonify({
            'success': False,
            'error': 'Alert notification system not available'
        }), 404
        
    try:
        # Get alert counts
        counts = alert_notifier.get_alerts_count_by_priority()
        
        return jsonify({
            'success': True,
            'counts': counts
        })
    except Exception as e:
        logger.error(f"Error getting alert counts: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/risk/alerts/test', methods=['POST'])
def send_test_alert():
    """API endpoint to send a test alert to verify notification channels."""
    if not alert_notifier:
        return jsonify({
            'success': False,
            'error': 'Alert notification system not available'
        }), 404
        
    try:
        data = request.json
        channels = data.get('channels', ['email', 'web'])
        
        # Convert string channel names to enum values
        channel_enums = []
        for channel in channels:
            if channel.upper() == 'EMAIL':
                channel_enums.append(AlertChannel.EMAIL)
            elif channel.upper() == 'SMS':
                channel_enums.append(AlertChannel.SMS)
            elif channel.upper() == 'WEB':
                channel_enums.append(AlertChannel.WEB)
        
        # Send test alert
        result = alert_notifier.send_alert(
            alert_type='test',
            message="This is a test alert from the risk management system",
            details={
                'timestamp': datetime.now().isoformat(),
                'test': True,
                'source': 'manual_test'
            },
            priority='medium',
            channels=channel_enums
        )
        
        return jsonify({
            'success': True,
            'result': result
        })
    except Exception as e:
        logger.error(f"Error sending test alert: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/risk/alerts/config', methods=['GET'])
def get_alert_config():
    """API endpoint to get the current alert configuration."""
    if not alert_notifier:
        return jsonify({
            'success': False,
            'error': 'Alert notification system not available'
        }), 404
        
    try:
        # Get alert configuration
        config = {
            'email_config': getattr(alert_notifier, 'email_config', {}),
            'sms_config': getattr(alert_notifier, 'sms_config', {}),
            'web_config': getattr(alert_notifier, 'web_config', {}),
            'alert_types': getattr(alert_notifier, 'alert_types_config', {})
        }
        
        # Redact sensitive information
        if 'api_key' in config['email_config']:
            config['email_config']['api_key'] = '********'
        if 'auth_token' in config['sms_config']:
            config['sms_config']['auth_token'] = '********'
        
        return jsonify({
            'success': True,
            'config': config
        })
    except Exception as e:
        logger.error(f"Error getting alert configuration: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/risk/alerts/config', methods=['POST'])
def update_alert_config():
    """API endpoint to update the alert configuration."""
    if not alert_notifier:
        return jsonify({
            'success': False,
            'error': 'Alert notification system not available'
        }), 404
        
    try:
        data = request.json
        
        # Update email configuration
        if 'email_config' in data:
            alert_notifier.update_channel_settings('email', data['email_config'])
            
        # Update SMS configuration
        if 'sms_config' in data:
            alert_notifier.update_channel_settings('sms', data['sms_config'])
            
        # Update web configuration
        if 'web_config' in data:
            alert_notifier.update_channel_settings('web', data['web_config'])
            
        # Update alert type configurations
        if 'alert_types' in data:
            for alert_type, settings in data['alert_types'].items():
                alert_notifier.update_alert_config(alert_type, settings)
        
        return jsonify({
            'success': True,
            'message': 'Alert configuration updated successfully'
        })
    except Exception as e:
        logger.error(f"Error updating alert configuration: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/risk/alerts/clear', methods=['POST'])
def clear_alert_history():
    """API endpoint to clear the alert history."""
    if not alert_notifier:
        return jsonify({
            'success': False,
            'error': 'Alert notification system not available'
        }), 404
        
    try:
        # Clear alert history
        success = alert_notifier.clear_history()
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Alert history cleared successfully'
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Failed to clear alert history'
            }), 500
    except Exception as e:
        logger.error(f"Error clearing alert history: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/configure_alerts', methods=['GET', 'POST'])
def configure_alerts():
    """Configure alert notification settings."""
    if not alert_notifier:
        flash('Alert notification system not available', 'danger')
        return redirect(url_for('risk_management'))
        
    if request.method == 'POST':
        try:
            # Email settings
            email_enabled = 'email_enabled' in request.form
            from_email = request.form.get('from_email', '')
            to_email = request.form.get('to_email', '')
            
            # SMS settings
            sms_enabled = 'sms_enabled' in request.form
            phone_number = request.form.get('phone_number', '')
            
            # API Keys
            sendgrid_key = request.form.get('sendgrid_api_key', '')
            twilio_account_sid = request.form.get('twilio_account_sid', '')
            twilio_auth_token = request.form.get('twilio_auth_token', '')
            twilio_phone = request.form.get('twilio_phone_number', '')
            
            # Configure Email
            if email_enabled:
                email_config = {
                    'enabled': True,
                    'from_email': from_email,
                    'to_email': to_email
                }
                
                # Only update API key if provided
                if sendgrid_key and sendgrid_key != '********':
                    email_config['api_key'] = sendgrid_key
                    
                alert_notifier.update_channel_settings('email', email_config)
            else:
                alert_notifier.update_channel_settings('email', {'enabled': False})
                
            # Configure SMS
            if sms_enabled:
                sms_config = {
                    'enabled': True,
                    'to_number': phone_number
                }
                
                # Only update API credentials if provided
                if twilio_account_sid and twilio_account_sid != '********':
                    sms_config['account_sid'] = twilio_account_sid
                    
                if twilio_auth_token and twilio_auth_token != '********':
                    sms_config['auth_token'] = twilio_auth_token
                    
                if twilio_phone and twilio_phone != '********':
                    sms_config['from_number'] = twilio_phone
                    
                alert_notifier.update_channel_settings('sms', sms_config)
            else:
                alert_notifier.update_channel_settings('sms', {'enabled': False})
                
            flash('Alert notification settings updated successfully', 'success')
        except Exception as e:
            logger.error(f"Error updating alert settings: {e}")
            flash(f'Error updating alert settings: {str(e)}', 'danger')
            
        return redirect(url_for('configure_alerts'))
        
    # Get current configuration
    try:
        # Get alert configuration
        email_config = getattr(alert_notifier, 'email_config', {})
        sms_config = getattr(alert_notifier, 'sms_config', {})
        alert_types = getattr(alert_notifier, 'alert_types_config', {})
        
        # Redact API keys for display
        if 'api_key' in email_config:
            email_config['api_key'] = '********'
        if 'auth_token' in sms_config:
            sms_config['auth_token'] = '********'
        if 'account_sid' in sms_config:
            sms_config['account_sid'] = '********'
        if 'from_number' in sms_config:
            sms_config['from_number'] = '********'
            
        return render_template(
            'configure_alerts.html',
            email_config=email_config,
            sms_config=sms_config,
            alert_types=alert_types,
            bot_status=bot_status
        )
    except Exception as e:
        logger.error(f"Error getting alert configuration: {e}")
        flash(f'Error getting alert configuration: {str(e)}', 'danger')
        return redirect(url_for('risk_management'))

@app.route('/send_test_notification', methods=['POST'])
def send_test_notification():
    """Send a test notification to verify configuration."""
    if not alert_notifier:
        flash('Alert notification system not available', 'danger')
        return redirect(url_for('configure_alerts'))
        
    try:
        # Get notification details
        channel = request.form.get('channel', 'web')
        message = request.form.get('message', 'This is a test notification')
        
        # Set up channels
        channels = []
        if channel == 'email':
            channels = [AlertChannel.EMAIL]
        elif channel == 'sms':
            channels = [AlertChannel.SMS]
        elif channel == 'all':
            channels = [AlertChannel.EMAIL, AlertChannel.SMS, AlertChannel.WEB]
        else:
            channels = [AlertChannel.WEB]
            
        # Send test alert
        result = alert_notifier.send_alert(
            alert_type='test',
            message=message,
            details={
                'timestamp': datetime.now().isoformat(),
                'test': True,
                'source': 'manual_test',
                'user_initiated': True
            },
            priority=AlertPriority.MEDIUM,
            channels=channels
        )
        
        if result.get('success', False):
            flash(f'Test notification sent successfully via {channel}', 'success')
        else:
            flash(f'Failed to send test notification: {result.get("error", "Unknown error")}', 'danger')
    except Exception as e:
        logger.error(f"Error sending test notification: {e}")
        flash(f'Error sending test notification: {str(e)}', 'danger')
        
    return redirect(url_for('configure_alerts'))

def get_risk_status():
    """Get the current status of the risk management system."""
    # Default status for when risk manager is not available
    default_status = {
        'enabled': False,
        'current_level': 'NORMAL',
        'current_level_since': datetime.now(),
        'position_size_multiplier': 1.0,
        'level_history': [],
        'action_history': [],
        'actions': {
            'reduced_position_sizes': False,
            'tightened_stop_losses': False,
            'paused_capital_scaling': False,
            'switched_to_defensive_strategies': False
        },
        'config': {
            'check_interval_minutes': 5,
            'recovery_check_interval_minutes': 15,
            'should_scale_positions': True,
            'should_modify_stop_losses': True,
            'should_switch_strategies': True,
            'should_pause_capital_scaling': True,
            'severe_risk_position_multiplier': 0.3
        },
        'current_metrics': {
            'volatility': {
                'BTC_Volatility': {'value': 0.0, 'percent': 0, 'is_high_risk': False, 'is_medium_risk': False},
                'Market_Volatility': {'value': 0.0, 'percent': 0, 'is_high_risk': False, 'is_medium_risk': False}
            },
            'drawdown': {
                'Portfolio_Drawdown': {'value': 0.0, 'percent': 0, 'is_high_risk': False, 'is_medium_risk': False},
                'BTC_Drawdown': {'value': 0.0, 'percent': 0, 'is_high_risk': False, 'is_medium_risk': False}
            },
            'price_action': {
                'Short_Term_Momentum': {'value': 0.0, 'percent': 0, 'is_high_risk': False, 'is_medium_risk': False},
                'Sudden_Price_Change': {'value': 0.0, 'percent': 0, 'is_high_risk': False, 'is_medium_risk': False}
            },
            'trend_strength': {
                'BTC_Trend': {'value': 0.0, 'percent': 0, 'is_high_risk': False, 'is_medium_risk': False},
                'Market_Direction': {'value': 0.0, 'percent': 0, 'is_high_risk': False, 'is_medium_risk': False}
            }
        }
    }
    
    # Return default status if risk manager is not available
    if not risk_manager:
        return default_status
    
    try:
        # Get the current risk level and history
        status = {
            'enabled': risk_manager.enabled,
            'current_level': risk_manager.current_risk_level.name if hasattr(risk_manager, 'current_risk_level') else 'NORMAL',
            'current_level_since': risk_manager.current_level_since if hasattr(risk_manager, 'current_level_since') else datetime.now(),
            'position_size_multiplier': risk_manager.get_position_size_multiplier() if hasattr(risk_manager, 'get_position_size_multiplier') else 1.0,
            'level_history': risk_manager.risk_level_history if hasattr(risk_manager, 'risk_level_history') else [],
            'action_history': risk_manager.action_history if hasattr(risk_manager, 'action_history') else [],
            'actions': {
                'reduced_position_sizes': risk_manager.is_action_active('reduce_position_sizes') if hasattr(risk_manager, 'is_action_active') else False,
                'tightened_stop_losses': risk_manager.is_action_active('tighten_stop_losses') if hasattr(risk_manager, 'is_action_active') else False,
                'paused_capital_scaling': risk_manager.is_action_active('pause_capital_scaling') if hasattr(risk_manager, 'is_action_active') else False,
                'switched_to_defensive_strategies': risk_manager.is_action_active('switch_to_defensive_strategies') if hasattr(risk_manager, 'is_action_active') else False
            },
            'config': {
                'check_interval_minutes': risk_manager.check_interval_minutes,
                'recovery_check_interval_minutes': risk_manager.recovery_check_interval_minutes,
                'should_scale_positions': risk_manager.should_scale_positions,
                'should_modify_stop_losses': risk_manager.should_modify_stop_losses,
                'should_switch_strategies': risk_manager.should_switch_strategies,
                'should_pause_capital_scaling': risk_manager.should_pause_capital_scaling,
                'severe_risk_position_multiplier': getattr(risk_manager, 'severe_risk_position_multiplier', 0.3)
            }
        }
        
        # Get current metrics if available
        if hasattr(risk_manager, 'get_current_metrics'):
            status['current_metrics'] = risk_manager.get_current_metrics()
        else:
            status['current_metrics'] = default_status['current_metrics']
            
        return status
    except Exception as e:
        logger.error(f"Error getting risk status: {e}")
        return default_status

# Add risk management navigation menu item
@app.context_processor
def inject_nav_items():
    """Inject navigation items for the templates."""
    nav_items = [
        {'name': 'Dashboard', 'url': url_for('index'), 'icon': 'bi-speedometer2'},
        {'name': 'Portfolio', 'url': url_for('portfolio'), 'icon': 'bi-wallet2'},
        {'name': 'Trade History', 'url': url_for('trade_history'), 'icon': 'bi-clock-history'},
        {'name': 'Trade Log', 'url': url_for('trade_log'), 'icon': 'bi-list-check'},
        {'name': 'Risk Management', 'url': url_for('risk_management'), 'icon': 'bi-shield-check'}
    ]
    
    return {'nav_items': nav_items}

if __name__ == "__main__":
    import sys
    import os
    import socket
    
    # Check if port 5000 is already in use - this suggests we're in the crypto_bot workflow
    # since the "Start application" workflow would have already taken port 5000
    port_in_use = False
    try:
        test_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        test_socket.bind(('0.0.0.0', 5000))
        test_socket.close()
    except socket.error:
        port_in_use = True
    
    # If we're in the crypto_bot workflow or the script flag is used, run without Flask
    if port_in_use or ('--script' in sys.argv):
        logger.info("Running in bot script mode (without web interface)...")
        run_bot_script()
    else:
        # Otherwise, start the Flask server
        logger.info("Running in web interface mode...")
        app.run(host='0.0.0.0', port=5000)
