#!/usr/bin/env python3
"""
Backup Script for Crypto Trading System

This script creates a backup of all important project files by:
1. Creating a backup directory
2. Copying all Python files
3. Copying all HTML templates
4. Creating an archive file

Run this script, then download the resulting ZIP file.
"""

import os
import shutil
import zipfile
from datetime import datetime

# Configuration
BACKUP_DIR = "backup_crypto_system"
ARCHIVE_NAME = f"crypto_system_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"

# Files to include in backup
PYTHON_FILES = [f for f in os.listdir() if f.endswith('.py')]
HTML_DIRS = ['templates']
OTHER_FILES = ['BACKUP_GUIDE.md', 'dependencies_backup.txt']

def create_backup():
    """Create a complete backup of the trading system"""
    print(f"Creating backup directory: {BACKUP_DIR}")
    
    # Remove old backup directory if it exists
    if os.path.exists(BACKUP_DIR):
        shutil.rmtree(BACKUP_DIR)
    
    # Create fresh backup directory
    os.makedirs(BACKUP_DIR)
    
    # Copy Python files
    print(f"Backing up {len(PYTHON_FILES)} Python files...")
    for py_file in PYTHON_FILES:
        shutil.copy(py_file, os.path.join(BACKUP_DIR, py_file))
    
    # Copy HTML templates
    for html_dir in HTML_DIRS:
        if os.path.exists(html_dir):
            dest_dir = os.path.join(BACKUP_DIR, html_dir)
            print(f"Backing up {html_dir} directory...")
            shutil.copytree(html_dir, dest_dir)
    
    # Copy other important files
    for other_file in OTHER_FILES:
        if os.path.exists(other_file):
            print(f"Backing up {other_file}...")
            shutil.copy(other_file, os.path.join(BACKUP_DIR, other_file))
    
    # Create zip archive
    print(f"Creating ZIP archive: {ARCHIVE_NAME}...")
    with zipfile.ZipFile(ARCHIVE_NAME, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, _, files in os.walk(BACKUP_DIR):
            for file in files:
                file_path = os.path.join(root, file)
                zipf.write(file_path, os.path.relpath(file_path, BACKUP_DIR))
    
    print(f"Backup completed! Download the file: {ARCHIVE_NAME}")
    print("Remember that API keys and environment variables are NOT included in this backup.")

if __name__ == "__main__":
    create_backup()