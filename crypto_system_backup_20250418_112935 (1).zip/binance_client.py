"""
Binance Client Module
Handles interaction with the Binance exchange through CCXT.
Supports both real trading and paper trading.
"""
import logging
import ccxt
import pandas as pd
from datetime import datetime, timedelta
from paper_trading import PaperTradingExchange

logger = logging.getLogger(__name__)

class BinanceClient:
    """Client for interacting with the Binance exchange."""
    
    def __init__(self, api_key, api_secret, testnet=False, paper_trading=True):
        """
        Initialize the Binance client with API credentials.
        
        Args:
            api_key (str): Binance API key
            api_secret (str): Binance API secret
            testnet (bool): Whether to use the Binance testnet
            paper_trading (bool): Whether to use paper trading
        """
        self.api_key = api_key
        self.api_secret = api_secret
        self.paper_trading = paper_trading
        
        logger.info(f"Initializing Binance client with paper_trading={paper_trading}, testnet={testnet}")
        
        if paper_trading:
            # Use paper trading implementation
            try:
                self.exchange = PaperTradingExchange(api_key, api_secret, initial_balance=1000, testnet=testnet)
                logger.info("Paper trading exchange initialized successfully")
            except Exception as e:
                logger.error(f"Error initializing paper trading exchange: {e}")
                raise
        else:
            # Use real exchange
            try:
                # Initialize CCXT exchange object
                options = {}
                if testnet:
                    options['test'] = True
                    
                self.exchange = ccxt.binance({
                    'apiKey': api_key,
                    'secret': api_secret,
                    'enableRateLimit': True,
                    'options': options
                })
                
                # Load markets to get symbol info
                self.exchange.load_markets()
                logger.info("Real exchange initialized and markets loaded successfully")
            except Exception as e:
                logger.error(f"Error initializing real exchange: {e}")
                raise
            
    def get_historical_prices(self, symbol, timeframe='1m', limit=100):
        """
        Get historical price data for a symbol.
        
        Args:
            symbol (str): Trading pair symbol
            timeframe (str): Timeframe for candles (e.g., '1m', '5m', '1h')
            limit (int): Number of candles to fetch
            
        Returns:
            pandas.DataFrame: Historical price data
        """
        try:
            # Fetch OHLCV data using exchange (real or paper)
            ohlcv = self.exchange.fetch_ohlcv(symbol, timeframe, limit=limit)
            
            # Convert to DataFrame
            df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            
            return df
            
        except Exception as e:
            logger.error(f"Error fetching historical prices for {symbol}: {e}")
            raise
    
    def get_current_price(self, symbol):
        """
        Get the current price for a symbol.
        
        Args:
            symbol (str): Trading pair symbol
            
        Returns:
            float: Current price
        """
        try:
            ticker = self.exchange.fetch_ticker(symbol)
            return ticker['last']
            
        except Exception as e:
            logger.error(f"Error fetching current price for {symbol}: {e}")
            raise
    
    def create_market_buy_order(self, symbol, amount_usdt):
        """
        Create a market buy order.
        
        Args:
            symbol (str): Trading pair symbol
            amount_usdt (float): Amount to buy in USDT
            
        Returns:
            dict: Order details
        """
        try:
            # Get the current price
            current_price = self.get_current_price(symbol)
            
            # Calculate the quantity of the asset to buy
            quantity = amount_usdt / current_price
            
            # Execute the market buy order (real or paper)
            order = self.exchange.create_market_buy_order(symbol, quantity)
            
            if self.paper_trading:
                logger.info(f"Created PAPER market buy order for {symbol}: {quantity} at ~{current_price}")
            else:
                logger.info(f"Created REAL market buy order for {symbol}: {quantity} at ~{current_price}")
                
            return order
            
        except Exception as e:
            logger.error(f"Error creating market buy order for {symbol}: {e}")
            raise
    
    def create_market_sell_order(self, symbol, quantity):
        """
        Create a market sell order.
        
        Args:
            symbol (str): Trading pair symbol
            quantity (float): Quantity of the asset to sell
            
        Returns:
            dict: Order details
        """
        try:
            # Execute the market sell order (real or paper)
            order = self.exchange.create_market_sell_order(symbol, quantity)
            
            if self.paper_trading:
                logger.info(f"Created PAPER market sell order for {symbol}: {quantity}")
            else:
                logger.info(f"Created REAL market sell order for {symbol}: {quantity}")
                
            return order
            
        except Exception as e:
            logger.error(f"Error creating market sell order for {symbol}: {e}")
            raise
    
    def get_account_balance(self):
        """
        Get account balance information.
        
        Returns:
            dict: Account balance
        """
        try:
            balance = self.exchange.fetch_balance()
            
            if self.paper_trading:
                logger.info(f"Fetched PAPER account balance")
            else:
                logger.info(f"Fetched REAL account balance")
                
            return balance
            
        except Exception as e:
            logger.error(f"Error fetching account balance: {e}")
            raise
            
    def get_portfolio_summary(self):
        """
        Get portfolio summary with USD values.
        
        Returns:
            dict: Portfolio summary including total USD value
        """
        if self.paper_trading and hasattr(self.exchange, 'get_account_balance_summary'):
            try:
                return self.exchange.get_account_balance_summary()
            except Exception as e:
                logger.error(f"Error getting paper trading portfolio summary: {e}")
                return {'balances': {}, 'total_usd_value': 0}
        else:
            try:
                # For real exchange, calculate portfolio value
                balance = self.get_account_balance()
                
                summary = {}
                total_usd_value = 0
                
                for currency, amount in balance['free'].items():
                    if amount <= 0:
                        continue
                        
                    if currency == 'USDT':
                        usd_value = amount
                    else:
                        try:
                            symbol = f"{currency}/USDT"
                            ticker = self.exchange.fetch_ticker(symbol)
                            price = ticker['last']
                            usd_value = amount * price
                        except:
                            usd_value = 0
                    
                    summary[currency] = {
                        'amount': amount,
                        'usd_value': usd_value
                    }
                    total_usd_value += usd_value
                
                return {
                    'balances': summary,
                    'total_usd_value': total_usd_value
                }
            except Exception as e:
                logger.error(f"Error calculating portfolio summary: {e}")
                return {'balances': {}, 'total_usd_value': 0}
