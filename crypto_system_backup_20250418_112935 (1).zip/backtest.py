"""
Backtesting Engine for Cryptocurrency Trading Strategies

This module provides functionality for backtesting trading strategies against
historical OHLCV (Open, High, Low, Close, Volume) data. It allows users to:
- Load historical data from CSV files or fetch from exchange API
- Run strategies against historical data
- Calculate performance metrics (win rate, PnL, drawdown, etc.)
- Visualize trades and equity curve

Usage:
    backtester = Backtester(strategy_name="dip_buyer", params={...})
    results = backtester.run(ohlcv_data)
    metrics = backtester.get_performance_metrics()
    
    # or with file input
    results = backtester.run_from_csv("btc_usdt_1h.csv")
"""
import os
import logging
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
import matplotlib.pyplot as plt
from strategies import get_strategy
from config import Config
from chart_utils import generate_ohlc_chart, generate_performance_chart

logger = logging.getLogger(__name__)

class Backtester:
    """
    Backtesting engine for cryptocurrency trading strategies.
    
    This class provides functionality to test trading strategies against
    historical price data and analyze the results.
    """
    
    def __init__(self, strategy_name, params=None, initial_balance=1000.0):
        """
        Initialize the backtester with a strategy and parameters.
        
        Args:
            strategy_name (str): Name of the strategy to backtest (e.g., "dip_buyer")
            params (dict, optional): Strategy-specific parameters to override defaults
            initial_balance (float, optional): Initial balance in USDT for the backtest
        """
        self.strategy_name = strategy_name
        self.strategy_params = params or {}
        self.initial_balance = initial_balance
        self.current_balance = initial_balance
        self.trades = []
        self.open_positions = {}
        self.equity_curve = []
        self.current_time = None
        self.results = None
        self.stop_loss_pct = params.get('stop_loss', Config.STOP_LOSS)
        self.take_profit_pct = params.get('take_profit', Config.TAKE_PROFIT)
        
        # Load the strategy
        self.strategy = self._load_strategy()
        
    def _load_strategy(self):
        """
        Load the trading strategy by name.
        
        Returns:
            object: Strategy instance
        """
        try:
            # Use the get_strategy function to get the strategy instance
            strategy_instance = get_strategy(self.strategy_name, **self.strategy_params)
            return strategy_instance
        except Exception as e:
            logger.error(f"Error loading strategy '{self.strategy_name}': {e}")
            raise ValueError(f"Could not load strategy '{self.strategy_name}': {e}")
    
    def run_from_csv(self, file_path, symbol=None, timeframe=None):
        """
        Run backtest using OHLCV data from a CSV file.
        
        Args:
            file_path (str): Path to the CSV file containing OHLCV data
            symbol (str, optional): Trading pair symbol (e.g., "BTC/USDT")
            timeframe (str, optional): Timeframe of the data (e.g., "1h")
            
        Returns:
            dict: Backtest results
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"CSV file not found: {file_path}")
        
        try:
            # Determine the file format and load accordingly
            df = pd.read_csv(file_path)
            
            # Try to automatically detect column names
            required_columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume']
            column_mapping = {}
            
            for required_col in required_columns:
                # Look for exact match first
                if required_col in df.columns:
                    column_mapping[required_col] = required_col
                else:
                    # Look for case-insensitive match
                    matches = [col for col in df.columns if col.lower() == required_col.lower()]
                    if matches:
                        column_mapping[required_col] = matches[0]
                    else:
                        # Use heuristics for common variations
                        if required_col == 'timestamp':
                            time_cols = [col for col in df.columns if 'time' in col.lower() or 'date' in col.lower()]
                            if time_cols:
                                column_mapping[required_col] = time_cols[0]
                        elif required_col == 'close':
                            close_cols = [col for col in df.columns if 'close' in col.lower() or 'price' in col.lower()]
                            if close_cols:
                                column_mapping[required_col] = close_cols[0]
            
            # Verify we found all required columns
            missing_cols = [col for col in required_columns if col not in column_mapping]
            if missing_cols:
                raise ValueError(f"Could not identify columns for: {', '.join(missing_cols)}")
            
            # Rename columns to standard format
            df = df.rename(columns={column_mapping[col]: col for col in required_columns})
            
            # Convert timestamp to datetime if it's not already
            if not pd.api.types.is_datetime64_any_dtype(df['timestamp']):
                try:
                    # Try parsing as Unix timestamp (seconds or milliseconds)
                    if pd.api.types.is_numeric_dtype(df['timestamp']):
                        if df['timestamp'].iloc[0] > 1e10:  # Milliseconds
                            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
                        else:  # Seconds
                            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s')
                    else:
                        # Try parsing as string date
                        df['timestamp'] = pd.to_datetime(df['timestamp'])
                except Exception as e:
                    raise ValueError(f"Could not parse timestamp column: {e}")
            
            # Sort by timestamp to ensure chronological order
            df = df.sort_values('timestamp')
            
            # Extract symbol from filename if not provided
            if symbol is None:
                filename = os.path.basename(file_path)
                parts = filename.split('_')
                if len(parts) >= 2:
                    symbol = f"{parts[0].upper()}/{parts[1].upper()}"
                else:
                    symbol = "UNKNOWN/USDT"
            
            # Extract timeframe from filename if not provided
            if timeframe is None:
                filename = os.path.basename(file_path)
                timeframe_patterns = ['1m', '5m', '15m', '30m', '1h', '4h', '1d']
                for pattern in timeframe_patterns:
                    if pattern in filename:
                        timeframe = pattern
                        break
                if timeframe is None:
                    timeframe = "1h"  # Default
            
            # Convert to OHLCV format for backtest
            ohlcv_data = df[['timestamp', 'open', 'high', 'low', 'close', 'volume']].values.tolist()
            
            # Run the backtest
            return self.run(ohlcv_data, symbol, timeframe)
            
        except Exception as e:
            logger.error(f"Error loading CSV data: {e}")
            raise ValueError(f"Failed to load OHLCV data from CSV: {e}")
    
    def run(self, ohlcv_data, symbol="BTC/USDT", timeframe="1h"):
        """
        Run the backtest on provided OHLCV data.
        
        Args:
            ohlcv_data (list or pd.DataFrame): OHLCV data in format [timestamp, open, high, low, close, volume]
            symbol (str, optional): Trading pair symbol
            timeframe (str, optional): Timeframe of the data
            
        Returns:
            dict: Backtest results
        """
        # Reset backtest state
        self.current_balance = self.initial_balance
        self.trades = []
        self.open_positions = {}
        self.equity_curve = []
        
        # Convert to DataFrame if it's a list
        if isinstance(ohlcv_data, list):
            df = pd.DataFrame(ohlcv_data, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        else:
            df = ohlcv_data.copy()
            
        # Ensure timestamp is in datetime format
        if not pd.api.types.is_datetime64_any_dtype(df['timestamp']):
            if pd.api.types.is_numeric_dtype(df['timestamp']):
                if df['timestamp'].iloc[0] > 1e10:  # Milliseconds
                    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
                else:  # Seconds
                    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s')
            else:
                df['timestamp'] = pd.to_datetime(df['timestamp'])
        
        # Sort by timestamp
        df = df.sort_values('timestamp')
        
        # Store metadata
        self.symbol = symbol
        self.timeframe = timeframe
        self.start_time = df['timestamp'].iloc[0]
        self.end_time = df['timestamp'].iloc[-1]
        
        # Initialize equity curve with starting balance
        self.equity_curve.append({
            'timestamp': self.start_time,
            'balance': self.current_balance,
            'equity': self.current_balance  # Equity = balance + value of open positions
        })
        
        # Process each candle
        for i, row in df.iterrows():
            candle = {
                'timestamp': row['timestamp'],
                'open': row['open'],
                'high': row['high'],
                'low': row['low'],
                'close': row['close'],
                'volume': row['volume']
            }
            
            self.current_time = candle['timestamp']
            
            # Update equity curve with current candle's close price
            self._update_equity_curve(candle)
            
            # Check for exit signals on existing positions
            self._check_exits(candle)
            
            # Check for entry signals if we have capacity for new positions
            if len(self.open_positions) < Config.MAX_OPEN_POSITIONS:
                self._check_entries(candle, df.iloc[:i+1])
        
        # Close any remaining open positions at the last price
        last_candle = {
            'timestamp': df['timestamp'].iloc[-1],
            'open': df['open'].iloc[-1],
            'high': df['high'].iloc[-1],
            'low': df['low'].iloc[-1],
            'close': df['close'].iloc[-1],
            'volume': df['volume'].iloc[-1]
        }
        
        self._close_all_positions(last_candle)
        
        # Calculate final performance metrics
        self.results = self._calculate_results()
        
        return self.results
    
    def _check_entries(self, candle, historical_data):
        """
        Check for entry signals on the current candle.
        
        Args:
            candle (dict): Current candle data
            historical_data (pd.DataFrame): Historical OHLCV data up to current candle
        """
        # Prepare data for strategy
        strategy_data = {
            'symbol': self.symbol,
            'ohlcv': historical_data.to_dict('records'),
            'current_candle': candle
        }
        
        # Check for entry signal
        try:
            entry_signal = self.strategy.check_entry(strategy_data)
            
            if entry_signal:
                # Calculate position size (use a fixed percentage of balance)
                position_size_usd = self.current_balance * 0.1  # 10% of balance per trade
                
                # Limit to max trade size in Config
                max_trade_size_usd = self.strategy_params.get('max_trade_size_usd', Config.MAX_TRADE_SIZE_USD)
                max_trade_size_pct = self.strategy_params.get('max_trade_size_pct', Config.MAX_TRADE_SIZE_PCT) / 100
                
                position_size_usd = min(
                    position_size_usd,
                    max_trade_size_usd,
                    self.current_balance * max_trade_size_pct
                )
                
                # Calculate quantity
                entry_price = candle['close']
                quantity = position_size_usd / entry_price
                
                # Create the position
                position_id = f"{self.symbol}_{len(self.trades)}"
                position = {
                    'id': position_id,
                    'symbol': self.symbol,
                    'entry_time': candle['timestamp'],
                    'entry_price': entry_price,
                    'quantity': quantity,
                    'position_size_usd': position_size_usd,
                    'strategy': self.strategy_name,
                    'params': self.strategy_params,
                    'stop_loss': entry_price * (1 - self.stop_loss_pct / 100),
                    'take_profit': entry_price * (1 + self.take_profit_pct / 100)
                }
                
                # Add to open positions
                self.open_positions[position_id] = position
                
                # Deduct from balance
                self.current_balance -= position_size_usd
                
                logger.info(f"[BACKTEST] {candle['timestamp']} - Entry signal for {self.symbol} at {entry_price}")
        
        except Exception as e:
            logger.error(f"Error checking entry signal: {e}")
    
    def _check_exits(self, candle):
        """
        Check for exit signals on open positions.
        
        Args:
            candle (dict): Current candle data
        """
        positions_to_close = []
        
        for position_id, position in self.open_positions.items():
            # Check stop loss
            if candle['low'] <= position['stop_loss']:
                # Stop loss hit, close at stop loss price
                positions_to_close.append({
                    'position_id': position_id,
                    'exit_price': position['stop_loss'],
                    'exit_time': candle['timestamp'],
                    'reason': 'stop_loss'
                })
                continue
                
            # Check take profit
            if candle['high'] >= position['take_profit']:
                # Take profit hit, close at take profit price
                positions_to_close.append({
                    'position_id': position_id,
                    'exit_price': position['take_profit'],
                    'exit_time': candle['timestamp'],
                    'reason': 'take_profit'
                })
                continue
                
            # Check strategy-specific exit signal
            try:
                # Prepare data for strategy
                position_data = {
                    'position': position,
                    'current_candle': candle
                }
                
                exit_signal = self.strategy.check_exit(position_data)
                
                if exit_signal:
                    # Strategy exit signal, close at current close price
                    positions_to_close.append({
                        'position_id': position_id,
                        'exit_price': candle['close'],
                        'exit_time': candle['timestamp'],
                        'reason': 'strategy_exit'
                    })
            
            except Exception as e:
                logger.error(f"Error checking exit signal: {e}")
        
        # Close positions that triggered exit conditions
        for exit_data in positions_to_close:
            self._close_position(
                exit_data['position_id'],
                exit_data['exit_price'],
                exit_data['exit_time'],
                exit_data['reason']
            )
    
    def _close_position(self, position_id, exit_price, exit_time, reason):
        """
        Close a position and record the trade.
        
        Args:
            position_id (str): ID of the position to close
            exit_price (float): Exit price
            exit_time (datetime): Exit time
            reason (str): Reason for exit (stop_loss, take_profit, strategy_exit)
        """
        if position_id not in self.open_positions:
            return
            
        position = self.open_positions[position_id]
        
        # Calculate profit/loss
        entry_value = position['entry_price'] * position['quantity']
        exit_value = exit_price * position['quantity']
        profit_loss = exit_value - entry_value
        profit_loss_pct = (exit_price / position['entry_price'] - 1) * 100
        
        # Create trade record
        trade = position.copy()
        trade.update({
            'exit_time': exit_time,
            'exit_price': exit_price,
            'profit_usdt': profit_loss,
            'profit_pct': profit_loss_pct,
            'exit_reason': reason
        })
        
        # Add to completed trades
        self.trades.append(trade)
        
        # Update balance
        self.current_balance += exit_value
        
        # Remove from open positions
        del self.open_positions[position_id]
        
        logger.info(f"[BACKTEST] {exit_time} - Closed position {position_id} for {self.symbol} at {exit_price}")
        logger.info(f"[BACKTEST] Profit/Loss: {profit_loss:.2f} USDT ({profit_loss_pct:.2f}%)")
    
    def _close_all_positions(self, last_candle):
        """
        Close all open positions at the end of the backtest.
        
        Args:
            last_candle (dict): Last candle in the data
        """
        positions_to_close = list(self.open_positions.keys())
        
        for position_id in positions_to_close:
            self._close_position(
                position_id,
                last_candle['close'],
                last_candle['timestamp'],
                'backtest_end'
            )
    
    def _update_equity_curve(self, candle):
        """
        Update the equity curve with the current balance and position values.
        
        Args:
            candle (dict): Current candle data
        """
        # Calculate total equity (balance + value of open positions)
        open_positions_value = 0
        for position in self.open_positions.values():
            current_value = position['quantity'] * candle['close']
            open_positions_value += current_value
        
        total_equity = self.current_balance + open_positions_value
        
        # Add to equity curve
        self.equity_curve.append({
            'timestamp': candle['timestamp'],
            'balance': self.current_balance,
            'equity': total_equity
        })
    
    def _calculate_results(self):
        """
        Calculate performance metrics for the backtest.
        
        Returns:
            dict: Performance metrics
        """
        if not self.trades:
            return {
                'symbol': self.symbol,
                'timeframe': self.timeframe,
                'strategy': self.strategy_name,
                'params': self.strategy_params,
                'start_time': self.start_time,
                'end_time': self.end_time,
                'initial_balance': self.initial_balance,
                'final_balance': self.current_balance,
                'profit_usdt': 0,
                'profit_pct': 0,
                'trade_count': 0,
                'win_count': 0,
                'loss_count': 0,
                'win_rate': 0,
                'max_drawdown': 0,
                'max_drawdown_pct': 0,
                'trades': [],
                'equity_curve': self.equity_curve
            }
        
        # Calculate basic metrics
        winning_trades = [t for t in self.trades if t['profit_usdt'] > 0]
        losing_trades = [t for t in self.trades if t['profit_usdt'] <= 0]
        
        win_count = len(winning_trades)
        loss_count = len(losing_trades)
        total_trades = len(self.trades)
        
        win_rate = (win_count / total_trades) * 100 if total_trades > 0 else 0
        
        total_profit = sum(t['profit_usdt'] for t in self.trades)
        profit_pct = ((self.current_balance / self.initial_balance) - 1) * 100
        
        # Calculate drawdown
        equity_values = [point['equity'] for point in self.equity_curve]
        peak = self.initial_balance
        drawdowns = []
        max_drawdown = 0
        max_drawdown_pct = 0
        
        for equity in equity_values:
            if equity > peak:
                peak = equity
            
            drawdown = peak - equity
            drawdown_pct = (drawdown / peak) * 100 if peak > 0 else 0
            
            drawdowns.append({
                'equity': equity,
                'peak': peak,
                'drawdown': drawdown,
                'drawdown_pct': drawdown_pct
            })
            
            if drawdown > max_drawdown:
                max_drawdown = drawdown
                max_drawdown_pct = drawdown_pct
        
        # Calculate average trade metrics
        avg_profit = total_profit / total_trades if total_trades > 0 else 0
        avg_win = sum(t['profit_usdt'] for t in winning_trades) / win_count if win_count > 0 else 0
        avg_loss = sum(t['profit_usdt'] for t in losing_trades) / loss_count if loss_count > 0 else 0
        
        # Calculate profit factor (gross profit / gross loss)
        gross_profit = sum(t['profit_usdt'] for t in winning_trades)
        gross_loss = abs(sum(t['profit_usdt'] for t in losing_trades))
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')
        
        # Compile results
        results = {
            'symbol': self.symbol,
            'timeframe': self.timeframe,
            'strategy': self.strategy_name,
            'params': self.strategy_params,
            'start_time': self.start_time,
            'end_time': self.end_time,
            'initial_balance': self.initial_balance,
            'final_balance': self.current_balance,
            'profit_usdt': total_profit,
            'profit_pct': profit_pct,
            'trade_count': total_trades,
            'win_count': win_count,
            'loss_count': loss_count,
            'win_rate': win_rate,
            'avg_profit': avg_profit,
            'avg_win': avg_win,
            'avg_loss': avg_loss,
            'profit_factor': profit_factor,
            'max_drawdown': max_drawdown,
            'max_drawdown_pct': max_drawdown_pct,
            'trades': self.trades,
            'equity_curve': self.equity_curve
        }
        
        return results
    
    def get_performance_metrics(self):
        """
        Get performance metrics for the most recent backtest.
        
        Returns:
            dict: Performance metrics
        """
        if self.results is None:
            return {'error': 'No backtest results available. Run a backtest first.'}
        
        return {
            'symbol': self.results['symbol'],
            'timeframe': self.results['timeframe'],
            'strategy': self.results['strategy'],
            'profit_usdt': round(self.results['profit_usdt'], 2),
            'profit_pct': round(self.results['profit_pct'], 2),
            'trade_count': self.results['trade_count'],
            'win_rate': round(self.results['win_rate'], 2),
            'max_drawdown_pct': round(self.results['max_drawdown_pct'], 2),
            'profit_factor': round(self.results['profit_factor'], 2),
        }
    
    def generate_equity_chart(self, height=400):
        """
        Generate an equity curve chart for the backtest.
        
        Args:
            height (int, optional): Height of the chart in pixels
            
        Returns:
            str: JSON representation of the chart
        """
        if self.results is None or not self.equity_curve:
            return json.dumps({
                'error': 'No backtest results available. Run a backtest first.'
            })
        
        # Convert equity curve to format expected by chart_utils
        balance_history = []
        for point in self.equity_curve:
            balance_history.append({
                'timestamp': point['timestamp'],
                'balance': point['equity']  # Use equity rather than balance
            })
        
        # Generate chart using chart_utils
        chart_json = generate_performance_chart(
            balance_history=balance_history,
            trades=self.trades,
            height=height,
            show_trades=True
        )
        
        return chart_json
    
    def generate_trade_chart(self, height=600, chart_type='candle'):
        """
        Generate a trade chart showing entries and exits on price chart.
        
        Args:
            height (int, optional): Height of the chart in pixels
            chart_type (str, optional): Type of chart (candle or ohlc)
            
        Returns:
            str: JSON representation of the chart
        """
        if self.results is None or not self.trades:
            return json.dumps({
                'error': 'No backtest results available. Run a backtest first.'
            })
        
        # Get OHLCV data from the backtest
        if not hasattr(self, 'ohlcv_data'):
            return json.dumps({
                'error': 'OHLCV data not available for chart generation.'
            })
        
        # Generate chart using chart_utils
        chart_json = generate_ohlc_chart(
            ohlc_data=self.ohlcv_data,
            trades=self.trades,
            timeframe=self.timeframe,
            symbol=self.symbol,
            show_volume=True,
            height=height,
            chart_type=chart_type
        )
        
        return chart_json
    
    def export_results_csv(self, file_path=None):
        """
        Export backtest results to CSV files.
        
        Args:
            file_path (str, optional): Directory to save CSV files
            
        Returns:
            dict: Paths to saved CSV files
        """
        if self.results is None:
            return {'error': 'No backtest results available. Run a backtest first.'}
        
        if file_path is None:
            file_path = os.path.join('data', 'backtest_results')
            
        # Create directory if it doesn't exist
        os.makedirs(file_path, exist_ok=True)
        
        # Generate a timestamp for the files
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        # Create base filename
        base_filename = f"{self.symbol.replace('/', '_')}_{self.timeframe}_{self.strategy_name}_{timestamp}"
        
        # Export trades to CSV
        trades_df = pd.DataFrame(self.trades)
        trades_csv_path = os.path.join(file_path, f"{base_filename}_trades.csv")
        trades_df.to_csv(trades_csv_path, index=False)
        
        # Export equity curve to CSV
        equity_df = pd.DataFrame(self.equity_curve)
        equity_csv_path = os.path.join(file_path, f"{base_filename}_equity.csv")
        equity_df.to_csv(equity_csv_path, index=False)
        
        # Export summary metrics to CSV
        metrics = self.get_performance_metrics()
        metrics_df = pd.DataFrame([metrics])
        metrics_csv_path = os.path.join(file_path, f"{base_filename}_metrics.csv")
        metrics_df.to_csv(metrics_csv_path, index=False)
        
        return {
            'trades_csv': trades_csv_path,
            'equity_csv': equity_csv_path,
            'metrics_csv': metrics_csv_path
        }

# Helper functions

def load_csv_data(file_path):
    """
    Load OHLCV data from a CSV file.
    
    Args:
        file_path (str): Path to the CSV file
        
    Returns:
        pd.DataFrame: DataFrame with OHLCV data
    """
    return pd.read_csv(file_path)

def load_sample_data():
    """
    Load sample OHLCV data for testing.
    
    Returns:
        list: Sample OHLCV data
    """
    # Generate sample data for BTC/USDT with hourly candles
    # Starting from 30 days ago
    start_time = datetime.now() - timedelta(days=30)
    candles = []
    
    # Initial price around $50,000
    price = 50000
    
    # Generate hourly candles for 30 days
    for i in range(30 * 24):
        timestamp = start_time + timedelta(hours=i)
        
        # Add some randomness to price
        random_change = np.random.normal(0, 0.01)  # Normal distribution with 1% std dev
        price = price * (1 + random_change)
        
        # Generate candle
        open_price = price
        high_price = price * (1 + abs(np.random.normal(0, 0.005)))
        low_price = price * (1 - abs(np.random.normal(0, 0.005)))
        close_price = price * (1 + np.random.normal(0, 0.008))
        
        # Ensure high is highest and low is lowest
        high_price = max(high_price, open_price, close_price)
        low_price = min(low_price, open_price, close_price)
        
        # Generate volume
        volume = np.random.uniform(10, 100) * price
        
        # Add to candles
        candles.append([
            timestamp,
            open_price,
            high_price,
            low_price,
            close_price,
            volume
        ])
        
        # Update price for next candle
        price = close_price
    
    return candles

def run_simple_backtest(strategy_name, symbol="BTC/USDT", timeframe="1h", initial_balance=1000):
    """
    Run a simple backtest with sample data.
    
    Args:
        strategy_name (str): Name of the strategy to backtest
        symbol (str, optional): Trading pair symbol
        timeframe (str, optional): Timeframe of the data
        initial_balance (float, optional): Initial balance in USDT
        
    Returns:
        dict: Backtest results
    """
    backtester = Backtester(
        strategy_name=strategy_name,
        initial_balance=initial_balance
    )
    
    # Load sample data
    ohlcv_data = load_sample_data()
    
    # Run backtest
    results = backtester.run(ohlcv_data, symbol, timeframe)
    
    return results

if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    
    # Run a sample backtest
    results = run_simple_backtest("dip_buyer")
    
    # Print results
    print(f"Strategy: {results['strategy']}")
    print(f"Symbol: {results['symbol']}")
    print(f"Timeframe: {results['timeframe']}")
    print(f"Initial Balance: ${results['initial_balance']:.2f}")
    print(f"Final Balance: ${results['final_balance']:.2f}")
    print(f"Profit/Loss: ${results['profit_usdt']:.2f} ({results['profit_pct']:.2f}%)")
    print(f"Total Trades: {results['trade_count']}")
    print(f"Win Rate: {results['win_rate']:.2f}%")
    print(f"Max Drawdown: ${results['max_drawdown']:.2f} ({results['max_drawdown_pct']:.2f}%)")