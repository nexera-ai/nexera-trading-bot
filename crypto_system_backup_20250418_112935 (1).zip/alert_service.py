"""
Performance Alert Service Module

This module handles monitoring of performance metrics and triggering of alerts
based on predefined rules. It is responsible for evaluating alert conditions,
logging triggered alerts, and optionally creating trigger events on the equity charts.
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Union, Any

from sqlalchemy import and_, func

from models import PerformanceAlertRule, PerformanceAlertLog, PresetEquityHistory, PresetTriggerEvent, db

# Set up logging
logger = logging.getLogger(__name__)


class AlertService:
    """
    Service for monitoring and triggering performance alerts.
    """

    @staticmethod
    def get_available_metrics() -> Dict[str, Dict[str, Any]]:
        """
        Get a list of all available metrics that can be used for alerts.
        
        Returns:
            Dict[str, Dict[str, Any]]: Dictionary of metric info with descriptions and value ranges
        """
        return {
            # Equity and P&L metrics
            "equity": {
                "name": "Equity",
                "description": "Current portfolio value",
                "unit": "currency",
                "category": "portfolio",
                "range": None,
                "recommended_conditions": ["below", "above", "changes_by"],
            },
            "pnl_percent": {
                "name": "P&L %",
                "description": "Profit/loss percentage",
                "unit": "percent",
                "category": "performance",
                "range": None,
                "recommended_conditions": ["below", "above"],
            },
            "drawdown_percent": {
                "name": "Drawdown %",
                "description": "Current drawdown from peak",
                "unit": "percent",
                "category": "risk",
                "range": (0, 100),
                "recommended_conditions": ["above"],
            },
            
            # Win/loss metrics
            "win_count": {
                "name": "Win Count",
                "description": "Number of winning trades",
                "unit": "count",
                "category": "performance",
                "range": (0, None),
                "recommended_conditions": ["below", "above"],
            },
            "loss_count": {
                "name": "Loss Count",
                "description": "Number of losing trades",
                "unit": "count",
                "category": "performance",
                "range": (0, None),
                "recommended_conditions": ["above"],
            },
            "win_rate": {
                "name": "Win Rate",
                "description": "Percentage of winning trades",
                "unit": "percent",
                "category": "performance",
                "range": (0, 100),
                "recommended_conditions": ["below", "above"],
            },
            
            # Risk-adjusted return metrics
            "sharpe_ratio": {
                "name": "Sharpe Ratio",
                "description": "Risk-adjusted return (higher is better)",
                "unit": "ratio",
                "category": "risk_adjusted",
                "range": None,
                "recommended_conditions": ["below"],
            },
            "sortino_ratio": {
                "name": "Sortino Ratio",
                "description": "Downside risk-adjusted return",
                "unit": "ratio",
                "category": "risk_adjusted",
                "range": None,
                "recommended_conditions": ["below"],
            },
            "max_drawdown": {
                "name": "Max Drawdown",
                "description": "Maximum drawdown percentage",
                "unit": "percent",
                "category": "risk",
                "range": (0, 100),
                "recommended_conditions": ["above"],
            },
            
            # Market condition metrics
            "market_conditions": {
                "name": "Market Conditions",
                "description": "Current market regime (bull, bear, sideways)",
                "unit": "category",
                "category": "market",
                "range": ["bull", "bear", "sideways", "volatile"],
                "recommended_conditions": ["equals"],
            },
            "vix_value": {
                "name": "VIX Value",
                "description": "Volatility index value",
                "unit": "index",
                "category": "market",
                "range": (0, None),
                "recommended_conditions": ["above", "below"],
            },
        }

    @staticmethod
    def get_available_conditions() -> Dict[str, Dict[str, Any]]:
        """
        Get a list of all available conditions for alert rules.
        
        Returns:
            Dict[str, Dict[str, Any]]: Dictionary of condition info with descriptions
        """
        return {
            "above": {
                "name": "Above",
                "description": "Triggers when the metric is greater than the threshold",
                "symbol": ">",
                "applicable_units": ["currency", "percent", "ratio", "count", "index"],
            },
            "below": {
                "name": "Below",
                "description": "Triggers when the metric is less than the threshold",
                "symbol": "<",
                "applicable_units": ["currency", "percent", "ratio", "count", "index"],
            },
            "equals": {
                "name": "Equals",
                "description": "Triggers when the metric equals the threshold (exact match for categories)",
                "symbol": "=",
                "applicable_units": ["category", "currency", "percent", "ratio", "count", "index"],
            },
            "changes_by": {
                "name": "Changes By",
                "description": "Triggers when the metric changes by more than the threshold percent in the timeframe",
                "symbol": "Δ%",
                "applicable_units": ["currency", "percent", "ratio", "count", "index"],
            },
        }

    @classmethod
    def evaluate_alerts_for_preset(cls, preset_id: int) -> List[Dict[str, Any]]:
        """
        Evaluate all alert rules for a specific preset and trigger alerts as needed.
        
        Args:
            preset_id (int): The ID of the strategy preset to evaluate
            
        Returns:
            List[Dict[str, Any]]: List of triggered alert details
        """
        logger.info(f"Evaluating alert rules for preset {preset_id}")
        
        # Get all enabled alert rules for this preset
        alert_rules = PerformanceAlertRule.query.filter(
            and_(
                PerformanceAlertRule.preset_id == preset_id,
                PerformanceAlertRule.enabled == True
            )
        ).all()
        
        if not alert_rules:
            logger.info(f"No active alert rules found for preset {preset_id}")
            return []
        
        # Track triggered alerts
        triggered_alerts = []
        
        # Evaluate each rule
        for rule in alert_rules:
            # Skip if in cooldown period
            if rule.last_triggered_at and (datetime.utcnow() - rule.last_triggered_at).total_seconds() < (rule.cool_down_minutes * 60):
                continue
                
            # Get current value for the metric
            current_value = cls._get_current_metric_value(preset_id, rule.metric, rule.comparison_window, rule.timeframe)
            
            if current_value is None:
                logger.warning(f"Could not get current value for metric {rule.metric}")
                continue
                
            # Check if the condition is met
            condition_met = cls._evaluate_condition(current_value, rule.condition, rule.threshold, rule.metric)
            
            if condition_met:
                # For consecutive triggers, check previous values
                if rule.consecutive_triggers > 1:
                    consecutive_met = cls._check_consecutive_condition(
                        preset_id, rule.metric, rule.condition, rule.threshold,
                        rule.consecutive_triggers, rule.timeframe
                    )
                    if not consecutive_met:
                        continue
                
                # Trigger the alert
                alert_log = cls._trigger_alert(rule, current_value)
                triggered_alerts.append(alert_log.to_dict())
                
                # Create a trigger event if configured
                if rule.create_trigger_event:
                    trigger_event = cls._create_trigger_event(rule, current_value)
                    if trigger_event:
                        # Update alert log with trigger event ID
                        alert_log.trigger_event_id = trigger_event.id
                        db.session.commit()
        
        return triggered_alerts

    @staticmethod
    def _get_current_metric_value(
        preset_id: int, 
        metric: str, 
        comparison_window: Optional[int] = None, 
        timeframe: Optional[str] = None
    ) -> Optional[Union[float, str]]:
        """
        Get the current value for a specific metric.
        
        Args:
            preset_id (int): The ID of the strategy preset
            metric (str): The metric name (e.g., 'win_rate', 'drawdown', etc.)
            comparison_window (Optional[int]): Number of data points to consider
            timeframe (Optional[str]): Timeframe for the comparison
            
        Returns:
            Optional[Union[float, str]]: The current metric value or None if not available
        """
        try:
            # Get the latest equity history entry
            latest_entry = PresetEquityHistory.query.filter_by(preset_id=preset_id).order_by(
                PresetEquityHistory.timestamp.desc()
            ).first()
            
            if not latest_entry:
                return None
                
            # If the metric is a direct field in the equity history
            if hasattr(latest_entry, metric):
                return getattr(latest_entry, metric)
                
            # Special calculated metrics
            if metric == "win_rate" and latest_entry.win_count is not None and latest_entry.loss_count is not None:
                total_trades = latest_entry.win_count + latest_entry.loss_count
                if total_trades > 0:
                    return (latest_entry.win_count / total_trades) * 100
                return 0.0
                
            # If we need to calculate a change over time
            if comparison_window and timeframe:
                # Define the lookback period
                if timeframe == "1h":
                    start_time = datetime.utcnow() - timedelta(hours=comparison_window)
                elif timeframe == "1d":
                    start_time = datetime.utcnow() - timedelta(days=comparison_window)
                elif timeframe == "7d":
                    start_time = datetime.utcnow() - timedelta(days=7*comparison_window)
                else:
                    # Default to 1 day
                    start_time = datetime.utcnow() - timedelta(days=comparison_window)
                
                # Get the baseline value
                baseline_entry = PresetEquityHistory.query.filter(
                    and_(
                        PresetEquityHistory.preset_id == preset_id,
                        PresetEquityHistory.timestamp >= start_time
                    )
                ).order_by(PresetEquityHistory.timestamp.asc()).first()
                
                if baseline_entry and hasattr(baseline_entry, metric):
                    baseline_value = getattr(baseline_entry, metric)
                    current_value = getattr(latest_entry, metric)
                    
                    if baseline_value is not None and current_value is not None and baseline_value != 0:
                        # Calculate percent change
                        return ((current_value - baseline_value) / abs(baseline_value)) * 100
            
            return None
            
        except Exception as e:
            logger.error(f"Error getting metric value for {metric}: {e}")
            return None

    @staticmethod
    def _evaluate_condition(
        current_value: Union[float, str], 
        condition: str, 
        threshold: float, 
        metric: str
    ) -> bool:
        """
        Evaluate if the current value meets the specified condition.
        
        Args:
            current_value (Union[float, str]): The current value of the metric
            condition (str): The condition to check
            threshold (float): The threshold value
            metric (str): The metric name (used for special cases)
            
        Returns:
            bool: True if the condition is met, False otherwise
        """
        # Handle string/category metrics separately
        if metric == "market_conditions" and isinstance(current_value, str):
            if condition == "equals":
                return current_value == threshold
            return False
            
        # Handle numeric conditions
        try:
            current_value_float = float(current_value)
            
            if condition == "above":
                return current_value_float > threshold
            elif condition == "below":
                return current_value_float < threshold
            elif condition == "equals":
                # For numeric values, use a small epsilon for floating point comparison
                epsilon = 0.000001
                return abs(current_value_float - threshold) < epsilon
            
            return False
            
        except (ValueError, TypeError):
            logger.warning(f"Cannot evaluate condition for non-numeric value: {current_value}")
            return False

    @staticmethod
    def _check_consecutive_condition(
        preset_id: int,
        metric: str,
        condition: str,
        threshold: float,
        consecutive_count: int,
        timeframe: Optional[str] = None
    ) -> bool:
        """
        Check if a condition has been met for consecutive data points.
        
        Args:
            preset_id (int): The ID of the strategy preset
            metric (str): The metric name
            condition (str): The condition to check
            threshold (float): The threshold value
            consecutive_count (int): Number of consecutive points needed
            timeframe (Optional[str]): Timeframe for the comparison
            
        Returns:
            bool: True if the condition is met for consecutive points
        """
        try:
            # Determine how many recent entries to check based on timeframe
            if timeframe == "1h":
                # For hourly, check the most recent entries
                entries_to_check = consecutive_count
            elif timeframe == "1d":
                # For daily, check one entry per day for consecutive days
                entries_to_check = consecutive_count * 24  # Assuming hourly data
            elif timeframe == "7d":
                # For weekly, check one entry per week
                entries_to_check = consecutive_count * 24 * 7
            else:
                # Default: just check the most recent entries
                entries_to_check = consecutive_count
            
            # Get recent equity history entries
            recent_entries = PresetEquityHistory.query.filter_by(preset_id=preset_id).order_by(
                PresetEquityHistory.timestamp.desc()
            ).limit(entries_to_check).all()
            
            # If we don't have enough data points, we can't confirm consecutive triggers
            if len(recent_entries) < consecutive_count:
                return False
            
            # Check each entry
            consecutive_satisfied = 0
            
            for entry in recent_entries:
                value = getattr(entry, metric, None)
                
                # Skip entries with None values
                if value is None:
                    continue
                
                # Special handling for win_rate which isn't a direct field
                if metric == "win_rate" and hasattr(entry, "win_count") and hasattr(entry, "loss_count"):
                    total_trades = entry.win_count + entry.loss_count
                    if total_trades > 0:
                        value = (entry.win_count / total_trades) * 100
                    else:
                        value = 0.0
                
                # Check the condition
                if AlertService._evaluate_condition(value, condition, threshold, metric):
                    consecutive_satisfied += 1
                    if consecutive_satisfied >= consecutive_count:
                        return True
                else:
                    # Condition failed, reset counter
                    consecutive_satisfied = 0
            
            return False
            
        except Exception as e:
            logger.error(f"Error checking consecutive condition: {e}")
            return False

    @staticmethod
    def _trigger_alert(rule: PerformanceAlertRule, current_value: Union[float, str]) -> PerformanceAlertLog:
        """
        Create an alert log entry for a triggered alert.
        
        Args:
            rule (PerformanceAlertRule): The alert rule that was triggered
            current_value (Union[float, str]): The current value that triggered the alert
            
        Returns:
            PerformanceAlertLog: The created alert log entry
        """
        try:
            # Create a new alert log
            alert_log = PerformanceAlertLog(
                alert_rule_id=rule.id,
                metric_value=float(current_value) if not isinstance(current_value, str) else 0.0,
                threshold_value=rule.threshold,
                details=f"Alert triggered: {rule.metric} is {rule.condition} {rule.threshold}"
            )
            
            db.session.add(alert_log)
            
            # Update the last triggered timestamp on the rule
            rule.last_triggered_at = datetime.utcnow()
            
            db.session.commit()
            
            logger.info(f"Alert triggered: Rule ID {rule.id} - {rule.name}")
            
            return alert_log
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error triggering alert: {e}")
            raise

    @staticmethod
    def _create_trigger_event(rule: PerformanceAlertRule, current_value: Union[float, str]) -> Optional[PresetTriggerEvent]:
        """
        Create a trigger event on the equity chart for a triggered alert.
        
        Args:
            rule (PerformanceAlertRule): The alert rule that was triggered
            current_value (Union[float, str]): The current value that triggered the alert
            
        Returns:
            Optional[PresetTriggerEvent]: The created trigger event or None if creation failed
        """
        try:
            # Map severity to color and icon
            severity_colors = {
                'low': '#17a2b8',      # Info blue
                'medium': '#ffc107',   # Warning yellow
                'high': '#fd7e14',     # Orange
                'critical': '#dc3545'  # Danger red
            }
            
            severity_icons = {
                'low': 'bi-info-circle',
                'medium': 'bi-exclamation-triangle',
                'high': 'bi-exclamation-circle',
                'critical': 'bi-exclamation-diamond-fill'
            }
            
            color = severity_colors.get(rule.severity, '#17a2b8')
            icon = severity_icons.get(rule.severity, 'bi-bell')
            
            # Format the condition symbol for display
            condition_symbol = {
                'above': '>',
                'below': '<',
                'equals': '=',
                'changes_by': 'Δ'
            }.get(rule.condition, rule.condition)
            
            # Create a new trigger event
            trigger_event = PresetTriggerEvent(
                preset_id=rule.preset_id,
                event_type='alert',
                event_subtype=rule.severity,
                title=f"Alert: {rule.name}",
                description=f"{rule.metric} {condition_symbol} {rule.threshold} (Actual: {current_value})",
                timestamp=datetime.utcnow(),
                color=color,
                icon=icon,
                importance=rule.trigger_event_importance,
                context_data={
                    'alert_rule_id': rule.id,
                    'metric': rule.metric,
                    'condition': rule.condition,
                    'threshold': rule.threshold,
                    'current_value': current_value,
                    'severity': rule.severity
                },
                is_auto_generated=True,
                created_by='alert_system'
            )
            
            db.session.add(trigger_event)
            db.session.commit()
            
            logger.info(f"Created trigger event for alert: {rule.name}")
            
            return trigger_event
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error creating trigger event for alert: {e}")
            return None

    @staticmethod
    def acknowledge_alert(alert_id: int) -> Dict[str, Any]:
        """
        Mark an alert as acknowledged.
        
        Args:
            alert_id (int): The ID of the alert to acknowledge
            
        Returns:
            Dict[str, Any]: Status information
        """
        try:
            alert = PerformanceAlertLog.query.get(alert_id)
            
            if not alert:
                return {'success': False, 'error': 'Alert not found'}
                
            alert.status = 'acknowledged'
            alert.acknowledged_at = datetime.utcnow()
            
            db.session.commit()
            
            logger.info(f"Alert {alert_id} acknowledged")
            
            return {
                'success': True,
                'message': 'Alert acknowledged',
                'alert': alert.to_dict()
            }
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error acknowledging alert: {e}")
            return {'success': False, 'error': str(e)}

    @staticmethod
    def resolve_alert(alert_id: int) -> Dict[str, Any]:
        """
        Mark an alert as resolved.
        
        Args:
            alert_id (int): The ID of the alert to resolve
            
        Returns:
            Dict[str, Any]: Status information
        """
        try:
            alert = PerformanceAlertLog.query.get(alert_id)
            
            if not alert:
                return {'success': False, 'error': 'Alert not found'}
                
            alert.status = 'resolved'
            alert.resolved_at = datetime.utcnow()
            
            db.session.commit()
            
            logger.info(f"Alert {alert_id} resolved")
            
            return {
                'success': True,
                'message': 'Alert resolved',
                'alert': alert.to_dict()
            }
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error resolving alert: {e}")
            return {'success': False, 'error': str(e)}