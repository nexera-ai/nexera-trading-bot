"""
Smart Capital Scaling Module

This module implements intelligent capital allocation scaling based on
strategy performance metrics. It temporarily boosts allocation to
high-performing strategies while maintaining risk controls.
"""

import os
import json
import time
import math
import logging
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Any, Tuple, Optional
import schedule
from collections import defaultdict

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CapitalScaler:
    """
    Smart Capital Scaling Engine
    
    Monitors strategy performance and temporarily increases allocation
    to well-performing strategies based on configurable thresholds.
    """
    
    def __init__(self, 
                data_dir: str = './data',
                lookback_hours: int = 48,
                check_interval_minutes: int = 240,  # 4 hours
                schedule_times: List[str] = ['00:00', '06:00', '12:00', '18:00'],
                min_trades_required: int = 5,
                is_enabled: bool = False):
        """
        Initialize the capital scaler.
        
        Args:
            data_dir: Directory for storing data
            lookback_hours: Hours to look back for performance metrics
            check_interval_minutes: Minutes between checks as a backup
            schedule_times: List of daily check times (HH:MM format)
            min_trades_required: Minimum trades required for scaling
            is_enabled: Whether capital scaling is enabled
        """
        self.data_dir = data_dir
        self.boosts_file = os.path.join(data_dir, 'capital_boosts.json')
        self.history_file = os.path.join(data_dir, 'boost_history.json')
        
        # Create data directory if it doesn't exist
        if not os.path.exists(data_dir):
            os.makedirs(data_dir)
            
        # Configuration
        self.lookback_hours = lookback_hours
        self.check_interval_minutes = check_interval_minutes
        self.schedule_times = schedule_times
        self.min_trades_required = min_trades_required
        self.is_enabled = is_enabled
        
        # Scaling parameters
        self.boost_factor = 1.5  # Default factor to multiply weight by
        self.boost_duration_hours = 24  # How long boost should last
        self.max_concurrent_boosts = 2  # Maximum number of boosted strategies
        
        # Thresholds for triggering boosts
        self.thresholds = {
            'win_rate': 0.75,  # 75% win rate
            'profit_factor': 2.0,  # Profit factor of 2.0
            'sharpe_ratio': 1.5,  # Sharpe ratio of 1.5
            'avg_return': 0.01,  # 1% average return per trade
            'max_drawdown': 0.05,  # 5% max drawdown
            'consistency_score': 0.7  # 70% consistency score
        }
        
        # Active boosts and history
        self.active_boosts = {}  # Strategy -> boost info
        self.boost_history = []  # List of historical boosts
        self.total_boosts_applied = 0
        self.last_check_time = None
        
        # Thread and scheduler
        self.scheduler_thread = None
        self.stop_requested = False
        
        # Load data
        self._load_data()
    
    def _load_data(self):
        """Load scaling history and current boosts from disk."""
        try:
            if os.path.exists(self.boosts_file):
                with open(self.boosts_file, 'r') as f:
                    self.active_boosts = json.load(f)
                    
            if os.path.exists(self.history_file):
                with open(self.history_file, 'r') as f:
                    self.boost_history = json.load(f)
                    self.total_boosts_applied = len(self.boost_history)
        except Exception as e:
            logger.error(f"Error loading capital scaling data: {e}")
    
    def _save_history(self):
        """Save scaling history to disk."""
        try:
            with open(self.history_file, 'w') as f:
                json.dump(self.boost_history, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving capital scaling history: {e}")
    
    def _save_active_boosts(self):
        """Save active boosts to disk."""
        try:
            with open(self.boosts_file, 'w') as f:
                json.dump(self.active_boosts, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving active boosts: {e}")
    
    def _calculate_metrics(self, strategy_name: str) -> Dict[str, float]:
        """
        Calculate performance metrics for a strategy.
        
        Args:
            strategy_name: Name of the strategy to analyze
            
        Returns:
            Dict of performance metrics
        """
        try:
            # Import here to avoid circular imports
            from performance_tracker import performance_tracker
            
            # Get performance data for the strategy
            end_time = datetime.now()
            start_time = end_time - timedelta(hours=self.lookback_hours)
            
            metrics = performance_tracker.get_strategy_metrics(
                strategy_name=strategy_name,
                start_time=start_time,
                end_time=end_time
            )
            
            # Check for enough trades
            if 'trade_list' in metrics and len(metrics['trade_list']) < self.min_trades_required:
                logger.info(f"Not enough trades for {strategy_name}: {len(metrics['trade_list'])} < {self.min_trades_required}")
                return {}
            
            # Calculate additional metrics if needed
            if metrics:
                # Calculate consistency score
                consistency = 0.0
                wins = 0
                avg_return = 0.0
                std_dev = 0.0
                
                if 'trade_list' in metrics and len(metrics['trade_list']) > 0:
                    trades = metrics['trade_list']
                    
                    # Count consecutive wins
                    max_consecutive_wins = 0
                    current_consecutive_wins = 0
                    for trade in trades:
                        if trade['profit_pct'] > 0:
                            current_consecutive_wins += 1
                            wins += 1
                        else:
                            max_consecutive_wins = max(max_consecutive_wins, current_consecutive_wins)
                            current_consecutive_wins = 0
                    
                    max_consecutive_wins = max(max_consecutive_wins, current_consecutive_wins)
                    
                    # Calculate average return and standard deviation
                    returns = [trade['profit_pct'] for trade in trades]
                    avg_return = sum(returns) / len(returns)
                    
                    # Standard deviation
                    if len(returns) > 1:
                        variance = sum((r - avg_return) ** 2 for r in returns) / (len(returns) - 1)
                        std_dev = math.sqrt(variance)
                    
                    # Calculate Sharpe-like ratio
                    if std_dev > 0:
                        sharpe = avg_return / std_dev
                    else:
                        sharpe = 0  # Avoid division by zero
                    
                    # Calculate profit factor
                    gross_profit = sum(r for r in returns if r > 0)
                    gross_loss = abs(sum(r for r in returns if r < 0))
                    
                    profit_factor = 0
                    if gross_loss > 0:
                        profit_factor = gross_profit / gross_loss
                    
                    # Calculate consistency score (weighted combination of metrics)
                    win_rate = wins / len(trades)
                    max_win_streak_ratio = max_consecutive_wins / len(trades)
                    
                    consistency = (0.4 * win_rate + 
                                  0.2 * max_win_streak_ratio + 
                                  0.2 * min(1.0, profit_factor / 3.0) + 
                                  0.2 * min(1.0, sharpe / 2.0))
                
                # Add calculated metrics
                metrics['consistency_score'] = consistency
                
                # Ensure standard metrics exist
                if 'win_rate' not in metrics:
                    metrics['win_rate'] = wins / len(metrics['trade_list']) if metrics.get('trade_list', []) else 0
                
                if 'profit_factor' not in metrics:
                    metrics['profit_factor'] = profit_factor
                
                if 'avg_return' not in metrics:
                    metrics['avg_return'] = avg_return
                
                if 'sharpe_ratio' not in metrics:
                    metrics['sharpe_ratio'] = avg_return / std_dev if std_dev > 0 else 0
                
            return metrics
            
        except Exception as e:
            logger.error(f"Error calculating metrics for {strategy_name}: {e}")
            return {}
    
    def _should_boost_strategy(self, strategy: str, metrics: Dict[str, float]) -> bool:
        """
        Determine if a strategy should receive a capital boost.
        
        Args:
            strategy: Strategy name
            metrics: Performance metrics
            
        Returns:
            Boolean indicating whether to boost
        """
        # Skip if no metrics or already boosted
        if not metrics or strategy in self.active_boosts:
            return False
        
        # Check if we've hit the maximum concurrent boosts
        if len(self.active_boosts) >= self.max_concurrent_boosts:
            return False
        
        # Check against thresholds
        threshold_checks = [
            metrics.get('win_rate', 0) >= self.thresholds['win_rate'],
            metrics.get('profit_factor', 0) >= self.thresholds['profit_factor'],
            metrics.get('sharpe_ratio', 0) >= self.thresholds['sharpe_ratio'],
            metrics.get('avg_return', 0) >= self.thresholds['avg_return'],
            metrics.get('max_drawdown', 1.0) <= self.thresholds['max_drawdown'],
            metrics.get('consistency_score', 0) >= self.thresholds['consistency_score']
        ]
        
        # Strategy must meet at least 4 out of 6 thresholds
        return sum(threshold_checks) >= 4
    
    def _apply_boost(self, strategy: str, metrics: Dict[str, float]) -> Dict[str, Any]:
        """
        Apply a capital boost to a strategy.
        
        Args:
            strategy: Strategy name
            metrics: Performance metrics
            
        Returns:
            Dictionary with boost details
        """
        try:
            # Import here to avoid circular imports
            from ensemble_engine import ensemble_manager
            
            # Get current ensemble
            ensemble = ensemble_manager.get_active_ensemble()
            if not ensemble:
                logger.warning(f"Cannot apply boost to {strategy}: No active ensemble")
                return {'success': False, 'error': 'No active ensemble'}
            
            # Get current weights
            current_weights = ensemble.get_strategy_weights()
            if strategy not in current_weights:
                logger.warning(f"Cannot apply boost to {strategy}: Not in active ensemble")
                return {'success': False, 'error': 'Strategy not in active ensemble'}
            
            current_weight = current_weights[strategy]
            
            # Calculate new weight
            new_weight = min(1.0, current_weight * self.boost_factor)
            
            # Apply boost
            applied_at = datetime.now()
            expires_at = applied_at + timedelta(hours=self.boost_duration_hours)
            
            # Update ensemble weights
            success = ensemble_manager.update_ensemble_weights({strategy: new_weight})
            
            if not success:
                logger.error(f"Failed to update weight for {strategy}")
                return {'success': False, 'error': 'Failed to update ensemble weights'}
            
            # Record the boost
            boost_info = {
                'strategy': strategy,
                'original_weight': current_weight,
                'boosted_weight': new_weight,
                'boost_factor': self.boost_factor,
                'applied_at': applied_at.isoformat(),
                'expires_at': expires_at.isoformat(),
                'metrics': metrics
            }
            
            # Add to active boosts
            self.active_boosts[strategy] = boost_info
            
            # Add to history
            history_entry = {
                'strategy': strategy,
                'type': 'automatic',
                'boost_factor': self.boost_factor,
                'duration_hours': self.boost_duration_hours,
                'original_weight': current_weight,
                'boosted_weight': new_weight,
                'applied_at': applied_at.isoformat(),
                'expires_at': expires_at.isoformat(),
                'status': 'active',
                'metrics': {
                    'win_rate': metrics.get('win_rate', 0),
                    'profit_factor': metrics.get('profit_factor', 0),
                    'sharpe_ratio': metrics.get('sharpe_ratio', 0),
                    'avg_return': metrics.get('avg_return', 0),
                    'consistency_score': metrics.get('consistency_score', 0)
                }
            }
            
            self.boost_history.append(history_entry)
            self.total_boosts_applied += 1
            
            # Save to disk
            self._save_active_boosts()
            self._save_history()
            
            logger.info(f"Applied capital boost to {strategy}: {current_weight:.2f} → {new_weight:.2f} (expires: {expires_at})")
            
            return {
                'success': True,
                'strategy': strategy,
                'original_weight': current_weight,
                'new_weight': new_weight,
                'boost_factor': self.boost_factor,
                'applied_at': applied_at.isoformat(),
                'expires_at': expires_at.isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error applying boost to {strategy}: {e}")
            return {'success': False, 'error': str(e)}
    
    def _remove_boost(self, strategy: str) -> bool:
        """
        Remove a capital boost from a strategy.
        
        Args:
            strategy: Strategy name
            
        Returns:
            Boolean indicating success
        """
        try:
            # Check if boost exists
            if strategy not in self.active_boosts:
                logger.warning(f"Cannot remove boost from {strategy}: No active boost")
                return False
            
            # Import here to avoid circular imports
            from ensemble_engine import ensemble_manager
            
            # Get original weight
            original_weight = self.active_boosts[strategy]['original_weight']
            
            # Get current ensemble
            ensemble = ensemble_manager.get_active_ensemble()
            if not ensemble:
                logger.warning(f"Cannot remove boost from {strategy}: No active ensemble")
                return False
            
            # Restore original weight
            success = ensemble_manager.update_ensemble_weights({strategy: original_weight})
            
            if not success:
                logger.error(f"Failed to restore original weight for {strategy}")
                return False
            
            # Update history entry
            for entry in self.boost_history:
                if (entry['strategy'] == strategy and 
                    entry['status'] == 'active' and
                    'applied_at' in entry and 
                    entry['applied_at'] == self.active_boosts[strategy]['applied_at']):
                    entry['status'] = 'completed'
                    entry['completed_at'] = datetime.now().isoformat()
                    break
                    
            # Remove from active boosts
            removed_boost = self.active_boosts.pop(strategy)
            
            # Save to disk
            self._save_active_boosts()
            self._save_history()
            
            logger.info(f"Removed capital boost from {strategy}: {removed_boost['boosted_weight']:.2f} → {original_weight:.2f}")
            
            return True
            
        except Exception as e:
            logger.error(f"Error removing boost from {strategy}: {e}")
            return False
    
    def _check_expired_boosts(self):
        """Check and remove expired capital boosts."""
        try:
            now = datetime.now()
            expired_strategies = []
            
            for strategy, boost in self.active_boosts.items():
                expires_at = datetime.fromisoformat(boost['expires_at'])
                if now >= expires_at:
                    expired_strategies.append(strategy)
            
            for strategy in expired_strategies:
                logger.info(f"Removing expired boost from {strategy}")
                self._remove_boost(strategy)
                
        except Exception as e:
            logger.error(f"Error checking expired boosts: {e}")
    
    def check_and_apply_scaling(self) -> Dict[str, Any]:
        """
        Run the capital scaling check and apply boosts if needed.
        
        Returns:
            Dictionary with scaling results
        """
        if not self.is_enabled:
            logger.info("Capital scaling is disabled, skipping check")
            return {'success': False, 'message': 'Capital scaling is disabled'}
        
        try:
            # Import here to avoid circular imports
            from ensemble_engine import ensemble_manager
            
            # Update last check time
            self.last_check_time = datetime.now()
            
            # Check for expired boosts first
            self._check_expired_boosts()
            
            # Get active ensemble
            ensemble = ensemble_manager.get_active_ensemble()
            if not ensemble:
                logger.warning("No active ensemble found")
                return {'success': False, 'message': 'No active ensemble found'}
            
            # Get current strategy weights
            strategies = ensemble.get_strategy_weights()
            
            results = {
                'success': True,
                'timestamp': self.last_check_time.isoformat(),
                'strategies_checked': len(strategies),
                'boosts_applied': 0,
                'boosts': []
            }
            
            # Check each strategy
            for strategy in strategies:
                # Skip if already boosted
                if strategy in self.active_boosts:
                    continue
                
                # Calculate metrics
                metrics = self._calculate_metrics(strategy)
                
                # Check if we should boost
                if metrics and self._should_boost_strategy(strategy, metrics):
                    boost_result = self._apply_boost(strategy, metrics)
                    if boost_result['success']:
                        results['boosts_applied'] += 1
                        results['boosts'].append({
                            'strategy': strategy,
                            'factor': self.boost_factor,
                            'expires_at': boost_result['expires_at']
                        })
            
            # Log results
            if results['boosts_applied'] > 0:
                logger.info(f"Capital scaling applied {results['boosts_applied']} boosts")
            else:
                logger.info("Capital scaling check completed, no boosts applied")
                
            return results
            
        except Exception as e:
            logger.error(f"Error during capital scaling check: {e}")
            return {'success': False, 'error': str(e)}
    
    def _scheduler_loop(self):
        """Background thread for running the scheduler."""
        # Create schedule for fixed times
        for time_str in self.schedule_times:
            schedule.every().day.at(time_str).do(self.check_and_apply_scaling)
        
        # Also schedule every check_interval_minutes as a backup
        schedule.every(self.check_interval_minutes).minutes.do(self.check_and_apply_scaling)
        
        # Run the scheduler
        while not self.stop_requested:
            schedule.run_pending()
            time.sleep(60)  # Sleep for 60 seconds
    
    def start_scheduler(self):
        """Start the background scheduler thread."""
        if self.scheduler_thread is None or not self.scheduler_thread.is_alive():
            self.stop_requested = False
            self.scheduler_thread = threading.Thread(target=self._scheduler_loop)
            self.scheduler_thread.daemon = True
            self.scheduler_thread.start()
            logger.info("Capital scaling scheduler started")
    
    def stop_scheduler(self):
        """Stop the background scheduler thread."""
        if self.scheduler_thread and self.scheduler_thread.is_alive():
            self.stop_requested = True
            self.scheduler_thread.join(timeout=5)
            logger.info("Capital scaling scheduler stopped")
    
    def manually_boost_strategy(self, strategy: str, boost_factor: float, 
                               duration_hours: int) -> Dict[str, Any]:
        """
        Manually apply a capital boost to a strategy.
        
        Args:
            strategy: Strategy name
            boost_factor: Multiplication factor for the strategy weight 
            duration_hours: How long the boost should last
            
        Returns:
            Dictionary with boost details
        """
        try:
            # Import here to avoid circular imports
            from ensemble_engine import ensemble_manager
            
            # Get current ensemble
            ensemble = ensemble_manager.get_active_ensemble()
            if not ensemble:
                logger.warning(f"Cannot apply manual boost to {strategy}: No active ensemble")
                return {'success': False, 'error': 'No active ensemble'}
            
            # Get current weights
            current_weights = ensemble.get_strategy_weights()
            if strategy not in current_weights:
                logger.warning(f"Cannot apply manual boost to {strategy}: Not in active ensemble")
                return {'success': False, 'error': 'Strategy not in active ensemble'}
            
            current_weight = current_weights[strategy]
            
            # Calculate new weight
            new_weight = min(1.0, current_weight * boost_factor)
            
            # Apply boost
            applied_at = datetime.now()
            expires_at = applied_at + timedelta(hours=duration_hours)
            
            # Remove existing boost if present
            if strategy in self.active_boosts:
                self._remove_boost(strategy)
            
            # Update ensemble weights
            success = ensemble_manager.update_ensemble_weights({strategy: new_weight})
            
            if not success:
                logger.error(f"Failed to update weight for {strategy}")
                return {'success': False, 'error': 'Failed to update ensemble weights'}
            
            # Record the boost
            boost_info = {
                'strategy': strategy,
                'original_weight': current_weight,
                'boosted_weight': new_weight,
                'boost_factor': boost_factor,
                'applied_at': applied_at.isoformat(),
                'expires_at': expires_at.isoformat(),
                'type': 'manual'
            }
            
            # Add to active boosts
            self.active_boosts[strategy] = boost_info
            
            # Add to history
            history_entry = {
                'strategy': strategy,
                'type': 'manual',
                'boost_factor': boost_factor,
                'duration_hours': duration_hours,
                'original_weight': current_weight,
                'boosted_weight': new_weight,
                'applied_at': applied_at.isoformat(),
                'expires_at': expires_at.isoformat(),
                'status': 'active'
            }
            
            self.boost_history.append(history_entry)
            self.total_boosts_applied += 1
            
            # Save to disk
            self._save_active_boosts()
            self._save_history()
            
            logger.info(f"Applied manual capital boost to {strategy}: {current_weight:.2f} → {new_weight:.2f} (expires: {expires_at})")
            
            return {
                'success': True,
                'strategy': strategy,
                'original_weight': current_weight,
                'new_weight': new_weight,
                'boost_factor': boost_factor,
                'applied_at': applied_at.isoformat(),
                'expires_at': expires_at.isoformat(),
                'expires_in': f"{duration_hours} hours",
                'type': 'manual'
            }
            
        except Exception as e:
            logger.error(f"Error applying manual boost to {strategy}: {e}")
            return {'success': False, 'error': str(e)}
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get the current status of capital scaling.
        
        Returns:
            Dictionary with status information
        """
        try:
            # Get current active boosts with expiry information
            active_boosts_with_expiry = {}
            now = datetime.now()
            
            for strategy, boost in self.active_boosts.items():
                expires_at = datetime.fromisoformat(boost['expires_at'])
                expires_in_seconds = max(0, (expires_at - now).total_seconds())
                hours = math.floor(expires_in_seconds / 3600)
                minutes = math.floor((expires_in_seconds % 3600) / 60)
                
                # Add expiry information
                boost_copy = boost.copy()
                boost_copy['expires_in'] = f"{hours}h {minutes}m"
                boost_copy['expires_in_seconds'] = expires_in_seconds
                
                active_boosts_with_expiry[strategy] = boost_copy
            
            return {
                'is_enabled': self.is_enabled,
                'active_boosts': active_boosts_with_expiry,
                'total_boosts_applied': self.total_boosts_applied,
                'lookback_hours': self.lookback_hours,
                'check_interval_minutes': self.check_interval_minutes,
                'min_trades_required': self.min_trades_required,
                'boost_factor': self.boost_factor,
                'boost_duration_hours': self.boost_duration_hours,
                'max_concurrent_boosts': self.max_concurrent_boosts,
                'thresholds': self.thresholds,
                'last_check_time': self.last_check_time.isoformat() if self.last_check_time else None,
                'scheduler_active': self.scheduler_thread is not None and self.scheduler_thread.is_alive()
            }
        except Exception as e:
            logger.error(f"Error getting capital scaling status: {e}")
            return {
                'is_enabled': self.is_enabled,
                'error': str(e)
            }
    
    def get_active_boosts(self) -> Dict[str, Dict[str, Any]]:
        """
        Get all active capital boosts.
        
        Returns:
            Dictionary of strategy boosts
        """
        try:
            # Add readable expiry time
            now = datetime.now()
            result = {}
            
            for strategy, boost in self.active_boosts.items():
                boost_copy = boost.copy()
                expires_at = datetime.fromisoformat(boost['expires_at'])
                expires_in_seconds = max(0, (expires_at - now).total_seconds())
                hours = math.floor(expires_in_seconds / 3600)
                minutes = math.floor((expires_in_seconds % 3600) / 60)
                
                boost_copy['expires_in'] = f"{hours}h {minutes}m"
                result[strategy] = boost_copy
            
            return result
            
        except Exception as e:
            logger.error(f"Error getting active boosts: {e}")
            return {}
    
    def get_boost_history(self, limit: int = 20) -> List[Dict[str, Any]]:
        """
        Get capital scaling history.
        
        Args:
            limit: Maximum number of records to return
            
        Returns:
            List of boost records
        """
        try:
            # Return most recent first
            history = sorted(self.boost_history, key=lambda x: x['applied_at'], reverse=True)
            return history[:limit]
            
        except Exception as e:
            logger.error(f"Error getting boost history: {e}")
            return []
    
    def update_thresholds(self, thresholds: Dict[str, float]) -> bool:
        """
        Update scaling thresholds.
        
        Args:
            thresholds: Dictionary of threshold values
            
        Returns:
            Boolean indicating success
        """
        try:
            # Validate thresholds
            for key, value in thresholds.items():
                if key in self.thresholds:
                    self.thresholds[key] = float(value)
            
            logger.info(f"Updated capital scaling thresholds: {self.thresholds}")
            return True
            
        except Exception as e:
            logger.error(f"Error updating thresholds: {e}")
            return False
    
    def update_parameters(self, params: Dict[str, Any]) -> bool:
        """
        Update scaling parameters.
        
        Args:
            params: Dictionary of parameter values
            
        Returns:
            Boolean indicating success
        """
        try:
            # Update parameters
            if 'lookback_hours' in params:
                self.lookback_hours = int(params['lookback_hours'])
                
            if 'check_interval_minutes' in params:
                self.check_interval_minutes = int(params['check_interval_minutes'])
                
            if 'min_trades_required' in params:
                self.min_trades_required = int(params['min_trades_required'])
                
            if 'boost_factor' in params:
                self.boost_factor = float(params['boost_factor'])
                
            if 'boost_duration_hours' in params:
                self.boost_duration_hours = int(params['boost_duration_hours'])
                
            if 'max_concurrent_boosts' in params:
                self.max_concurrent_boosts = int(params['max_concurrent_boosts'])
                
            if 'schedule_times' in params:
                self.schedule_times = params['schedule_times']
            
            logger.info(f"Updated capital scaling parameters")
            
            # Restart scheduler if it's running
            if self.scheduler_thread and self.scheduler_thread.is_alive():
                self.stop_scheduler()
                self.start_scheduler()
                
            return True
            
        except Exception as e:
            logger.error(f"Error updating parameters: {e}")
            return False
    
    def enable(self):
        """Enable capital scaling."""
        self.is_enabled = True
        logger.info("Capital scaling enabled")
        
        # Start scheduler if not running
        if not self.scheduler_thread or not self.scheduler_thread.is_alive():
            self.start_scheduler()
            
    def disable(self):
        """Disable capital scaling."""
        self.is_enabled = False
        logger.info("Capital scaling disabled")
        
        # Stop scheduler
        self.stop_scheduler()
        
    def reset_all_boosts(self) -> bool:
        """
        Reset all active capital boosts.
        
        Returns:
            Boolean indicating success
        """
        try:
            # Get list of strategies to reset
            strategies = list(self.active_boosts.keys())
            
            # Remove each boost
            for strategy in strategies:
                self._remove_boost(strategy)
                
            logger.info(f"Reset all capital boosts ({len(strategies)} boosts removed)")
            return True
            
        except Exception as e:
            logger.error(f"Error resetting all boosts: {e}")
            return False

# Create singleton instance
capital_scaler = CapitalScaler()