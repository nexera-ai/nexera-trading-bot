"""
Utility functions for the trading bot.
"""
import logging
import time
import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta
import ccxt

logger = logging.getLogger(__name__)

def calculate_profit_percentage(entry_price, current_price):
    """
    Calculate the profit/loss percentage between entry and current price.
    
    Args:
        entry_price (float): Entry price
        current_price (float): Current price
        
    Returns:
        float: Profit/loss percentage
    """
    return ((current_price - entry_price) / entry_price) * 100

def format_number(number, decimals=8):
    """
    Format a number with the specified number of decimal places.
    
    Args:
        number (float): Number to format
        decimals (int): Number of decimal places
        
    Returns:
        str: Formatted number
    """
    return f"{number:.{decimals}f}"

def calculate_position_size_with_fee(amount_usdt, fee_percentage=0.1):
    """
    Calculate the position size accounting for the trading fee.
    
    Args:
        amount_usdt (float): Amount in USDT
        fee_percentage (float): Fee percentage
        
    Returns:
        float: Position size after fees
    """
    fee_factor = fee_percentage / 100
    return amount_usdt * (1 - fee_factor)

def timestamp_to_datetime(timestamp_ms):
    """
    Convert a timestamp in milliseconds to a datetime object.
    
    Args:
        timestamp_ms (int): Timestamp in milliseconds
        
    Returns:
        datetime: Datetime object
    """
    return datetime.fromtimestamp(timestamp_ms / 1000)

def datetime_to_timestamp(dt):
    """
    Convert a datetime object to a timestamp in milliseconds.
    
    Args:
        dt (datetime): Datetime object
        
    Returns:
        int: Timestamp in milliseconds
    """
    return int(dt.timestamp() * 1000)

def retry_api_call(func, max_retries=3, delay=1):
    """
    Retry a function call with exponential backoff.
    
    Args:
        func (callable): Function to call
        max_retries (int): Maximum number of retries
        delay (int): Initial delay in seconds
        
    Returns:
        Any: Result of the function call
    """
    retries = 0
    while retries < max_retries:
        try:
            return func()
        except Exception as e:
            retries += 1
            if retries == max_retries:
                raise
            
            wait_time = delay * (2 ** (retries - 1))
            logger.warning(f"API call failed. Retrying in {wait_time} seconds... ({retries}/{max_retries})")
            logger.debug(f"Error: {e}")
            time.sleep(wait_time)


def generate_historical_data(symbol, timeframe='1h', start_date=None, end_date=None, num_candles=None):
    """
    Generate historical price data for backtesting.
    
    This function attempts to fetch real data from the exchange when possible,
    falling back to realistic-looking simulated data if needed.
    
    Args:
        symbol (str): Trading pair symbol (e.g., 'BTC/USDT')
        timeframe (str): Timeframe for candles (e.g., '1h', '15m', '1d')
        start_date (datetime, optional): Start date for the data
        end_date (datetime, optional): End date for the data
        num_candles (int, optional): Number of candles to fetch (if start_date/end_date not provided)
        
    Returns:
        pd.DataFrame: OHLCV data with columns: timestamp, open, high, low, close, volume
    """
    if end_date is None:
        end_date = datetime.now()
    
    if start_date is None and num_candles:
        # Calculate start date based on number of candles
        if timeframe.endswith('m'):
            minutes = int(timeframe[:-1])
            start_date = end_date - timedelta(minutes=minutes * num_candles)
        elif timeframe.endswith('h'):
            hours = int(timeframe[:-1])
            start_date = end_date - timedelta(hours=hours * num_candles)
        elif timeframe.endswith('d'):
            days = int(timeframe[:-1])
            start_date = end_date - timedelta(days=days * num_candles)
        else:
            # Default to days
            start_date = end_date - timedelta(days=num_candles)
    elif start_date is None:
        # Default to 30 days of data
        if timeframe.endswith('m'):
            start_date = end_date - timedelta(days=2)  # 2 days of minutes
        elif timeframe.endswith('h'):
            start_date = end_date - timedelta(days=30)  # 30 days of hours
        else:
            start_date = end_date - timedelta(days=365)  # 365 days of days
    
    # Convert dates to timestamps
    start_timestamp = int(start_date.timestamp() * 1000)
    end_timestamp = int(end_date.timestamp() * 1000)
    
    # Try to fetch real data from exchange
    try:
        exchange = ccxt.binance()
        ohlcv = exchange.fetch_ohlcv(symbol, timeframe, since=start_timestamp, limit=1000)
        
        # Filter by date range
        ohlcv = [candle for candle in ohlcv if start_timestamp <= candle[0] <= end_timestamp]
        
        if ohlcv:
            df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            return df
        
        logger.warning(f"No data fetched from exchange for {symbol}, {timeframe}. Falling back to simulation.")
    except Exception as e:
        logger.warning(f"Error fetching data from exchange: {e}. Falling back to simulation.")

    # If we reach here, simulate data
    return _generate_simulated_data(symbol, timeframe, start_date, end_date)


def _generate_simulated_data(symbol, timeframe, start_date, end_date):
    """
    Generate simulated OHLCV data for backtesting when real exchange data is unavailable.
    
    Args:
        symbol (str): Trading pair symbol (e.g., 'BTC/USDT')
        timeframe (str): Timeframe for candles (e.g., '1h', '15m', '1d')
        start_date (datetime): Start date for the data
        end_date (datetime): End date for the data
        
    Returns:
        pd.DataFrame: Simulated OHLCV data
    """
    # Figure out the candle interval
    if timeframe.endswith('m'):
        minutes = int(timeframe[:-1])
        interval = timedelta(minutes=minutes)
    elif timeframe.endswith('h'):
        hours = int(timeframe[:-1])
        interval = timedelta(hours=hours)
    elif timeframe.endswith('d'):
        days = int(timeframe[:-1])
        interval = timedelta(days=days)
    else:
        interval = timedelta(hours=1)  # Default to 1h
    
    # Generate timestamps
    current_time = start_date
    timestamps = []
    while current_time <= end_date:
        timestamps.append(current_time)
        current_time += interval
    
    # Set appropriate base price based on symbol
    base_price = 50000.0  # Default (BTC-like)
    if symbol.startswith('ETH'):
        base_price = 3000.0
    elif symbol.startswith('SOL'):
        base_price = 100.0
    elif symbol.startswith('BNB'):
        base_price = 300.0
    elif symbol.startswith('DOGE'):
        base_price = 0.1
    elif symbol.startswith('XRP'):
        base_price = 0.5
    elif symbol.startswith('ADA'):
        base_price = 0.3
    
    # Initialize with a base price
    price = base_price
    trend = 0  # 0 is neutral, positive is uptrend, negative is downtrend
    
    # Generate OHLCV data with realistic price movements
    data = []
    for ts in timestamps:
        # Adjust trend occasionally to create realistic patterns
        if random.random() < 0.1:
            trend = random.uniform(-0.5, 0.5)
        
        # Apply trend and randomness
        daily_volatility = price * 0.02  # 2% daily volatility
        price_change = price * (trend * 0.01) + random.uniform(-daily_volatility, daily_volatility)
        price += price_change
        
        # Ensure price doesn't go negative
        price = max(price, 0.00001)
        
        # Generate candle data with appropriate ranges
        candle_range = price * random.uniform(0.005, 0.02)  # 0.5-2% range per candle
        open_price = price
        close_price = price + random.uniform(-candle_range, candle_range)
        
        high_price = max(open_price, close_price) + random.uniform(0, candle_range * 0.5)
        low_price = min(open_price, close_price) - random.uniform(0, candle_range * 0.5)
        
        # Volume increases with volatility
        volume = (abs(high_price - low_price) / price) * random.uniform(10000, 100000)
        
        data.append([ts, open_price, high_price, low_price, close_price, volume])
        
        # Update the current price for the next candle
        price = close_price
    
    # Create DataFrame with simulated data
    df = pd.DataFrame(data, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    return df
