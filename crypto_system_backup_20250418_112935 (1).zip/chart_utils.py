"""
Chart Utility Module for Trading Bot

This module provides functions to generate interactive charts for the trading bot,
including price charts with entry/exit points, performance charts, and more.
"""
import json
import logging
from datetime import datetime, timedelta
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.io as pio
import pandas as pd
import numpy as np

logger = logging.getLogger(__name__)

def generate_ohlc_chart(
    ohlc_data, 
    trades=None, 
    timeframe='1h', 
    symbol=None, 
    show_volume=True,
    height=600,
    chart_type='candle'
):
    """
    Generate an OHLC or candlestick chart with trade entry/exit points.
    
    Args:
        ohlc_data (list or pandas.DataFrame): OHLC data as a list of lists [timestamp, open, high, low, close, volume]
                                              or as a DataFrame with columns ['timestamp', 'open', 'high', 'low', 'close', 'volume']
        trades (list, optional): List of trade dictionaries with entry_time, exit_time, entry_price, exit_price, etc.
        timeframe (str, optional): Timeframe for the chart (e.g., '1m', '1h', '1d')
        symbol (str, optional): Symbol/ticker to display in the chart title
        show_volume (bool, optional): Whether to display volume bars
        height (int, optional): Height of the chart in pixels
        chart_type (str, optional): Type of chart - 'candle' or 'ohlc'
        
    Returns:
        str: JSON representation of the Plotly figure
    """
    try:
        # Convert to DataFrame if it's a list of lists
        if isinstance(ohlc_data, list):
            ohlc_df = pd.DataFrame(ohlc_data, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            # If timestamp is in milliseconds, convert to datetime
            if ohlc_df['timestamp'].iloc[0] > 1e10:
                ohlc_df['timestamp'] = pd.to_datetime(ohlc_df['timestamp'], unit='ms')
            else:
                ohlc_df['timestamp'] = pd.to_datetime(ohlc_df['timestamp'], unit='s')
        else:
            ohlc_df = ohlc_data.copy()
            
        # Create subplots with or without volume
        if show_volume:
            fig = make_subplots(rows=2, cols=1, shared_xaxes=True, 
                               vertical_spacing=0.02, 
                               row_heights=[0.8, 0.2])
        else:
            fig = make_subplots(rows=1, cols=1)
        
        # Add candlestick/OHLC chart
        if chart_type == 'candle':
            fig.add_trace(
                go.Candlestick(
                    x=ohlc_df['timestamp'],
                    open=ohlc_df['open'], 
                    high=ohlc_df['high'],
                    low=ohlc_df['low'], 
                    close=ohlc_df['close'],
                    name='Price',
                    increasing_line_color='#26a69a', 
                    decreasing_line_color='#ef5350'
                ),
                row=1, col=1
            )
        else:  # OHLC chart
            fig.add_trace(
                go.Ohlc(
                    x=ohlc_df['timestamp'],
                    open=ohlc_df['open'], 
                    high=ohlc_df['high'],
                    low=ohlc_df['low'], 
                    close=ohlc_df['close'],
                    name='Price',
                    increasing_line_color='#26a69a', 
                    decreasing_line_color='#ef5350'
                ),
                row=1, col=1
            )
        
        # Add volume bars if required
        if show_volume:
            # Color the volume bars based on price movement
            colors = ['#26a69a' if ohlc_df.close.iloc[i] >= ohlc_df.open.iloc[i] else '#ef5350' 
                     for i in range(len(ohlc_df))]
            
            fig.add_trace(
                go.Bar(
                    x=ohlc_df['timestamp'],
                    y=ohlc_df['volume'],
                    marker_color=colors,
                    name='Volume',
                    opacity=0.7
                ),
                row=2, col=1
            )
        
        # Add trade markers if provided
        if trades and len(trades) > 0:
            add_trades_to_chart(fig, trades, ohlc_df, show_volume)
        
        # Set chart title
        chart_title = f"{symbol} - {timeframe} Chart" if symbol else f"{timeframe} Chart"
        
        # Update layout
        fig.update_layout(
            title=chart_title,
            xaxis_title="Time",
            yaxis_title="Price",
            height=height,
            xaxis_rangeslider_visible=False,
            template='plotly_dark',
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            ),
            yaxis={
                'automargin': True,
            },
            margin=dict(l=50, r=50, b=50, t=80, pad=4)
        )
        
        if show_volume:
            fig.update_layout(
                yaxis2_title="Volume",
                yaxis2={
                    'automargin': True,
                }
            )
        
        # Convert to JSON and return
        return pio.to_json(fig)
        
    except Exception as e:
        logger.error(f"Error generating OHLC chart: {e}")
        # Create a default error chart
        error_fig = go.Figure()
        error_fig.add_trace(go.Scatter(
            x=[0, 1],
            y=[0, 0],
            mode='markers',
            marker=dict(color='red', size=10),
            name='Error'
        ))
        error_fig.update_layout(
            title=f"Error generating chart: {e}",
            annotations=[
                dict(
                    x=0.5,
                    y=0.5,
                    xref="paper",
                    yref="paper",
                    text=f"Error: {e}",
                    showarrow=False,
                    font=dict(size=16)
                )
            ]
        )
        return pio.to_json(error_fig)


def add_trades_to_chart(fig, trades, ohlc_df, show_volume=True):
    """
    Add trade entry and exit points to a chart.
    
    Args:
        fig (plotly.graph_objects.Figure): Plotly figure to add traces to
        trades (list): List of trade dictionaries
        ohlc_df (pandas.DataFrame): OHLC data as a DataFrame
        show_volume (bool): Whether the chart has a volume subplot
    """
    # Extract all entry and exit points
    entry_times = []
    entry_prices = []
    exit_times = []
    exit_prices = []
    profitable_trades = []
    trade_symbols = []
    trade_profits = []
    
    for trade in trades:
        if 'entry_time' in trade and 'entry_price' in trade:
            entry_time = parse_timestamp(trade['entry_time'])
            entry_times.append(entry_time)
            entry_prices.append(trade['entry_price'])
            
            # Track whether the trade was profitable
            is_profitable = False
            if 'exit_time' in trade and 'exit_price' in trade:
                exit_time = parse_timestamp(trade['exit_time'])
                exit_times.append(exit_time)
                exit_prices.append(trade['exit_price'])
                
                if 'profit_pct' in trade:
                    profit_pct = trade['profit_pct']
                    is_profitable = profit_pct > 0
                    trade_profits.append(profit_pct)
                elif trade['exit_price'] > trade['entry_price']:
                    is_profitable = True
                    trade_profits.append((trade['exit_price'] / trade['entry_price'] - 1) * 100)
                else:
                    trade_profits.append((trade['exit_price'] / trade['entry_price'] - 1) * 100)
            else:
                # If trade is still open
                exit_times.append(None)
                exit_prices.append(None)
                trade_profits.append(None)
                
            profitable_trades.append(is_profitable)
            trade_symbols.append(trade.get('symbol', 'Unknown'))
    
    # Add entry points
    for i, (time, price, profit, symbol) in enumerate(zip(entry_times, entry_prices, profitable_trades, trade_symbols)):
        if time is not None and price is not None:
            fig.add_trace(
                go.Scatter(
                    x=[time],
                    y=[price],
                    mode='markers',
                    marker=dict(
                        color='green',
                        size=10,
                        symbol='triangle-up',
                        line=dict(color='white', width=1)
                    ),
                    name='Entry',
                    text=[f"Entry: {symbol} @ {price}"],
                    legendgroup='entries',
                    showlegend=i==0  # Only show legend once for entries
                ),
                row=1, col=1
            )
    
    # Add exit points
    for i, (time, price, profit, profit_pct, symbol) in enumerate(zip(exit_times, exit_prices, profitable_trades, trade_profits, trade_symbols)):
        if time is not None and price is not None:
            color = 'green' if profit else 'red'
            text = f"Exit: {symbol} @ {price}<br>Profit: {profit_pct:.2f}%" if profit_pct is not None else f"Exit: {symbol} @ {price}"
            
            fig.add_trace(
                go.Scatter(
                    x=[time],
                    y=[price],
                    mode='markers',
                    marker=dict(
                        color=color,
                        size=10,
                        symbol='triangle-down',
                        line=dict(color='white', width=1)
                    ),
                    name='Exit',
                    text=[text],
                    legendgroup='exits',
                    showlegend=i==0  # Only show legend once for exits
                ),
                row=1, col=1
            )
    
    # Connect entry-exit pairs with lines
    for i, (entry_time, entry_price, exit_time, exit_price, profit, symbol) in enumerate(
        zip(entry_times, entry_prices, exit_times, exit_prices, profitable_trades, trade_symbols)
    ):
        if entry_time is not None and exit_time is not None:
            fig.add_trace(
                go.Scatter(
                    x=[entry_time, exit_time],
                    y=[entry_price, exit_price],
                    mode='lines',
                    line=dict(
                        color='green' if profit else 'red',
                        width=1,
                        dash='dot'
                    ),
                    name=f"{symbol} Trade",
                    showlegend=False
                ),
                row=1, col=1
            )


def parse_timestamp(timestamp):
    """
    Parse a timestamp in various formats to a datetime object.
    
    Args:
        timestamp (str, int, float, datetime): Timestamp to parse
        
    Returns:
        datetime: Parsed datetime object
    """
    if isinstance(timestamp, (datetime, pd.Timestamp)):
        return timestamp
    
    if isinstance(timestamp, (int, float)):
        # Check if milliseconds or seconds
        if timestamp > 1e10:  # Milliseconds
            return pd.Timestamp(timestamp, unit='ms')
        else:  # Seconds
            return pd.Timestamp(timestamp, unit='s')
    
    if isinstance(timestamp, str):
        try:
            # Try ISO format first
            return pd.Timestamp(timestamp)
        except:
            # Try various formats
            formats = [
                '%Y-%m-%d %H:%M:%S',
                '%Y-%m-%d %H:%M',
                '%Y-%m-%d',
                '%m/%d/%Y %H:%M:%S',
                '%m/%d/%Y'
            ]
            
            for fmt in formats:
                try:
                    return datetime.strptime(timestamp, fmt)
                except:
                    continue
    
    # Return current time if parsing fails
    logger.warning(f"Could not parse timestamp: {timestamp}. Using current time.")
    return datetime.now()


def generate_performance_chart(
    balance_history,
    trades=None,
    benchmark_data=None,
    height=400,
    show_trades=True
):
    """
    Generate a performance chart showing balance over time with optional benchmark comparison.
    
    Args:
        balance_history (list or pandas.DataFrame): Balance history data
        trades (list, optional): List of trade dictionaries
        benchmark_data (dict, optional): Benchmark data for comparison (e.g., BTC price)
        height (int, optional): Height of the chart in pixels
        show_trades (bool, optional): Whether to mark trades on the chart
        
    Returns:
        str: JSON representation of the Plotly figure
    """
    try:
        # Convert to DataFrame if it's a list
        if isinstance(balance_history, list):
            if isinstance(balance_history[0], dict):
                # List of dictionaries with timestamp and balance
                bal_df = pd.DataFrame(balance_history)
            else:
                # List of [timestamp, balance] pairs
                bal_df = pd.DataFrame(balance_history, columns=['timestamp', 'balance'])
                
            # Convert timestamp to datetime if needed
            if 'timestamp' in bal_df.columns:
                if pd.api.types.is_numeric_dtype(bal_df['timestamp']):
                    if bal_df['timestamp'].iloc[0] > 1e10:  # Milliseconds
                        bal_df['timestamp'] = pd.to_datetime(bal_df['timestamp'], unit='ms')
                    else:  # Seconds
                        bal_df['timestamp'] = pd.to_datetime(bal_df['timestamp'], unit='s')
                else:
                    bal_df['timestamp'] = pd.to_datetime(bal_df['timestamp'])
        else:
            bal_df = balance_history.copy()
        
        # Create figure
        fig = go.Figure()
        
        # Add balance line
        x_col = 'timestamp' if 'timestamp' in bal_df.columns else bal_df.columns[0]
        y_col = 'balance' if 'balance' in bal_df.columns else bal_df.columns[1]
        
        fig.add_trace(
            go.Scatter(
                x=bal_df[x_col],
                y=bal_df[y_col],
                mode='lines',
                name='Portfolio Balance',
                line=dict(color='#2962ff', width=2)
            )
        )
        
        # Add benchmark if provided
        if benchmark_data is not None:
            if isinstance(benchmark_data, dict):
                benchmark_df = pd.DataFrame(list(benchmark_data.items()), columns=['timestamp', 'value'])
                if pd.api.types.is_numeric_dtype(benchmark_df['timestamp']):
                    benchmark_df['timestamp'] = pd.to_datetime(benchmark_df['timestamp'], unit='ms')
                else:
                    benchmark_df['timestamp'] = pd.to_datetime(benchmark_df['timestamp'])
            else:
                benchmark_df = pd.DataFrame(benchmark_data, columns=['timestamp', 'value'])
                if pd.api.types.is_numeric_dtype(benchmark_df['timestamp']):
                    benchmark_df['timestamp'] = pd.to_datetime(benchmark_df['timestamp'], unit='ms')
            
            # Normalize benchmark to match starting portfolio value
            start_balance = bal_df[y_col].iloc[0]
            start_benchmark = benchmark_df['value'].iloc[0]
            benchmark_df['normalized_value'] = benchmark_df['value'] * (start_balance / start_benchmark)
            
            fig.add_trace(
                go.Scatter(
                    x=benchmark_df['timestamp'],
                    y=benchmark_df['normalized_value'],
                    mode='lines',
                    name='Benchmark',
                    line=dict(color='#ff6d00', width=1, dash='dash')
                )
            )
        
        # Mark trade entry/exit points if provided
        if trades and show_trades:
            # Extract trade times
            trade_times = []
            trade_effects = []
            trade_texts = []
            
            for trade in trades:
                if 'exit_time' in trade and trade['exit_time']:
                    time = parse_timestamp(trade['exit_time'])
                    effect = trade.get('profit_pct', 0)
                    symbol = trade.get('symbol', 'Unknown')
                    entry_price = trade.get('entry_price', 0)
                    exit_price = trade.get('exit_price', 0)
                    
                    trade_times.append(time)
                    trade_effects.append(effect)
                    trade_texts.append(f"{symbol}: {effect:.2f}%<br>Entry: {entry_price}<br>Exit: {exit_price}")
            
            # Find balance at each trade time
            trade_balances = []
            for time in trade_times:
                if len(bal_df) > 0:
                    # Find closest time in balance history
                    idx = (bal_df[x_col] - time).abs().argmin()
                    trade_balances.append(bal_df[y_col].iloc[idx])
                else:
                    trade_balances.append(None)
            
            # Add markers for profitable and unprofitable trades
            profitable_times = []
            profitable_balances = []
            profitable_texts = []
            
            unprofitable_times = []
            unprofitable_balances = []
            unprofitable_texts = []
            
            for time, balance, effect, text in zip(trade_times, trade_balances, trade_effects, trade_texts):
                if effect > 0:
                    profitable_times.append(time)
                    profitable_balances.append(balance)
                    profitable_texts.append(text)
                else:
                    unprofitable_times.append(time)
                    unprofitable_balances.append(balance)
                    unprofitable_texts.append(text)
            
            if profitable_times:
                fig.add_trace(
                    go.Scatter(
                        x=profitable_times,
                        y=profitable_balances,
                        mode='markers',
                        marker=dict(color='green', size=8, symbol='circle'),
                        name='Profitable Trade',
                        text=profitable_texts
                    )
                )
            
            if unprofitable_times:
                fig.add_trace(
                    go.Scatter(
                        x=unprofitable_times,
                        y=unprofitable_balances,
                        mode='markers',
                        marker=dict(color='red', size=8, symbol='circle'),
                        name='Unprofitable Trade',
                        text=unprofitable_texts
                    )
                )
        
        # Calculate and display performance metrics
        if len(bal_df) >= 2:
            start_value = bal_df[y_col].iloc[0]
            end_value = bal_df[y_col].iloc[-1]
            total_return_pct = ((end_value / start_value) - 1) * 100
            
            # Calculate maximum drawdown
            bal_df['rolling_max'] = bal_df[y_col].cummax()
            bal_df['drawdown'] = (bal_df[y_col] / bal_df['rolling_max'] - 1) * 100
            max_drawdown = bal_df['drawdown'].min()
            
            annotations = [
                dict(
                    x=1.0,
                    y=1.05,
                    xref='paper',
                    yref='paper',
                    text=f"Return: {total_return_pct:.2f}% | Max Drawdown: {max_drawdown:.2f}%",
                    showarrow=False,
                    font=dict(size=12),
                    xanchor='right'
                )
            ]
        else:
            annotations = []
        
        # Update layout
        fig.update_layout(
            title="Performance Chart",
            xaxis_title="Date",
            yaxis_title="Balance (USDT)",
            height=height,
            template='plotly_dark',
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            ),
            annotations=annotations,
            margin=dict(l=50, r=50, b=50, t=80, pad=4)
        )
        
        # Convert to JSON and return
        return pio.to_json(fig)
        
    except Exception as e:
        logger.error(f"Error generating performance chart: {e}")
        # Create a default error chart
        error_fig = go.Figure()
        error_fig.add_trace(go.Scatter(
            x=[0, 1],
            y=[0, 0],
            mode='markers',
            marker=dict(color='red', size=10),
            name='Error'
        ))
        error_fig.update_layout(
            title=f"Error generating performance chart: {e}",
            annotations=[
                dict(
                    x=0.5,
                    y=0.5,
                    xref="paper",
                    yref="paper",
                    text=f"Error: {e}",
                    showarrow=False,
                    font=dict(size=16)
                )
            ]
        )
        return pio.to_json(error_fig)