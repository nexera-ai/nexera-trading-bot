"""
AI Strategy Recommender for neXera Trading Platform.

This module analyzes historical performance data of different strategies
and generates optimized weight allocations based on ROI, Sharpe ratio,
volatility, and other metrics to recommend optimal strategy combinations.
"""

import logging
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any

from models import db, StrategyPreset, PresetEquityHistory, AllocationPreset

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class StrategyRecommender:
    """
    AI Strategy Recommender engine that analyzes strategy performance 
    and recommends optimal allocation weights.
    """
    
    def __init__(self):
        """Initialize the Strategy Recommender with default parameters."""
        # Scoring weights for different metrics (customizable)
        self.metric_weights = {
            'roi': 0.35,           # Return on Investment
            'sharpe_ratio': 0.25,  # Risk-adjusted return
            'win_rate': 0.15,      # Win/loss ratio
            'volatility': 0.15,    # Volatility (lower is better)
            'max_drawdown': 0.10,  # Maximum drawdown (lower is better)
        }
        
        # Default analysis period
        self.default_lookback_days = 30
        
        # Minimum weight allocation per strategy (avoid too small allocations)
        self.min_allocation = 0.05  # 5% minimum
        
        # Maximum weight allocation per strategy (avoid concentration risk)
        self.max_allocation = 0.70  # 70% maximum
        
        # Minimum data points required for analysis
        self.min_data_points = 5
        
        # Whether to recommend strategies with negative performance
        self.include_negative_performers = False
        
        # Whether to apply volatility-based adjustment
        self.volatility_adjusted = True
        
        # Whether to use market condition context
        self.use_market_context = True
        
        # Save optimization history
        self.optimization_history = []
        
        logger.info("Strategy Recommender initialized with default parameters")
    
    def set_metric_weights(self, weights: Dict[str, float]) -> None:
        """
        Set custom weights for scoring metrics.
        
        Args:
            weights: Dictionary mapping metric names to weight values (0-1)
        """
        # Validate weights
        total_weight = sum(weights.values())
        if abs(total_weight - 1.0) > 0.01:  # Allow small rounding errors
            logger.warning(f"Metric weights should sum to 1.0 (currently {total_weight:.2f})")
            # Normalize weights to sum to 1.0
            weights = {k: v / total_weight for k, v in weights.items()}
            
        self.metric_weights = weights
        logger.info(f"Metric weights updated: {weights}")
    
    def analyze_strategies(
        self,
        lookback_days: int = None,
        strategy_ids: List[int] = None,
        min_data_points: int = None
    ) -> Dict[int, Dict[str, Any]]:
        """
        Analyze strategies based on historical performance.
        
        Args:
            lookback_days: Number of days to look back for analysis
            strategy_ids: List of strategy IDs to analyze (None for all)
            min_data_points: Minimum data points required for analysis
            
        Returns:
            Dictionary mapping strategy IDs to their analysis results
        """
        lookback_days = lookback_days or self.default_lookback_days
        min_data_points = min_data_points or self.min_data_points
        
        # Calculate cutoff date
        cutoff_date = datetime.now() - timedelta(days=lookback_days)
        
        # Get strategies to analyze
        if strategy_ids:
            presets = StrategyPreset.query.filter(
                StrategyPreset.id.in_(strategy_ids)
            ).all()
        else:
            # Get all strategy presets
            presets = StrategyPreset.query.all()
        
        strategy_analysis = {}
        
        for preset in presets:
            # Get equity history for this preset within the lookback period
            equity_history = PresetEquityHistory.query.filter(
                PresetEquityHistory.preset_id == preset.id,
                PresetEquityHistory.timestamp >= cutoff_date
            ).order_by(PresetEquityHistory.timestamp).all()
            
            # Skip if not enough data points
            if len(equity_history) < min_data_points:
                logger.info(f"Skipping strategy {preset.name} (ID: {preset.id}) - insufficient data points ({len(equity_history)})")
                continue
            
            # Calculate performance metrics
            metrics = self._calculate_metrics(equity_history)
            
            # Skip strategies with negative performance if configured to do so
            if not self.include_negative_performers and metrics['roi'] < 0:
                logger.info(f"Skipping strategy {preset.name} (ID: {preset.id}) - negative ROI ({metrics['roi']:.2f}%)")
                continue
            
            # Add strategy to analysis results
            strategy_analysis[preset.id] = {
                'id': preset.id,
                'name': preset.name,
                'metrics': metrics,
                'score': self._calculate_score(metrics),
                'config_type': preset.config_type,
                'tags': preset.tags,
                'description': preset.description
            }
            
        logger.info(f"Analyzed {len(strategy_analysis)} strategies over {lookback_days} days")
        return strategy_analysis
    
    def _calculate_metrics(self, equity_history: List[PresetEquityHistory]) -> Dict[str, float]:
        """
        Calculate performance metrics from equity history.
        
        Args:
            equity_history: List of PresetEquityHistory objects
            
        Returns:
            Dictionary of calculated metrics
        """
        if not equity_history:
            return {
                'roi': 0,
                'sharpe_ratio': 0,
                'volatility': 0,
                'max_drawdown': 0,
                'win_rate': 0
            }
        
        # Extract equity values
        equity_values = [entry.equity for entry in equity_history]
        
        # Calculate ROI
        initial_equity = equity_values[0]
        final_equity = equity_values[-1]
        roi = ((final_equity / initial_equity) - 1) * 100
        
        # Calculate returns
        returns = np.diff(equity_values) / equity_values[:-1]
        
        # Calculate volatility (annualized standard deviation of returns)
        volatility = np.std(returns) * np.sqrt(252) * 100 if len(returns) > 1 else 0
        
        # Calculate Sharpe ratio if possible
        risk_free_rate = 0.02  # Assume 2% risk-free rate
        daily_risk_free = (1 + risk_free_rate) ** (1/252) - 1
        excess_returns = returns - daily_risk_free
        sharpe_ratio = np.mean(excess_returns) / np.std(returns) * np.sqrt(252) if len(returns) > 1 and np.std(returns) > 0 else 0
        
        # Calculate max drawdown
        peak = equity_values[0]
        max_drawdown = 0
        for value in equity_values:
            if value > peak:
                peak = value
            drawdown = (peak - value) / peak * 100
            max_drawdown = max(max_drawdown, drawdown)
        
        # Calculate win rate if available
        win_count = sum(1 for entry in equity_history if hasattr(entry, 'win_count') and entry.win_count is not None)
        loss_count = sum(1 for entry in equity_history if hasattr(entry, 'loss_count') and entry.loss_count is not None)
        
        if win_count + loss_count > 0:
            win_rate = win_count / (win_count + loss_count) * 100
        else:
            # If no win/loss data, estimate from returns
            win_rate = len([r for r in returns if r > 0]) / len(returns) * 100 if returns.size > 0 else 50
        
        return {
            'roi': roi,
            'sharpe_ratio': sharpe_ratio,
            'volatility': volatility,
            'max_drawdown': max_drawdown,
            'win_rate': win_rate
        }
    
    def _calculate_score(self, metrics: Dict[str, float]) -> float:
        """
        Calculate an overall score for a strategy based on its metrics.
        
        Args:
            metrics: Dictionary of performance metrics
            
        Returns:
            Composite score (higher is better)
        """
        # Normalize and weight each metric
        score_components = {}
        
        # ROI (higher is better)
        score_components['roi'] = max(0, metrics['roi'] / 100)  # Normalize to 0-1 range
        
        # Sharpe ratio (higher is better)
        score_components['sharpe_ratio'] = max(0, min(1, metrics['sharpe_ratio'] / 3))  # Normalize to 0-1 range
        
        # Volatility (lower is better)
        vol_score = max(0, 1 - (metrics['volatility'] / 50))  # Normalize to 0-1 range
        score_components['volatility'] = vol_score
        
        # Max drawdown (lower is better)
        dd_score = max(0, 1 - (metrics['max_drawdown'] / 50))  # Normalize to 0-1 range
        score_components['max_drawdown'] = dd_score
        
        # Win rate (higher is better)
        score_components['win_rate'] = metrics['win_rate'] / 100  # Normalize to 0-1 range
        
        # Calculate weighted score
        weighted_score = sum(
            score_components[metric] * weight
            for metric, weight in self.metric_weights.items()
            if metric in score_components
        )
        
        return weighted_score
    
    def recommend_allocation(
        self,
        lookback_days: int = None,
        strategy_ids: List[int] = None,
        min_allocation: float = None,
        max_allocation: float = None,
        optimization_objective: str = 'balanced',
        current_weights: Dict[int, float] = None
    ) -> Dict[str, Any]:
        """
        Recommend optimal allocation weights for strategies.
        
        Args:
            lookback_days: Number of days to look back for analysis
            strategy_ids: List of strategy IDs to consider (None for all)
            min_allocation: Minimum allocation per strategy (0-1)
            max_allocation: Maximum allocation per strategy (0-1)
            optimization_objective: Optimization objective 
                                   ('balanced', 'max_return', 'min_risk', 'max_sharpe')
            current_weights: Current allocation weights for comparison (optional)
                                   
        Returns:
            Dictionary with recommendation results
        """
        # Set parameters
        min_allocation = min_allocation or self.min_allocation
        max_allocation = max_allocation or self.max_allocation
        
        # Analyze strategies
        strategy_analysis = self.analyze_strategies(
            lookback_days=lookback_days,
            strategy_ids=strategy_ids
        )
        
        if not strategy_analysis:
            logger.warning("No suitable strategies found for allocation recommendation")
            return {
                'success': False,
                'message': 'No suitable strategies found for allocation recommendation',
                'timestamp': datetime.now().isoformat(),
                'weights': {}
            }
        
        # Get scores
        strategy_scores = {
            strategy_id: data['score']
            for strategy_id, data in strategy_analysis.items()
        }
        
        # Adjust scores based on optimization objective
        if optimization_objective == 'max_return':
            # Prioritize ROI more heavily
            strategy_scores = {
                strategy_id: data['metrics']['roi'] / 100 * 0.7 + data['score'] * 0.3
                for strategy_id, data in strategy_analysis.items()
            }
        elif optimization_objective == 'min_risk':
            # Prioritize low volatility and drawdown
            strategy_scores = {
                strategy_id: (1 - data['metrics']['volatility'] / 100) * 0.4 + 
                            (1 - data['metrics']['max_drawdown'] / 100) * 0.3 + 
                            data['score'] * 0.3
                for strategy_id, data in strategy_analysis.items()
            }
        elif optimization_objective == 'max_sharpe':
            # Prioritize Sharpe ratio
            strategy_scores = {
                strategy_id: data['metrics']['sharpe_ratio'] / 3 * 0.7 + data['score'] * 0.3
                for strategy_id, data in strategy_analysis.items()
                if data['metrics']['sharpe_ratio'] > 0
            }
        
        # Calculate initial weights based on scores
        total_score = sum(strategy_scores.values())
        if total_score <= 0:
            # If all scores are negative or zero, use equal weights
            raw_weights = {
                strategy_id: 1.0 / len(strategy_scores)
                for strategy_id in strategy_scores
            }
        else:
            # Allocate proportional to scores
            raw_weights = {
                strategy_id: score / total_score
                for strategy_id, score in strategy_scores.items()
            }
        
        # Apply min and max allocation constraints
        weights = self._optimize_weights(raw_weights, min_allocation, max_allocation)
        
        # Format weights as percentages
        weight_percentages = {
            str(strategy_id): round(weight * 100, 2)
            for strategy_id, weight in weights.items()
        }
        
        # Calculate projected metrics
        projected_metrics = self._calculate_projected_metrics(weights, strategy_analysis)
        
        # Format strategy details
        strategies = []
        for strategy_id, weight in weights.items():
            strategy_data = strategy_analysis[strategy_id]
            strategies.append({
                'id': strategy_id,
                'name': strategy_data['name'],
                'weight': round(weight * 100, 2),
                'score': strategy_data['score'],
                'roi': strategy_data['metrics']['roi'],
                'sharpe_ratio': strategy_data['metrics']['sharpe_ratio'],
                'volatility': strategy_data['metrics']['volatility'],
                'max_drawdown': strategy_data['metrics']['max_drawdown'],
                'win_rate': strategy_data['metrics']['win_rate']
            })
        
        # Sort strategies by weight (descending)
        strategies.sort(key=lambda s: s['weight'], reverse=True)
        
        # Create recommendation result
        result = {
            'success': True,
            'timestamp': datetime.now().isoformat(),
            'lookback_days': lookback_days or self.default_lookback_days,
            'optimization_objective': optimization_objective,
            'weights': weight_percentages,
            'projected_metrics': projected_metrics,
            'strategies': strategies
        }
        
        # Save to optimization history
        self.optimization_history.append({
            'timestamp': datetime.now(),
            'recommendation': result
        })
        
        logger.info(f"Generated allocation recommendation with {len(weights)} strategies")
        return result
    
    def _optimize_weights(
        self,
        raw_weights: Dict[int, float],
        min_allocation: float,
        max_allocation: float
    ) -> Dict[int, float]:
        """
        Optimize weights to satisfy constraints.
        
        Args:
            raw_weights: Initial weight allocations
            min_allocation: Minimum allocation per strategy
            max_allocation: Maximum allocation per strategy
            
        Returns:
            Optimized weights
        """
        # Sort strategies by weight (descending)
        sorted_strategies = sorted(
            raw_weights.items(),
            key=lambda x: x[1],
            reverse=True
        )
        
        # Initialize optimized weights
        optimized_weights = {}
        remaining_allocation = 1.0
        remaining_strategies = []
        
        # First pass: apply max constraint
        for strategy_id, weight in sorted_strategies:
            if weight > max_allocation:
                optimized_weights[strategy_id] = max_allocation
                remaining_allocation -= max_allocation
            else:
                remaining_strategies.append((strategy_id, weight))
        
        # Filter out strategies that would get less than min_allocation
        # if we distributed remaining_allocation equally
        while remaining_strategies and remaining_allocation / len(remaining_strategies) < min_allocation:
            # Remove the strategy with the lowest weight
            remaining_strategies.sort(key=lambda x: x[1])
            remaining_strategies.pop(0)
        
        # Second pass: distribute remaining allocation
        if remaining_strategies:
            # Get total weight of remaining strategies
            total_remaining_weight = sum(weight for _, weight in remaining_strategies)
            
            # Distribute proportionally
            for strategy_id, weight in remaining_strategies:
                if total_remaining_weight > 0:
                    proportion = weight / total_remaining_weight
                    optimized_weights[strategy_id] = remaining_allocation * proportion
                else:
                    # Equal distribution if all weights are zero
                    optimized_weights[strategy_id] = remaining_allocation / len(remaining_strategies)
        
        # Normalize to ensure sum to 1.0
        total_weight = sum(optimized_weights.values())
        if total_weight > 0:
            optimized_weights = {
                k: v / total_weight for k, v in optimized_weights.items()
            }
        
        return optimized_weights
    
    def _calculate_projected_metrics(
        self,
        weights: Dict[int, float],
        strategy_analysis: Dict[int, Dict[str, Any]]
    ) -> Dict[str, float]:
        """
        Calculate projected metrics for the recommended allocation.
        
        Args:
            weights: Allocation weights for strategies
            strategy_analysis: Analysis results for strategies
            
        Returns:
            Projected performance metrics
        """
        # Initialize metrics
        projected = {
            'roi': 0,
            'sharpe_ratio': 0,
            'volatility': 0,
            'max_drawdown': 0,
            'win_rate': 0
        }
        
        # Weighted average of metrics
        for strategy_id, weight in weights.items():
            metrics = strategy_analysis[strategy_id]['metrics']
            
            # ROI can be directly averaged
            projected['roi'] += metrics['roi'] * weight
            
            # Win rate can be directly averaged
            projected['win_rate'] += metrics['win_rate'] * weight
            
            # Max drawdown is not a simple weighted average, but we'll approximate
            projected['max_drawdown'] += metrics['max_drawdown'] * weight
        
        # Calculate volatility (more complex)
        # This is just an approximation, assuming independence between strategies
        weighted_variance = sum(
            (strategy_analysis[strategy_id]['metrics']['volatility'] / 100) ** 2 * weight ** 2
            for strategy_id, weight in weights.items()
        )
        projected['volatility'] = np.sqrt(weighted_variance) * 100
        
        # Approximate Sharpe ratio
        if projected['volatility'] > 0:
            projected['sharpe_ratio'] = (projected['roi'] / 100) / (projected['volatility'] / 100) * np.sqrt(252)
        else:
            projected['sharpe_ratio'] = 0
        
        return projected
    
    def save_recommendation_as_preset(
        self,
        recommendation: Dict[str, Any],
        name: str = None,
        description: str = None
    ) -> Optional[AllocationPreset]:
        """
        Save a recommendation as an allocation preset.
        
        Args:
            recommendation: Recommendation result from recommend_allocation
            name: Name for the preset (default: "AI Recommendation - {date}")
            description: Description for the preset
            
        Returns:
            Created AllocationPreset instance or None if failed
        """
        try:
            if not recommendation or not recommendation.get('success'):
                logger.error("Cannot save invalid recommendation")
                return None
            
            # Create name if not provided
            if not name:
                current_date = datetime.now().strftime('%Y-%m-%d %H:%M')
                name = f"AI Recommendation - {current_date}"
            
            # Create description if not provided
            if not description:
                lookback = recommendation.get('lookback_days', self.default_lookback_days)
                objective = recommendation.get('optimization_objective', 'balanced')
                description = (
                    f"AI-generated allocation based on {lookback} days of historical data. "
                    f"Optimization objective: {objective}. "
                    f"Generated on {datetime.now().strftime('%Y-%m-%d %H:%M')}."
                )
            
            # Convert percentage weights back to proportions
            weights = {
                int(strategy_id): float(weight) / 100
                for strategy_id, weight in recommendation['weights'].items()
            }
            
            # Create preset
            preset = AllocationPreset(
                name=name,
                description=description,
                weights=weights,
                created_at=datetime.now(),
                updated_at=datetime.now(),
                is_favorite=False,
                tags="ai-generated,recommendation"
            )
            
            # Add projected metrics
            if 'projected_metrics' in recommendation:
                preset.total_return = recommendation['projected_metrics'].get('roi')
                preset.sharpe_ratio = recommendation['projected_metrics'].get('sharpe_ratio')
                preset.max_drawdown = recommendation['projected_metrics'].get('max_drawdown')
                preset.volatility = recommendation['projected_metrics'].get('volatility')
            
            # Save to database
            db.session.add(preset)
            db.session.commit()
            
            logger.info(f"Saved recommendation as preset '{name}' (ID: {preset.id})")
            return preset
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error saving recommendation as preset: {e}")
            return None


# Global instance
strategy_recommender = StrategyRecommender()