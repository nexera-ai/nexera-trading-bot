"""
Risk-Off Trigger System

This module provides automated risk management by monitoring market conditions
and triggering defensive actions when volatile or dangerous market conditions are detected.

Key features:
- Market volatility monitoring with multiple metrics
- Rapid drawdown detection and response
- Auto-scaling of position sizes based on risk level
- Integration with strategy rotation and capital scaling systems
- Automatic recovery when market conditions normalize

Usage:
    from risk_manager import risk_manager
    
    # Check current risk status
    risk_status = risk_manager.get_current_risk_status()
    
    # Manually trigger risk-off mode
    risk_manager.activate_risk_off_mode("Manual trigger due to news event")
    
    # Reset to normal operations
    risk_manager.reset_to_normal()
"""

import logging
import time
import math
import traceback
from datetime import datetime, timedelta
from enum import Enum
from typing import Dict, List, Optional, Tuple, Union, Any

import threading

# This is imported with partial imports to avoid circular imports
# Full imports are done in the RiskManager.__init__ method
from trading_bot import adjust_position_size_multiplier

# Import the alert notifier for risk notifications
try:
    from alert_notifier import alert_notifier, AlertType, AlertPriority, AlertChannel
except ImportError:
    # Create a dummy alert_notifier for backwards compatibility
    class DummyAlertNotifier:
        def send_alert(self, *args, **kwargs):
            logger.debug("Alert notification skipped (alert_notifier not available)")
            return {"status": "skipped", "reason": "module_not_available"}
    
    alert_notifier = DummyAlertNotifier()
    
    # Create dummy enums for backwards compatibility
    class AlertType(Enum):
        RISK_LEVEL_CHANGE = "risk_level_change"
        RISK_OFF_ACTIVATED = "risk_off_activated"
        RISK_OFF_DEACTIVATED = "risk_off_deactivated"
        DEFENSIVE_ACTION = "defensive_action"
        MANUAL_OVERRIDE = "manual_override"
        EMERGENCY_STOP = "emergency_stop"
        
    class AlertPriority(Enum):
        LOW = "low"
        MEDIUM = "medium" 
        HIGH = "high"
        CRITICAL = "critical"
        
    class AlertChannel(Enum):
        EMAIL = "email"
        SMS = "sms"
        WEB = "web"

logger = logging.getLogger(__name__)

# Risk level definitions
class RiskLevel(Enum):
    """Risk levels used by the Risk-Off Trigger System"""
    NORMAL = 0       # Normal market conditions, full operations
    ELEVATED = 1     # Slightly elevated risk, reduce position sizes
    HIGH = 2         # High risk, significant position size reduction
    SEVERE = 3       # Severe risk, enter defensive posture
    EXTREME = 4      # Extreme risk, pause all trading


class RiskMetricType(Enum):
    """Types of risk metrics tracked by the system"""
    VOLATILITY = "volatility"            # Market volatility metrics
    DRAWDOWN = "drawdown"                # Portfolio/asset drawdown
    CORRELATION = "correlation"          # Asset correlation
    VOLUME = "volume"                    # Unusual volume
    PRICE_ACTION = "price_action"        # Unusual price action
    TREND_STRENGTH = "trend_strength"    # Trend strength indicators
    LIQUIDITY = "liquidity"              # Market liquidity
    MARKET_IMPACT = "market_impact"      # Our own market impact
    CUSTOM = "custom"                    # Custom risk metrics


class RiskManager:
    """
    Risk-Off Trigger System that monitors market conditions and activates
    defensive measures when risky conditions are detected.
    """
    
    def __init__(self):
        """Initialize the risk manager"""
        # Configuration
        self.enabled = False
        self.check_interval_minutes = 5
        self.recovery_check_interval_minutes = 15
        self.auto_recovery_enabled = True
        
        # Risk thresholds
        self.volatility_threshold_elevated = 1.5    # 1.5x normal volatility
        self.volatility_threshold_high = 2.0        # 2x normal volatility
        self.volatility_threshold_severe = 3.0      # 3x normal volatility
        self.volatility_threshold_extreme = 4.0     # 4x normal volatility
        
        self.drawdown_threshold_elevated = 0.03     # 3% drawdown
        self.drawdown_threshold_high = 0.05         # 5% drawdown
        self.drawdown_threshold_severe = 0.08       # 8% drawdown
        self.drawdown_threshold_extreme = 0.12      # 12% drawdown
        
        self.volume_threshold_elevated = 1.5        # 1.5x normal volume
        self.volume_threshold_high = 2.0            # 2x normal volume
        self.volume_threshold_severe = 3.0          # 3x normal volume
        
        # Risk state
        self.current_risk_level = RiskLevel.NORMAL
        self.current_level_since = datetime.now()
        self.risk_level_history = []
        self.action_history = []
        self.max_history_items = 100  # Maximum number of history items to keep
        
        self.risk_off_activated_at = None
        self.risk_off_reason = None
        self.normal_operations_restored_at = None
        self.recovery_attempts = 0
        self.emergency_recovery_required = False
        
        # Defensive action tracking
        self.current_actions = {}
        
        # Strategy risk mapping (lower number = lower risk)
        self.strategy_risk_mapping = {
            'dip_buyer': 3,  # Higher risk (requires price drops)
            'mean_reversion': 2,  # Medium risk
            'breakout': 3,  # Higher risk
            'trend_follower': 2  # Medium risk
        }
        
        # Position size multiplier for severe risk
        self.severe_risk_position_multiplier = 0.3
        self.max_recovery_attempts = 3
        self.recovery_cooldown_minutes = 60
        
        # Risk metrics
        self.volatility_metrics = {}
        self.drawdown_metrics = {}
        self.volume_metrics = {}
        self.price_action_metrics = {}
        self.baseline_metrics = {}
        
        # Risk detection settings
        self.rapid_change_threshold = 0.03          # 3% in short timeframe
        self.rapid_change_lookback_minutes = 15     # Look back 15 minutes
        self.extreme_volume_threshold = 3.0         # 3x normal volume
        self.unusual_spread_threshold = 2.0         # 2x normal spread
        
        # Integration settings
        self.should_scale_positions = True          # Scale down position sizes
        self.should_modify_stop_losses = True       # Tighten stop losses
        self.should_switch_strategies = True        # Switch to defensive strategies
        self.should_pause_capital_scaling = True    # Pause capital scaling boosts
        
        # Threading
        self.monitoring_thread = None
        self.is_running = False
        self.thread_lock = threading.Lock()
        
        # Emergency settings
        self.emergency_stop_threshold = 0.15        # 15% drawdown emergency stop
        self.emergency_recovery_required = False    # Require manual recovery after emergency
        
        # Performance impact tracking
        self.performance_impact = {
            'capital_preserved': 0.0,               # Estimated capital preserved by risk-off actions
            'opportunity_cost': 0.0,                # Estimated opportunity cost of risk-off actions
            'false_alarms': 0,                      # Number of false alarms
            'successful_interventions': 0,          # Number of successful interventions
        }
        
        # Update strategy risk mapping with additional strategies
        self.strategy_risk_mapping.update({
            'trend_following': 2,        # Medium risk strategy
            'range_trading': 1,          # Lower risk strategy
            'grid_trading': 1,           # Lower risk strategy
            'stablecoin_yield': 0,       # Lowest risk (safe haven)
        })
        
    def start(self):
        """Start the risk monitoring thread"""
        if self.is_running:
            logger.info("Risk monitoring is already running")
            return
            
        self.enabled = True
        self.is_running = True
        
        # Initialize baseline metrics
        self._initialize_baseline_metrics()
        
        self.monitoring_thread = threading.Thread(
            target=self._monitoring_loop,
            daemon=True
        )
        self.monitoring_thread.start()
        
        logger.info("Risk-Off Trigger System started")
        
    def stop(self):
        """Stop the risk monitoring thread"""
        self.is_running = False
        if self.monitoring_thread and self.monitoring_thread.is_alive():
            self.monitoring_thread.join(timeout=5.0)
        logger.info("Risk-Off Trigger System stopped")
        
    def _monitoring_loop(self):
        """Main monitoring loop that runs in a separate thread"""
        while self.is_running:
            try:
                # Only check if enabled
                if self.enabled:
                    self._check_risk_metrics()
                    
                    # Check if we need to attempt recovery
                    if (self.current_risk_level != RiskLevel.NORMAL and 
                        self.auto_recovery_enabled and 
                        self.risk_off_activated_at):
                        
                        # Calculate time since risk-off mode activated
                        time_since_activation = datetime.now() - self.risk_off_activated_at
                        recovery_interval = timedelta(minutes=self.recovery_check_interval_minutes)
                        
                        if time_since_activation > recovery_interval:
                            self._attempt_recovery()
                
                # Sleep for the check interval
                check_interval = (self.check_interval_minutes * 60)
                time.sleep(check_interval)
                
            except Exception as e:
                logger.error(f"Error in risk monitoring loop: {e}")
                time.sleep(60)  # Wait a minute before trying again
                
    def _initialize_baseline_metrics(self):
        """Initialize baseline metrics for volatility and volume comparisons"""
        # Import here to avoid circular imports
        try:
            from trading_bot import get_historical_data
        except ImportError:
            logger.warning("Could not import get_historical_data, using fallback data")
            # Define a fallback function for testing
            def get_historical_data(symbol, timeframe, limit=100):
                """Fallback historical data when actual data isn't available"""
                import numpy as np
                import pandas as pd
                from datetime import datetime, timedelta
                import random
                
                # Create mock OHLCV data for testing only
                now = datetime.now()
                dates = [now - timedelta(hours=i) for i in range(limit)]
                dates.reverse()
                
                # Generate basic price data
                base_price = 50000.0  # For BTC
                if 'ETH' in symbol:
                    base_price = 3000.0
                elif 'SOL' in symbol:
                    base_price = 150.0
                
                # Create synthetic data with trend and volatility
                trend = np.linspace(0, 0.1, limit)  # 10% trend
                cycle = 0.03 * np.sin(np.linspace(0, 4*np.pi, limit))
                noise = 0.01 * np.random.randn(limit)
                changes = trend + cycle + noise
                
                # Generate OHLCV data
                mock_data = []
                current_price = base_price
                
                for i in range(limit):
                    # Calculate price movement
                    change_pct = changes[i]
                    new_price = current_price * (1 + change_pct)
                    
                    # Create candle data
                    open_price = current_price
                    close_price = new_price
                    high_price = max(open_price, close_price) * (1 + 0.005)
                    low_price = min(open_price, close_price) * (1 - 0.005)
                    volume = base_price * random.uniform(50, 150)
                    
                    # Add to results
                    timestamp = int(dates[i].timestamp() * 1000)
                    candle = [timestamp, open_price, high_price, low_price, close_price, volume]
                    mock_data.append(candle)
                    
                    current_price = new_price
                
                df = pd.DataFrame(mock_data, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
                return df
        
        try:
            # Get baseline data for major pairs
            pairs = ["BTC/USDT", "ETH/USDT"]
            timeframes = ["1h", "4h", "1d"]
            
            self.baseline_metrics = {}
            
            for pair in pairs:
                self.baseline_metrics[pair] = {}
                
                for timeframe in timeframes:
                    # Get last 30 days of data
                    data = get_historical_data(pair, timeframe, limit=720)  # 30 days x 24 hours
                    
                    if not data or len(data) < 30:
                        logger.warning(f"Insufficient historical data for {pair} {timeframe}")
                        continue
                        
                    # Calculate baseline volatility (standard deviation of returns)
                    closes = [candle[4] for candle in data]  # Close prices
                    returns = []
                    
                    for i in range(1, len(closes)):
                        returns.append((closes[i] - closes[i-1]) / closes[i-1])
                        
                    # Calculate standard deviation of returns
                    import numpy as np
                    volatility = np.std(returns) if returns else 0
                    
                    # Calculate average volume
                    volumes = [candle[5] for candle in data]  # Volume
                    avg_volume = sum(volumes) / len(volumes) if volumes else 0
                    
                    # Store baseline metrics
                    self.baseline_metrics[pair][timeframe] = {
                        'volatility': volatility,
                        'avg_volume': avg_volume,
                        'updated_at': datetime.now()
                    }
                    
            logger.info(f"Initialized baseline metrics for {len(pairs)} pairs")
            
        except Exception as e:
            logger.error(f"Error initializing baseline metrics: {e}")
            
    def _update_risk_metrics(self):
        """Update current risk metrics based on market data"""
        # Import here to avoid circular imports
        try:
            from trading_bot import get_historical_data
        except ImportError:
            # Use the same fallback function defined in _initialize_baseline_metrics
            logger.warning("Could not import get_historical_data from trading_bot in _update_risk_metrics")
            get_historical_data = getattr(self, '_get_historical_data_fallback', None)
            if not get_historical_data:
                logger.error("No fallback function for get_historical_data available")
                return
                
        from performance_tracker import performance_tracker
        
        try:
            # Update volatility metrics
            pairs = ["BTC/USDT", "ETH/USDT"]
            timeframes = ["1h", "4h"]
            
            for pair in pairs:
                for timeframe in timeframes:
                    # Get recent data
                    data = get_historical_data(pair, timeframe, limit=24)
                    
                    if not data or len(data) < 12:
                        logger.warning(f"Insufficient recent data for {pair} {timeframe}")
                        continue
                        
                    # Calculate current volatility
                    closes = [candle[4] for candle in data]  # Close prices
                    returns = []
                    
                    for i in range(1, len(closes)):
                        returns.append((closes[i] - closes[i-1]) / closes[i-1])
                        
                    # Calculate standard deviation of returns
                    import numpy as np
                    current_volatility = np.std(returns) if returns else 0
                    
                    # Calculate current volume
                    volumes = [candle[5] for candle in data]  # Volume
                    current_volume = sum(volumes[-5:]) / 5 if len(volumes) >= 5 else 0
                    
                    # Calculate volatility ratio (current vs baseline)
                    baseline = self.baseline_metrics.get(pair, {}).get(timeframe, {})
                    baseline_volatility = baseline.get('volatility', 0.001)  # Avoid division by zero
                    baseline_volume = baseline.get('avg_volume', 0.001)  # Avoid division by zero
                    
                    volatility_ratio = current_volatility / baseline_volatility if baseline_volatility else 1
                    volume_ratio = current_volume / baseline_volume if baseline_volume else 1
                    
                    # Store metrics
                    if pair not in self.volatility_metrics:
                        self.volatility_metrics[pair] = {}
                    
                    if pair not in self.volume_metrics:
                        self.volume_metrics[pair] = {}
                        
                    self.volatility_metrics[pair][timeframe] = {
                        'current': current_volatility,
                        'baseline': baseline_volatility,
                        'ratio': volatility_ratio,
                        'updated_at': datetime.now()
                    }
                    
                    self.volume_metrics[pair][timeframe] = {
                        'current': current_volume,
                        'baseline': baseline_volume,
                        'ratio': volume_ratio,
                        'updated_at': datetime.now()
                    }
            
            # Update drawdown metrics from performance tracker
            portfolio_stats = performance_tracker.get_portfolio_stats()
            
            max_drawdown = portfolio_stats.get('max_drawdown', 0)
            current_drawdown = portfolio_stats.get('current_drawdown', 0)
            
            self.drawdown_metrics = {
                'max': max_drawdown,
                'current': current_drawdown,
                'updated_at': datetime.now()
            }
            
            logger.debug(f"Updated risk metrics - volatility, volume, and drawdown")
            
        except Exception as e:
            logger.error(f"Error updating risk metrics: {e}")
            
    def _check_risk_metrics(self):
        """Check if any risk metrics exceed our thresholds"""
        # First update all metrics
        self._update_risk_metrics()
        
        # Start with assumption of normal conditions
        highest_risk_level = RiskLevel.NORMAL
        risk_triggers = {}
        
        # Check volatility metrics
        for pair, timeframes in self.volatility_metrics.items():
            for timeframe, metrics in timeframes.items():
                volatility_ratio = metrics.get('ratio', 1.0)
                
                # Determine risk level based on volatility ratio
                if volatility_ratio >= self.volatility_threshold_extreme:
                    risk_level = RiskLevel.EXTREME
                elif volatility_ratio >= self.volatility_threshold_severe:
                    risk_level = RiskLevel.SEVERE
                elif volatility_ratio >= self.volatility_threshold_high:
                    risk_level = RiskLevel.HIGH
                elif volatility_ratio >= self.volatility_threshold_elevated:
                    risk_level = RiskLevel.ELEVATED
                else:
                    risk_level = RiskLevel.NORMAL
                    
                # Update highest risk level found
                if risk_level.value > highest_risk_level.value:
                    highest_risk_level = risk_level
                    risk_triggers['primary_trigger'] = f"Volatility ({pair} {timeframe})"
                    risk_triggers['volatility_ratio'] = volatility_ratio
        
        # Check drawdown metrics
        current_drawdown = self.drawdown_metrics.get('current', 0)
        
        # Emergency stop check
        if current_drawdown >= self.emergency_stop_threshold:
            # This is a critical situation, activate emergency procedures
            highest_risk_level = RiskLevel.EXTREME
            risk_triggers['primary_trigger'] = f"Emergency drawdown threshold exceeded"
            risk_triggers['drawdown'] = current_drawdown
            self.emergency_recovery_required = True
            
        # Normal drawdown thresholds
        elif current_drawdown >= self.drawdown_threshold_extreme:
            drawdown_risk = RiskLevel.EXTREME
        elif current_drawdown >= self.drawdown_threshold_severe:
            drawdown_risk = RiskLevel.SEVERE
        elif current_drawdown >= self.drawdown_threshold_high:
            drawdown_risk = RiskLevel.HIGH
        elif current_drawdown >= self.drawdown_threshold_elevated:
            drawdown_risk = RiskLevel.ELEVATED
        else:
            drawdown_risk = RiskLevel.NORMAL
            
        # Update highest risk level if drawdown risk is higher
        if drawdown_risk.value > highest_risk_level.value:
            highest_risk_level = drawdown_risk
            risk_triggers['primary_trigger'] = f"Portfolio drawdown"
            risk_triggers['drawdown'] = current_drawdown
        
        # Check volume metrics (unusual volume can indicate upcoming volatility)
        for pair, timeframes in self.volume_metrics.items():
            for timeframe, metrics in timeframes.items():
                volume_ratio = metrics.get('ratio', 1.0)
                
                # Determine risk level based on volume ratio
                if volume_ratio >= self.volume_threshold_severe:
                    volume_risk = RiskLevel.HIGH  # High not severe since volume alone isn't as critical
                elif volume_ratio >= self.volume_threshold_high:
                    volume_risk = RiskLevel.ELEVATED
                elif volume_ratio >= self.volume_threshold_elevated:
                    volume_risk = RiskLevel.ELEVATED
                else:
                    volume_risk = RiskLevel.NORMAL
                    
                # Update highest risk level if volume risk is higher
                if volume_risk.value > highest_risk_level.value:
                    highest_risk_level = volume_risk
                    risk_triggers['primary_trigger'] = f"Unusual volume ({pair} {timeframe})"
                    risk_triggers['volume_ratio'] = volume_ratio
        
        # If risk level has changed, take appropriate actions
        if highest_risk_level != self.current_risk_level:
            self._update_risk_level(highest_risk_level, risk_triggers)
            
    def _update_risk_level(self, new_risk_level: RiskLevel, triggers: Dict[str, Any]):
        """Update the current risk level and take appropriate actions"""
        old_risk_level = self.current_risk_level
        self.current_risk_level = new_risk_level
        self.current_level_since = datetime.now()
        
        # Create a record for the risk level history
        history_entry = {
            'timestamp': datetime.now(),
            'from_level': old_risk_level.name,
            'to_level': new_risk_level.name,
            'triggers': triggers
        }
        
        # Add to history and maintain max length
        self.risk_level_history.append(history_entry)
        if len(self.risk_level_history) > self.max_history_items:
            self.risk_level_history = self.risk_level_history[-self.max_history_items:]
        
        logger.info(f"Risk level changed from {old_risk_level.name} to {new_risk_level.name}")
        
        # Map risk levels to alert priorities
        risk_priority_map = {
            RiskLevel.NORMAL: AlertPriority.LOW,
            RiskLevel.ELEVATED: AlertPriority.MEDIUM,
            RiskLevel.HIGH: AlertPriority.HIGH,
            RiskLevel.SEVERE: AlertPriority.HIGH,
            RiskLevel.EXTREME: AlertPriority.CRITICAL
        }
        
        # Send alert notification for risk level change
        alert_message = f"Risk level changed from {old_risk_level.name} to {new_risk_level.name}"
        trigger_reason = triggers.get('primary_trigger', 'Multiple risk factors')
        
        alert_details = {
            'old_risk_level': old_risk_level.name,
            'new_risk_level': new_risk_level.name,
            'trigger_reason': trigger_reason
        }
        
        # Add specific metrics that triggered the change if available
        if 'volatility_ratio' in triggers:
            alert_details['volatility_ratio'] = triggers['volatility_ratio']
        if 'drawdown' in triggers:
            alert_details['drawdown'] = triggers['drawdown']
        if 'volume_ratio' in triggers:
            alert_details['volume_ratio'] = triggers['volume_ratio']
            
        # Send the alert with appropriate priority
        priority = risk_priority_map.get(new_risk_level, AlertPriority.MEDIUM)
        alert_notifier.send_alert(
            AlertType.RISK_LEVEL_CHANGE,
            alert_message,
            details=alert_details,
            priority=priority
        )
        
        # If moving to any elevated risk level, activate risk-off mode
        if new_risk_level != RiskLevel.NORMAL and old_risk_level == RiskLevel.NORMAL:
            trigger_reason = triggers.get('primary_trigger', 'Multiple risk factors')
            self.activate_risk_off_mode(f"{trigger_reason} - {new_risk_level.name} risk detected")
            
        # If returning to normal from an elevated level, restore normal operations
        elif new_risk_level == RiskLevel.NORMAL and old_risk_level != RiskLevel.NORMAL:
            # Only auto-recover if not in emergency mode
            if not self.emergency_recovery_required:
                self.reset_to_normal()
            else:
                logger.warning("Emergency recovery required - manual intervention needed")
        
        # If moving between non-normal risk levels, update the defensive posture
        elif new_risk_level != RiskLevel.NORMAL and old_risk_level != RiskLevel.NORMAL:
            self._adjust_defensive_posture(new_risk_level)
            
    def manual_risk_off(self, risk_level: RiskLevel, reason: str):
        """
        Manually trigger risk-off mode with a specific risk level.
        
        Args:
            risk_level (RiskLevel): The risk level to set
            reason (str): The reason for activating risk-off mode
        """
        # Update the risk level
        old_level = self.current_risk_level
        self.current_risk_level = risk_level
        self.current_level_since = datetime.now()
        
        # Record level change in history
        history_entry = {
            'timestamp': datetime.now(),
            'from_level': old_level.name,
            'to_level': risk_level.name,
            'reason': reason
        }
        self.risk_level_history.append(history_entry)
        
        # Send manual override alert with HIGH priority to ensure notification
        alert_message = f"MANUAL OVERRIDE: Risk level set to {risk_level.name}"
        alert_details = {
            'old_risk_level': old_level.name,
            'new_risk_level': risk_level.name,
            'reason': reason,
            'user_triggered': True
        }
        
        # Always use HIGH priority for manual overrides
        alert_notifier.send_alert(
            AlertType.MANUAL_OVERRIDE,
            alert_message,
            details=alert_details,
            priority=AlertPriority.HIGH,
            # Manual overrides should use all available channels
            channels=[AlertChannel.EMAIL, AlertChannel.SMS, AlertChannel.WEB]
        )
        
        # Activate risk-off with the provided reason
        self.activate_risk_off_mode(f"MANUAL: {reason}")
    
    def manual_reset_to_normal(self, reason: str):
        """
        Manually reset to normal operations.
        
        Args:
            reason (str): The reason for resetting to normal
        """
        # Override any emergency recovery requirements
        self.emergency_recovery_required = False
        
        # Reset the risk level
        old_level = self.current_risk_level
        self.current_risk_level = RiskLevel.NORMAL
        self.current_level_since = datetime.now()
        
        # Record level change in history
        history_entry = {
            'timestamp': datetime.now(),
            'from_level': old_level.name,
            'to_level': RiskLevel.NORMAL.name,
            'reason': reason
        }
        self.risk_level_history.append(history_entry)
        
        # Reset to normal operations
        self.reset_to_normal()
        
    def is_action_active(self, action_name: str) -> bool:
        """
        Check if a specific defensive action is currently active.
        
        Args:
            action_name (str): The name of the action to check
            
        Returns:
            bool: True if the action is active, False otherwise
        """
        # If we're in normal mode, no actions are active
        if self.current_risk_level == RiskLevel.NORMAL:
            return False
            
        # Check if we have active actions for this type
        for action in reversed(self.action_history):
            if action.get('type') == 'activate_risk_off':
                return True
            elif action.get('type') == 'restore_normal':
                return False
                
        return False
    
    def get_position_size_multiplier(self) -> float:
        """
        Get the current position size multiplier based on risk level.
        
        Returns:
            float: The position size multiplier (0.0-1.0)
        """
        if self.current_risk_level == RiskLevel.NORMAL:
            return 1.0
        elif self.current_risk_level == RiskLevel.ELEVATED:
            return 0.75
        elif self.current_risk_level == RiskLevel.HIGH:
            return 0.5
        elif self.current_risk_level == RiskLevel.SEVERE:
            return getattr(self, 'severe_risk_position_multiplier', 0.3)
        elif self.current_risk_level == RiskLevel.EXTREME:
            return 0.0
        else:
            return 1.0
    
    def get_current_metrics(self) -> dict:
        """
        Get current risk metrics for display in the dashboard.
        
        Returns:
            dict: Dictionary of current metrics by category
        """
        # Create mock data for UI testing since we don't have real metrics yet
        # This will be replaced with real metrics as they become available
        return {
            'volatility': {
                'BTC_Volatility': {
                    'value': 1.2,
                    'percent': 60,
                    'is_high_risk': False,
                    'is_medium_risk': True
                },
                'Market_Volatility': {
                    'value': 0.9,
                    'percent': 45,
                    'is_high_risk': False,
                    'is_medium_risk': False
                }
            },
            'drawdown': {
                'Portfolio_Drawdown': {
                    'value': 2.5,
                    'percent': 25,
                    'is_high_risk': False,
                    'is_medium_risk': False
                },
                'BTC_Drawdown': {
                    'value': 5.2,
                    'percent': 52,
                    'is_high_risk': False,
                    'is_medium_risk': True
                }
            },
            'price_action': {
                'Short_Term_Momentum': {
                    'value': -0.3,
                    'percent': 30,
                    'is_high_risk': False,
                    'is_medium_risk': False
                },
                'Sudden_Price_Change': {
                    'value': 0.7,
                    'percent': 35,
                    'is_high_risk': False,
                    'is_medium_risk': False
                }
            },
            'trend_strength': {
                'BTC_Trend': {
                    'value': 0.5,
                    'percent': 50,
                    'is_high_risk': False,
                    'is_medium_risk': False
                },
                'Market_Direction': {
                    'value': 0.6,
                    'percent': 60,
                    'is_high_risk': False,
                    'is_medium_risk': True
                }
            }
        }
    
    def activate_risk_off_mode(self, reason: str):
        """
        Activate risk-off mode with the specified reason.
        
        Args:
            reason (str): The reason for activating risk-off mode
        """
        # Record activation time and reason
        self.risk_off_activated_at = datetime.now()
        self.risk_off_reason = reason
        self.normal_operations_restored_at = None
        self.recovery_attempts = 0
        
        # Take defensive actions
        self._take_defensive_actions()
        
        logger.warning(f"ACTIVATED RISK-OFF MODE: {reason}")
        
        # Create action record
        action = {
            'timestamp': datetime.now(),
            'type': 'activate_risk_off',
            'risk_level': self.current_risk_level.name,
            'reason': reason
        }
        self.action_history.append(action)
        
        # Send risk-off activation alert
        alert_message = f"RISK-OFF MODE ACTIVATED: {self.current_risk_level.name} risk level"
        alert_details = {
            'risk_level': self.current_risk_level.name,
            'reason': reason,
            'actions_taken': self._get_active_defensive_actions()
        }
        
        # Map risk levels to alert priorities
        risk_priority_map = {
            RiskLevel.NORMAL: AlertPriority.LOW,
            RiskLevel.ELEVATED: AlertPriority.MEDIUM,
            RiskLevel.HIGH: AlertPriority.HIGH,
            RiskLevel.SEVERE: AlertPriority.HIGH,
            RiskLevel.EXTREME: AlertPriority.CRITICAL
        }
        
        # Higher risk levels should always trigger SMS
        channels = [AlertChannel.EMAIL, AlertChannel.WEB]
        if self.current_risk_level.value >= RiskLevel.HIGH.value:
            channels.append(AlertChannel.SMS)
        
        priority = risk_priority_map.get(self.current_risk_level, AlertPriority.HIGH)
        alert_notifier.send_alert(
            AlertType.RISK_OFF_ACTIVATED,
            alert_message,
            details=alert_details,
            priority=priority,
            channels=channels
        )
        
        # Notify any subscribers (could be implemented as a callback system)
        self._notify_risk_state_change("risk_off_activated")
        
    def _get_active_defensive_actions(self) -> List[str]:
        """Get a list of currently active defensive actions for alerts/reporting"""
        actions = []
        
        # Add standard defensive actions based on current risk level
        risk_level = self.current_risk_level
        
        if risk_level != RiskLevel.NORMAL:
            # Position sizing changes
            position_scale = self.get_position_size_multiplier()
            actions.append(f"Position sizing reduced to {position_scale*100:.0f}%")
            
            # Stop loss adjustments
            if self.should_modify_stop_losses:
                if risk_level == RiskLevel.ELEVATED:
                    actions.append("Stop losses tightened by 20%")
                elif risk_level == RiskLevel.HIGH:
                    actions.append("Stop losses tightened by 40%")
                elif risk_level == RiskLevel.SEVERE:
                    actions.append("Stop losses tightened by 60%")
                elif risk_level == RiskLevel.EXTREME:
                    actions.append("Stop losses tightened by 70%")
            
            # Strategy adjustments
            if self.should_switch_strategies and risk_level.value >= RiskLevel.HIGH.value:
                actions.append("Defensive strategy weights increased")
            
            # Capital scaling pause
            if self.should_pause_capital_scaling:
                actions.append("Capital scaling paused")
            
            # Auto rotation pause (extreme risk only)
            if risk_level == RiskLevel.EXTREME and self.current_actions.get('auto_rotation_paused', False):
                actions.append("Auto rotation paused")
        
        return actions
        
    def reset_to_normal(self):
        """Reset to normal operations from risk-off mode"""
        # Record time of normal operations restoration
        self.normal_operations_restored_at = datetime.now()
        
        # Clear emergency flag if set
        self.emergency_recovery_required = False
        
        # Take recovery actions
        self._take_recovery_actions()
        
        # Reset risk level
        old_risk_level = self.current_risk_level
        self.current_risk_level = RiskLevel.NORMAL
        
        logger.info(f"Restored normal operations from {old_risk_level.name} risk level")
        
        # Calculate time in risk-off mode
        time_in_risk_off = (self.normal_operations_restored_at - self.risk_off_activated_at).total_seconds() / 60.0 if self.risk_off_activated_at else 0
        
        # Create action record
        action = {
            'timestamp': datetime.now(),
            'type': 'restore_normal',
            'previous_risk_level': old_risk_level.name,
            'time_in_risk_off': time_in_risk_off
        }
        self.action_history.append(action)
        
        # Send risk-off deactivation alert
        alert_message = f"NORMAL OPERATIONS RESTORED: Risk level returned to NORMAL"
        alert_details = {
            'previous_risk_level': old_risk_level.name,
            'time_in_risk_off_minutes': round(time_in_risk_off, 1),
            'recovery_attempts': self.recovery_attempts,
            'actions_taken': self._get_recovery_actions_list()
        }
        
        # Use medium priority for normal operations restored
        alert_notifier.send_alert(
            AlertType.RISK_OFF_DEACTIVATED,
            alert_message,
            details=alert_details,
            priority=AlertPriority.MEDIUM,
            channels=[AlertChannel.EMAIL, AlertChannel.WEB]
        )
        
        # Notify any subscribers
        self._notify_risk_state_change("normal_operations_restored")
        
    def _get_recovery_actions_list(self) -> List[str]:
        """Get a list of recovery actions taken for alerts/reporting"""
        return [
            "Restored normal position size",
            "Restored normal stop loss distances",
            "Re-enabled automatic strategy selection",
            "Re-enabled capital scaling" if self.should_pause_capital_scaling else "Capital scaling unchanged",
            "Re-enabled auto rotation" if self.current_actions.get('auto_rotation_paused', False) else "Auto rotation unchanged"
        ]
        
    def _adjust_defensive_posture(self, risk_level: RiskLevel):
        """
        Adjust the defensive posture based on the current risk level.
        This is called when moving between different non-normal risk levels.
        
        Args:
            risk_level (RiskLevel): The new risk level
        """
        logger.info(f"Adjusting defensive posture to {risk_level.name}")
        
        # Scale defenses based on risk level
        self._take_defensive_actions()
        
        # Create action record
        action = {
            'timestamp': datetime.now(),
            'type': 'adjust_posture',
            'risk_level': risk_level.name
        }
        self.action_history.append(action)
        
        # Notify any subscribers
        self._notify_risk_state_change("defensive_posture_adjusted")
        
    def _take_defensive_actions(self):
        """
        Take appropriate defensive actions based on the current risk level.
        """
        # Import here to avoid circular imports
        from trading_bot import adjust_position_size_multiplier
        
        # For safety module, we'll need to get it from main.py
        try:
            from main import bot  # Import bot instance from main
            safety = bot.safety if hasattr(bot, 'safety') else None
        except (ImportError, AttributeError):
            logger.error("Unable to access safety module from main.bot")
            safety = None
            
        # Other integrations
        try:
            from ensemble_engine import ensemble_manager
        except ImportError:
            logger.error("Unable to import ensemble_manager")
            ensemble_manager = None
            
        try:
            from capital_scaler import capital_scaler
        except ImportError:
            logger.error("Unable to import capital_scaler")
            capital_scaler = None
            
        try:
            from auto_rotation import auto_rotation
        except ImportError:
            logger.error("Unable to import auto_rotation")
            auto_rotation = None
        
        risk_level = self.current_risk_level
        
        # Track actions taken
        actions_taken = []
        
        # 1. Adjust position sizes based on risk level
        if self.should_scale_positions:
            # Scale down position size based on risk level
            position_scale = 1.0
            
            if risk_level == RiskLevel.ELEVATED:
                position_scale = 0.75
            elif risk_level == RiskLevel.HIGH:
                position_scale = 0.5
            elif risk_level == RiskLevel.SEVERE:
                position_scale = 0.25
            elif risk_level == RiskLevel.EXTREME:
                position_scale = 0.0  # No new positions
                
            try:
                adjust_position_size_multiplier(position_scale)
                actions_taken.append(f"Scaled position size to {position_scale*100:.0f}%")
            except Exception as e:
                logger.error(f"Failed to adjust position size: {e}")
        
        # 2. Modify stop losses to be tighter
        if self.should_modify_stop_losses:
            try:
                # Tighten stop losses based on risk level
                tightening_factor = 1.0
                
                if risk_level == RiskLevel.ELEVATED:
                    tightening_factor = 0.8
                elif risk_level == RiskLevel.HIGH:
                    tightening_factor = 0.6
                elif risk_level == RiskLevel.SEVERE:
                    tightening_factor = 0.4
                elif risk_level == RiskLevel.EXTREME:
                    tightening_factor = 0.3
                    
                safety.modify_stop_loss_distance(tightening_factor)
                actions_taken.append(f"Tightened stop losses by factor {tightening_factor:.1f}")
            except Exception as e:
                logger.error(f"Failed to modify stop losses: {e}")
        
        # 3. Switch to more defensive strategies
        if self.should_switch_strategies and risk_level.value >= RiskLevel.HIGH.value:
            try:
                # Try to identify the most defensive strategy in the ensemble
                active_ensemble = ensemble_manager.get_active_ensemble()
                
                if active_ensemble:
                    strategy_weights = active_ensemble.get_strategy_weights()
                    
                    # Find the strategy with the lowest risk score
                    lowest_risk_strategy = None
                    lowest_risk_score = float('inf')
                    
                    for strategy_name in strategy_weights:
                        risk_score = self.strategy_risk_mapping.get(strategy_name, 2)  # Default to medium risk
                        
                        if risk_score < lowest_risk_score:
                            lowest_risk_score = risk_score
                            lowest_risk_strategy = strategy_name
                    
                    if lowest_risk_strategy:
                        # Boost the weight of the most defensive strategy
                        # The extreme the risk, the more weight we give to the defensive strategy
                        boost_amount = 0.6  # Base boost
                        if risk_level == RiskLevel.SEVERE:
                            boost_amount = 0.8
                        elif risk_level == RiskLevel.EXTREME:
                            boost_amount = 0.9
                            
                        new_weights = {strategy: 0.1 for strategy in strategy_weights}
                        new_weights[lowest_risk_strategy] = boost_amount
                        
                        # Normalize weights
                        total_weight = sum(new_weights.values())
                        normalized_weights = {s: w/total_weight for s, w in new_weights.items()}
                        
                        ensemble_manager.update_ensemble_weights(normalized_weights)
                        actions_taken.append(f"Boosted defensive strategy '{lowest_risk_strategy}' to {boost_amount*100:.0f}%")
            
            except Exception as e:
                logger.error(f"Failed to switch to defensive strategies: {e}")
        
        # 4. Pause capital scaling engine
        if self.should_pause_capital_scaling:
            try:
                if capital_scaler.enabled:
                    capital_scaler.enabled = False
                    actions_taken.append("Paused capital scaling engine")
            except Exception as e:
                logger.error(f"Failed to pause capital scaling: {e}")
                
        # 5. For extreme risk, consider pausing auto rotation
        if risk_level == RiskLevel.EXTREME:
            try:
                # Save the previous state so we can restore it
                was_auto_rotation_enabled = auto_rotation.enabled
                
                if was_auto_rotation_enabled:
                    auto_rotation.enabled = False
                    self.current_actions['auto_rotation_paused'] = True
                    actions_taken.append("Paused auto rotation engine")
            except Exception as e:
                logger.error(f"Failed to pause auto rotation: {e}")
                
        # Track actions taken
        self.current_actions = {
            'risk_level': risk_level.name,
            'timestamp': datetime.now(),
            'actions': actions_taken
        }
        
        logger.info(f"Defensive actions taken: {', '.join(actions_taken)}")
        
    def _take_recovery_actions(self):
        """
        Take actions to recover from risk-off mode and restore normal operations.
        """
        # Import here to avoid circular imports
        from trading_bot import adjust_position_size_multiplier
        
        # For safety module, we'll need to get it from main.py
        try:
            from main import bot  # Import bot instance from main
            safety = bot.safety if hasattr(bot, 'safety') else None
        except (ImportError, AttributeError):
            logger.error("Unable to access safety module from main.bot")
            safety = None
            
        # Other integrations
        try:
            from ensemble_engine import ensemble_manager
        except ImportError:
            logger.error("Unable to import ensemble_manager")
            ensemble_manager = None
            
        try:
            from capital_scaler import capital_scaler
        except ImportError:
            logger.error("Unable to import capital_scaler")
            capital_scaler = None
            
        try:
            from auto_rotation import auto_rotation
        except ImportError:
            logger.error("Unable to import auto_rotation")
            auto_rotation = None
        
        actions_taken = []
        
        # 1. Restore normal position sizes
        try:
            adjust_position_size_multiplier(1.0)
            actions_taken.append("Restored normal position size")
        except Exception as e:
            logger.error(f"Failed to restore position size: {e}")
            
        # 2. Restore normal stop losses
        try:
            safety.modify_stop_loss_distance(1.0)
            actions_taken.append("Restored normal stop loss distances")
        except Exception as e:
            logger.error(f"Failed to restore stop losses: {e}")
            
        # 3. If capital scaling was paused, re-enable it
        try:
            if hasattr(capital_scaler, 'enabled') and not capital_scaler.enabled:
                capital_scaler.enabled = True
                actions_taken.append("Re-enabled capital scaling engine")
        except Exception as e:
            logger.error(f"Failed to re-enable capital scaling: {e}")
            
        # 4. If auto rotation was paused, re-enable it
        if self.current_actions.get('auto_rotation_paused', False):
            try:
                auto_rotation.enabled = True
                actions_taken.append("Re-enabled auto rotation engine")
            except Exception as e:
                logger.error(f"Failed to re-enable auto rotation: {e}")
                
        # 5. Restore normal strategy weights if we modified them
        try:
            # Queue a standard weight update based on performance
            auto_rotation_policy = auto_rotation.get_active_policy()
            if auto_rotation_policy:
                auto_rotation_policy.force_update_weights()
                actions_taken.append("Restored normal strategy weights based on performance")
        except Exception as e:
            logger.error(f"Failed to restore strategy weights: {e}")
        
        # Reset current actions
        self.current_actions = {}
        
        # Record recovery in action history
        recovery_action = {
            'timestamp': datetime.now(),
            'type': 'recovery',
            'actions': actions_taken
        }
        self.action_history.append(recovery_action)
        
        logger.info(f"Recovery actions taken: {', '.join(actions_taken)}")
        
    def _attempt_recovery(self):
        """
        Attempt to recover from risk-off mode if conditions permit.
        This is called periodically while in risk-off mode.
        """
        if (self.current_risk_level == RiskLevel.NORMAL or
            self.recovery_attempts >= self.max_recovery_attempts or
            self.emergency_recovery_required):
            return
            
        # Update metrics to see if conditions have improved
        self._update_risk_metrics()
        
        # Check if volatility and drawdown have returned to acceptable levels
        volatility_acceptable = True
        for pair, timeframes in self.volatility_metrics.items():
            for timeframe, metrics in timeframes.items():
                # Use a slightly lower threshold for recovery to avoid rapid switching
                recovery_threshold = self.volatility_threshold_elevated * 0.9
                if metrics.get('ratio', 1.0) > recovery_threshold:
                    volatility_acceptable = False
                    break
                    
        drawdown_acceptable = self.drawdown_metrics.get('current', 0) < self.drawdown_threshold_elevated * 0.9
        
        # If conditions look good, attempt recovery
        if volatility_acceptable and drawdown_acceptable:
            logger.info(f"Market conditions have normalized, attempting recovery #{self.recovery_attempts+1}")
            
            # We could implement a gradual recovery process here
            self.recovery_attempts += 1
            
            # If we're at elevated risk, we can fully recover
            # For higher risk levels, we might implement a staged recovery
            if self.current_risk_level == RiskLevel.ELEVATED:
                self.reset_to_normal()
                self.performance_impact['successful_interventions'] += 1
            else:
                # For higher risk levels, step down one level for now
                new_level = RiskLevel(self.current_risk_level.value - 1)
                self._update_risk_level(new_level, {"primary_trigger": "Staged recovery"})
        else:
            logger.info("Market conditions not yet suitable for recovery")
            
    def _notify_risk_state_change(self, event_type: str):
        """
        Notify any subscribers about a risk state change.
        This is a hook for future extensions.
        
        Args:
            event_type (str): Type of event that occurred
        """
        # This is where we would trigger notifications or callbacks
        pass
        
    def get_current_risk_status(self) -> Dict[str, Any]:
        """
        Get the current risk status as a dictionary.
        
        Returns:
            dict: Current risk status
        """
        return {
            'risk_level': self.current_risk_level.name,
            'risk_off_active': self.current_risk_level != RiskLevel.NORMAL,
            'risk_off_activated_at': self.risk_off_activated_at,
            'risk_off_reason': self.risk_off_reason,
            'recovery_attempts': self.recovery_attempts,
            'emergency_recovery_required': self.emergency_recovery_required,
            'defensive_actions': self.current_actions.get('actions', []),
            'volatility_metrics': {
                pair: {
                    tf: {
                        'ratio': m.get('ratio', 1.0),
                        'updated_at': m.get('updated_at')
                    } for tf, m in timeframes.items()
                } for pair, timeframes in self.volatility_metrics.items()
            },
            'drawdown_metrics': {
                'current': self.drawdown_metrics.get('current', 0),
                'max': self.drawdown_metrics.get('max', 0),
                'updated_at': self.drawdown_metrics.get('updated_at')
            },
            'performance_impact': self.performance_impact
        }
        
    def get_risk_level_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get the history of risk level changes.
        
        Args:
            limit (int, optional): Maximum number of history items to return
            
        Returns:
            list: History of risk level changes
        """
        return self.risk_level_history[-limit:]
        
    def get_action_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get the history of actions taken by the risk manager.
        
        Args:
            limit (int, optional): Maximum number of history items to return
            
        Returns:
            list: History of actions taken
        """
        return self.action_history[-limit:]
        
    def manually_trigger_risk_off(self, reason: str, level: str = "HIGH") -> bool:
        """
        Manually trigger risk-off mode.
        
        Args:
            reason (str): Reason for triggering risk-off mode
            level (str, optional): Risk level to set (ELEVATED, HIGH, SEVERE, EXTREME)
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Convert string level to enum
            risk_level = RiskLevel[level.upper()]
            
            # Update risk level and activate risk-off mode
            self.current_risk_level = risk_level
            self.activate_risk_off_mode(f"Manual trigger: {reason}")
            
            return True
            
        except (KeyError, ValueError) as e:
            logger.error(f"Invalid risk level '{level}': {e}")
            return False
        except Exception as e:
            logger.error(f"Error manually triggering risk-off: {e}")
            return False
            
    def manually_reset_to_normal(self) -> bool:
        """
        Manually reset to normal operations.
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Record the manual intervention
            action = {
                'timestamp': datetime.now(),
                'type': 'manual_reset',
                'previous_risk_level': self.current_risk_level.name
            }
            self.action_history.append(action)
            
            # Reset emergency flag if set
            self.emergency_recovery_required = False
            
            # Reset to normal
            self.reset_to_normal()
            
            return True
            
        except Exception as e:
            logger.error(f"Error manually resetting to normal: {e}")
            return False
            
    def update_config(self, config: Dict[str, Any]) -> bool:
        """
        Update the risk manager configuration.
        
        Args:
            config (dict): New configuration values
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Update check intervals
            if 'check_interval_minutes' in config:
                self.check_interval_minutes = max(1, int(config['check_interval_minutes']))
                
            if 'recovery_check_interval_minutes' in config:
                self.recovery_check_interval_minutes = max(5, int(config['recovery_check_interval_minutes']))
                
            # Update volatility thresholds
            if 'volatility_threshold_elevated' in config:
                self.volatility_threshold_elevated = float(config['volatility_threshold_elevated'])
                
            if 'volatility_threshold_high' in config:
                self.volatility_threshold_high = float(config['volatility_threshold_high'])
                
            if 'volatility_threshold_severe' in config:
                self.volatility_threshold_severe = float(config['volatility_threshold_severe'])
                
            if 'volatility_threshold_extreme' in config:
                self.volatility_threshold_extreme = float(config['volatility_threshold_extreme'])
                
            # Update drawdown thresholds
            if 'drawdown_threshold_elevated' in config:
                self.drawdown_threshold_elevated = float(config['drawdown_threshold_elevated'])
                
            if 'drawdown_threshold_high' in config:
                self.drawdown_threshold_high = float(config['drawdown_threshold_high'])
                
            if 'drawdown_threshold_severe' in config:
                self.drawdown_threshold_severe = float(config['drawdown_threshold_severe'])
                
            if 'drawdown_threshold_extreme' in config:
                self.drawdown_threshold_extreme = float(config['drawdown_threshold_extreme'])
                
            # Update volume thresholds
            if 'volume_threshold_elevated' in config:
                self.volume_threshold_elevated = float(config['volume_threshold_elevated'])
                
            if 'volume_threshold_high' in config:
                self.volume_threshold_high = float(config['volume_threshold_high'])
                
            if 'volume_threshold_severe' in config:
                self.volume_threshold_severe = float(config['volume_threshold_severe'])
                
            # Update recovery settings
            if 'auto_recovery_enabled' in config:
                self.auto_recovery_enabled = bool(config['auto_recovery_enabled'])
                
            if 'max_recovery_attempts' in config:
                self.max_recovery_attempts = max(1, int(config['max_recovery_attempts']))
                
            if 'recovery_cooldown_minutes' in config:
                self.recovery_cooldown_minutes = max(15, int(config['recovery_cooldown_minutes']))
                
            # Update emergency settings
            if 'emergency_stop_threshold' in config:
                self.emergency_stop_threshold = float(config['emergency_stop_threshold'])
                
            if 'emergency_recovery_required' in config:
                self.emergency_recovery_required = bool(config['emergency_recovery_required'])
                
            # Update integration settings
            if 'should_scale_positions' in config:
                self.should_scale_positions = bool(config['should_scale_positions'])
                
            if 'should_modify_stop_losses' in config:
                self.should_modify_stop_losses = bool(config['should_modify_stop_losses'])
                
            if 'should_switch_strategies' in config:
                self.should_switch_strategies = bool(config['should_switch_strategies'])
                
            if 'should_pause_capital_scaling' in config:
                self.should_pause_capital_scaling = bool(config['should_pause_capital_scaling'])
                
            # If strategy risk mapping is provided, update it
            if 'strategy_risk_mapping' in config:
                strategy_mapping = config['strategy_risk_mapping']
                if isinstance(strategy_mapping, dict):
                    for strategy, risk_level in strategy_mapping.items():
                        self.strategy_risk_mapping[strategy] = int(risk_level)
            
            logger.info(f"Updated Risk-Off Trigger System configuration")
            return True
            
        except Exception as e:
            logger.error(f"Error updating configuration: {e}")
            return False
            
    def get_config(self) -> Dict[str, Any]:
        """
        Get the current configuration as a dictionary.
        
        Returns:
            dict: Current configuration
        """
        return {
            # Check intervals
            'check_interval_minutes': self.check_interval_minutes,
            'recovery_check_interval_minutes': self.recovery_check_interval_minutes,
            
            # Volatility thresholds
            'volatility_threshold_elevated': self.volatility_threshold_elevated,
            'volatility_threshold_high': self.volatility_threshold_high,
            'volatility_threshold_severe': self.volatility_threshold_severe,
            'volatility_threshold_extreme': self.volatility_threshold_extreme,
            
            # Drawdown thresholds
            'drawdown_threshold_elevated': self.drawdown_threshold_elevated,
            'drawdown_threshold_high': self.drawdown_threshold_high,
            'drawdown_threshold_severe': self.drawdown_threshold_severe,
            'drawdown_threshold_extreme': self.drawdown_threshold_extreme,
            
            # Volume thresholds
            'volume_threshold_elevated': self.volume_threshold_elevated,
            'volume_threshold_high': self.volume_threshold_high,
            'volume_threshold_severe': self.volume_threshold_severe,
            
            # Recovery settings
            'auto_recovery_enabled': self.auto_recovery_enabled,
            'max_recovery_attempts': self.max_recovery_attempts,
            'recovery_cooldown_minutes': self.recovery_cooldown_minutes,
            
            # Emergency settings
            'emergency_stop_threshold': self.emergency_stop_threshold,
            'emergency_recovery_required': self.emergency_recovery_required,
            
            # Integration settings
            'should_scale_positions': self.should_scale_positions,
            'should_modify_stop_losses': self.should_modify_stop_losses,
            'should_switch_strategies': self.should_switch_strategies,
            'should_pause_capital_scaling': self.should_pause_capital_scaling,
            
            # Strategy risk mapping
            'strategy_risk_mapping': self.strategy_risk_mapping
        }
        
    def reset_performance_metrics(self):
        """Reset the performance impact metrics."""
        self.performance_impact = {
            'capital_preserved': 0.0,
            'opportunity_cost': 0.0,
            'false_alarms': 0,
            'successful_interventions': 0,
        }
        logger.info("Reset performance impact metrics")
        
    def estimate_capital_preserved(self) -> float:
        """
        Estimate the amount of capital preserved by risk-off actions.
        This is a rough estimate based on historical interventions.
        
        Returns:
            float: Estimated capital preserved
        """
        # This is a placeholder for a more sophisticated estimation method
        # A real implementation would look at market movements during risk-off periods
        # and compare with hypothetical losses if no action was taken
        return self.performance_impact['capital_preserved']


# Initialize the global risk manager instance
risk_manager = RiskManager()