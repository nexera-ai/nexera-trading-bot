# neXera Trading Platform - Backup Guide

This guide explains how to back up your neXera Trading Platform data to protect your trading strategies, allocations, and performance history.

## Automated Backup

The neXera Trading Platform includes an automated backup system (`backup_project.py`) that creates timestamped ZIP files containing all essential data.

### Using the Automated Backup Tool

1. **Running a Manual Backup**
   ```
   python backup_project.py
   ```
   This will create a backup file named `crypto_system_backup_YYYYMMDD_HHMMSS.zip` in the root directory.

2. **Scheduling Regular Backups**
   
   The system includes a preconfigured daily backup schedule that runs at 2:00 AM local time.
   
   You can modify the schedule in `main.py` by changing the scheduling code:
   ```python
   # Schedule daily backup at 2:00 AM
   schedule.every().day.at("02:00").do(backup_project)
   ```

### What Gets Backed Up

The automated backup includes:
- Strategy configuration files
- Auto-rotation settings and policies
- Allocation presets
- Performance history data
- Trading logs
- User preferences
- Database files (if using SQLite)

## Manual Backup

You can also perform manual backups of key components:

### 1. Database Backup

If using PostgreSQL:
```
pg_dump -U your_username -d nexera_db > nexera_db_backup.sql
```

If using SQLite:
```
# Simply copy the .db file
cp nexera.db nexera_backup.db
```

### 2. Configuration Files

Key files to back up manually:
- `data/auto_rotation_config.json`
- `data/allocation_presets.json`
- `data/allocation_schedules.json`
- `data/strategy_attributions.json`

### 3. Complete System Backup

To back up everything manually:
1. Stop the neXera Trading Platform
2. Copy the entire application directory to a safe location
3. Restart the platform

## Restoring from Backup

### Automated Backup Restoration

1. Stop the neXera Trading Platform
2. Extract the backup ZIP file to a temporary location
3. Copy the extracted files to your neXera installation directory
4. Restart the platform

### Database Restoration

If using PostgreSQL:
```
psql -U your_username -d nexera_db < nexera_db_backup.sql
```

If using SQLite:
```
# Replace the database file
mv nexera_backup.db nexera.db
```

## Best Practices

1. **Regular Backups**:
   - Keep at least 7 days of daily backups
   - Perform a manual backup before major changes

2. **Off-site Storage**:
   - Store copies of backups in cloud storage (Google Drive, Dropbox, etc.)
   - Consider using encrypted storage for sensitive data

3. **Verification**:
   - Periodically verify that backups can be successfully restored
   - Test restoration in a separate environment when possible

4. **Documentation**:
   - Keep notes of any custom configurations
   - Document any changes to the backup schedule

## Backup Verification Procedure

To verify your backups are valid:

1. Create a new directory for testing
2. Extract a backup file into this directory
3. Try starting the platform in this location
4. Verify that your data, settings, and history are intact