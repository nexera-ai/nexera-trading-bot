import os
import time
import logging
import threading
from datetime import datetime, timedelta

import schedule

from models import db, AllocationSchedule, AllocationPreset, PresetTriggerEvent
from auto_rotation import AutoRotationEngine

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

class AllocationScheduler:
    """
    Service for scheduling and executing allocation preset activations.
    
    This service runs in the background and checks for scheduled allocations
    that are due to be executed. It handles:
    - Applying scheduled allocation presets at the specified time
    - Sending notifications before scheduled activations
    - Creating trigger events and logs for allocation transitions
    - Running in preview mode for testing/audit purposes
    """
    
    def __init__(self, 
                 check_interval_seconds: int = 60,
                 notification_service=None,
                 app=None):
        """
        Initialize the allocation scheduler.
        
        Args:
            check_interval_seconds: How often to check for due schedules (in seconds)
            notification_service: Optional notification service for sending alerts
            app: Flask app context for database operations
        """
        self.check_interval_seconds = check_interval_seconds
        self.notification_service = notification_service
        self.app = app
        self.is_running = False
        self.scheduler_thread = None
        self.auto_rotation_engine = AutoRotationEngine()
        
    def start(self):
        """Start the background scheduler thread."""
        if self.is_running:
            logger.warning("Allocation scheduler is already running")
            return
            
        logger.info("Starting allocation scheduler service")
        self.is_running = True
        self.scheduler_thread = threading.Thread(target=self._scheduler_loop, daemon=True)
        self.scheduler_thread.start()
        
    def stop(self):
        """Stop the background scheduler thread."""
        if not self.is_running:
            logger.warning("Allocation scheduler is not running")
            return
            
        logger.info("Stopping allocation scheduler service")
        self.is_running = False
        if self.scheduler_thread:
            self.scheduler_thread.join(timeout=5)
            self.scheduler_thread = None
    
    def _scheduler_loop(self):
        """Background thread for running the scheduler checks."""
        logger.info("Allocation scheduler thread started")
        
        # Schedule the job to run at the specified interval
        schedule.every(self.check_interval_seconds).seconds.do(self._check_schedules)
        
        # Run the loop as long as the service is running
        while self.is_running:
            schedule.run_pending()
            time.sleep(1)
            
        logger.info("Allocation scheduler thread stopped")
    
    def _check_schedules(self):
        """Check for schedules that are due to be executed or notified."""
        try:
            # Use app context if provided, otherwise use a direct database session
            if self.app:
                with self.app.app_context():
                    self._process_due_schedules()
                    self._process_notification_schedules()
            else:
                self._process_due_schedules()
                self._process_notification_schedules()
        except Exception as e:
            logger.error(f"Error checking allocation schedules: {e}")
    
    def _process_due_schedules(self):
        """Process schedules that are due to be executed."""
        now = datetime.utcnow()
        
        # Query for active, non-executed schedules where the scheduled time is in the past
        due_schedules = AllocationSchedule.query.filter(
            AllocationSchedule.is_active == True,
            AllocationSchedule.is_executed == False,
            AllocationSchedule.scheduled_time <= now
        ).all()
        
        if due_schedules:
            logger.info(f"Found {len(due_schedules)} allocation schedules due for execution")
            
        for schedule_item in due_schedules:
            try:
                self._execute_schedule(schedule_item)
            except Exception as e:
                logger.error(f"Error executing allocation schedule {schedule_item.id}: {e}")
                
                # Mark as executed but failed
                schedule_item.is_executed = True
                schedule_item.execution_time = datetime.utcnow()
                schedule_item.execution_status = 'failed'
                schedule_item.execution_note = f"Error: {str(e)}"
                db.session.commit()
    
    def _process_notification_schedules(self):
        """Process schedules that need notifications sent."""
        now = datetime.utcnow()
        
        # Query for active, non-executed schedules with notification settings
        # where notifications haven't been sent yet
        notification_schedules = AllocationSchedule.query.filter(
            AllocationSchedule.is_active == True,
            AllocationSchedule.is_executed == False,
            AllocationSchedule.notification_sent == False,
            AllocationSchedule.notify_before_minutes != None
        ).all()
        
        for schedule_item in notification_schedules:
            # Calculate when notification should be sent
            notification_time = schedule_item.scheduled_time - timedelta(minutes=schedule_item.notify_before_minutes)
            
            # Check if it's time to send notification
            if now >= notification_time:
                try:
                    self._send_notification(schedule_item)
                    
                    # Mark notification as sent
                    schedule_item.notification_sent = True
                    db.session.commit()
                except Exception as e:
                    logger.error(f"Error sending notification for schedule {schedule_item.id}: {e}")
    
    def _execute_schedule(self, schedule_item: AllocationSchedule):
        """
        Execute a scheduled allocation.
        
        Args:
            schedule_item: The allocation schedule to execute
        """
        logger.info(f"Executing allocation schedule {schedule_item.id} for preset '{schedule_item.preset.name}'")
        
        preset = schedule_item.preset
        
        if schedule_item.preview_mode:
            # In preview mode, don't actually apply the weights
            logger.info(f"PREVIEW MODE: Would apply preset '{preset.name}' with weights {preset.weights}")
            
            # Update execution status
            schedule_item.is_executed = True
            schedule_item.execution_time = datetime.utcnow()
            schedule_item.execution_status = 'preview'
            schedule_item.execution_note = f"Preview mode: Would apply preset '{preset.name}' with weights {preset.weights}"
            db.session.commit()
            
            # Create trigger event for the preview
            self._create_trigger_event(
                preset_id=preset.id, 
                title=f"PREVIEW: Scheduled Allocation '{preset.name}'",
                description=f"Preview of scheduled allocation '{preset.name}' with weights {preset.weights}",
                event_type='allocation_preview',
                importance=3,
                color='#FFA000'  # Amber color for preview events
            )
            
            return
            
        # Apply the weights from the preset
        success = self.auto_rotation_engine.apply_manual_weights(
            weights=preset.weights, 
            preset_name=preset.name,
            description=f"Applied via scheduled allocation (ID: {schedule_item.id})"
        )
        
        if success:
            # Update execution status
            schedule_item.is_executed = True
            schedule_item.execution_time = datetime.utcnow()
            schedule_item.execution_status = 'success'
            schedule_item.execution_note = f"Successfully applied preset '{preset.name}' with weights {preset.weights}"
            
            # Update preset's last applied timestamp
            preset.last_applied_at = datetime.utcnow()
            
            db.session.commit()
            
            # Create trigger event for the successful execution
            self._create_trigger_event(
                preset_id=preset.id, 
                title=f"Scheduled Allocation Applied: {preset.name}",
                description=f"Scheduled allocation '{preset.name}' applied with weights {preset.weights}",
                event_type='allocation_applied',
                importance=4,
                color='#43A047'  # Green color for success
            )
            
            logger.info(f"Successfully executed allocation schedule {schedule_item.id}")
        else:
            # Mark as executed but failed
            schedule_item.is_executed = True
            schedule_item.execution_time = datetime.utcnow()
            schedule_item.execution_status = 'failed'
            schedule_item.execution_note = "Failed to apply preset weights through auto-rotation engine"
            db.session.commit()
            
            # Create trigger event for the failed execution
            self._create_trigger_event(
                preset_id=preset.id,
                title=f"Scheduled Allocation Failed: {preset.name}",
                description=f"Failed to apply scheduled allocation '{preset.name}'",
                event_type='allocation_failed',
                importance=4,
                color='#F44336'  # Red color for failure
            )
            
            logger.error(f"Failed to execute allocation schedule {schedule_item.id}")
    
    def _send_notification(self, schedule_item: AllocationSchedule):
        """
        Send a notification for an upcoming scheduled allocation.
        
        Args:
            schedule_item: The allocation schedule to notify about
        """
        logger.info(f"Sending notification for upcoming allocation schedule {schedule_item.id}")
        
        # If no notification service is available, just log it
        if not self.notification_service:
            logger.info(f"No notification service available. Would notify about upcoming allocation: '{schedule_item.preset.name}'")
            return
            
        # Calculate time remaining
        time_remaining = schedule_item._get_time_remaining()
        
        # Prepare the notification message
        message = f"Upcoming scheduled allocation: '{schedule_item.preset.name}' will be applied in {time_remaining}"
        details = {
            'schedule_id': schedule_item.id,
            'preset_id': schedule_item.preset_id,
            'preset_name': schedule_item.preset.name,
            'scheduled_time': schedule_item.scheduled_time.isoformat(),
            'weights': schedule_item.preset.weights,
            'preview_mode': schedule_item.preview_mode
        }
        
        # Send the notification through the notification service
        try:
            from alert_notifier import AlertType, AlertPriority, AlertChannel
            
            self.notification_service.send_alert(
                alert_type=AlertType.SCHEDULED_ALLOCATION,
                message=message,
                details=details,
                priority=AlertPriority.MEDIUM,
                channels=[AlertChannel.EMAIL, AlertChannel.WEB]
            )
            logger.info(f"Notification sent for allocation schedule {schedule_item.id}")
        except ImportError:
            # If alert_notifier module is not available or doesn't have these types
            logger.warning("Could not import alert types from alert_notifier, using string values")
            
            # Fallback to using strings
            self.notification_service.send_alert(
                alert_type="scheduled_allocation",
                message=message,
                details=details,
                priority="medium",
                channels=["email", "web"]
            )
            logger.info(f"Notification sent (fallback method) for allocation schedule {schedule_item.id}")
        except Exception as e:
            logger.error(f"Failed to send notification for schedule {schedule_item.id}: {e}")
    
    def _create_trigger_event(self, preset_id, title, description, event_type, importance=3, color=None):
        """
        Create a trigger event for allocation activities.
        
        Args:
            preset_id: ID of the strategy preset
            title: Short event title
            description: Detailed description
            event_type: Type of event
            importance: Importance level (1-5)
            color: Optional CSS color for the event
        
        Returns:
            The created trigger event
        """
        try:
            # Create the trigger event
            trigger_event = PresetTriggerEvent(
                preset_id=preset_id,
                timestamp=datetime.utcnow(),
                event_type=event_type,
                event_subtype='allocation_scheduling',
                title=title,
                description=description,
                importance=importance,
                color=color,
                is_auto_generated=True,
                created_by='allocation_scheduler'
            )
            
            db.session.add(trigger_event)
            db.session.commit()
            
            logger.info(f"Created trigger event for preset {preset_id}: {title}")
            return trigger_event
        except Exception as e:
            logger.error(f"Failed to create trigger event: {e}")
            return None
            
    def get_schedules(self, include_executed=False, include_inactive=False, limit=100):
        """
        Get a list of allocation schedules.
        
        Args:
            include_executed: Whether to include already executed schedules
            include_inactive: Whether to include inactive schedules
            limit: Maximum number of schedules to return
            
        Returns:
            List of allocation schedules
        """
        query = AllocationSchedule.query
        
        if not include_executed:
            query = query.filter(AllocationSchedule.is_executed == False)
            
        if not include_inactive:
            query = query.filter(AllocationSchedule.is_active == True)
            
        # Order by scheduled time (earliest first)
        query = query.order_by(AllocationSchedule.scheduled_time)
        
        # Apply limit
        query = query.limit(limit)
        
        return query.all()
    
    def get_schedule(self, schedule_id):
        """
        Get a specific allocation schedule by ID.
        
        Args:
            schedule_id: ID of the schedule to retrieve
            
        Returns:
            The allocation schedule or None if not found
        """
        return AllocationSchedule.query.get(schedule_id)
    
    def create_schedule(self, preset_id, scheduled_time, notify_before_minutes=None, preview_mode=False, created_by=None):
        """
        Create a new allocation schedule.
        
        Args:
            preset_id: ID of the allocation preset to apply
            scheduled_time: When to apply the preset (datetime or ISO string)
            notify_before_minutes: Optional minutes before to send notification
            preview_mode: Whether to run in preview mode
            created_by: Optional user or system component that created the schedule
            
        Returns:
            The created allocation schedule
        """
        # Convert string time to datetime if needed
        if isinstance(scheduled_time, str):
            scheduled_time = datetime.fromisoformat(scheduled_time)
            
        # Create the schedule
        schedule_item = AllocationSchedule(
            preset_id=preset_id,
            scheduled_time=scheduled_time,
            notify_before_minutes=notify_before_minutes,
            preview_mode=preview_mode,
            created_by=created_by
        )
        
        db.session.add(schedule_item)
        db.session.commit()
        
        logger.info(f"Created allocation schedule {schedule_item.id} for preset {preset_id} at {scheduled_time}")
        return schedule_item
    
    def update_schedule(self, schedule_id, scheduled_time=None, notify_before_minutes=None, 
                       is_active=None, preview_mode=None):
        """
        Update an existing allocation schedule.
        
        Args:
            schedule_id: ID of the schedule to update
            scheduled_time: New scheduled time (optional)
            notify_before_minutes: New notification time (optional)
            is_active: New active status (optional)
            preview_mode: New preview mode setting (optional)
            
        Returns:
            The updated schedule or None if not found
        """
        schedule_item = AllocationSchedule.query.get(schedule_id)
        if not schedule_item:
            logger.warning(f"Allocation schedule {schedule_id} not found")
            return None
            
        # Update fields if provided
        if scheduled_time is not None:
            if isinstance(scheduled_time, str):
                scheduled_time = datetime.fromisoformat(scheduled_time)
            schedule_item.scheduled_time = scheduled_time
            
        if notify_before_minutes is not None:
            schedule_item.notify_before_minutes = notify_before_minutes
            # Reset notification sent status if changing notification time
            schedule_item.notification_sent = False
            
        if is_active is not None:
            schedule_item.is_active = is_active
            
        if preview_mode is not None:
            schedule_item.preview_mode = preview_mode
            
        # Update the timestamp
        schedule_item.updated_at = datetime.utcnow()
        
        db.session.commit()
        logger.info(f"Updated allocation schedule {schedule_id}")
        
        return schedule_item
    
    def cancel_schedule(self, schedule_id, note=None):
        """
        Cancel an allocation schedule.
        
        Args:
            schedule_id: ID of the schedule to cancel
            note: Optional note about why it was cancelled
            
        Returns:
            The cancelled schedule or None if not found
        """
        schedule_item = AllocationSchedule.query.get(schedule_id)
        if not schedule_item:
            logger.warning(f"Allocation schedule {schedule_id} not found")
            return None
            
        # Set as inactive but keep the record
        schedule_item.is_active = False
        schedule_item.execution_status = 'cancelled'
        schedule_item.execution_note = note or "Cancelled manually"
        schedule_item.updated_at = datetime.utcnow()
        
        db.session.commit()
        logger.info(f"Cancelled allocation schedule {schedule_id}")
        
        # Create trigger event for the cancellation
        self._create_trigger_event(
            preset_id=schedule_item.preset_id,
            title=f"Allocation Schedule Cancelled: {schedule_item.preset.name}",
            description=f"Cancelled scheduled allocation for preset '{schedule_item.preset.name}' that was planned for {schedule_item.scheduled_time.isoformat()}",
            event_type='allocation_cancelled',
            importance=3,
            color='#FFC107'  # Amber/yellow for cancellation
        )
        
        return schedule_item
    
    def delete_schedule(self, schedule_id):
        """
        Delete an allocation schedule.
        
        Args:
            schedule_id: ID of the schedule to delete
            
        Returns:
            Success status
        """
        schedule_item = AllocationSchedule.query.get(schedule_id)
        if not schedule_item:
            logger.warning(f"Allocation schedule {schedule_id} not found")
            return False
            
        # Record details for logging
        preset_name = schedule_item.preset.name if schedule_item.preset else "Unknown"
        scheduled_time = schedule_item.scheduled_time
        
        # Delete the schedule
        db.session.delete(schedule_item)
        db.session.commit()
        
        logger.info(f"Deleted allocation schedule {schedule_id} for preset '{preset_name}' at {scheduled_time}")
        return True
        
    def execute_now(self, schedule_id):
        """
        Execute a scheduled allocation immediately.
        
        Args:
            schedule_id: ID of the schedule to execute
            
        Returns:
            Success status
        """
        schedule_item = AllocationSchedule.query.get(schedule_id)
        if not schedule_item:
            logger.warning(f"Allocation schedule {schedule_id} not found")
            return False
            
        if schedule_item.is_executed:
            logger.warning(f"Allocation schedule {schedule_id} has already been executed")
            return False
            
        if not schedule_item.is_active:
            logger.warning(f"Allocation schedule {schedule_id} is not active")
            return False
            
        try:
            # Execute the schedule
            self._execute_schedule(schedule_item)
            return True
        except Exception as e:
            logger.error(f"Error executing allocation schedule {schedule_id}: {e}")
            return False
    
    # Static method for initializing with a Flask app
    @classmethod
    def init_app(cls, app, start=True):
        """
        Initialize the allocation scheduler with a Flask app.
        
        Args:
            app: Flask application
            start: Whether to start the scheduler immediately
            
        Returns:
            An initialized AllocationScheduler instance
        """
        # Try to get notification service if available
        notification_service = None
        try:
            from alert_notifier import AlertNotifier
            notification_service = AlertNotifier()
        except ImportError:
            app.logger.warning("AlertNotifier not available, notifications will be logged only")
        
        # Create scheduler
        scheduler = cls(
            app=app,
            notification_service=notification_service
        )
        
        # Start scheduler if requested
        if start:
            scheduler.start()
            
        # Store in app context for access in routes
        app.allocation_scheduler = scheduler
        
        return scheduler