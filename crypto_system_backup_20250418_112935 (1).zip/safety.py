"""
Safety Module for Trading Bot

This module provides risk management and safety features for live trading.
It implements various safety checks and limits to protect the user's funds.
"""

import logging
import time
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Union

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@dataclass
class SafetyConfig:
    """Configuration settings for trading safety limits."""
    # Trade size limits
    max_trade_size_usd: float = 100.0  # Maximum trade size in USD
    max_trade_size_pct: float = 2.0    # Maximum trade size as percentage of total balance
    
    # Loss limits
    max_daily_loss_usd: float = 50.0   # Maximum daily loss in USD
    max_daily_loss_pct: float = 5.0    # Maximum daily loss as percentage of balance
    
    # Trade frequency limits
    min_trade_interval_seconds: int = 60  # Minimum time between trades (cooldown)
    max_trades_per_hour: int = 5          # Maximum number of trades per hour
    max_trades_per_day: int = 20          # Maximum number of trades per day
    
    # Asset exposure limits
    max_single_asset_exposure_pct: float = 15.0  # Maximum exposure to a single asset
    max_total_exposure_pct: float = 50.0         # Maximum total exposure across all assets
    
    # Emergency stop
    emergency_stop_active: bool = False          # Emergency stop switch
    
    # API safety
    require_trade_only_api_permissions: bool = True  # Require API keys with only trade permissions
    
    # Mode
    live_trading_enabled: bool = False            # Whether live trading is enabled
    safety_mode_level: str = "strict"             # Safety mode: strict, moderate, minimal

    def __str__(self) -> str:
        """String representation of the safety configuration."""
        return (
            f"Safety Config (Mode: {self.safety_mode_level}, Live Trading: {'Enabled' if self.live_trading_enabled else 'Disabled'})\n"
            f"- Max Trade Size: ${self.max_trade_size_usd} USD ({self.max_trade_size_pct}% of balance)\n"
            f"- Max Daily Loss: ${self.max_daily_loss_usd} USD ({self.max_daily_loss_pct}% of balance)\n"
            f"- Trade Frequency: {self.max_trades_per_hour}/hour, {self.max_trades_per_day}/day, {self.min_trade_interval_seconds}s cooldown\n"
            f"- Exposure Limits: {self.max_single_asset_exposure_pct}% per asset, {self.max_total_exposure_pct}% total\n"
            f"- Emergency Stop: {'ACTIVE' if self.emergency_stop_active else 'Inactive'}"
        )


class TradeSafety:
    """
    Manages trading safety limits and risk controls.
    """
    
    def __init__(self, config: Optional[SafetyConfig] = None):
        """
        Initialize the safety module with configuration.
        
        Args:
            config (SafetyConfig, optional): Safety configuration. If None, default config is used.
        """
        self.config = config or SafetyConfig()
        self.trade_history: List[Dict] = []
        self.trade_timestamps: List[datetime] = []
        self.daily_loss = 0.0
        self.initial_balance = 0.0
        self.last_check_time = datetime.now()
        self.check_count = 0
        
        logger.info(f"Safety module initialized with settings:\n{self.config}")
    
    def set_initial_balance(self, balance: float) -> None:
        """
        Set the initial balance for percentage-based calculations.
        
        Args:
            balance (float): Initial balance in USD
        """
        self.initial_balance = balance
        logger.info(f"Safety module: Initial balance set to ${balance:.2f}")
    
    def update_config(self, new_config: Dict) -> None:
        """
        Update the safety configuration with new settings.
        
        Args:
            new_config (Dict): Dictionary with configuration values to update
        """
        for key, value in new_config.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)
                logger.info(f"Safety config updated: {key} = {value}")
        
        logger.info(f"Updated safety configuration:\n{self.config}")
    
    def record_trade(self, trade_data: Dict) -> None:
        """
        Record a trade for safety checks and analysis.
        
        Args:
            trade_data (Dict): Trade data including amount, price, profit/loss
        """
        self.trade_history.append(trade_data)
        self.trade_timestamps.append(datetime.now())
        
        # Update daily loss if the trade resulted in a loss
        pnl = trade_data.get('pnl', 0)
        if pnl < 0:
            self.daily_loss += abs(pnl)
            logger.info(f"Daily loss updated: ${self.daily_loss:.2f}")
    
    def reset_daily_stats(self) -> None:
        """Reset daily statistics (should be called at the start of each day)."""
        previous_loss = self.daily_loss
        self.daily_loss = 0.0
        
        # Filter timestamps to keep only trades from the last 24 hours
        now = datetime.now()
        cutoff = now - timedelta(days=1)
        self.trade_timestamps = [ts for ts in self.trade_timestamps if ts > cutoff]
        
        logger.info(f"Daily stats reset. Previous day loss: ${previous_loss:.2f}")
    
    def check_api_permissions(self, permissions: List[str]) -> Tuple[bool, str]:
        """
        Check if the API permissions are safe for trading.
        
        Args:
            permissions (List[str]): List of API permissions
        
        Returns:
            Tuple[bool, str]: (is_safe, message)
        """
        if not self.config.require_trade_only_api_permissions:
            return True, "API permission check disabled"
        
        # Check for dangerous permissions that could compromise funds
        dangerous_permissions = ['withdraw', 'transfer']
        has_dangerous = any(perm in permissions for perm in dangerous_permissions)
        
        if has_dangerous:
            warning = "⚠️ DANGEROUS API PERMISSIONS DETECTED: Your API key has withdrawal or transfer permissions, which poses a security risk."
            logger.warning(warning)
            return False, warning
        
        return True, "API permissions are safe (trade-only)"
    
    def can_execute_trade(self, symbol: str, amount_usd: float, current_balance: float,
                          asset_exposure: Dict[str, float]) -> Tuple[bool, str]:
        """
        Check if a trade can be executed based on safety limits.
        
        Args:
            symbol (str): Trading pair symbol
            amount_usd (float): Trade amount in USD
            current_balance (float): Current account balance in USD
            asset_exposure (Dict[str, float]): Current exposure to different assets in USD
        
        Returns:
            Tuple[bool, str]: (can_execute, reason)
        """
        # Emergency stop check
        if self.config.emergency_stop_active:
            return False, "Emergency stop is active. All trading is halted."
        
        # Live trading check
        if not self.config.live_trading_enabled and not symbol.endswith('_paper'):
            return False, "Live trading is disabled. Only paper trading is allowed."
        
        # Cooldown check
        if self.trade_timestamps:
            seconds_since_last_trade = (datetime.now() - self.trade_timestamps[-1]).total_seconds()
            if seconds_since_last_trade < self.config.min_trade_interval_seconds:
                return False, f"Trade cooldown in effect. Please wait {self.config.min_trade_interval_seconds - seconds_since_last_trade:.0f} more seconds."
        
        # Trade frequency check
        trades_last_hour = sum(1 for ts in self.trade_timestamps 
                              if ts > datetime.now() - timedelta(hours=1))
        if trades_last_hour >= self.config.max_trades_per_hour:
            return False, f"Hourly trade limit reached ({self.config.max_trades_per_hour} trades/hour)."
        
        trades_last_day = len(self.trade_timestamps)  # We already filtered for last 24h
        if trades_last_day >= self.config.max_trades_per_day:
            return False, f"Daily trade limit reached ({self.config.max_trades_per_day} trades/day)."
        
        # Trade size checks
        max_trade_size_from_pct = current_balance * (self.config.max_trade_size_pct / 100.0)
        max_trade_size = min(self.config.max_trade_size_usd, max_trade_size_from_pct)
        
        if amount_usd > max_trade_size:
            return False, f"Trade size (${amount_usd:.2f}) exceeds limit (${max_trade_size:.2f})."
        
        # Daily loss check
        max_daily_loss_from_pct = self.initial_balance * (self.config.max_daily_loss_pct / 100.0)
        max_daily_loss = min(self.config.max_daily_loss_usd, max_daily_loss_from_pct)
        
        if self.daily_loss >= max_daily_loss:
            return False, f"Daily loss limit reached (${self.daily_loss:.2f} of ${max_daily_loss:.2f} max)."
        
        # Asset exposure checks
        base_currency = symbol.split('/')[0]
        
        # Calculate new exposure after the trade
        new_exposure = asset_exposure.copy()
        if base_currency in new_exposure:
            new_exposure[base_currency] += amount_usd
        else:
            new_exposure[base_currency] = amount_usd
        
        # Check single asset exposure
        max_single_exposure = current_balance * (self.config.max_single_asset_exposure_pct / 100.0)
        if new_exposure[base_currency] > max_single_exposure:
            return False, f"Exposure to {base_currency} (${new_exposure[base_currency]:.2f}) would exceed limit (${max_single_exposure:.2f})."
        
        # Check total exposure
        new_total_exposure = sum(new_exposure.values())
        max_total_exposure = current_balance * (self.config.max_total_exposure_pct / 100.0)
        if new_total_exposure > max_total_exposure:
            return False, f"Total exposure (${new_total_exposure:.2f}) would exceed limit (${max_total_exposure:.2f})."
        
        # All checks passed
        return True, "Trade passes all safety checks"
    
    def modify_stop_loss_distance(self, adjustment_factor: float) -> bool:
        """
        Modify the stop loss distance by a given factor.
        This is used by the Risk-Off Trigger System to tighten stop losses during high-risk periods.
        
        Args:
            adjustment_factor (float): Factor to adjust stop loss distance.
                                      Values < 1.0 tighten stops (e.g., 0.5 reduces distance by half)
                                      Values > 1.0 widen stops (e.g., 1.5 increases distance by 50%)
                                      Value of 1.0 restores default settings
        
        Returns:
            bool: Success or failure
        """
        try:
            # Store the adjustment factor for future reference
            self.stop_loss_adjustment_factor = adjustment_factor
            
            # Apply the adjustment to any active positions
            # This would typically involve iterating through open positions
            # and adjusting their stop loss values
            
            # In practice, we might want to access the trading_bot module 
            # to modify stop losses for all active positions
            
            # For demo purposes, we'll just log the change here
            if adjustment_factor < 1.0:
                logger.info(f"Stop losses tightened by factor {adjustment_factor:.2f}")
            elif adjustment_factor > 1.0:
                logger.info(f"Stop losses widened by factor {adjustment_factor:.2f}")
            else:
                logger.info("Stop losses restored to default settings")
                
            return True
            
        except Exception as e:
            logger.error(f"Error modifying stop loss distances: {e}")
            return False
            
    def get_stop_loss_adjustment_factor(self) -> float:
        """
        Get the current stop loss adjustment factor.
        
        Returns:
            float: The current adjustment factor (default 1.0 if not set)
        """
        return getattr(self, 'stop_loss_adjustment_factor', 1.0)
    
    def get_safety_status(self, current_balance: float, 
                          asset_exposure: Dict[str, float]) -> Dict:
        """
        Get the current safety status and limits.
        
        Args:
            current_balance (float): Current account balance in USD
            asset_exposure (Dict[str, float]): Current exposure to different assets in USD
        
        Returns:
            Dict: Safety status information
        """
        total_exposure = sum(asset_exposure.values())
        max_exposure = current_balance * (self.config.max_total_exposure_pct / 100.0)
        exposure_pct = (total_exposure / current_balance * 100) if current_balance > 0 else 0
        
        max_trade_size_from_pct = current_balance * (self.config.max_trade_size_pct / 100.0)
        max_trade_size = min(self.config.max_trade_size_usd, max_trade_size_from_pct)
        
        max_daily_loss_from_pct = self.initial_balance * (self.config.max_daily_loss_pct / 100.0)
        max_daily_loss = min(self.config.max_daily_loss_usd, max_daily_loss_from_pct)
        
        trades_last_hour = sum(1 for ts in self.trade_timestamps 
                              if ts > datetime.now() - timedelta(hours=1))
        
        safety_status = {
            "live_trading_enabled": self.config.live_trading_enabled,
            "safety_mode": self.config.safety_mode_level,
            "emergency_stop_active": self.config.emergency_stop_active,
            "stop_loss_adjustment": self.get_stop_loss_adjustment_factor(),
            "exposure": {
                "current": total_exposure,
                "max": max_exposure,
                "percentage": exposure_pct,
                "by_asset": asset_exposure
            },
            "trade_limits": {
                "max_size_usd": max_trade_size,
                "hourly_count": {
                    "current": trades_last_hour,
                    "max": self.config.max_trades_per_hour
                },
                "daily_count": {
                    "current": len(self.trade_timestamps),
                    "max": self.config.max_trades_per_day
                }
            },
            "loss_limits": {
                "daily_loss": {
                    "current": self.daily_loss,
                    "max": max_daily_loss
                }
            }
        }
        
        return safety_status