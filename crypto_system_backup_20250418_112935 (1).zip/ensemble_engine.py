"""
Ensemble Strategy Engine

This module provides functionality for combining multiple trading strategies
into ensemble models that can make more robust trading decisions.

Key features:
- Run multiple strategies in parallel
- Combine signals using weighted voting or portfolio allocation
- Dynamically adjust strategy weights based on performance metrics
- Provide unified entry/exit decisions based on ensemble consensus

Usage:
    ensemble = EnsembleStrategy(strategies=['dip_buyer', 'mean_reversion'], 
                               weights=[0.6, 0.4])
    signal = ensemble.check_for_signal(ohlcv_data)
"""
import logging
from typing import List, Dict, Tuple, Optional, Union, Any, cast
from enum import Enum

from config import Config
from strategies import get_strategy, get_available_strategies
from strategies.base_strategy import BaseStrategy
from batch_comparison import BatchComparison
from backtest import Backtester

# Configure logging
logger = logging.getLogger(__name__)

class SignalType(Enum):
    """Types of trading signals."""
    BUY = 1
    SELL = 2
    HOLD = 0
    UNKNOWN = -1

class VotingMethod(Enum):
    """Methods for combining strategy signals."""
    MAJORITY_VOTE = 'majority_vote'  # Simple majority wins
    WEIGHTED_VOTE = 'weighted_vote'  # Votes weighted by strategy confidence/performance
    UNANIMOUS = 'unanimous'          # All strategies must agree
    VETO = 'veto'                    # Any SELL signal vetoes a BUY
    PERFORMANCE_WEIGHTED = 'performance_weighted'  # Weights based on recent performance

class EnsembleStrategy(BaseStrategy):
    """
    Ensemble Strategy that combines signals from multiple strategies.
    
    Attributes:
        strategy_names (list): List of strategy names to include in the ensemble
        strategies (dict): Dictionary of strategy instances
        weights (dict): Dictionary of strategy weights
        voting_method (VotingMethod): Method for combining strategy signals
        min_agreement_pct (float): Minimum percentage of strategies that must agree for a signal
        performance_lookback (int): Number of days to use for performance-based weighting
    """
    
    def __init__(self, 
                 strategy_names: Optional[List[str]] = None, 
                 weights: Optional[Dict[str, float]] = None,
                 voting_method: Union[str, VotingMethod] = VotingMethod.WEIGHTED_VOTE,
                 min_agreement_pct: float = 0.5,
                 performance_lookback: int = 30,
                 name: str = "ensemble",
                 take_profit: float = 3.0,
                 stop_loss: float = 1.5,
                 **kwargs):
        """
        Initialize the ensemble strategy.
        
        Args:
            strategy_names (list, optional): List of strategy names to include.
                If None, all available strategies will be used.
            weights (dict, optional): Dictionary of strategy weights.
                If None, equal weights will be assigned.
            voting_method (VotingMethod, optional): Method for combining strategy signals.
            min_agreement_pct (float, optional): Minimum percentage of strategies that must agree.
            performance_lookback (int, optional): Days to look back for performance-based weighting.
            name (str, optional): Name of the ensemble strategy.
            take_profit (float, optional): Take profit percentage
            stop_loss (float, optional): Stop loss percentage
            **kwargs: Additional parameters for the base strategy
        """
        # Initialize the base strategy
        super().__init__(take_profit=take_profit, stop_loss=stop_loss, **kwargs)
        if isinstance(voting_method, str):
            try:
                voting_method = VotingMethod(voting_method)
            except ValueError:
                logger.warning(f"Invalid voting method '{voting_method}'. Using WEIGHTED_VOTE.")
                voting_method = VotingMethod.WEIGHTED_VOTE
        
        self.voting_method = voting_method
        self.min_agreement_pct = min_agreement_pct
        self.performance_lookback = performance_lookback
        self.name = name
        
        # Initialize strategy components
        if strategy_names is None:
            strategy_names = [s['id'] for s in get_available_strategies()]
        self.strategy_names = strategy_names
        
        # Initialize strategies with default parameters
        self.strategies = {}
        for strategy_name in self.strategy_names:
            try:
                self.strategies[strategy_name] = get_strategy(strategy_name)
            except Exception as e:
                logger.error(f"Error initializing strategy {strategy_name}: {e}")
        
        # Initialize weights
        if weights is None:
            # Equal weighting by default
            weights = {strategy_name: 1.0 / len(self.strategy_names) for strategy_name in self.strategy_names}
        self.weights = weights
        
        # Normalize weights to sum to 1.0
        weight_sum = sum(self.weights.values())
        if weight_sum > 0:
            for strategy_name in self.weights:
                self.weights[strategy_name] /= weight_sum
        
        # Initialize tracking attributes
        self.decision_history = []  # List of recent decisions with metadata
        self.decision_counts = {strategy_name: 0 for strategy_name in self.strategy_names}  # Count of how often each strategy influenced decisions
        self.trade_history = []  # List of trades executed based on this ensemble's decisions
        
        logger.info(f"Initialized ensemble strategy with {len(self.strategies)} sub-strategies")
        logger.info(f"Voting method: {self.voting_method.name}")
        logger.info(f"Strategy weights: {self.weights}")
    
    def update_weights_from_performance(self, symbol: Optional[str] = "BTC/USDT", timeframe: str = "1h", 
                                       lookback_days: Optional[int] = None) -> Dict[str, float]:
        """
        Update strategy weights based on recent performance.
        
        Args:
            symbol (str, optional): Trading pair to evaluate
            timeframe (str, optional): Timeframe to evaluate
            lookback_days (int, optional): Days to look back
                
        Returns:
            dict: Updated strategy weights
        """
        if lookback_days is None:
            lookback_days = self.performance_lookback
        
        # Run batch comparison for performance analysis
        # Handle None value for symbol
        actual_symbol = symbol if symbol is not None else "BTC/USDT"
        batch = BatchComparison(
            strategies=self.strategy_names,
            symbol=actual_symbol,
            timeframe=timeframe
        )
        
        try:
            # Load data and run comparison
            batch.load_data()
            batch.run_comparison(use_optimal_params=True)
            
            # Get metrics for each strategy
            new_weights = {}
            metrics_by_strategy = {}
            
            for strategy_name, result in batch.results.items():
                metrics = result.get('metrics', {})
                metrics_by_strategy[strategy_name] = metrics
            
            # Calculate performance scores based on balanced metrics
            # We'll use a simplified version of the balanced scoring from optimize.py
            scores = {}
            for strategy_name, metrics in metrics_by_strategy.items():
                # Skip strategies with invalid metrics
                if not metrics or 'total_return_pct' not in metrics:
                    scores[strategy_name] = 0
                    continue
                
                # Balanced score components with weights
                win_rate = metrics.get('win_rate', 0)
                total_return = metrics.get('total_return_pct', 0)
                sharpe = metrics.get('sharpe_ratio', 0)
                max_dd = metrics.get('max_drawdown', 100)  # Higher is worse
                profit_factor = metrics.get('profit_factor', 1)
                
                # Calculate balanced score - using the same weights as in optimize.py
                score = (
                    (0.25 * total_return) +  # 25% weight to total return
                    (0.25 * win_rate) +      # 25% weight to win rate
                    (0.20 * sharpe) +        # 20% weight to Sharpe ratio
                    (0.20 * (100 - max_dd) / 100) +  # 20% weight to drawdown protection (inverted)
                    (0.10 * profit_factor)   # 10% weight to profit factor
                )
                
                # Store score
                scores[strategy_name] = max(0, score)  # Ensure non-negative scores
            
            # Normalize scores to get weights summing to 1.0
            total_score = sum(scores.values())
            if total_score > 0:
                for strategy_name in scores:
                    new_weights[strategy_name] = scores[strategy_name] / total_score
            else:
                # If all scores are 0, use equal weights
                for strategy_name in scores:
                    new_weights[strategy_name] = 1.0 / len(scores)
            
            # Update weights
            self.weights = new_weights
            logger.info(f"Updated weights based on performance: {self.weights}")
            
            return self.weights
            
        except Exception as e:
            logger.error(f"Error updating weights from performance: {e}")
            return self.weights
    
    def should_enter(self, historical_data):
        """
        Check if the ensemble strategy suggests entering a position.
        This method overrides the BaseStrategy method and maintains interface compatibility.
        
        Args:
            historical_data: Historical market data in the format expected by strategies
            
        Returns:
            bool: True if a buy signal is generated, False otherwise
        """
        signal_result = self.check_for_signal(historical_data)
        return signal_result['signal'] == SignalType.BUY if isinstance(signal_result, dict) and 'signal' in signal_result else False
    
    def should_exit(self, position, current_price):
        """
        Check if the ensemble strategy suggests exiting a position.
        This method maintains compatibility with the BaseStrategy interface.
        
        Args:
            position (dict): Position information
            current_price (float): Current market price
            
        Returns:
            tuple: (should_exit, exit_reason) where exit_reason is 'take_profit', 'stop_loss', or None
        """
        # First check standard take profit / stop loss (from BaseStrategy)
        should_exit, reason = super().should_exit(position, current_price)
        if should_exit:
            # Make sure reason is either 'take_profit' or 'stop_loss'
            if reason == "take_profit" or reason == "stop_loss":
                return True, reason
            
        # For ensemble strategies, we treat a SELL signal as a stop_loss condition
        # to maintain return type compatibility with the base class
        if 'historical_data' in position:
            signal_result = self.check_for_signal(position['historical_data'])
            if isinstance(signal_result, dict) and 'signal' in signal_result and signal_result['signal'] == SignalType.SELL:
                # Use the standard exit reason 'stop_loss' for compatibility
                return True, "stop_loss"
                
        return False, None
    
    def check_for_signal(self, historical_data, symbol=None):
        """
        Check for trading signals from all strategies and combine them.
        
        Args:
            historical_data: Market data in the format expected by strategies
            symbol (str, optional): Trading pair symbol
            
        Returns:
            dict: Signal information including:
                - signal_type: SignalType
                - confidence: Float between 0 and 1
                - strategy_signals: Dict of individual strategy signals
                - reasoning: Explanation of the decision
        """
        strategy_signals = {}
        signal_counts = {
            SignalType.BUY: 0,
            SignalType.SELL: 0,
            SignalType.HOLD: 0,
            SignalType.UNKNOWN: 0
        }
        
        # Get signals from each strategy
        for strategy_name, strategy in self.strategies.items():
            try:
                # Get strategy signal
                signal = strategy.check_for_signal(historical_data, symbol)
                
                # Standardize signal format
                if isinstance(signal, bool):
                    # Simple boolean signal (True = BUY, False = HOLD)
                    signal = {
                        'signal': SignalType.BUY if signal else SignalType.HOLD,
                        'confidence': 1.0 if signal else 0.0
                    }
                elif isinstance(signal, dict):
                    # Convert string signal to enum
                    if 'signal' in signal and isinstance(signal['signal'], str):
                        signal_str = signal['signal'].upper()
                        if signal_str == 'BUY':
                            signal['signal'] = SignalType.BUY
                        elif signal_str == 'SELL':
                            signal['signal'] = SignalType.SELL
                        elif signal_str == 'HOLD':
                            signal['signal'] = SignalType.HOLD
                        else:
                            signal['signal'] = SignalType.UNKNOWN
                    
                    # Ensure confidence is present
                    if 'confidence' not in signal:
                        signal['confidence'] = 1.0
                else:
                    # Unknown signal format
                    signal = {
                        'signal': SignalType.UNKNOWN,
                        'confidence': 0.0
                    }
                
                # Store signal
                strategy_signals[strategy_name] = signal
                signal_counts[signal['signal']] += 1
                
            except Exception as e:
                logger.error(f"Error getting signal from strategy {strategy_name}: {e}")
                strategy_signals[strategy_name] = {
                    'signal': SignalType.UNKNOWN,
                    'confidence': 0.0,
                    'error': str(e)
                }
                signal_counts[SignalType.UNKNOWN] += 1
        
        # Combine signals using the specified method
        if self.voting_method == VotingMethod.MAJORITY_VOTE:
            return self._majority_vote(strategy_signals, signal_counts)
        elif self.voting_method == VotingMethod.WEIGHTED_VOTE:
            return self._weighted_vote(strategy_signals)
        elif self.voting_method == VotingMethod.UNANIMOUS:
            return self._unanimous_vote(strategy_signals, signal_counts)
        elif self.voting_method == VotingMethod.VETO:
            return self._veto_vote(strategy_signals, signal_counts)
        elif self.voting_method == VotingMethod.PERFORMANCE_WEIGHTED:
            return self._performance_weighted_vote(strategy_signals, symbol)
        else:
            # Default to weighted vote
            return self._weighted_vote(strategy_signals)
    
    def _majority_vote(self, strategy_signals, signal_counts):
        """Simple majority voting method."""
        total_strategies = len(strategy_signals)
        if total_strategies == 0:
            return {
                'signal': SignalType.HOLD,
                'confidence': 0.0,
                'strategy_signals': strategy_signals,
                'reasoning': 'No strategies available'
            }
        
        # Find the signal type with the most votes
        max_count = 0
        final_signal = SignalType.HOLD
        for signal_type, count in signal_counts.items():
            if signal_type != SignalType.UNKNOWN and count > max_count:
                max_count = count
                final_signal = signal_type
        
        # Check if we meet the minimum agreement threshold
        agreement_pct = max_count / total_strategies
        if agreement_pct < self.min_agreement_pct:
            final_signal = SignalType.HOLD
            reasoning = f"Insufficient agreement ({agreement_pct:.1%} < {self.min_agreement_pct:.1%})"
        else:
            reasoning = f"Majority vote: {max_count}/{total_strategies} strategies agree on {final_signal.name}"
        
        return {
            'signal': final_signal,
            'confidence': agreement_pct,
            'strategy_signals': strategy_signals,
            'reasoning': reasoning
        }
    
    def _weighted_vote(self, strategy_signals):
        """Weighted voting method based on predefined weights."""
        if not strategy_signals:
            return {
                'signal': SignalType.HOLD,
                'confidence': 0.0,
                'strategy_signals': strategy_signals,
                'reasoning': 'No strategies available'
            }
        
        # Calculate weighted votes for each signal type
        weighted_votes = {
            SignalType.BUY: 0.0,
            SignalType.SELL: 0.0,
            SignalType.HOLD: 0.0
        }
        
        for strategy_name, signal_info in strategy_signals.items():
            if strategy_name in self.weights and signal_info['signal'] != SignalType.UNKNOWN:
                weight = self.weights[strategy_name]
                confidence = signal_info.get('confidence', 1.0)
                signal_type = signal_info['signal']
                weighted_votes[signal_type] += weight * confidence
        
        # Determine the final signal
        max_vote = 0.0
        final_signal = SignalType.HOLD
        for signal_type, vote in weighted_votes.items():
            if vote > max_vote:
                max_vote = vote
                final_signal = signal_type
        
        # Check if the winning vote meets our threshold
        total_weight = sum(self.weights.values())
        if total_weight > 0:
            confidence = max_vote / total_weight
            if confidence < self.min_agreement_pct and final_signal != SignalType.HOLD:
                final_signal = SignalType.HOLD
                reasoning = f"Insufficient weighted agreement ({confidence:.1%} < {self.min_agreement_pct:.1%})"
            else:
                reasoning = f"Weighted vote: {final_signal.name} with {confidence:.1%} confidence"
        else:
            confidence = 0.0
            reasoning = "No valid weights available"
        
        return {
            'signal': final_signal,
            'confidence': confidence,
            'strategy_signals': strategy_signals,
            'weighted_votes': weighted_votes,
            'reasoning': reasoning
        }
    
    def _unanimous_vote(self, strategy_signals, signal_counts):
        """Unanimous voting method - all strategies must agree."""
        total_strategies = len(strategy_signals)
        if total_strategies == 0:
            return {
                'signal': SignalType.HOLD,
                'confidence': 0.0,
                'strategy_signals': strategy_signals,
                'reasoning': 'No strategies available'
            }
        
        # Check if all strategies agree on BUY or SELL
        if signal_counts[SignalType.BUY] == total_strategies:
            final_signal = SignalType.BUY
            confidence = 1.0
            reasoning = "Unanimous BUY decision"
        elif signal_counts[SignalType.SELL] == total_strategies:
            final_signal = SignalType.SELL
            confidence = 1.0
            reasoning = "Unanimous SELL decision"
        else:
            final_signal = SignalType.HOLD
            # Calculate the level of agreement on the most common signal
            max_count = max(signal_counts[SignalType.BUY], signal_counts[SignalType.SELL])
            confidence = max_count / total_strategies
            reasoning = f"No unanimous decision ({confidence:.1%} agreement on most common signal)"
        
        return {
            'signal': final_signal,
            'confidence': confidence,
            'strategy_signals': strategy_signals,
            'reasoning': reasoning
        }
    
    def _veto_vote(self, strategy_signals, signal_counts):
        """Veto voting method - any SELL signal vetoes a BUY."""
        total_strategies = len(strategy_signals)
        if total_strategies == 0:
            return {
                'signal': SignalType.HOLD,
                'confidence': 0.0,
                'strategy_signals': strategy_signals,
                'reasoning': 'No strategies available'
            }
        
        # If any strategy says SELL, the ensemble says HOLD
        if signal_counts[SignalType.SELL] > 0:
            final_signal = SignalType.HOLD
            confidence = signal_counts[SignalType.SELL] / total_strategies
            reasoning = f"SELL veto activated ({signal_counts[SignalType.SELL]} strategies suggest selling)"
        # Otherwise, if enough strategies say BUY, the ensemble says BUY
        elif signal_counts[SignalType.BUY] / total_strategies >= self.min_agreement_pct:
            final_signal = SignalType.BUY
            confidence = signal_counts[SignalType.BUY] / total_strategies
            reasoning = f"BUY signal with {confidence:.1%} agreement"
        # Otherwise, HOLD
        else:
            final_signal = SignalType.HOLD
            confidence = signal_counts[SignalType.HOLD] / total_strategies
            reasoning = f"Insufficient BUY agreement ({signal_counts[SignalType.BUY] / total_strategies:.1%} < {self.min_agreement_pct:.1%})"
        
        return {
            'signal': final_signal,
            'confidence': confidence,
            'strategy_signals': strategy_signals,
            'reasoning': reasoning
        }
    
    def _performance_weighted_vote(self, strategy_signals, symbol=None):
        """Performance-weighted voting method based on recent performance."""
        # This is just a wrapper around weighted_vote that updates weights first
        # Handle None value for symbol
        actual_symbol = symbol if symbol is not None else "BTC/USDT"
        self.update_weights_from_performance(symbol=actual_symbol)
        return self._weighted_vote(strategy_signals)
    
    def get_strategy_weights(self):
        """
        Get the current strategy weights.
        
        Returns:
            dict: Dictionary mapping strategy names to weights
        """
        return self.weights.copy()
        
    def get_parameters(self):
        """
        Get the current parameters of the ensemble strategy.
        
        Returns:
            dict: Current parameters
        """
        return {
            'name': self.name,
            'strategy_names': self.strategy_names,
            'weights': self.weights,
            'voting_method': self.voting_method.value,
            'min_agreement_pct': self.min_agreement_pct,
            'performance_lookback': self.performance_lookback
        }
    
    def update_parameters(self, parameters):
        """
        Update the parameters of the ensemble strategy.
        
        Args:
            parameters (dict): New parameters
        """
        if 'strategy_names' in parameters:
            new_strategies = parameters['strategy_names']
            # Only update if the list has changed
            if set(new_strategies) != set(self.strategy_names):
                self.strategy_names = new_strategies
                # Reinitialize strategies
                self.strategies = {}
                for strategy_name in self.strategy_names:
                    try:
                        self.strategies[strategy_name] = get_strategy(strategy_name)
                    except Exception as e:
                        logger.error(f"Error initializing strategy {strategy_name}: {e}")
                
                # Reset weights if they're not provided
                if 'weights' not in parameters:
                    self.weights = {strategy_name: 1.0 / len(self.strategy_names) for strategy_name in self.strategy_names}
        
        if 'weights' in parameters:
            new_weights = parameters['weights']
            # Normalize weights to sum to 1.0
            weight_sum = sum(new_weights.values())
            if weight_sum > 0:
                self.weights = {strategy_name: weight / weight_sum for strategy_name, weight in new_weights.items()}
            else:
                # If all weights are 0, use equal weights
                self.weights = {strategy_name: 1.0 / len(new_weights) for strategy_name in new_weights}
        
        if 'voting_method' in parameters:
            voting_method = parameters['voting_method']
            if isinstance(voting_method, str):
                try:
                    self.voting_method = VotingMethod(voting_method)
                except ValueError:
                    logger.warning(f"Invalid voting method '{voting_method}'. Using {self.voting_method.value}.")
            elif isinstance(voting_method, VotingMethod):
                self.voting_method = voting_method
        
        if 'min_agreement_pct' in parameters:
            self.min_agreement_pct = float(parameters['min_agreement_pct'])
        
        if 'performance_lookback' in parameters:
            self.performance_lookback = int(parameters['performance_lookback'])
        
        if 'name' in parameters:
            self.name = parameters['name']
        
        logger.info(f"Updated ensemble strategy parameters: {self.get_parameters()}")
    
    def get_performance_data(self):
        """
        Get performance metrics for this ensemble strategy.
        
        Returns:
            dict: Performance metrics including:
                - win_rate: Overall win rate of trades
                - profit_factor: Ratio of profits to losses
                - avg_return: Average return per trade
                - strategy_contributions: How much each strategy contributed to decisions
                - recent_performance: Recent performance metrics
        """
        # Start with basic performance data
        performance_data = {
            'win_rate': 0.0,
            'profit_factor': 0.0,
            'avg_return': 0.0,
            'strategy_contributions': {},
            'recent_performance': [],
            'total_trades': 0,
            'profitable_trades': 0,
        }
        
        # Calculate strategy contributions based on how often each was used
        total_decisions = sum(self.decision_counts.values()) if hasattr(self, 'decision_counts') else 0
        if total_decisions > 0:
            for strategy_name in self.strategy_names:
                strategy_count = self.decision_counts.get(strategy_name, 0) if hasattr(self, 'decision_counts') else 0
                performance_data['strategy_contributions'][strategy_name] = strategy_count / total_decisions
        
        # Get performance from recent trades if available
        if hasattr(self, 'trade_history') and self.trade_history:
            trades = self.trade_history
            performance_data['total_trades'] = len(trades)
            profitable_trades = sum(1 for trade in trades if trade.get('profit_pct', 0) > 0)
            performance_data['profitable_trades'] = profitable_trades
            
            if performance_data['total_trades'] > 0:
                performance_data['win_rate'] = profitable_trades / performance_data['total_trades']
                
                # Calculate profit factor and average return
                total_profit = sum(trade.get('profit_pct', 0) for trade in trades if trade.get('profit_pct', 0) > 0)
                total_loss = abs(sum(trade.get('profit_pct', 0) for trade in trades if trade.get('profit_pct', 0) < 0))
                
                if total_loss > 0:
                    performance_data['profit_factor'] = total_profit / total_loss
                else:
                    performance_data['profit_factor'] = total_profit if total_profit > 0 else 0
                    
                performance_data['avg_return'] = sum(trade.get('profit_pct', 0) for trade in trades) / len(trades)
                
                # Recent performance (last 10 trades)
                recent_trades = trades[-10:] if len(trades) > 10 else trades
                performance_data['recent_performance'] = [trade.get('profit_pct', 0) for trade in recent_trades]
        
        return performance_data
    
    def get_recent_decisions(self, limit=10):
        """
        Get recent trading decisions made by this ensemble.
        
        Args:
            limit (int): Maximum number of decisions to return
            
        Returns:
            list: Recent decisions with details about each strategy's vote
        """
        if not hasattr(self, 'decision_history'):
            return []
            
        # Return the most recent decisions first
        recent_decisions = self.decision_history[-limit:]
        
        # Format the decisions for display
        formatted_decisions = []
        for decision in recent_decisions:
            formatted_decision = {
                'timestamp': decision.get('timestamp', ''),
                'symbol': decision.get('symbol', ''),
                'signal_type': decision.get('signal_type', 'UNKNOWN'),
                'consensus_pct': decision.get('consensus_pct', 0),
                'strategy_votes': decision.get('strategy_votes', {})
            }
            formatted_decisions.append(formatted_decision)
            
        return formatted_decisions
    
    def get_description(self):
        """
        Get a user-friendly description of this ensemble strategy.
        
        Returns:
            str: Description of the ensemble strategy
        """
        strategy_list = ", ".join(self.strategy_names)
        
        # Map voting method to readable description
        voting_descriptions = {
            VotingMethod.MAJORITY_VOTE: "Simple majority voting",
            VotingMethod.WEIGHTED_VOTE: "Weighted voting based on assigned weights",
            VotingMethod.UNANIMOUS: "Unanimous agreement required",
            VotingMethod.VETO: "Any strategy can veto a trade",
            VotingMethod.PERFORMANCE_WEIGHTED: f"Performance-weighted (lookback: {self.performance_lookback} days)"
        }
        
        voting_desc = voting_descriptions.get(
            self.voting_method, 
            f"Custom voting method: {self.voting_method.value if hasattr(self.voting_method, 'value') else self.voting_method}"
        )
        
        # Build the description
        description = f"""
        <p><strong>Ensemble Strategy: {self.name}</strong></p>
        <p>This ensemble combines {len(self.strategy_names)} different trading strategies:</p>
        <ul>
            <li><strong>Component Strategies:</strong> {strategy_list}</li>
            <li><strong>Decision Method:</strong> {voting_desc}</li>
            <li><strong>Min Agreement:</strong> {self.min_agreement_pct * 100:.0f}% of strategies must agree for a signal</li>
        </ul>
        
        <p>When this ensemble is active, all component strategies will analyze the market conditions,
        and their signals will be combined according to the configured voting method to make the final trading decision.</p>
        """
        
        return description

class EnsembleManager:
    """
    Manager for creating, updating, and tracking ensemble strategies.
    """
    
    def __init__(self):
        """Initialize the ensemble manager."""
        self.ensembles = {}
        self.active_ensemble = None
    
    def create_ensemble_strategy(self, ensemble_name: str, strategies_config: List[Dict], voting_method: str = 'majority') -> EnsembleStrategy:
        """
        Create an ensemble strategy from component strategies configuration.
        This method is used by trading_bot.py to initialize an ensemble strategy.
        
        Args:
            ensemble_name (str): Name of the ensemble
            strategies_config (list): List of strategy configurations
            voting_method (str): Voting method for the ensemble
            
        Returns:
            EnsembleStrategy: The created ensemble strategy
        """
        # Extract strategy names and weights from config
        strategy_names = []
        weights = {}
        
        for strategy_config in strategies_config:
            strategy_name = strategy_config.get('name')
            if strategy_name:
                strategy_names.append(strategy_name)
                weights[strategy_name] = strategy_config.get('weight', 1.0)
        
        # Create the ensemble
        return self.create_ensemble(
            name=ensemble_name,
            strategy_names=strategy_names,
            weights=weights,
            voting_method=voting_method
        )
    
    def create_ensemble(self, name: str, **parameters) -> EnsembleStrategy:
        """
        Create a new ensemble strategy.
        
        Args:
            name (str): Name of the ensemble
            **parameters: Parameters for the ensemble
            
        Returns:
            EnsembleStrategy: The created ensemble
        """
        if name in self.ensembles:
            logger.warning(f"Ensemble '{name}' already exists. Updating parameters.")
            self.ensembles[name].update_parameters(parameters)
            return self.ensembles[name]
        
        parameters['name'] = name
        ensemble = EnsembleStrategy(**parameters)
        self.ensembles[name] = ensemble
        
        # Set as active if it's the first ensemble
        if not self.active_ensemble:
            self.active_ensemble = name
        
        return ensemble
    
    def get_ensemble(self, name: Optional[str] = None) -> Optional[EnsembleStrategy]:
        """
        Get an ensemble strategy by name.
        
        Args:
            name (str, optional): Name of the ensemble.
                If None, the active ensemble is returned.
                
        Returns:
            EnsembleStrategy: The ensemble strategy or None if not found
        """
        if name is None:
            name = self.active_ensemble
        
        return self.ensembles.get(name)
    
    def get_all_ensembles(self) -> Dict[str, EnsembleStrategy]:
        """
        Get all ensemble strategies.
        
        Returns:
            dict: Dictionary of ensemble strategies
        """
        return self.ensembles
        
    def get_active_ensemble(self) -> Optional[EnsembleStrategy]:
        """
        Get the currently active ensemble strategy.
        
        Returns:
            The active EnsembleStrategy object or None if no active ensemble
        """
        if not self.active_ensemble:
            return None
        return self.ensembles.get(self.active_ensemble)
    
    def delete_ensemble(self, name: str) -> bool:
        """
        Delete an ensemble strategy.
        
        Args:
            name (str): Name of the ensemble
            
        Returns:
            bool: True if successful, False otherwise
        """
        if name in self.ensembles:
            del self.ensembles[name]
            
            # Update active ensemble if needed
            if self.active_ensemble == name:
                if self.ensembles:
                    self.active_ensemble = next(iter(self.ensembles))
                else:
                    self.active_ensemble = None
            
            return True
        
        return False
    
    def set_active_ensemble(self, name: str) -> bool:
        """
        Set the active ensemble strategy.
        
        Args:
            name (str): Name of the ensemble
            
        Returns:
            bool: True if successful, False otherwise
        """
        if name in self.ensembles:
            self.active_ensemble = name
            logger.info(f"Set active ensemble to '{name}'")
            return True
        
        logger.warning(f"Ensemble '{name}' not found. Active ensemble unchanged.")
        return False
        
    def update_ensemble_weights(self, weights: Dict[str, float]) -> bool:
        """
        Update weights of strategies in the active ensemble.
        
        Args:
            weights (Dict[str, float]): Dictionary mapping strategy names to new weights
            
        Returns:
            bool: True if successful, False otherwise
        """
        active_ensemble = self.get_active_ensemble()
        if not active_ensemble:
            logger.warning("Cannot update weights: No active ensemble")
            return False
            
        # Get current weights
        current_weights = active_ensemble.weights
        
        # Update weights
        for strategy, weight in weights.items():
            if strategy in current_weights:
                current_weights[strategy] = weight
                logger.info(f"Updated weight for {strategy} to {weight:.2f}")
            else:
                logger.warning(f"Strategy {strategy} not found in active ensemble")
                
        # Normalize weights
        total_weight = sum(current_weights.values())
        if total_weight > 0:
            for strategy in current_weights:
                current_weights[strategy] /= total_weight
                
        active_ensemble.weights = current_weights
        logger.info(f"Updated ensemble weights: {current_weights}")
        return True
    
    def save_ensembles(self, file_path: str = 'data/ensembles.json') -> bool:
        """
        Save all ensembles to a file.
        
        Args:
            file_path (str, optional): Path to save the file
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            import os
            import json
            
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            # Convert ensembles to serializable format
            ensemble_data = {}
            for name, ensemble in self.ensembles.items():
                ensemble_data[name] = ensemble.get_parameters()
            
            # Save to file
            with open(file_path, 'w') as f:
                json.dump({
                    'ensembles': ensemble_data,
                    'active_ensemble': self.active_ensemble
                }, f, indent=2)
            
            logger.info(f"Saved {len(self.ensembles)} ensembles to {file_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error saving ensembles: {e}")
            return False
    
    def load_ensembles(self, file_path: str = 'data/ensembles.json') -> bool:
        """
        Load ensembles from a file.
        
        Args:
            file_path (str, optional): Path to the file
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            import json
            import os
            
            if not os.path.exists(file_path):
                logger.warning(f"Ensemble file {file_path} not found")
                return False
            
            with open(file_path, 'r') as f:
                data = json.load(f)
            
            # Clear existing ensembles
            self.ensembles = {}
            
            # Create ensembles from data
            for name, parameters in data.get('ensembles', {}).items():
                self.create_ensemble(name, **parameters)
            
            # Set active ensemble
            active_ensemble = data.get('active_ensemble')
            if active_ensemble and active_ensemble in self.ensembles:
                self.active_ensemble = active_ensemble
            elif self.ensembles:
                self.active_ensemble = next(iter(self.ensembles))
            
            logger.info(f"Loaded {len(self.ensembles)} ensembles from {file_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error loading ensembles: {e}")
            return False

# Initialize the ensemble manager
ensemble_manager = EnsembleManager()

# Helper function to get the active ensemble
def get_active_ensemble(ensemble_name: Optional[str] = None) -> Optional[EnsembleStrategy]:
    """
    Get the active ensemble strategy or a specific ensemble by name.
    
    Args:
        ensemble_name (str, optional): Name of ensemble to get.
          If None, returns the active ensemble.
          
    Returns:
        EnsembleStrategy: The ensemble strategy or None if not found
    """
    return ensemble_manager.get_ensemble(ensemble_name)

# Create default ensembles
def create_default_ensembles():
    """Create default ensemble strategies if none exist."""
    if not ensemble_manager.ensembles:
        # Balanced ensemble with all strategies
        ensemble_manager.create_ensemble(
            name="balanced_ensemble",
            strategy_names=['dip_buyer', 'mean_reversion', 'breakout'],
            voting_method=VotingMethod.WEIGHTED_VOTE.value,
            min_agreement_pct=0.5
        )
        
        # Conservative ensemble with veto power
        ensemble_manager.create_ensemble(
            name="conservative_ensemble",
            strategy_names=['dip_buyer', 'mean_reversion', 'breakout'],
            voting_method=VotingMethod.VETO.value,
            min_agreement_pct=0.66  # Higher agreement threshold
        )
        
        # Performance-weighted ensemble
        ensemble_manager.create_ensemble(
            name="adaptive_ensemble",
            strategy_names=['dip_buyer', 'mean_reversion', 'breakout'],
            voting_method=VotingMethod.PERFORMANCE_WEIGHTED.value,
            min_agreement_pct=0.5,
            performance_lookback=14  # 2 weeks lookback for weighting
        )
        
        logger.info("Created default ensemble strategies")