"""
Paper Trading Wrapper Module
Simulates trading without real money by wrapping the CCXT exchange.
"""
import os
import json
import logging
import time
import ccxt
import pandas as pd
from datetime import datetime
import random

logger = logging.getLogger(__name__)

class PaperTradingExchange:
    """
    A wrapper around CCXT exchange that simulates trading without real money.
    """
    
    def __init__(self, api_key, api_secret, initial_balance=1000, testnet=False):
        """
        Initialize paper trading exchange with a real exchange for market data.
        
        Args:
            api_key (str): Binance API key (used only for market data)
            api_secret (str): Binance API secret (used only for market data)
            initial_balance (float): Initial balance in USDT
            testnet (bool): Whether to use testnet
        """
        self.api_key = api_key
        self.api_secret = api_secret
        
        # Use real exchange for market data
        options = {}
        if testnet:
            options['test'] = True
        
        self.real_exchange = ccxt.binance({
            'apiKey': api_key,
            'secret': api_secret,
            'enableRateLimit': True,
            'options': options
        })
        
        # Initialize paper trading state
        self.balances = {'USDT': initial_balance}
        self.open_orders = []
        self.order_history = []
        self.trade_history = []
        self.next_order_id = 1
        
        # Load existing paper trading data if available
        self.data_file = 'paper_trading_data.json'
        self.load_data()
        
        # Load markets
        try:
            self.markets = self.real_exchange.load_markets()
            logger.info("Markets loaded successfully for paper trading")
        except Exception as e:
            # In case of API issues, create a minimal market structure
            logger.warning(f"Could not load real markets: {e}. Using simulated markets.")
            self.markets = self._create_simulated_markets()
    
    def _create_simulated_markets(self):
        """Create simulated market data when real API is not available."""
        common_pairs = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "DOGE/USDT"]
        markets = {}
        
        for pair in common_pairs:
            base, quote = pair.split('/')
            markets[pair] = {
                'id': pair.replace('/', ''),
                'symbol': pair,
                'base': base,
                'quote': quote,
                'precision': {
                    'amount': 6,
                    'price': 2
                },
                'limits': {
                    'amount': {
                        'min': 0.000001,
                        'max': 9999999
                    },
                    'price': {
                        'min': 0.01,
                        'max': 1000000
                    }
                }
            }
            
        return markets
    
    def load_data(self):
        """Load paper trading data from file if available."""
        try:
            if os.path.exists(self.data_file):
                with open(self.data_file, 'r') as f:
                    data = json.load(f)
                    self.balances = data.get('balances', {'USDT': 1000})
                    self.open_orders = data.get('open_orders', [])
                    self.order_history = data.get('order_history', [])
                    self.trade_history = data.get('trade_history', [])
                    self.next_order_id = data.get('next_order_id', 1)
                    logger.info(f"Loaded paper trading data: {self.balances}")
            else:
                logger.info("No existing paper trading data found. Starting with fresh balance.")
        except Exception as e:
            logger.error(f"Error loading paper trading data: {e}")
    
    def save_data(self):
        """Save paper trading data to file."""
        try:
            data = {
                'balances': self.balances,
                'open_orders': self.open_orders,
                'order_history': self.order_history,
                'trade_history': self.trade_history,
                'next_order_id': self.next_order_id
            }
            with open(self.data_file, 'w') as f:
                json.dump(data, f, indent=2)
            logger.debug("Saved paper trading data")
        except Exception as e:
            logger.error(f"Error saving paper trading data: {e}")
            
    def generate_ohlcv(self, symbol, timeframe='1h', limit=100):
        """
        Generate simulated OHLCV data for a given symbol and timeframe.
        This is useful for testing and UI display when real market data is not available.
        
        Args:
            symbol (str): Trading pair symbol
            timeframe (str): Timeframe for candles (e.g., '1m', '5m', '1h')
            limit (int): Number of candles to generate
            
        Returns:
            list: List of OHLCV candles in the format [timestamp, open, high, low, close, volume]
        """
        # Get base asset from symbol (e.g., 'BTC' from 'BTC/USDT')
        base_asset = symbol.split('/')[0].upper()
        
        # Define reasonable price ranges for different assets
        price_ranges = {
            'BTC': (40000, 60000),
            'ETH': (2500, 4000),
            'SOL': (120, 200),
            'BNB': (400, 600),
            'DOGE': (0.1, 0.2),
            'ADA': (0.5, 1.5),
            'XRP': (0.5, 1.0)
        }
        
        # Use default range if asset is not in the predefined list
        price_range = price_ranges.get(base_asset, (100, 1000))
        base_price = sum(price_range) / 2
        
        # Determine time step based on timeframe
        timeframe_multipliers = {
            '1m': 60,
            '5m': 300,
            '15m': 900,
            '30m': 1800,
            '1h': 3600,
            '4h': 14400,
            '1d': 86400,
            '1w': 604800
        }
        time_step = timeframe_multipliers.get(timeframe, 3600)  # Default to 1h
        
        now = int(time.time() * 1000)
        
        # Create simulated price data with some volatility
        ohlcv = []
        current_price = base_price
        
        for i in range(limit):
            # Calculate timestamp for the candle (going backward from now)
            timestamp = now - (limit - i) * time_step * 1000
            
            # Add some randomness for price movement (more volatile for shorter timeframes)
            volatility = 0.01  # Default volatility
            if timeframe in ['1m', '5m', '15m']:
                volatility = 0.015
            elif timeframe in ['30m', '1h']:
                volatility = 0.01
            else:
                volatility = 0.005
            
            # Create a realistic candle with random movement
            price_change = current_price * volatility * (random.random() * 2 - 1)
            open_price = current_price
            close_price = current_price + price_change
            
            # Ensure the price stays within a reasonable range
            min_price, max_price = price_range
            close_price = max(min_price, min(max_price, close_price))
            
            # Determine high and low with some randomness
            high_price = max(open_price, close_price) * (1 + random.random() * volatility)
            low_price = min(open_price, close_price) * (1 - random.random() * volatility)
            
            # Ensure high is always highest and low is always lowest
            high_price = max(high_price, open_price, close_price)
            low_price = min(low_price, open_price, close_price)
            
            # Generate realistic volume
            avg_volume = base_price * 10  # Base volume based on price
            volume = avg_volume * (0.5 + random.random())
            
            # Add some trends and patterns for realism
            if i > 0:
                # Add some trend continuation probability
                if ohlcv[i-1][4] > ohlcv[i-1][1]:  # If previous candle was green
                    if random.random() < 0.6:  # 60% chance to continue trend
                        close_price = open_price * (1 + random.random() * volatility)
                else:  # If previous candle was red
                    if random.random() < 0.6:  # 60% chance to continue trend
                        close_price = open_price * (1 - random.random() * volatility)
            
            # Append the candle
            ohlcv.append([
                timestamp,
                float(f"{open_price:.2f}"),
                float(f"{high_price:.2f}"),
                float(f"{low_price:.2f}"),
                float(f"{close_price:.2f}"),
                float(f"{volume:.2f}")
            ])
            
            # Update current price for next candle
            current_price = close_price
        
        return ohlcv
    
    def fetch_ticker(self, symbol):
        """
        Get current ticker data for a symbol.
        Falls back to simulated data if real API fails.
        
        Args:
            symbol (str): Trading pair symbol
            
        Returns:
            dict: Ticker data
        """
        try:
            return self.real_exchange.fetch_ticker(symbol)
        except Exception as e:
            logger.warning(f"Could not fetch real ticker for {symbol}: {e}. Using simulated data.")
            # Generate a reasonable price based on common cryptocurrency values
            base_prices = {
                "BTC/USDT": 60000,
                "ETH/USDT": 3000,
                "SOL/USDT": 150,
                "BNB/USDT": 500,
                "DOGE/USDT": 0.1
            }
            
            base_price = base_prices.get(symbol, 100)
            variation = random.uniform(-0.02, 0.02)  # 2% random variation
            price = base_price * (1 + variation)
            
            return {
                'symbol': symbol,
                'timestamp': int(time.time() * 1000),
                'datetime': datetime.now().isoformat(),
                'high': price * 1.01,
                'low': price * 0.99,
                'bid': price * 0.999,
                'ask': price * 1.001,
                'last': price,
                'close': price,
                'previousClose': price * (1 - variation/2),
                'change': price * variation,
                'percentage': variation * 100,
                'average': price,
                'baseVolume': random.uniform(1000, 10000),
                'quoteVolume': random.uniform(1000, 10000) * price
            }
    
    def fetch_ohlcv(self, symbol, timeframe='1m', limit=100):
        """
        Get historical OHLCV data for a symbol.
        Falls back to simulated data if real API fails.
        
        Args:
            symbol (str): Trading pair symbol
            timeframe (str): Timeframe for candles
            limit (int): Number of candles
            
        Returns:
            list: OHLCV data
        """
        try:
            return self.real_exchange.fetch_ohlcv(symbol, timeframe, limit=limit)
        except Exception as e:
            logger.warning(f"Could not fetch real OHLCV for {symbol}: {e}. Using simulated data.")
            
            # Generate reasonable simulated OHLCV data
            base_prices = {
                "BTC/USDT": 60000,
                "ETH/USDT": 3000,
                "SOL/USDT": 150,
                "BNB/USDT": 500,
                "DOGE/USDT": 0.1
            }
            
            base_price = base_prices.get(symbol, 100)
            now_ms = int(time.time() * 1000)
            timeframe_ms = self._timeframe_to_milliseconds(timeframe)
            
            ohlcv_data = []
            price = base_price
            
            for i in range(limit):
                timestamp = now_ms - (limit - i - 1) * timeframe_ms
                change_pct = random.uniform(-0.01, 0.01)  # 1% random change
                
                price = price * (1 + change_pct)
                high = price * (1 + random.uniform(0, 0.005))
                low = price * (1 - random.uniform(0, 0.005))
                open_price = price * (1 - change_pct)
                close = price
                volume = random.uniform(10, 100) * base_price
                
                candle = [timestamp, open_price, high, low, close, volume]
                ohlcv_data.append(candle)
            
            return ohlcv_data
    
    def _timeframe_to_milliseconds(self, timeframe):
        """Convert timeframe to milliseconds."""
        unit = timeframe[-1]
        value = int(timeframe[:-1])
        
        if unit == 'm':
            return value * 60 * 1000
        elif unit == 'h':
            return value * 60 * 60 * 1000
        elif unit == 'd':
            return value * 24 * 60 * 60 * 1000
        else:
            return 60 * 1000  # Default to 1m
    
    def fetch_balance(self):
        """
        Get account balance.
        
        Returns:
            dict: Balance information
        """
        return {
            'info': {},
            'free': self.balances.copy(),
            'used': {k: 0 for k in self.balances},
            'total': self.balances.copy()
        }
    
    def _calculate_volatility_score(self, symbol):
        """
        Calculate a volatility score for a trading pair.
        
        Args:
            symbol (str): Trading pair symbol
            
        Returns:
            float: Volatility score between 0 and 1
        """
        try:
            # Attempt to get recent price data
            ohlcv = self.fetch_ohlcv(symbol, timeframe='1m', limit=10)
            
            # Convert to DataFrame for easier analysis
            import pandas as pd
            df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            
            # Calculate price range percentage for each candle
            df['range_pct'] = (df['high'] - df['low']) / df['low'] * 100
            
            # Average range as volatility indicator
            avg_range = df['range_pct'].mean()
            
            # Normalize to a 0-1 scale (5% range in a minute would be very high volatility)
            volatility_score = min(avg_range / 5.0, 1.0)
            
            return volatility_score
        except Exception as e:
            # If we can't calculate volatility, return a default moderate value
            logger.debug(f"Could not calculate volatility for {symbol}: {e}. Using default value.")
            return 0.3
    
    def _simulate_execution_delay(self, symbol, order_size_usd):
        """
        Simulate realistic execution delay based on market volatility.
        
        Args:
            symbol (str): Trading pair symbol
            order_size_usd (float): Size of the order in USD
        """
        # Calculate volatility score
        volatility_score = self._calculate_volatility_score(symbol)
        
        # Base delay and adjustments (low volatility = 0.1s, high volatility = up to 2s)
        base_delay = 0.1
        volatility_multiplier = min(volatility_score, 1.0) * 2.0
        
        # Larger orders take more time to fill
        size_factor = min(order_size_usd / 10000, 0.5)  # 0.5s max additional delay based on size
        
        # Calculate total delay
        delay = base_delay + volatility_multiplier + size_factor
        
        # Log the delay factors
        logger.debug(f"Execution delay factors for {symbol}: volatility={volatility_score:.2f}, " +
                     f"order_size=${order_size_usd:.2f}, total_delay={delay:.2f}s")
        
        # Wait to simulate the execution delay
        time.sleep(delay)
    
    def _apply_market_impact(self, price, side, order_size_usd):
        """
        Apply market impact based on order size.
        
        Args:
            price (float): Current market price
            side (str): Order side ('buy' or 'sell')
            order_size_usd (float): Size of the order in USD
            
        Returns:
            float: Adjusted price with market impact
        """
        # Calculate impact (larger orders have more impact, max 0.5%)
        impact = min(order_size_usd / 10000, 0.005)
        
        # Apply impact based on side (buy orders push price up, sell orders push price down)
        if side == 'buy':
            adjusted_price = price * (1 + impact)
        else:
            adjusted_price = price * (1 - impact)
        
        logger.debug(f"Market impact for ${order_size_usd:.2f} order: {impact*100:.4f}% " +
                     f"adjusting price from {price} to {adjusted_price}")
        
        return adjusted_price
    
    def _simulate_market_slippage(self, price, side, symbol, order_size_usd):
        """
        Simulate market slippage with realistic factors.
        
        Args:
            price (float): Base price
            side (str): Order side ('buy' or 'sell')
            symbol (str): Trading pair symbol
            order_size_usd (float): Size of the order in USD
            
        Returns:
            float: Adjusted price with slippage
        """
        # 1. First calculate baseline slippage (spread + small random factor)
        if side == 'buy':
            # Buy orders typically execute at slightly higher prices
            base_slippage = random.uniform(0.0001, 0.002)  # 0.01% to 0.2% base slippage
            adjusted_price = price * (1 + base_slippage)
        else:
            # Sell orders typically execute at slightly lower prices
            base_slippage = random.uniform(0.0001, 0.002)  # 0.01% to 0.2% base slippage
            adjusted_price = price * (1 - base_slippage)
        
        # 2. Apply market impact based on order size
        adjusted_price = self._apply_market_impact(adjusted_price, side, order_size_usd)
        
        # 3. Simulate execution delay that would happen in real trading
        self._simulate_execution_delay(symbol, order_size_usd)
        
        # Calculate total slippage percentage
        total_slippage_pct = ((adjusted_price / price) - 1) * 100 if side == 'buy' else \
                             ((price / adjusted_price) - 1) * 100
        
        logger.debug(f"Total slippage for {side} {symbol}: {total_slippage_pct:.4f}%")
        
        return adjusted_price
        
    def create_market_buy_order(self, symbol, amount, params={}):
        """
        Create a simulated market buy order.
        
        Args:
            symbol (str): Trading pair symbol
            amount (float): Amount of the base currency to buy
            params (dict): Additional parameters
            
        Returns:
            dict: Order details
        """
        ticker = self.fetch_ticker(symbol)
        base_price = ticker['last']
        
        # Calculate order size in USD
        order_size_usd = amount * base_price
        
        # Apply simulated slippage to the price with market impact and execution delay
        price = self._simulate_market_slippage(base_price, 'buy', symbol, order_size_usd)
        
        base, quote = symbol.split('/')
        
        cost = amount * price
        fee = cost * 0.001  # Simulated fee (0.1%)
        total_cost = cost + fee
        
        # Check if we have enough balance
        if quote not in self.balances:
            self.balances[quote] = 0
            
        # Add a 1% buffer to ensure we have enough for the order with slippage
        required_balance = total_cost * 1.01
            
        if self.balances[quote] < required_balance:
            logger.warning(f"Insufficient {quote} balance for market buy order. Required: {required_balance}, Available: {self.balances[quote]}")
            raise Exception(f"Insufficient {quote} balance for market buy order. Required: {required_balance:.2f}, Available: {self.balances[quote]:.2f}")
        
        # Execute the trade
        if base not in self.balances:
            self.balances[base] = 0
            
        self.balances[quote] -= total_cost
        self.balances[base] += amount
        
        # Create order object
        order_id = f"paper_buy_{self.next_order_id}"
        self.next_order_id += 1
        
        timestamp = int(time.time() * 1000)
        
        order = {
            'id': order_id,
            'timestamp': timestamp,
            'datetime': datetime.fromtimestamp(timestamp / 1000).isoformat(),
            'symbol': symbol,
            'type': 'market',
            'side': 'buy',
            'price': price,
            'amount': amount,
            'cost': cost,
            'fee': {
                'cost': fee,
                'currency': quote,
                'rate': 0.001
            },
            'filled': amount,
            'remaining': 0,
            'status': 'closed',
            'slippage_pct': ((price / base_price) - 1) * 100  # Record slippage percentage
        }
        
        # Add to order history
        self.order_history.append(order)
        
        # Add to trade history
        trade = {
            'order_id': order_id,
            'timestamp': timestamp,
            'datetime': datetime.fromtimestamp(timestamp / 1000).isoformat(),
            'symbol': symbol,
            'type': 'market',
            'side': 'buy',
            'price': price,
            'base_price': base_price,
            'amount': amount,
            'cost': cost,
            'fee': {
                'cost': fee,
                'currency': quote,
                'rate': 0.001
            },
            'slippage_pct': ((price / base_price) - 1) * 100  # Record slippage percentage
        }
        self.trade_history.append(trade)
        
        # Save updated data
        self.save_data()
        
        logger.info(f"Created paper market buy order: {order_id}, {amount} {base} at {price} {quote} (slippage: {((price / base_price) - 1) * 100:.4f}%)")
        return order
    
    def create_market_sell_order(self, symbol, amount, params={}):
        """
        Create a simulated market sell order.
        
        Args:
            symbol (str): Trading pair symbol
            amount (float): Amount of the base currency to sell
            params (dict): Additional parameters
            
        Returns:
            dict: Order details
        """
        ticker = self.fetch_ticker(symbol)
        base_price = ticker['last']
        
        # Calculate order size in USD
        order_size_usd = amount * base_price
        
        # Apply simulated slippage to the price with market impact and execution delay
        price = self._simulate_market_slippage(base_price, 'sell', symbol, order_size_usd)
        
        base, quote = symbol.split('/')
        
        cost = amount * price
        fee = cost * 0.001  # Simulated fee (0.1%)
        total_received = cost - fee
        
        # Check if we have enough balance
        if base not in self.balances:
            self.balances[base] = 0
            
        # Add a small buffer to account for potential rounding issues
        required_amount = amount * 1.001
            
        if self.balances[base] < required_amount:
            logger.warning(f"Insufficient {base} balance for market sell order. Required: {required_amount}, Available: {self.balances[base]}")
            raise Exception(f"Insufficient {base} balance for market sell order. Required: {required_amount:.8f}, Available: {self.balances[base]:.8f}")
        
        # Execute the trade
        if quote not in self.balances:
            self.balances[quote] = 0
            
        self.balances[base] -= amount
        self.balances[quote] += total_received
        
        # Create order object
        order_id = f"paper_sell_{self.next_order_id}"
        self.next_order_id += 1
        
        timestamp = int(time.time() * 1000)
        
        order = {
            'id': order_id,
            'timestamp': timestamp,
            'datetime': datetime.fromtimestamp(timestamp / 1000).isoformat(),
            'symbol': symbol,
            'type': 'market',
            'side': 'sell',
            'price': price,
            'amount': amount,
            'cost': cost,
            'fee': {
                'cost': fee,
                'currency': quote,
                'rate': 0.001
            },
            'filled': amount,
            'remaining': 0,
            'status': 'closed',
            'slippage_pct': ((price / base_price) - 1) * 100  # Record slippage percentage
        }
        
        # Add to order history
        self.order_history.append(order)
        
        # Add to trade history
        trade = {
            'order_id': order_id,
            'timestamp': timestamp,
            'datetime': datetime.fromtimestamp(timestamp / 1000).isoformat(),
            'symbol': symbol,
            'type': 'market',
            'side': 'sell',
            'price': price,
            'base_price': base_price,
            'amount': amount,
            'cost': cost,
            'fee': {
                'cost': fee,
                'currency': quote,
                'rate': 0.001
            },
            'slippage_pct': ((price / base_price) - 1) * 100  # Record slippage percentage
        }
        self.trade_history.append(trade)
        
        # Save updated data
        self.save_data()
        
        logger.info(f"Created paper market sell order: {order_id}, {amount} {base} at {price} {quote} (slippage: {((price / base_price) - 1) * 100:.4f}%)")
        return order
    
    def fetch_my_trades(self, symbol=None, since=None, limit=None, params={}):
        """
        Get trade history for a symbol.
        
        Args:
            symbol (str): Trading pair symbol
            since (int): Timestamp to fetch trades from
            limit (int): Maximum number of trades to fetch
            params (dict): Additional parameters
            
        Returns:
            list: Trade history
        """
        trades = self.trade_history.copy()
        
        if symbol:
            trades = [t for t in trades if t['symbol'] == symbol]
        
        if since:
            trades = [t for t in trades if t['timestamp'] >= since]
        
        if limit:
            trades = trades[-limit:]
        
        return trades
    
    def get_account_balance_summary(self):
        """
        Get a summary of account balances with USD equivalent, including unrealized P&L.
        
        Returns:
            dict: Balance summary with unrealized P&L
        """
        summary = {}
        total_usd_value = 0
        total_cost_basis = 0
        unrealized_profit = 0
        
        # Track actual balances first
        for currency, amount in self.balances.items():
            if amount <= 0:
                continue
                
            if currency == 'USDT':
                usd_value = amount
                # USDT has no unrealized P&L
                unrealized_pct = 0
                cost_basis = amount
            else:
                try:
                    symbol = f"{currency}/USDT"
                    ticker = self.fetch_ticker(symbol)
                    price = ticker['last']
                    usd_value = amount * price
                    
                    # Try to find cost basis from trades
                    cost_basis = self._calculate_cost_basis(currency)
                    
                    # Calculate unrealized P&L
                    if cost_basis > 0:
                        unrealized_pct = ((usd_value - cost_basis) / cost_basis) * 100
                    else:
                        unrealized_pct = 0
                        cost_basis = usd_value  # If we can't determine cost basis
                        
                except Exception as e:
                    logger.debug(f"Error calculating value for {currency}: {e}")
                    usd_value = 0
                    unrealized_pct = 0
                    cost_basis = 0
            
            summary[currency] = {
                'amount': amount,
                'usd_value': usd_value,
                'cost_basis': cost_basis,
                'unrealized_pct': unrealized_pct,
                'unrealized_profit': usd_value - cost_basis
            }
            
            total_usd_value += usd_value
            total_cost_basis += cost_basis
            unrealized_profit += (usd_value - cost_basis)
        
        # Add portfolio stats
        portfolio_performance = {
            'balances': summary,
            'total_usd_value': total_usd_value,
            'total_cost_basis': total_cost_basis,
            'unrealized_profit': unrealized_profit,
            'unrealized_pct': (unrealized_profit / total_cost_basis * 100) if total_cost_basis > 0 else 0
        }
        
        # Add transaction metrics
        portfolio_performance.update(self._calculate_trading_metrics())
        
        return portfolio_performance
        
    def _calculate_cost_basis(self, currency):
        """
        Calculate the cost basis for a currency based on trade history.
        Uses average cost method.
        
        Args:
            currency (str): Currency to calculate cost basis for
            
        Returns:
            float: Cost basis in USDT
        """
        # Look for buy trades for this currency
        buys = []
        sells = []
        
        for trade in self.trade_history:
            if trade['symbol'].startswith(currency + '/'):
                if trade['side'] == 'buy':
                    buys.append({
                        'amount': trade['amount'],
                        'cost': trade['cost'] + trade['fee']['cost'] if trade['fee']['currency'] != currency else trade['cost']
                    })
                elif trade['side'] == 'sell':
                    sells.append({
                        'amount': trade['amount']
                    })
        
        # Calculate total amount bought and total cost
        total_bought = sum(buy['amount'] for buy in buys)
        total_cost = sum(buy['cost'] for buy in buys)
        
        # Calculate total amount sold
        total_sold = sum(sell['amount'] for sell in sells)
        
        # Calculate remaining amount and its cost basis
        remaining = total_bought - total_sold
        
        if remaining <= 0 or total_bought == 0:
            return 0
            
        # Use average cost method
        cost_basis = (total_cost / total_bought) * remaining
        
        return cost_basis
        
    def _calculate_trading_metrics(self):
        """
        Calculate various trading metrics from trade history.
        
        Returns:
            dict: Trading metrics
        """
        if not self.trade_history:
            return {
                'total_trades': 0,
                'avg_trade_size': 0,
                'avg_holding_time': 0,
                'realized_profit': 0,
                'win_rate': 0,
                'largest_gain': 0,
                'largest_loss': 0
            }
            
        # Group trades by symbol and calculate P&L
        trades_by_symbol = {}
        for trade in self.trade_history:
            symbol = trade['symbol']
            if symbol not in trades_by_symbol:
                trades_by_symbol[symbol] = []
            trades_by_symbol[symbol].append(trade)
        
        # Calculate metrics
        total_realized_profit = 0
        winning_trades = 0
        losing_trades = 0
        largest_gain = 0
        largest_loss = 0
        holding_times = []
        trade_sizes = [trade['cost'] for trade in self.trade_history]
        
        # Calculate realized P&L
        for symbol, trades in trades_by_symbol.items():
            # Group by buy/sell
            buys = [t for t in trades if t['side'] == 'buy']
            sells = [t for t in trades if t['side'] == 'sell']
            
            # Simple FIFO matching for realized P&L
            remaining_buys = buys.copy()
            for sell in sells:
                sell_amount = sell['amount']
                sell_price = sell['price']
                
                while sell_amount > 0 and remaining_buys:
                    buy = remaining_buys[0]
                    buy_amount = buy['amount']
                    buy_price = buy['price']
                    
                    # Calculate match amount
                    match_amount = min(sell_amount, buy_amount)
                    
                    # Calculate P&L
                    profit = match_amount * (sell_price - buy_price)
                    total_realized_profit += profit
                    
                    # Update metrics
                    if profit > 0:
                        winning_trades += 1
                        largest_gain = max(largest_gain, profit)
                    else:
                        losing_trades += 1
                        largest_loss = min(largest_loss, profit)
                        
                    # Calculate holding time if timestamps available
                    if 'timestamp' in buy and 'timestamp' in sell:
                        holding_time = (sell['timestamp'] - buy['timestamp']) / (1000 * 60 * 60)  # hours
                        holding_times.append(holding_time)
                    
                    # Update remaining
                    sell_amount -= match_amount
                    buy['amount'] -= match_amount
                    
                    # Remove buy if fully used
                    if buy['amount'] <= 0:
                        remaining_buys.pop(0)
        
        # Calculate final metrics
        total_trades = len(self.trade_history)
        avg_trade_size = sum(trade_sizes) / total_trades if total_trades > 0 else 0
        avg_holding_time = sum(holding_times) / len(holding_times) if holding_times else 0
        win_rate = (winning_trades / (winning_trades + losing_trades)) * 100 if (winning_trades + losing_trades) > 0 else 0
        
        return {
            'total_trades': total_trades,
            'avg_trade_size': avg_trade_size,
            'avg_holding_time': avg_holding_time,
            'realized_profit': total_realized_profit,
            'win_rate': win_rate,
            'largest_gain': largest_gain,
            'largest_loss': largest_loss
        }
    
    def reset_balance(self, usdt_amount=1000.0):
        """
        Reset paper trading balance.
        
        Args:
            usdt_amount (float): Initial USDT balance to reset to
        """
        self.balances = {'USDT': float(usdt_amount)}
        self.save_data()
        logger.info(f"Reset paper trading balance to {usdt_amount} USDT")