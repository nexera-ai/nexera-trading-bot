#!/usr/bin/env python3
"""
neXera Trading Platform Installer Creator

This script creates the zip file for building the Windows installer.
It bundles the essential files and proper configuration settings.
"""
import os
import zipfile
import shutil
from pathlib import Path

# Configuration settings
NEXERA_VERSION = "1.0.0"
OPENAI_VERSION = "1.14.3"  # Fixed correct version

# Create temporary directory
temp_dir = Path("./nexera_installer_temp")
output_dir = Path("./")
if temp_dir.exists():
    shutil.rmtree(temp_dir)
temp_dir.mkdir(exist_ok=True)

# Create nexera.spec file with proper OpenAI version
spec_content = f"""# -*- mode: python ; coding: utf-8 -*-

block_cipher = None

a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=[],
    datas=[
        ('templates', 'templates'),
        ('static', 'static'),
        ('strategies', 'strategies'),
        ('data', 'data'),
        ('chart_templates', 'chart_templates'),
    ],
    hiddenimports=[
        'flask',
        'sqlalchemy',
        'ccxt',
        'matplotlib',
        'openai=={OPENAI_VERSION}',  # Fixed OpenAI version
        'numpy',
        'requests',
        'pandas',
        'plotly',
        'sendgrid',
        'twilio',
        'schedule',
        'seaborn',
        'weasyprint',
    ],
    hookspath=[],
    hooksconfig={{}},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='nexera',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='static/img/nexera_icon.ico',
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='nexera',
)
"""

with open(temp_dir / "nexera.spec", "w") as f:
    f.write(spec_content)

# Create Inno Setup script
iss_content = f"""#define MyAppName "neXera Trading Platform"
#define MyAppVersion "{NEXERA_VERSION}"
#define MyAppPublisher "neXera"
#define MyAppURL "https://nexera.design"
#define MyAppExeName "nexera.exe"

[Setup]
AppId={{{{9B1F54A4-FA82-43C7-82F1-A3F3E9CCDBFD}}}}
AppName={{#MyAppName}}
AppVersion={{#MyAppVersion}}
AppPublisher={{#MyAppPublisher}}
AppPublisherURL={{#MyAppURL}}
AppSupportURL={{#MyAppURL}}
AppUpdatesURL={{#MyAppURL}}
DefaultDirName={{autopf}}\\{{#MyAppName}}
DisableProgramGroupPage=yes
LicenseFile=LICENSE
InfoBeforeFile=README.md
OutputDir=Output
OutputBaseFilename=neXera_Trading_Platform_Setup
SetupIconFile=static\\img\\nexera_icon.ico
Compression=lzma
SolidCompression=yes
WizardStyle=modern
WizardImageFile=static\\img\\nexera_installer_large.bmp
WizardSmallImageFile=static\\img\\nexera_installer_small.bmp

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{{cm:CreateDesktopIcon}}"; GroupDescription: "{{cm:AdditionalIcons}}"; Flags: unchecked

[Files]
Source: "dist\\nexera\\{{#MyAppExeName}}"; DestDir: "{{app}}"; Flags: ignoreversion
Source: "dist\\nexera\\*"; DestDir: "{{app}}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "LICENSE"; DestDir: "{{app}}"; Flags: ignoreversion
Source: "README.md"; DestDir: "{{app}}"; Flags: ignoreversion
Source: "BACKUP_GUIDE.md"; DestDir: "{{app}}"; Flags: ignoreversion
Source: "DOMAIN_SETUP.md"; DestDir: "{{app}}"; Flags: ignoreversion

[Icons]
Name: "{{autoprograms}}\\{{#MyAppName}}"; Filename: "{{app}}\\{{#MyAppExeName}}"
Name: "{{autodesktop}}\\{{#MyAppName}}"; Filename: "{{app}}\\{{#MyAppExeName}}"; Tasks: desktopicon

[Run]
Filename: "{{app}}\\{{#MyAppExeName}}"; Description: "{{cm:LaunchProgram,{{#StringChange(MyAppName, '&', '&&')}}}}"; Flags: nowait postinstall skipifsilent
"""

with open(temp_dir / "nexera_installer.iss", "w") as f:
    f.write(iss_content)

# Create batch file to build the installer
batch_content = """@echo off
echo neXera Trading Platform - Installer Build Script
echo =============================================
echo.

REM Check for Python installation
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Python is not installed or not in PATH
    echo Please install Python 3.10 or higher
    pause
    exit /b 1
)

REM Install required packages
echo Installing required packages...
pip install pyinstaller
pip install innosetup

REM Install application dependencies
echo Installing application dependencies...
pip install openai==1.14.3
pip install ccxt
pip install flask
pip install flask-sqlalchemy
pip install matplotlib
pip install numpy
pip install pandas
pip install plotly
pip install psycopg2-binary
pip install schedule
pip install seaborn
pip install sendgrid
pip install sqlalchemy
pip install twilio
pip install weasyprint

REM Build the executable
echo.
echo Building the executable with PyInstaller...
pyinstaller nexera.spec

REM Check if the executable was created
if not exist "dist\\nexera\\nexera.exe" (
    echo ERROR: Failed to create executable
    echo Check the PyInstaller output for errors
    pause
    exit /b 1
)

REM Check for Inno Setup
iscc /? >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo Inno Setup is not installed or not in PATH
    echo Please install Inno Setup from: https://jrsoftware.org/isdl.php
    echo Then run Inno Setup Compiler manually to build the installer:
    echo 1. Open Inno Setup Compiler
    echo 2. Open the nexera_installer.iss file
    echo 3. Click Build > Compile
    pause
    exit /b 1
)

REM Build the installer
echo.
echo Building the installer with Inno Setup...
iscc nexera_installer.iss

REM Check if the installer was created
if not exist "Output\\neXera_Trading_Platform_Setup.exe" (
    echo ERROR: Failed to create installer
    echo Check the Inno Setup output for errors
    pause
    exit /b 1
)

echo.
echo =============================================
echo Build completed successfully!
echo The installer is located at: Output\\neXera_Trading_Platform_Setup.exe
echo =============================================
echo.
pause
"""

with open(temp_dir / "build_installer.bat", "w") as f:
    f.write(batch_content)

# Create detailed instructions
instructions_content = """# neXera Trading Platform - Windows Installer Creation Guide

## Introduction
This package contains everything you need to create a Windows installer for the neXera Trading Platform. Please follow the step-by-step instructions below.

## Prerequisites
- Windows 10/11 computer
- Python 3.10 or higher installed
- Administrator privileges
- Internet connection for downloading dependencies

## Step 1: Prepare the Project Files
1. Download your complete neXera project from Replit using the "Download as zip" option
2. Create a folder on your Windows PC (e.g., C:\\neXera)
3. Extract the Replit project zip file to this folder
4. Copy all files from this installer package to the same folder:
   - nexera.spec
   - nexera_installer.iss
   - build_installer.bat
   - README_INSTALLER.md (this file)

## Step 2: Create the Icon (if missing)
If your project doesn't have the neXera icon:
1. Create a folder: C:\\neXera\\static\\img\\
2. Save the neXera icon as: C:\\neXera\\static\\img\\nexera_icon.ico

## Step 3: Run the Build Script
1. Open Command Prompt as Administrator
2. Navigate to your project folder: 
   ```
   cd C:\\neXera
   ```
3. Run the build script:
   ```
   build_installer.bat
   ```
4. Follow the on-screen instructions

## Step 4: Locate the Installer
After successful completion, find your installer at:
```
C:\\neXera\\Output\\neXera_Trading_Platform_Setup.exe
```

## Troubleshooting

### Missing Files:
If the executable isn't generated:
1. Check the dist\\nexera folder exists
2. Ensure all dependencies are installed correctly

### Dependency Issues:
If you see errors about missing libraries:
```
pip install [library_name]
```

### OpenAI Version:
If you have OpenAI version issues:
```
pip uninstall openai
pip install openai==1.14.3
```

### Inno Setup Missing:
If Inno Setup isn't found:
1. Download and install from: https://jrsoftware.org/isdl.php
2. Add to PATH or run the compiler manually

## Support
If you need assistance, please contact support@nexera.design
"""

with open(temp_dir / "README_INSTALLER.md", "w") as f:
    f.write(instructions_content)

# Create the zip file
zip_filename = output_dir / "neXera_Trading_Bot_Final_Installer_Config.zip"
with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for file in temp_dir.glob('*'):
        zipf.write(file, arcname=file.name)

# Clean up
shutil.rmtree(temp_dir)

print(f"Installer package created successfully: {zip_filename}")
print("Size:", os.path.getsize(zip_filename), "bytes")