#!/usr/bin/env python3
"""
Smart Reinvestment Scaling Logic

This module analyzes strategy performance and dynamically adjusts weights
to increase allocation to high-performing strategies while maintaining
risk management controls.
"""

import os
import json
import logging
import datetime
from typing import Dict, List, Any, Tuple, Optional
import time
import threading

from performance_tracker import PerformanceTracker
from ensemble_engine import ensemble_manager
from auto_rotation import auto_rotation_engine

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('smart_scaling')

class SmartScaling:
    """
    Smart Scaling Logic for dynamically adjusting strategy weights
    based on performance metrics.
    """
    
    def __init__(self, 
                 data_dir: str = './data',
                 growth_threshold: float = 0.03,  # 3% over lookback period
                 min_sharpe_threshold: float = 1.8,
                 lookback_period_hours: int = 48,  # 2 days
                 scaling_factor: float = 0.2,  # 20% increase in weight
                 max_allocation_increase: float = 0.5,  # Cap at 50% increase
                 check_interval_hours: int = 6,
                 is_enabled: bool = False):
        """
        Initialize the smart scaling logic.
        
        Args:
            data_dir: Directory for storing data
            growth_threshold: Minimum growth percentage over lookback period
            min_sharpe_threshold: Minimum Sharpe ratio required for scaling
            lookback_period_hours: Hours to look back for performance
            scaling_factor: Factor to increase weight by (as percentage)
            max_allocation_increase: Maximum increase in allocation
            check_interval_hours: Hours between checks
            is_enabled: Whether scaling is enabled
        """
        self.data_dir = data_dir
        self.growth_threshold = growth_threshold
        self.min_sharpe_threshold = min_sharpe_threshold
        self.lookback_period_hours = lookback_period_hours
        self.scaling_factor = scaling_factor
        self.max_allocation_increase = max_allocation_increase
        self.check_interval_hours = check_interval_hours
        self.is_enabled = is_enabled
        
        self.scaling_history = []
        self.scaled_strategies = {}  # Currently scaled strategies
        self.last_check_time = None
        self.scheduler_running = False
        self.thread = None
        
        # Create scaling history directory
        self.history_dir = os.path.join(data_dir, 'scaling_history')
        os.makedirs(self.history_dir, exist_ok=True)
        
        # Load scaling history
        self._load_history()
    
    def _load_history(self):
        """Load scaling history from disk."""
        history_file = os.path.join(self.history_dir, 'scaling_history.json')
        if os.path.exists(history_file):
            try:
                with open(history_file, 'r') as f:
                    self.scaling_history = json.load(f)
                logger.info(f"Loaded {len(self.scaling_history)} scaling history records")
                
                # Restore scaled strategies state
                for record in self.scaling_history:
                    if record.get('active', False):
                        strategy_name = record.get('strategy')
                        if strategy_name:
                            self.scaled_strategies[strategy_name] = record
            except Exception as e:
                logger.error(f"Error loading scaling history: {e}")
    
    def _save_history(self):
        """Save scaling history to disk."""
        history_file = os.path.join(self.history_dir, 'scaling_history.json')
        try:
            with open(history_file, 'w') as f:
                json.dump(self.scaling_history, f, indent=2)
            logger.debug("Saved scaling history")
        except Exception as e:
            logger.error(f"Error saving scaling history: {e}")
    
    def get_strategy_performance(self, strategy_name: str) -> Dict[str, Any]:
        """
        Get performance metrics for a specific strategy over the lookback period.
        
        Args:
            strategy_name: Name of the strategy to analyze
            
        Returns:
            Dict containing performance metrics
        """
        tracker = PerformanceTracker(data_dir=self.data_dir)
        strategy_perf = tracker.get_strategy_performance().get(strategy_name, {})
        
        # Calculate lookback period
        now = datetime.datetime.now()
        lookback_time = now - datetime.timedelta(hours=self.lookback_period_hours)
        
        # Filter trade list to lookback period
        trade_list = strategy_perf.get('trade_list', [])
        recent_trades = []
        
        for trade in trade_list:
            trade_time = trade.get('timestamp')
            if not trade_time:
                continue
                
            if isinstance(trade_time, str):
                try:
                    trade_time = datetime.datetime.fromisoformat(trade_time.replace('Z', '+00:00'))
                except ValueError:
                    continue
            
            if trade_time >= lookback_time:
                recent_trades.append(trade)
        
        # Calculate performance metrics from recent trades
        total_pnl = sum(trade.get('pnl', 0) for trade in recent_trades)
        
        # Calculate starting equity
        first_equity = tracker.get_first_equity_value()
        if first_equity <= 0:
            first_equity = 10000  # Default if unknown
            
        growth_pct = total_pnl / first_equity
        
        # Get win rate
        wins = sum(1 for trade in recent_trades if trade.get('pnl', 0) > 0)
        total = len(recent_trades)
        win_rate = wins / total if total > 0 else 0
        
        # Calculate Sharpe ratio
        returns = [trade.get('pnl', 0) / first_equity for trade in recent_trades]
        if not returns:
            sharpe_ratio = 0
        else:
            mean_return = sum(returns) / len(returns)
            # Calculate standard deviation with small epsilon to avoid division by zero
            std_dev = max(1e-8, (sum((r - mean_return) ** 2 for r in returns) / len(returns)) ** 0.5)
            # Annualize the Sharpe ratio (assuming daily returns)
            sharpe_ratio = mean_return / std_dev * (365 / (self.lookback_period_hours / 24)) ** 0.5
        
        return {
            'strategy': strategy_name,
            'growth_pct': growth_pct,
            'sharpe_ratio': sharpe_ratio,
            'win_rate': win_rate,
            'trade_count': total,
            'total_pnl': total_pnl,
            'period_hours': self.lookback_period_hours
        }
    
    def should_scale_strategy(self, strategy_name: str) -> Tuple[bool, Dict[str, Any]]:
        """
        Determine if a strategy should have its allocation scaled up.
        
        Args:
            strategy_name: Name of the strategy to check
            
        Returns:
            Tuple of (should_scale, metrics)
        """
        # Check if already scaled
        if strategy_name in self.scaled_strategies:
            return False, {}
        
        # Get performance metrics
        metrics = self.get_strategy_performance(strategy_name)
        
        # Check scaling criteria
        should_scale = (
            metrics.get('growth_pct', 0) >= self.growth_threshold and
            metrics.get('sharpe_ratio', 0) >= self.min_sharpe_threshold and
            metrics.get('trade_count', 0) >= 5  # Minimum trades for statistical significance
        )
        
        return should_scale, metrics
    
    def scale_strategy(self, strategy_name: str, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """
        Scale up a strategy's allocation.
        
        Args:
            strategy_name: Name of the strategy to scale
            metrics: Performance metrics
            
        Returns:
            Dict containing scaling details
        """
        # Get current weight
        active_ensemble = ensemble_manager.get_active_ensemble()
        if not active_ensemble:
            logger.warning("No active ensemble found")
            return {}
            
        current_weight = active_ensemble.get_strategy_weight(strategy_name)
        if current_weight is None:
            logger.warning(f"Strategy {strategy_name} not found in active ensemble")
            return {}
        
        # Calculate new weight with scaling factor
        weight_increase = current_weight * self.scaling_factor
        
        # Cap the increase based on max_allocation_increase
        max_increase = current_weight * self.max_allocation_increase
        weight_increase = min(weight_increase, max_increase)
        
        new_weight = current_weight + weight_increase
        
        # Apply the new weight
        success = ensemble_manager.update_strategy_weight(strategy_name, new_weight)
        
        if not success:
            logger.error(f"Failed to apply scaled weight to {strategy_name}")
            return {}
        
        # Record the scaling event
        scaling_record = {
            'timestamp': datetime.datetime.now().isoformat(),
            'strategy': strategy_name,
            'original_weight': current_weight,
            'new_weight': new_weight,
            'increase_pct': (new_weight / current_weight - 1) * 100,
            'metrics': metrics,
            'scaling_factor': self.scaling_factor,
            'active': True
        }
        
        # Add to history and current scaled strategies
        self.scaling_history.append(scaling_record)
        self.scaled_strategies[strategy_name] = scaling_record
        
        # Save history
        self._save_history()
        
        logger.info(f"Scaled strategy {strategy_name} from {current_weight:.2f} to {new_weight:.2f}")
        return scaling_record
    
    def revert_scaling(self, strategy_name: str) -> bool:
        """
        Revert scaling for a strategy that no longer meets criteria.
        
        Args:
            strategy_name: Name of the strategy to revert
            
        Returns:
            True if successful, False otherwise
        """
        if strategy_name not in self.scaled_strategies:
            return False
        
        # Get original weight
        scaling_record = self.scaled_strategies[strategy_name]
        original_weight = scaling_record.get('original_weight')
        
        if original_weight is None:
            logger.warning(f"Original weight not found for {strategy_name}")
            return False
        
        # Apply original weight
        success = ensemble_manager.update_strategy_weight(strategy_name, original_weight)
        
        if not success:
            logger.error(f"Failed to revert scaling for {strategy_name}")
            return False
        
        # Update the record
        scaling_record['active'] = False
        scaling_record['reverted_at'] = datetime.datetime.now().isoformat()
        
        # Remove from active scaled strategies
        del self.scaled_strategies[strategy_name]
        
        # Save history
        self._save_history()
        
        logger.info(f"Reverted scaling for strategy {strategy_name} to original weight {original_weight:.2f}")
        return True
    
    def check_scaled_strategies(self):
        """
        Check all currently scaled strategies to see if they still meet criteria.
        If not, revert their scaling.
        """
        # Make a copy of keys to avoid modifying during iteration
        strategy_names = list(self.scaled_strategies.keys())
        
        for strategy_name in strategy_names:
            should_scale, metrics = self.should_scale_strategy(strategy_name)
            
            # Override should_scale since it always returns False for already scaled strategies
            # Instead, check metrics directly
            still_meets_criteria = (
                metrics.get('growth_pct', 0) >= self.growth_threshold and
                metrics.get('sharpe_ratio', 0) >= self.min_sharpe_threshold
            )
            
            if not still_meets_criteria:
                self.revert_scaling(strategy_name)
    
    def run_scaling_check(self) -> List[Dict[str, Any]]:
        """
        Check all strategies for scaling opportunities and apply scaling as needed.
        
        Returns:
            List of scaling actions taken
        """
        if not self.is_enabled:
            logger.info("Smart scaling is disabled")
            return []
        
        # Update check time
        self.last_check_time = datetime.datetime.now()
        
        # Check existing scaled strategies
        self.check_scaled_strategies()
        
        # Get all strategies from active ensemble
        active_ensemble = ensemble_manager.get_active_ensemble()
        if not active_ensemble:
            logger.warning("No active ensemble found")
            return []
            
        strategies = active_ensemble.get_strategies()
        scaling_actions = []
        
        # Check each strategy
        for strategy_name in strategies:
            should_scale, metrics = self.should_scale_strategy(strategy_name)
            
            if should_scale:
                scaling_record = self.scale_strategy(strategy_name, metrics)
                if scaling_record:
                    scaling_actions.append(scaling_record)
        
        return scaling_actions
    
    def _scheduler_loop(self):
        """Background thread for running the scheduler."""
        logger.info("Starting smart scaling scheduler")
        
        while self.scheduler_running:
            try:
                self.run_scaling_check()
            except Exception as e:
                logger.error(f"Error in scaling check: {e}")
            
            # Sleep until next check
            time.sleep(self.check_interval_hours * 3600)
        
        logger.info("Smart scaling scheduler stopped")
    
    def start_scheduler(self):
        """Start the background scheduler thread."""
        if self.thread and self.thread.is_alive():
            logger.warning("Scheduler already running")
            return
        
        self.scheduler_running = True
        self.thread = threading.Thread(target=self._scheduler_loop)
        self.thread.daemon = True  # Thread will exit when main program exits
        self.thread.start()
        
        logger.info(f"Smart scaling scheduled to run every {self.check_interval_hours} hours")
    
    def stop_scheduler(self):
        """Stop the background scheduler thread."""
        self.scheduler_running = False
        
        if self.thread:
            self.thread.join(timeout=2.0)  # Wait for thread to exit
            self.thread = None
        
        logger.info("Smart scaling scheduler stopped")
    
    def enable(self):
        """Enable smart scaling."""
        self.is_enabled = True
        if not self.scheduler_running:
            self.start_scheduler()
    
    def disable(self):
        """Disable smart scaling."""
        self.is_enabled = False
        if self.scheduler_running:
            self.stop_scheduler()
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get current status of smart scaling.
        
        Returns:
            Dict[str, Any]: Status information
        """
        return {
            'is_enabled': self.is_enabled,
            'scheduler_running': self.scheduler_running,
            'last_check_time': self.last_check_time.isoformat() if self.last_check_time else None,
            'growth_threshold': self.growth_threshold,
            'min_sharpe_threshold': self.min_sharpe_threshold,
            'lookback_period_hours': self.lookback_period_hours,
            'scaling_factor': self.scaling_factor,
            'max_allocation_increase': self.max_allocation_increase,
            'check_interval_hours': self.check_interval_hours,
            'scaled_strategies': list(self.scaled_strategies.keys()),
            'scaling_count': len(self.scaling_history)
        }
    
    def get_history(self, limit: int = 10, active_only: bool = False) -> List[Dict[str, Any]]:
        """
        Get scaling history.
        
        Args:
            limit: Maximum number of records to return
            active_only: If True, only return active (non-reverted) scaling events
            
        Returns:
            List[Dict[str, Any]]: Scaling history
        """
        if active_only:
            filtered_history = [record for record in self.scaling_history if record.get('active', False)]
        else:
            filtered_history = self.scaling_history
            
        # Return most recent records first
        return sorted(filtered_history, key=lambda x: x['timestamp'], reverse=True)[:limit]


# Create global instance
smart_scaling = SmartScaling(data_dir='./data')