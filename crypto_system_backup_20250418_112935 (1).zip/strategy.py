"""
Trading Strategy Module
Contains the logic for entry and exit decisions.
"""
import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class TradingStrategy:
    """Trading strategy implementation based on price drop percentage."""
    
    def __init__(self, price_drop_threshold=2.5, price_drop_timeframe=15, 
                 take_profit=3.0, stop_loss=1.5):
        """
        Initialize the trading strategy with parameters.
        
        Args:
            price_drop_threshold (float): Minimum price drop percentage to trigger entry
            price_drop_timeframe (int): Timeframe to check for price drop (minutes)
            take_profit (float): Take profit percentage
            stop_loss (float): Stop loss percentage
        """
        self.price_drop_threshold = price_drop_threshold
        self.price_drop_timeframe = price_drop_timeframe
        self.take_profit = take_profit
        self.stop_loss = stop_loss
        
        logger.info(f"Strategy initialized: Entry on {price_drop_threshold}% drop in {price_drop_timeframe} minutes, "
                    f"exit at +{take_profit}% profit or -{stop_loss}% loss")
    
    def should_enter(self, historical_data):
        """
        Check if entry conditions are met based on price drop threshold.
        
        Args:
            historical_data (pandas.DataFrame): Historical price data with OHLCV
            
        Returns:
            bool: True if entry conditions are met, False otherwise
        """
        try:
            # Make sure we have enough data
            if len(historical_data) < self.price_drop_timeframe:
                logger.warning(f"Not enough historical data for analysis. Needed: {self.price_drop_timeframe}, Got: {len(historical_data)}")
                return False
            
            # Get the current price and the price from timeframe minutes ago
            current_price = historical_data['close'].iloc[-1]
            previous_price = historical_data['close'].iloc[-self.price_drop_timeframe]
            
            # Calculate price change percentage
            price_change_percentage = ((current_price - previous_price) / previous_price) * 100
            
            # Check if the price has dropped by the threshold percentage
            if price_change_percentage <= -self.price_drop_threshold:
                logger.info(f"Price dropped by {abs(price_change_percentage):.2f}% in the last {self.price_drop_timeframe} minutes")
                logger.info(f"Previous price: {previous_price}, Current price: {current_price}")
                return True
            else:
                logger.debug(f"Price change: {price_change_percentage:.2f}%, not meeting drop threshold of -{self.price_drop_threshold}%")
                return False
                
        except Exception as e:
            logger.error(f"Error in should_enter: {e}")
            return False
    
    def calculate_exit_prices(self, entry_price):
        """
        Calculate take profit and stop loss prices based on entry price.
        
        Args:
            entry_price (float): Entry price
            
        Returns:
            tuple: (take_profit_price, stop_loss_price)
        """
        take_profit_price = entry_price * (1 + (self.take_profit / 100))
        stop_loss_price = entry_price * (1 - (self.stop_loss / 100))
        
        return take_profit_price, stop_loss_price
