import zipfile
import os
from datetime import datetime

# Define the output zip filename
zip_filename = "neXera_Trading_Bot_Final_Installer_Config.zip"

# List of files to include in the zip
files_to_zip = [
    "nexera.spec",
    "nexera_installer.iss",
    "build_installer.bat",
    "NEXERA_DOMAIN_CONFIG.md",
    "BACKUP_GUIDE.md",
    "NEXERA_EXTRACTION_REPORT.md"
]

# Create a new zip file
with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
    # Add each file to the zip
    for file in files_to_zip:
        if os.path.exists(file):
            zipf.write(file)
            print(f"Added {file} to {zip_filename}")
        else:
            print(f"Warning: File {file} not found, skipped")

# Verify the zip file was created
if os.path.exists(zip_filename):
    filesize = os.path.getsize(zip_filename) / 1024  # Size in KB
    print(f"\nSuccess! Created {zip_filename} ({filesize:.2f} KB)")
    print(f"Contents: {', '.join(files_to_zip)}")
else:
    print(f"Error: Failed to create {zip_filename}")