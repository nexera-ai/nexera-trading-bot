import os
import json
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase, relationship
from sqlalchemy import ForeignKey

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

class StrategyPreset(db.Model):
    """Model for storing strategy configuration presets"""
    __tablename__ = 'strategy_presets'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    description = db.Column(db.Text, nullable=True)
    config_type = db.Column(db.String(50), nullable=False)  # 'ensemble', 'rotation', etc.
    config_data = db.Column(db.JSON, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    performance_metrics = db.Column(db.JSON, nullable=True)  # Optional performance data
    tags = db.Column(db.String(200), nullable=True)  # Comma-separated tags
    is_favorite = db.Column(db.Boolean, default=False)
    
    # Relationships
    equity_history = relationship("PresetEquityHistory", back_populates="preset", cascade="all, delete-orphan")
    trigger_events = relationship("PresetTriggerEvent", back_populates="preset", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<StrategyPreset {self.name}>"
    
    def to_dict(self):
        """Convert preset to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'config_type': self.config_type,
            'config_data': self.config_data,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'performance_metrics': self.performance_metrics,
            'tags': self.tags.split(',') if self.tags else [],
            'is_favorite': self.is_favorite
        }
    
    @classmethod
    def from_dict(cls, data):
        """Create a preset from dictionary data"""
        tags = ','.join(data.get('tags', [])) if data.get('tags') else None
        
        return cls(
            name=data.get('name'),
            description=data.get('description'),
            config_type=data.get('config_type'),
            config_data=data.get('config_data'),
            performance_metrics=data.get('performance_metrics'),
            tags=tags,
            is_favorite=data.get('is_favorite', False)
        )


class PresetEquityHistory(db.Model):
    """Model for storing equity history for strategy presets over time"""
    __tablename__ = 'preset_equity_history'
    
    id = db.Column(db.Integer, primary_key=True)
    preset_id = db.Column(db.Integer, ForeignKey('strategy_presets.id', ondelete='CASCADE'), nullable=False)
    timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    equity = db.Column(db.Float, nullable=False)  # Portfolio value
    base_currency = db.Column(db.String(10), nullable=False, default='USDT')  # Base currency (e.g., USDT, USD)
    
    # Additional metrics
    pnl_percent = db.Column(db.Float, nullable=True)  # Profit/loss percentage
    drawdown_percent = db.Column(db.Float, nullable=True)  # Current drawdown percentage
    win_count = db.Column(db.Integer, nullable=True)  # Number of winning trades
    loss_count = db.Column(db.Integer, nullable=True)  # Number of losing trades
    
    # Performance metrics
    sharpe_ratio = db.Column(db.Float, nullable=True)  # Sharpe ratio (risk-adjusted return)
    sortino_ratio = db.Column(db.Float, nullable=True)  # Sortino ratio (downside risk-adjusted return)
    max_drawdown = db.Column(db.Float, nullable=True)  # Maximum drawdown percentage
    
    # Market context
    market_conditions = db.Column(db.String(20), nullable=True)  # e.g., bull, bear, sideways
    vix_value = db.Column(db.Float, nullable=True)  # Volatility index value
    
    # Relationship
    preset = relationship("StrategyPreset", back_populates="equity_history")
    
    def __repr__(self):
        return f"<PresetEquityHistory {self.preset_id} {self.timestamp} {self.equity}>"
    
    def to_dict(self):
        """Convert equity history record to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'preset_id': self.preset_id,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'equity': self.equity,
            'base_currency': self.base_currency,
            'pnl_percent': self.pnl_percent,
            'drawdown_percent': self.drawdown_percent,
            'win_count': self.win_count,
            'loss_count': self.loss_count,
            'sharpe_ratio': self.sharpe_ratio,
            'sortino_ratio': self.sortino_ratio,
            'max_drawdown': self.max_drawdown,
            'market_conditions': self.market_conditions,
            'vix_value': self.vix_value
        }


class PresetTriggerEvent(db.Model):
    """Model for storing trigger events that can be overlaid on equity charts"""
    __tablename__ = 'preset_trigger_events'
    
    id = db.Column(db.Integer, primary_key=True)
    preset_id = db.Column(db.Integer, ForeignKey('strategy_presets.id', ondelete='CASCADE'), nullable=False)
    timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    
    # Event metadata
    event_type = db.Column(db.String(50), nullable=False)  # e.g., 'policy_activation', 'market_shift', 'parameter_change', 'strategy_change'
    event_subtype = db.Column(db.String(50), nullable=True)  # More specific categorization
    title = db.Column(db.String(100), nullable=False)  # Short event title
    description = db.Column(db.Text, nullable=True)  # Detailed description
    
    # Visual representation properties
    color = db.Column(db.String(20), nullable=True)  # CSS color for the trigger point
    icon = db.Column(db.String(50), nullable=True)  # Icon identifier (e.g., bootstrap icon name)
    importance = db.Column(db.Integer, nullable=False, default=1)  # 1-5 scale of importance
    
    # Event context data (JSON)
    context_data = db.Column(db.JSON, nullable=True)  # Additional event-specific data
    
    # For automated vs manual triggers
    is_auto_generated = db.Column(db.Boolean, nullable=False, default=False)
    created_by = db.Column(db.String(100), nullable=True)  # User or system component that created the event
    
    # Relationships
    preset = relationship("StrategyPreset", back_populates="trigger_events")
    
    def __repr__(self):
        return f"<PresetTriggerEvent {self.preset_id} {self.timestamp} {self.event_type}>"
    
    def to_dict(self):
        """Convert trigger event to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'preset_id': self.preset_id,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'event_type': self.event_type,
            'event_subtype': self.event_subtype,
            'title': self.title,
            'description': self.description,
            'color': self.color,
            'icon': self.icon,
            'importance': self.importance,
            'context_data': self.context_data,
            'is_auto_generated': self.is_auto_generated,
            'created_by': self.created_by
        }


class PerformanceAlertRule(db.Model):
    """Model for storing performance alert rules"""
    __tablename__ = 'performance_alert_rules'
    
    id = db.Column(db.Integer, primary_key=True)
    preset_id = db.Column(db.Integer, ForeignKey('strategy_presets.id', ondelete='CASCADE'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    
    # Alert conditions
    metric = db.Column(db.String(50), nullable=False)  # e.g., 'win_rate', 'drawdown', 'sharpe_ratio', 'equity'
    condition = db.Column(db.String(20), nullable=False)  # e.g., 'above', 'below', 'equals', 'changes_by'
    threshold = db.Column(db.Float, nullable=False)  # Threshold value
    
    # Advanced conditions
    comparison_window = db.Column(db.Integer, nullable=True)  # Number of data points to consider (e.g., last 24 hours)
    timeframe = db.Column(db.String(20), nullable=True)  # Optional timeframe (e.g., '1h', '1d', '7d')
    consecutive_triggers = db.Column(db.Integer, nullable=False, default=1)  # Number of consecutive times condition must be met
    cool_down_minutes = db.Column(db.Integer, nullable=False, default=60)  # Minutes before alert can trigger again
    
    # Alert settings
    severity = db.Column(db.String(20), nullable=False, default='medium')  # 'low', 'medium', 'high', 'critical'
    enabled = db.Column(db.Boolean, nullable=False, default=True)
    
    # Auto-actions
    create_trigger_event = db.Column(db.Boolean, nullable=False, default=True)  # Create a trigger event when alert fires
    trigger_event_importance = db.Column(db.Integer, nullable=False, default=3)  # Importance level for trigger events
    
    # Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_triggered_at = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    preset = relationship("StrategyPreset", backref=db.backref("alert_rules", cascade="all, delete-orphan"))
    alert_logs = relationship("PerformanceAlertLog", back_populates="alert_rule", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<PerformanceAlertRule {self.id} {self.preset_id} {self.metric} {self.condition} {self.threshold}>"
    
    def to_dict(self):
        """Convert alert rule to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'preset_id': self.preset_id,
            'name': self.name,
            'description': self.description,
            'metric': self.metric,
            'condition': self.condition,
            'threshold': self.threshold,
            'comparison_window': self.comparison_window,
            'timeframe': self.timeframe,
            'consecutive_triggers': self.consecutive_triggers,
            'cool_down_minutes': self.cool_down_minutes,
            'severity': self.severity,
            'enabled': self.enabled,
            'create_trigger_event': self.create_trigger_event,
            'trigger_event_importance': self.trigger_event_importance,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'last_triggered_at': self.last_triggered_at.isoformat() if self.last_triggered_at else None
        }


class PerformanceAlertLog(db.Model):
    """Model for storing triggered performance alerts"""
    __tablename__ = 'performance_alert_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    alert_rule_id = db.Column(db.Integer, ForeignKey('performance_alert_rules.id', ondelete='CASCADE'), nullable=False)
    timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    
    # Alert context
    metric_value = db.Column(db.Float, nullable=False)  # Actual value of the metric when triggered
    threshold_value = db.Column(db.Float, nullable=False)  # Threshold value at time of triggering
    
    # Additional context
    details = db.Column(db.Text, nullable=True)  # Additional details about the alert
    status = db.Column(db.String(20), nullable=False, default='new')  # 'new', 'acknowledged', 'resolved'
    acknowledged_at = db.Column(db.DateTime, nullable=True)
    resolved_at = db.Column(db.DateTime, nullable=True)
    
    # References
    trigger_event_id = db.Column(db.Integer, ForeignKey('preset_trigger_events.id', ondelete='SET NULL'), nullable=True)
    
    # Relationships
    alert_rule = relationship("PerformanceAlertRule", back_populates="alert_logs")
    
    def __repr__(self):
        return f"<PerformanceAlertLog {self.id} {self.alert_rule_id} {self.timestamp}>"
    
    def to_dict(self):
        """Convert alert log to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'alert_rule_id': self.alert_rule_id,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'metric_value': self.metric_value,
            'threshold_value': self.threshold_value,
            'details': self.details,
            'status': self.status,
            'acknowledged_at': self.acknowledged_at.isoformat() if self.acknowledged_at else None,
            'resolved_at': self.resolved_at.isoformat() if self.resolved_at else None,
            'trigger_event_id': self.trigger_event_id
        }


class AllocationPreset(db.Model):
    """Model for storing strategy allocation weight presets from the simulator"""
    __tablename__ = 'allocation_presets'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    description = db.Column(db.Text, nullable=True)
    
    # Weight data
    weights = db.Column(db.JSON, nullable=False)  # Dictionary mapping strategy names to weights
    
    # Reference to original data for recreating simulation
    equity_curve_data = db.Column(db.JSON, nullable=True)  # Combined equity curve data points
    
    # Performance metrics
    total_return = db.Column(db.Float, nullable=True)
    sharpe_ratio = db.Column(db.Float, nullable=True)
    max_drawdown = db.Column(db.Float, nullable=True)
    volatility = db.Column(db.Float, nullable=True)
    
    # Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_favorite = db.Column(db.Boolean, default=False)
    last_applied_at = db.Column(db.DateTime, nullable=True)  # When last applied to live trading
    
    # Settings
    tags = db.Column(db.String(200), nullable=True)  # Comma-separated tags
    
    # Relationship
    schedules = relationship("AllocationSchedule", back_populates="preset", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<AllocationPreset {self.name}>"
    
    def to_dict(self):
        """Convert preset to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'weights': self.weights,
            'equity_curve_data': self.equity_curve_data,
            'total_return': self.total_return,
            'sharpe_ratio': self.sharpe_ratio,
            'max_drawdown': self.max_drawdown,
            'volatility': self.volatility,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'is_favorite': self.is_favorite,
            'last_applied_at': self.last_applied_at.isoformat() if self.last_applied_at else None,
            'tags': self.tags.split(',') if self.tags else []
        }
    
    @classmethod
    def from_dict(cls, data):
        """Create an allocation preset from dictionary data"""
        tags = ','.join(data.get('tags', [])) if data.get('tags') else None
        
        return cls(
            name=data.get('name'),
            description=data.get('description'),
            weights=data.get('weights'),
            equity_curve_data=data.get('equity_curve_data'),
            total_return=data.get('total_return'),
            sharpe_ratio=data.get('sharpe_ratio'),
            max_drawdown=data.get('max_drawdown'),
            volatility=data.get('volatility'),
            is_favorite=data.get('is_favorite', False),
            last_applied_at=datetime.fromisoformat(data.get('last_applied_at')) if data.get('last_applied_at') else None,
            tags=tags
        )


class AllocationSchedule(db.Model):
    """Model for scheduling future allocation preset activations"""
    __tablename__ = 'allocation_schedules'
    
    id = db.Column(db.Integer, primary_key=True)
    preset_id = db.Column(db.Integer, ForeignKey('allocation_presets.id', ondelete='CASCADE'), nullable=False)
    scheduled_time = db.Column(db.DateTime, nullable=False)
    
    # Status tracking
    is_active = db.Column(db.Boolean, default=True)  # Whether this schedule is active
    is_executed = db.Column(db.Boolean, default=False)  # Whether it has been executed
    execution_time = db.Column(db.DateTime, nullable=True)  # When it was actually executed
    execution_status = db.Column(db.String(50), nullable=True)  # 'success', 'failed', 'cancelled'
    execution_note = db.Column(db.Text, nullable=True)  # Additional information about execution
    
    # Optional notification settings
    notify_before_minutes = db.Column(db.Integer, nullable=True)  # Minutes before to send notification
    notification_sent = db.Column(db.Boolean, default=False)  # Whether notification was sent
    
    # Safe mode preview
    preview_mode = db.Column(db.Boolean, default=False)  # Whether to run in preview mode (no actual changes)
    
    # Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.String(100), nullable=True)  # User or system component that created the schedule
    
    # Relationships
    preset = relationship("AllocationPreset", back_populates="schedules")
    
    def __repr__(self):
        status = "Executed" if self.is_executed else "Pending" if self.is_active else "Cancelled"
        return f"<AllocationSchedule {self.id} {self.preset.name if self.preset else 'Unknown'} {self.scheduled_time} {status}>"
    
    def to_dict(self):
        """Convert schedule to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'preset_id': self.preset_id,
            'preset_name': self.preset.name if self.preset else "Unknown",
            'scheduled_time': self.scheduled_time.isoformat() if self.scheduled_time else None,
            'is_active': self.is_active,
            'is_executed': self.is_executed,
            'execution_time': self.execution_time.isoformat() if self.execution_time else None,
            'execution_status': self.execution_status,
            'execution_note': self.execution_note,
            'notify_before_minutes': self.notify_before_minutes,
            'notification_sent': self.notification_sent,
            'preview_mode': self.preview_mode,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'time_remaining': self._get_time_remaining()
        }
    
    def _get_time_remaining(self):
        """Get the time remaining until scheduled activation"""
        if self.is_executed or not self.is_active:
            return None
            
        now = datetime.utcnow()
        if now >= self.scheduled_time:
            return "Due now"
            
        delta = self.scheduled_time - now
        days = delta.days
        hours, remainder = divmod(delta.seconds, 3600)
        minutes, _ = divmod(remainder, 60)
        
        if days > 0:
            return f"{days}d {hours}h {minutes}m"
        elif hours > 0:
            return f"{hours}h {minutes}m"
        else:
            return f"{minutes}m"
    
    @classmethod
    def from_dict(cls, data):
        """Create a schedule from dictionary data"""
        scheduled_time = datetime.fromisoformat(data.get('scheduled_time')) if data.get('scheduled_time') else None
        
        return cls(
            preset_id=data.get('preset_id'),
            scheduled_time=scheduled_time,
            is_active=data.get('is_active', True),
            notify_before_minutes=data.get('notify_before_minutes'),
            preview_mode=data.get('preview_mode', False),
            created_by=data.get('created_by')
        )


class StrategyAttribution(db.Model):
    """Model for storing continuous strategy periods for attribution on equity charts"""
    __tablename__ = 'strategy_attributions'
    
    id = db.Column(db.Integer, primary_key=True)
    preset_id = db.Column(db.Integer, ForeignKey('strategy_presets.id', ondelete='CASCADE'), nullable=False)
    
    # Time period
    start_time = db.Column(db.DateTime, nullable=False)
    end_time = db.Column(db.DateTime, nullable=True)  # Null means ongoing
    
    # Strategy details
    strategy_name = db.Column(db.String(100), nullable=False)  # Display name of the strategy
    strategy_id = db.Column(db.String(50), nullable=True)  # Internal ID/key if applicable
    
    # Visual representation
    color = db.Column(db.String(20), nullable=True)  # CSS color for the attribution block
    display_name = db.Column(db.String(100), nullable=True)  # Optional custom display name
    
    # Performance metrics for this period
    performance_data = db.Column(db.JSON, nullable=True)  # Optional performance data for this specific period
    
    # Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text, nullable=True)
    
    # Relationships
    preset = relationship("StrategyPreset", backref=db.backref("strategy_attributions", cascade="all, delete-orphan"))
    
    def __repr__(self):
        return f"<StrategyAttribution {self.preset_id} {self.strategy_name} {self.start_time} to {self.end_time or 'now'}>"
    
    def to_dict(self):
        """Convert strategy attribution to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'preset_id': self.preset_id,
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'strategy_name': self.strategy_name,
            'strategy_id': self.strategy_id,
            'color': self.color,
            'display_name': self.display_name or self.strategy_name,
            'performance_data': self.performance_data,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'notes': self.notes
        }


class SystemActionLog(db.Model):
    """Model for logging system actions and their results"""
    __tablename__ = 'system_action_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    
    # Action metadata
    action_type = db.Column(db.String(100), nullable=False)  # e.g., 'apply_ai_recommendation', 'manual_weight_change', etc.
    
    # Action details stored as JSON
    details = db.Column(db.JSON, nullable=True)  # Contains action-specific data
    
    # Result information
    status = db.Column(db.String(20), nullable=False, default='success')  # 'success', 'failed', 'pending'
    message = db.Column(db.Text, nullable=True)  # Descriptive message about the action
    error_details = db.Column(db.Text, nullable=True)  # Details about any errors that occurred
    
    # Context information
    ip_address = db.Column(db.String(45), nullable=True)  # Source IP address
    user_agent = db.Column(db.String(255), nullable=True)  # User agent string
    source = db.Column(db.String(50), nullable=True)  # 'web', 'api', 'system', etc.
    
    def __repr__(self):
        return f"<SystemActionLog {self.id} {self.action_type} {self.status}>"
    
    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'action_type': self.action_type,
            'details': self.details,
            'status': self.status,
            'message': self.message,
            'error_details': self.error_details,
            'ip_address': self.ip_address,
            'user_agent': self.user_agent,
            'source': self.source
        }